			<footer class="main-footer">
				<div class="pull-right hidden-xs">
				  <b>Version</b> 1.0
				</div>
				<strong>Copyright &copy; <?php echo date("Y"); ?> <a href="http://openhotelier.com">Openhotelier Inc.</a></strong> All rights reserved.
			</footer>
		</div>
		<!-- jQuery UI 1.11.4 -->
		<script src="https://code.jquery.com/ui/1.11.4/jquery-ui.min.js"></script>
		<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
		<script>
		  $.widget.bridge('uibutton', $.ui.button);
		</script>
		<script src="<?php echo BASE_URL; ?>js/custom.js"></script>
		<!-- Bootstrap 3.3.6 -->
		<script src="<?php echo BASE_URL.'theme/'.THEME_NAME.'/'; ?>bootstrap/js/bootstrap.min.js"></script>
		<script src="<?php echo BASE_URL.'theme/'.THEME_NAME.'/'; ?>plugins/select2/select2.full.min.js"></script>

		<!-- datepicker -->
		<script src="<?php echo BASE_URL.'theme/'.THEME_NAME.'/'; ?>plugins/datepicker/bootstrap-datepicker.js"></script>

		<!-- Slimscroll -->
		<script src="<?php echo BASE_URL.'theme/'.THEME_NAME.'/'; ?>plugins/slimScroll/jquery.slimscroll.min.js"></script>
		<!-- FastClick -->
		<!-- AdminLTE App -->
		<script src="<?php echo BASE_URL.'theme/'.THEME_NAME.'/'; ?>dist/js/app.min.js"></script>
		<!-- AdminLTE for demo purposes -->
		<script src="<?php echo BASE_URL.'theme/'.THEME_NAME.'/'; ?>dist/js/demo.js"></script>
		<script src="<?php echo BASE_URL.'theme/'.THEME_NAME.'/'; ?>plugins/touch-spin/jquery.bootstrap-touchspin.js"></script>
		<script src="<?php echo BASE_URL.'theme/'.THEME_NAME.'/'; ?>plugins/jquery-validation/jquery.validate.js"></script>
		<script src="<?php echo BASE_URL.'theme/'.THEME_NAME.'/'; ?>plugins/jquery-validation/additional-methods.js"></script>
		<script>
		  $(function () {
			//Initialize Select2 Elements
			$(".select2").select2();
			$('.datepicker').datepicker({
				startDate:new Date(),
				format: "yyyy-mm-dd",
				autoclose: true
			});
		  });
		</script>
	</body>
</html>