<div class="col-md-12" id="room<?php echo $r; ?>">
	<div class="form-group">
		<label class="col-md-2 control-label">Room <?php echo $r; ?></label>
		<div class="col-md-3">
			<input type="text" class="form-control room-adult" readonly name="<?php echo 'r'.$r.'adults'; ?>" value="2" rel="<?php echo $r; ?>">
		</div>
		<div class="col-md-3">
			<input type="text" class="form-control room-child" readonly name="<?php echo 'r'.$r.'child'; ?>" value="0" rel="<?php echo $r; ?>">
		</div>
		<div class="col-md-3">
			<input type="text" class="form-control room-infant" readonly name="<?php echo 'r'.$r.'infant'; ?>" value="0" rel="<?php echo $r; ?>">
		</div>
	</div>
</div>
<div class="col-md-12">
	<div class="booking-room-note">
		Note: Date of birth is required for children and infants.
	</div>
</div>
<?php for($p=1;$p<=4;$p++){?>
	<div class="guest-drop col-md-12 <?php echo ($p>2) ? 'display-none' : ''; ?>" id="room<?php echo $r.$p; ?>">
		<div class="form-group">
			<label class="col-md-2 control-label"></label>
			<div class="col-md-1">
				<select class="form-control <?php echo ($r == 1 && $p == 1) ? 'required' : 'required'; ?>" name="<?php echo 'r'.$r.'in'.$p;?>">
					<option value=''></option>
					<option>MR.</option>
					<option>MRS.</option>
					<option>MS.</option>
					<option>DR.</option>
				</select>
			</div>
			<div class="col-md-3">
				<input type="text" class="form-control <?php echo ($r == 1 && $p == 1) ? 'required' : 'required'; ?>" name="<?php echo 'r'.$r.'f'.$p;?>" placeholder="First Name">
			</div>
			<div class="col-md-3">
				<input type="text" class="form-control <?php echo ($r == 1 && $p == 1) ? 'required' : 'required'; ?>" name="<?php echo 'r'.$r.'l'.$p;?>" placeholder="Last Name">
			</div>
			<div class="col-md-2 input-group date child-infant display-none">
				<div class="input-group-addon">
					<i class="fa fa-calendar"></i>
				</div>	
				<input type="text" class="form-control child-infant-age dob-datepicker required" name="<?php echo 'r'.$r.'dob'.$p;?>" placeholder="Date of Birth">
			</div>
		</div>
	</div>
<?php }?>