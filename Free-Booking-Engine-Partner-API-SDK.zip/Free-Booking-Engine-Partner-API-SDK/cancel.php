<?php
$pageTitle = "Cancel Booking";
include("includes/header.php");
$booking_id = $_GET['booking_id'];
if(isset($_POST['cancel_booking'])){
	$cancelResponse = $dataQuery->bookingCancel($booking_id, $_POST['cancellation_reason']);
	if(isset($bookingResponse->success) && $bookingResponse->success == 1){
		unset($_SESSION['search_key']);
		header('Location:view.php?booking_id='.$bookingResponse->booking_id);
	}else{
		header('Location:booking.php');
	}
}
$bookingDetail = $dataQuery->getBookingDetailByBookingId($booking_id);
if(empty($bookingDetail)){
	header("Location:".BASE_URL);
}
$countryName = $dataQuery->dbSelectFirst("oh_country_city", "cnt_name", "cnt_code='".$bookingDetail['country_passport']."'");
?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Booking
        <small>Cancel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Availability</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Main row -->
      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title">Booking Cancel</h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <div class="row">
			<div class="col-md-6">
				<div class="well bg-yellow text-cap-center">
					Booking ID: <?php echo $bookingDetail['booking_id']; ?>
				</div>
			</div>
			<div class="col-md-6">
				<div class="well bg-light-blue text-cap-center">
					Booking Status: <?php echo $bookingDetail['booking_status']; ?>
				</div>
			</div>
			<form class="form-horizontal" method="POST" id="validate-cancel-form">
				<div class="col-md-offset-2 col-md-6">
					<h3 class="text-center">
						<?php echo $bookingDetail['booking_id']; ?> - Reason for Cancellation.
					</h3>
				</div>
				<div class="col-md-12">
					<div class="form-group">
						<label class="col-md-4 control-label">Property:</label>
						<div class="col-md-8 display-booking-val">
							<?php echo $bookingDetail['property_name']; ?>
						</div>
					</div>
				</div>
				<div class="col-md-12">
					<div class="form-group">
						<label class="col-md-4 control-label">Check In Date:</label>
						<div class="col-md-8 display-booking-val">
							<?php echo date("D, d M Y", strtotime($bookingDetail['check_in_date'])); ?>
						</div>
					</div>
				</div>
				<div class="col-md-12">
					<div class="form-group">
						<label class="col-md-4 control-label">Room Type:</label>
						<div class="col-md-8 display-booking-val">
							<?php echo $bookingDetail['room_type']; ?>
						</div>
					</div>
				</div>
				<div class="col-md-12">
					<div class="form-group">
						<label class="col-md-4 control-label">Release:</label>
						<div class="col-md-8 display-booking-val">
							10 days (Booking already with in release)
						</div>
					</div>
				</div>
				<div class="col-md-12">
					<div class="form-group">
						<label class="col-md-4 control-label">Reason:</label>
						<div class="col-md-6">
							<textarea class="form-control required" name="cancellation_reason" placeholder="Enter cancellation reason."></textarea>
						</div>
						<div class="col-md-offset-4 col-md-6">*Note: This note / reason will appear on the email notification and on the booking history.</div>
					</div>
				</div>
				<div class="col-md-offset-4 col-md-6">
					<div class="form-group">
						<h4>Cancellation and No-Show policy.</h4>
						<div class="box box-success">
							<div class="box-header">
								<h3 class="box-title">Cancellation & last minute amendments</h3>
							</div>
							<div class="box-body chat" id="cancelation-policy">
								<div class="item">
									<p>Cancellations and amendments of dates and names after release period, apart from departure date extension will be considered as a cancellation and charged as per our cancellation policy below. &gt;Release (in days) for each rate period and each room category is given along with the room rates.</p>
									<ul>
										<li>After the release period and 14 days before arrival date: 50% of the total nights per room</li>
										<li>Less than 14 days to arrival date: 100% of the total nights per room</li>
									</ul>
									<h4>No-show Charges</h4>
									Cancellation notification 3 days prior to arrival will be considered as NO SHOW
									<ul>
										<li>100% of the total nights per room and one way transfer charges</li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-offset-4 col-md-6">
					<div class="form-group">
						<div class="checkbox">
							<label>
								<input type="checkbox" class="required" name="agree"> I have read and agree with the cancellation policy.
							</label>
						</div>
					</div>
				</div>
				<div class="col-md-10">
					<div class="form-group pull-right margin-right-0">
						<a href="<?php echo BASE_URL.'view.php?booking_id='.$booking_id; ?>" class="btn btn-info" name="booking">Abort</a>
						<button class="btn btn-info" name="cancel_booking">Submit</button>
					</div>
					<!-- /.form-group -->
				</div>
				<!-- /.col -->
			</form>
          </div>
          <!-- /.row -->
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
      <!-- /.row (main row) -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<script>
$(function(){
	$("#validate-cancel-form").validate({
        errorPlacement: function() {
            return false;
        }
	});
	
	$('#cancelation-policy').slimScroll({
		height: '150px'
	});
});
</script>
<?php
include("includes/footer.php");
?>