<?php
include('db_config.php');
$dataQuery = new dbConfig();
$whatToDo = $_POST['whattodo'];
switch($whatToDo){
	case "get_city":
		$country_code = $_POST['country_code'];
		$cities = $dataQuery->getCity($country_code);
		$city_options = "<option value=''>All Cities</option>";
		foreach($cities AS $city){
			$city_options .= "<option value=$city[city_code]>$city[city_name]</option>";
		}
		echo $city_options;
	break;
	
	case "update_property":
		$country_code = $_POST['country_code'];
		$city_code = $_POST['city_code'];
		$properties = $dataQuery->getProperty($country_code, $city_code, 1);
		
		$property_options = "";
		foreach($properties AS $property){
			$property_options .= "<option value=$property[id]>$property[property_name]</option>";
		}
		echo $property_options;
	break;
	
	case "search_availability":
		$search_availability = $dataQuery->searchAvailability($_POST);
		$properties = array();
		if(empty($search_availability)){
			$properties['error'] = "No result found.";
			$properties = (Object)$properties;
		} else if(isset($search_availability->error)){
			$properties = $search_availability;
		} else{
			$_SESSION['search_key'] = $_POST;
			$properties = isset($search_availability->properties) ? $search_availability->properties : array();
			$properties = (count($properties->property) > 1) ? $properties->property : $properties;
		}
		include('includes/property_block.php');
		die;
	break;
	
	case "booking_session_set":
		$booking_data = explode("|", $_POST['booking_data']);		
		$_SESSION['search_key']['booking_property'] = $booking_data[0]; 
		$_SESSION['search_key']['room_category'] = $booking_data[1]; 
		$_SESSION['search_key']['room_type'] = $booking_data[2];
		$room_hold = $dataQuery->roomHold();
		$_SESSION['search_key']['hold_time'] = date("Y-m-d H:i:s");
		if($room_hold->status == 1){
			$_SESSION['search_key']['room_hold_token'] = $room_hold->room_hold_token;
		}
	break;
	
	case "changeNoOfRooms":
		$previous_rooms = $_POST['previous_rooms']+1;
		$new_rooms = $_POST['new_rooms'];
		for($r = $previous_rooms; $r<=$new_rooms; $r++){
			include('includes/booking_rooms_append.php');
		}
		die;
	break;
	
	case "dashboard_graph":
		$cols = array();
		$col['id'] = "";
		$col['label'] = "Months";
		$col['pattern'] = "";
		$col['type'] = "string";
		array_push($cols, $col);
		
		$col['id'] = "";
		$col['label'] = "Success";
		$col['pattern'] = "";
		$col['type'] = "number";
		array_push($cols, $col);
		
		$col['id'] = "";
		$col['label'] = "Failure";
		$col['pattern'] = "";
		$col['type'] = "number";
		array_push($cols, $col);
		$rows = array();
		
		for($i=1;$i<=date('m');$i++){
			$month = str_pad($i, 2, 0, STR_PAD_LEFT);
			$monthSearch = $dataQuery->graphRowsData($month);
			array_push($rows, $monthSearch);
		}

		$dataArr['cols'] = $cols;
		$dataArr['rows'] = $rows;
		echo json_encode($dataArr);
	break;
}
?>