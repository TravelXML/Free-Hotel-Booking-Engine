<?php
session_start();
class dbConfig {
	function __construct(){
		$config = parse_ini_file("includes/config.ini");
		// Check all configuration settings are correct
		$flag = 0;
		if(!empty($config)){
			foreach($config AS $key=>$val){
				if($key != 'PASSWORD' && $key != 'LOGO' && $config[$key] == ""){
					$flag = 1;
					break;
				}
			}
		}else{
			$flag = 1;
		}
		
		if($flag == 1){
			header("Location:settings.php");
			die;
		}

		$this->hostname = $config['HOSTNAME'];
		$this->username = $config['USERNAME'];
		$this->password = $config['PASSWORD'];
		$this->dbname = $config['DBNAME'];
		$this->endpoint = $config['ENDPOINT'];
		$this->apikey = $config['APIKEY'];
		$this->showPrice = $config['SHOW_PRICE'];
		$this->partner_id = $config['PARTNER_ID'];
		$this->agencyTitle = $config['AGENCY_TITLE'];
		$this->baseUrl = $config['BASE_URL'];
		$this->themeName = $config['THEME_NAME'];
		
		// Meal Plan Array
		$this->mealPlanCode = array('1' => 'RO', '2' => 'BB', '3' => 'HB', '4' => 'FB', '5' => 'AI');
		$this->mealPlan = array('1' => 'Room Only', '2' => 'Bed n Breakfast', '3' => 'Half Board', '4' => 'Full Board', '5' => 'All Inclusive');

		// Transfer Code Array
		$this->transferCode = array('1' => 'Speed  Boat', '2' => 'Sea Plane', '3' => 'Motor Boat', '4' => 'Mini Couch', '5' => 'Car', '6' => 'Couch', '7' => 'Private Limousine', '8' => 'Private Stretch Limousine', '10' => 'Large Couch', '11' => 'In House', '12' => 'Helicopter', '13' => 'Domestic Flight', '14' => 'Fast Motor Boat', '99' => 'Not Required');

		// Meal Plan Array
		$this->bookingStatus = array('0' => 'Waiting', '1' => 'Confirmed', '2' => 'Cancelled By Property', '22' => 'Cancelled By Partner');
		$this->conn = mysqli_connect($this->hostname, $this->username, $this->password, $this->dbname);
	}
	
	function sendRequest($requestData){
		$curl = curl_init($this->endpoint); 
		curl_setopt($curl, CURLOPT_HEADER, false); 
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true); 
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false); 
		curl_setopt($curl, CURLOPT_HTTPHEADER, array( 
			"Content-type: application/json", 
			"APIKEY: ".$this->apikey 
		)); 
		curl_setopt($curl, CURLOPT_POST, true); 
		curl_setopt($curl, CURLOPT_POSTFIELDS, $requestData); 
		$JsonResponse = curl_exec($curl); 
		
		// Check if any error occurred 
		if (curl_errno($curl)) { 
			echo 'Curl error: ' . curl_error($curl); 
		} 
		curl_close($curl);
		$this->createRequestHistory($requestData, $JsonResponse);
		return $JsonResponse;
	}
	
	function createRequestHistory($requestData, $JsonResponse){
		$request = json_decode($requestData);
		$response = json_decode($JsonResponse);
		switch($request->action){
			case 1:
				$message = "Availability By Property All Room Types:<br/>PropertyId: ".$request->property_id.", Room Type: All";
			break;
			
			case 2:
				$message = "Availability By Property - Single Room Type:<br/>PropertyId: ".$request->property_id.", Room Type: ".$request->room_type;
			break;
			
			case 4:
				$message = "List Of Properties Available By Country:<br/>Country Code: ".$request->country_code.", City Code: ".$request->city_code;
			break;
			
			case 5:
				$message = "List Of Room Types Available For A Property:<br/>PropertyId Code: ".$request->property_id;
			break;
			
			case 10:
				$message = "Room Hold:<br/>PropertyId: ".$request->property_id.", Room Type: ".$request->rooms->room[0]->room_type.", Check In Date: ".$request->check_in_date.", No. of Night(s): ".$request->no_of_nights.", No. of Room(s): ".$request->no_of_rooms;
			break;
			
			case 11:
				$message = "Room Hold Release:<br/>Room Hold Token: ".$request->room_hold_token;
			break;
			
			case 6:
				$message = "Create Booking:<br/>Property Id: ".$request->property_id.", Room Type: ".$request->rooms->room[0]->room_type.", Check In Date: ".$request->check_in_date.", No. of Night(s): ".$request->no_of_nights.", No. of Room(s): ".$request->no_of_rooms;
			break;
			
			case 8:
				$message = "Modify Booking:<br/>Booking Id: ".$request->booking_id.", Room Type: ".$request->rooms->room[0]->room_type.", Check In Date: ".$request->check_in_date.", No. of Night(s): ".$request->no_of_nights.", No. of Room(s): ".$request->no_of_rooms;
			break;
			
			case 9:
				$message = "Cancel Booking:<br/>Booking Id: ".$request->booking_id;
			break;
			
			case 7:
				$message = "Fetch Booking:<br/>Booking Id: ".$request->booking_id;
			break;
			
			default:
				$message = "Undefined request action.";
			break;
		}
		$requestHistory['request_action'] = $request->action;
		$requestHistory['message'] = $message;
		$requestHistory['request_ip'] = $_SERVER['REMOTE_ADDR'];
		$requestHistory['status'] = (isset($response->error_no)) ? 0 : 1;
		$requestHistory['request_json'] = mysqli_real_escape_string($this->conn, json_encode($request));
		$requestHistory['response_json'] = mysqli_real_escape_string($this->conn, json_encode($response));
		$requestHistory['created'] = date("Y-m-d H:i:s");
		$requestHistoryData[] = $requestHistory;
		$this->dbInsert("oh_request_history", $requestHistoryData);
	}
	
	function getProperty($countryCode = 'mv', $cityCode = "", $updateProperty = NULL){
		$condition = " WHERE country_code = '".$countryCode."'";
		if($cityCode != "")
			$condition .= " AND city_code = '".$cityCode."'";
		$condition .= " ORDER BY property_name";
		$query = mysqli_query($this->conn, "SELECT * FROM oh_property".$condition);
		
		if($updateProperty == 1 || mysqli_num_rows($query) <= 0){
			
			//Set Request Data
			$requestData = array(
				"country_code" => $countryCode,
				"city_code" => $cityCode,
				"action" => 4
			);
			
			//Convert Request Data Array to Json String
			$jsonString = json_encode($requestData);
			
			//Send a Request and Get Response
			$jsonResponse = $this->sendRequest($jsonString);
			$response = json_decode($jsonResponse);
			$responseData = array();
			if(isset($response->properties)){
				foreach($response->properties->property AS $key=>$properties){
					$responseData[$key]['id'] = $properties->property_id;
					$responseData[$key]['property_name'] = $properties->property_name;
					$responseData[$key]['country_code'] = $properties->country_code;
					$responseData[$key]['country_name'] = $properties->country_name;
					$responseData[$key]['city_code'] = $properties->city_code;
					$responseData[$key]['city_name'] = $properties->city_name;
					if(isset($properties->available_meal_plans->default_meal_plan_code))
						$responseData[$key]['default_meal_plan_code'] = $properties->available_meal_plans->default_meal_plan_code;
					if(isset($properties->available_transfer_plans->transfer_plan->transfer_plan_code))
						$responseData[$key]['transfer_plan_code'] = $properties->available_transfer_plans->transfer_plan->transfer_plan_code;
					if(isset($properties->details)){
						$responseData[$key]['latitude'] = $properties->details->latitude;
						$responseData[$key]['longitude'] = $properties->details->longitude;
					}
				}
			}
			if(empty($responseData))
				return $responseData;
			
			if($updateProperty != NULL){
				$this->dbUpdate("oh_property", $responseData, "id");
				$condition = " WHERE country_code = '".$countryCode."'";
				if($cityCode != "")
					$condition .= " AND city_code = '".$cityCode."'";
				$condition .= " ORDER BY property_name";
				$query = mysqli_query($this->conn, "SELECT * FROM oh_property".$condition);
				$returnData = array();
				while($result = mysqli_fetch_assoc($query))
					$returnData[] = $result;
				return $returnData;
			}
			else{
				$this->dbInsert("oh_property", $responseData);
				//$this->getProperty($countryCode, $cityCode);
				$condition = " WHERE country_code = '".$countryCode."'";
				if($cityCode != "")
					$condition .= " AND city_code = '".$cityCode."'";
				$condition .= " ORDER BY property_name";
				$query = mysqli_query($this->conn, "SELECT * FROM oh_property".$condition);
				$returnData = array();
				while($result = mysqli_fetch_assoc($query)){
					$returnData[] = $result;
				}
				return $returnData;
			}
		}else{
			$returnData = array();
			while($result = mysqli_fetch_assoc($query))
				$returnData[] = $result;
			return $returnData;
		}
	}
	
	function searchAvailability($searchData){
		$property_ids = implode(",", $searchData['property_id']);
		$check_in_date = $searchData['check_in_date'];
		$no_of_nights = $searchData['no_of_nights'];
		$no_of_rooms = $searchData['no_of_rooms'];
		//Set Request Data
		
		$requestData = array(
			"property_id" => $property_ids,
			"check_in_date" => $check_in_date,
			"no_of_nights" => $no_of_nights,
			"no_of_rooms" => $no_of_rooms,
			"rate" => "1",
			"arrival_transfer" => "",
			"departure_transfer" => "",
			"meal_plan" => "",
			"action" => "1"
		);
		
		//Convert Request Data Array to Json String
		$jsonString = json_encode($requestData);
		
		//Send a Request and Get Response
		$jsonResponse = $this->sendRequest($jsonString);
		$response = json_decode($jsonResponse);
		return $response;
	}
	
	function bookingRequest($bookingData){
		$rooms = $bookingData['no_of_rooms'];
		$roomsArr = array();
		for($r = 1; $r <= $rooms; $r++){
			$adult = $bookingData['r'.$r.'adults'];
			$child = $bookingData['r'.$r.'child'];
			$infant = $bookingData['r'.$r.'infant'];
			$totalGuest = $adult+$child+$infant;

			$guests = array();
			$adultArr = $childArr = $infantArr = array();
			for($p = 1; $p <= $totalGuest; $p++){
				if($p <= $adult){
					$persons = array();
					$persons['initial_name'] = $bookingData['r'.$r.'in'.$p];
					$persons['first_name'] = $bookingData['r'.$r.'f'.$p];
					$persons['last_name'] = $bookingData['r'.$r.'l'.$p];
					$persons['nation'] = $bookingData['country_passport'];
					if($adult > 1)
						array_push($adultArr, $persons);
					else
						$adultArr = $persons;
				}
				
				if($p > $adult && $p <= ($adult+$child)){
					$persons = array();
					$persons['initial_name'] = $bookingData['r'.$r.'in'.$p];
					$persons['first_name'] = $bookingData['r'.$r.'f'.$p];
					$persons['last_name'] = $bookingData['r'.$r.'l'.$p];
					$persons['nation'] = $bookingData['country_passport'];
					$persons['age_or_dob'] = $bookingData['r'.$r.'dob'.$p];
					if($child > 1)
						array_push($childArr, $persons);
					else
						$childArr = $persons;
				}
				
				if($p > ($adult+$child) && $p <= ($infant+$adult+$child)){
					$persons = array();
					$persons['initial_name'] = $bookingData['r'.$r.'in'.$p];
					$persons['first_name'] = $bookingData['r'.$r.'f'.$p];
					$persons['last_name'] = $bookingData['r'.$r.'l'.$p];
					$persons['nation'] = $bookingData['country_passport'];
					$persons['age_or_dob'] = $bookingData['r'.$r.'dob'.$p];
					if($infant > 1)
						array_push($infantArr, $persons);
					else
						$infantArr = $persons;
				}
			}
			if(!empty($adultArr))
				$guests['adult'] = $adultArr;
			if(!empty($childArr))
				$guests['child'] = $childArr;
			if(!empty($infantArr))
				$guests['infant'] = $infantArr;
			
			$room = array();
			$room['room_type'] = $bookingData['room_type_code'];
			$room['meal_type_code'] = $bookingData['meal_type_code'];
			$room['room_note'] = '';
			$room['late_check_out_time'] = ($bookingData['late_check_out'] == 1) ? $bookingData['late_check_out_time'] : 0;
			$room['no_of_adult'] = $adult;
			$room['no_of_child'] = $child;
			$room['no_of_infant'] = $infant;
			$room['guests'] = $guests;
			array_push($roomsArr, $room);
		}
		$roomsDetail['room'] = $roomsArr;
		$booking['property_id'] = $bookingData['property_id'];
		$booking['check_in_date'] = $bookingData['check_in_date'];
		$booking['no_of_rooms'] = $bookingData['no_of_rooms'];
		$booking['no_of_nights'] = $bookingData['no_of_nights'];
		$booking['partner_allot'] = $bookingData['partner_allot'];
		$booking['comments'] = $bookingData['comments'];
		$booking['transfer_code_arrival'] = $bookingData['transfer_code_arrival'];
		$booking['transfer_code_departure'] = $bookingData['transfer_code_departure'];
		$booking['arrival_flight_details'] = $bookingData['arrival_flight_details'];
		$booking['departure_flight_details'] = $bookingData['departure_flight_details'];
		$booking['airport_handling'] = $bookingData['airport_handling'];
		$booking['buyer_reference'] = $this->partner_id;
		$booking['t_user'] = '';
		$booking['action'] = 6;
		$booking['rooms'] = $roomsDetail;

		//Convert Request Data Array to Json String
		$jsonString = json_encode($booking);
		
		//Send a Request and Get Response
		$jsonResponse = $this->sendRequest($jsonString);
		$response = json_decode($jsonResponse);
		if(isset($response->success) && $response->success == 1){
			$this->createBooking($response, $roomsArr, $bookingData);
		}
		return $response;
	}
	
	function createBooking($response, $roomsArr, $bookingData){
		// Create json for booking_details table field room_guest_detail
		$roomGuestDetail = array();
		foreach($roomsArr AS $rooms){
			unset($rooms['room_type']);
			unset($rooms['meal_type_code']);
			unset($rooms['room_note']);
			unset($rooms['late_check_out_time']);
			array_push($roomGuestDetail, $rooms);
		}
		$roomGuestDetailJson = json_encode($roomGuestDetail);
		// End

		// Calculation for total number of adult, child and infant
		$total_adult = 0;
		$total_child = 0;
		$total_infant = 0;
		for($i=1;$i<=$bookingData['no_of_rooms'];$i++){
			$total_adult += $bookingData['r'.$i.'adults'];
			$total_child += $bookingData['r'.$i.'child'];
			$total_infant += $bookingData['r'.$i.'infant'];
		}
		// End
		
		$bookingDetail['booking_id'] = $response->booking_id;
		$bookingDetail['property_id'] = $bookingData['property_id'];
		$bookingDetail['booking_status'] = $this->bookingStatus[$response->booking_status_code];
		$bookingDetail['property_guest_name'] = $bookingData['r1in1'].' '.$bookingData['r1f1'].' '.$bookingData['r1l1'];
		$bookingDetail['room_type_code'] = $bookingData['room_type_code'];
		$bookingDetail['room_type'] = $bookingData['room_type'];
		$bookingDetail['no_of_nights'] = $bookingData['no_of_nights'];
		$bookingDetail['check_in_date'] = $bookingData['check_in_date'];
		$bookingDetail['check_out_date'] = date("Y-m-d", strtotime("+".$bookingData['no_of_nights']." days", strtotime($bookingData['check_in_date'])));
		$bookingDetail['no_of_rooms'] = $bookingData['no_of_rooms'];
		$bookingDetail['buyer_ref'] = $this->partner_id;
		$bookingDetail['meal_type_code'] = $bookingData['meal_type_code'];
		$bookingDetail['country_passport'] = $bookingData['country_passport'];
		$bookingDetail['arrival_flight_info'] = $bookingData['arrival_flight_details'];
		$bookingDetail['departure_flight_info'] = $bookingData['departure_flight_details'];
		$bookingDetail['arrival_transfer'] = $bookingData['transfer_code_arrival'];
		$bookingDetail['departure_transfer'] = $bookingData['transfer_code_departure'];
		$bookingDetail['airport_handling'] = $bookingData['airport_handling'];
		$bookingDetail['late_check_out_time'] = ($bookingData['late_check_out'] != 0) ? $bookingData['late_check_out_time'] : 0;
		$bookingDetail['total_adult'] = $total_adult;
		$bookingDetail['total_child'] = $total_child;
		$bookingDetail['total_infant'] = $total_infant;
		$bookingDetail['comments'] = $bookingData['comments'];
		$bookingDetail['created'] = date("Y-m-d H:i:s");
		$bookingDetail['room_guest_detail'] = $roomGuestDetailJson;
		$bookingDetails[] = $bookingDetail;
		$this->dbInsert("oh_booking_details", $bookingDetails);
		$this->dbInsert("oh_booking_details_history", $bookingDetails);
	}
	
	function amendBookingRequest($booking_id, $bookingData){
		$lastDetail = $this->dbSelectFirst("oh_booking_details", "*", "booking_id='".$booking_id."'");
		$lastDetail['nation'] = $lastDetail['country_passport'];
		$lastDetail['arrival_flight_details'] = $lastDetail['arrival_flight_info'];
		$lastDetail['departure_flight_details'] = $lastDetail['departure_flight_info'];
		$lastDetail['transfer_code_arrival'] = $lastDetail['arrival_transfer'];
		$lastDetail['transfer_code_departure'] = $lastDetail['departure_transfer'];
		$guestDetails = json_decode($lastDetail['room_guest_detail']);
		$unsetFields = array('booking_id', 'buyer_ref', 'country_passport', 'arrival_flight_info', 'departure_flight_info', 'arrival_transfer', 'departure_transfer', 'id', 'property_guest_name', 'booking_status', 'total_adult', 'total_child', 'total_infant', 'room_guest_detail', 'cancelled', 'amend', 'created', 'modified');

		foreach($lastDetail AS $key=>$val){
			if(in_array($key, $unsetFields)){
				unset($lastDetail[$key]);
			}
		}
		
		$count = 0;
		foreach($guestDetails AS $key=>$guest){
			$count++;
			$lastDetail['r'.$count.'adults'] = $guest->no_of_adult;
			$lastDetail['r'.$count.'child'] = $guest->no_of_child;
			$lastDetail['r'.$count.'infant'] = $guest->no_of_infant;
			if(count($guest->guests->adult) == 1)
				$pastAdults[] = $guest->guests->adult;
			else
				$pastAdults = $guest->guests->adult;
			foreach($pastAdults AS $key=>$val){
				$lastDetail['r'.$count.'in'.++$key] = $val->initial_name;
				$lastDetail['r'.$count.'f'.$key] = $val->first_name;
				$lastDetail['r'.$count.'l'.$key] = $val->last_name;
				$lastDetail['r'.$count.'dob'.$key] = isset($val->age_or_dob) ? $val->age_or_dob : '';
			}
		}
		$bookingData['late_check_out_time'] = ($bookingData['late_check_out'] == 1) ? $bookingData['late_check_out_time'] : 0;
		$diffArr1 = array_diff($lastDetail, $bookingData);
		$diffArr2 = array_diff($bookingData, $lastDetail);
		$mergeDiff = array_merge($diffArr1, $diffArr2);

		$rooms = $bookingData['no_of_rooms'];
		$roomsArr = array();
		for($r = 1; $r <= $rooms; $r++){
			$adult = $bookingData['r'.$r.'adults'];
			$child = $bookingData['r'.$r.'child'];
			$infant = $bookingData['r'.$r.'infant'];
			$totalGuest = $adult+$child+$infant;

			$guests = array();
			$adultArr = $childArr = $infantArr = array();
			for($p = 1; $p <= $totalGuest; $p++){
				if($p <= $adult){
					$persons = array();
					$persons['initial_name'] = $bookingData['r'.$r.'in'.$p];
					$persons['first_name'] = $bookingData['r'.$r.'f'.$p];
					$persons['last_name'] = $bookingData['r'.$r.'l'.$p];
					$persons['nation'] = $bookingData['nation'];
					if($adult > 1)
						array_push($adultArr, $persons);
					else
						$adultArr = $persons;
				}
				
				if($p > $adult && $p <= ($adult+$child)){
					$persons = array();
					$persons['initial_name'] = $bookingData['r'.$r.'in'.$p];
					$persons['first_name'] = $bookingData['r'.$r.'f'.$p];
					$persons['last_name'] = $bookingData['r'.$r.'l'.$p];
					$persons['nation'] = $bookingData['nation'];
					$persons['age_or_dob'] = $bookingData['r'.$r.'dob'.$p];
					if($child > 1)
						array_push($childArr, $persons);
					else
						$childArr = $persons;
				}
				
				if($p > ($adult+$child) && $p <= ($infant+$adult+$child)){
					$persons = array();
					$persons['initial_name'] = $bookingData['r'.$r.'in'.$p];
					$persons['first_name'] = $bookingData['r'.$r.'f'.$p];
					$persons['last_name'] = $bookingData['r'.$r.'l'.$p];
					$persons['nation'] = $bookingData['nation'];
					$persons['age_or_dob'] = $bookingData['r'.$r.'dob'.$p];
					if($infant > 1)
						array_push($infantArr, $persons);
					else
						$infantArr = $persons;
				}
			}
			if(!empty($adultArr))
				$guests['adult'] = $adultArr;
			if(!empty($childArr))
				$guests['child'] = $childArr;
			if(!empty($infantArr))
				$guests['infant'] = $infantArr;
			
			$room = array();
			$room['room_type'] = $bookingData['room_type_code'];
			$room['meal_type_code'] = $bookingData['meal_type_code'];
			$room['room_note'] = '';
			$room['late_check_out_time'] = ($bookingData['late_check_out'] == 1) ? $bookingData['late_check_out_time'] : 0;
			$room['no_of_adult'] = $adult;
			$room['no_of_child'] = $child;
			$room['no_of_infant'] = $infant;
			$room['guests'] = $guests;
			array_push($roomsArr, $room);
		}
		$roomsDetail['room'] = $roomsArr;
		$booking['booking_id'] = $booking_id;
		$booking['check_in_date'] = $bookingData['check_in_date'];
		$booking['no_of_rooms'] = $bookingData['no_of_rooms'];
		$booking['no_of_nights'] = $bookingData['no_of_nights'];
		$booking['amend_reason'] = $bookingData['amend_reason'];
		$booking['partner_allot'] = 0;
		$booking['comments'] = $bookingData['comments'];
		$booking['transfer_code_arrival'] = $bookingData['transfer_code_arrival'];
		$booking['transfer_code_departure'] = $bookingData['transfer_code_departure'];
		$booking['arrival_flight_details'] = $bookingData['arrival_flight_details'];
		$booking['departure_flight_details'] = $bookingData['departure_flight_details'];
		$booking['airport_handling'] = $bookingData['airport_handling'];
		$booking['buyer_reference'] = $this->partner_id;
		$booking['t_user'] = '';
		$booking['action'] = 8;
		$booking['rooms'] = $roomsDetail;

		//Convert Request Data Array to Json String
		$jsonString = json_encode($booking);
		//Send a Request and Get Response
		$jsonResponse = $this->sendRequest($jsonString);
		$response = json_decode($jsonResponse);
		if(isset($response->success) && $response->success == 1){
			$bookingData['property_id'] = $lastDetail['property_id'];
			$this->amendBooking($response, $roomsArr, $bookingData);
		}
		return $response;
	}
	
	function amendBooking($response, $roomsArr, $bookingData){
		// Create json for booking_details table field room_guest_detail
		$roomGuestDetail = array();
		foreach($roomsArr AS $rooms){
			unset($rooms['room_type']);
			unset($rooms['meal_type_code']);
			unset($rooms['room_note']);
			unset($rooms['late_check_out_time']);
			array_push($roomGuestDetail, $rooms);
		}
		$roomGuestDetailJson = json_encode($roomGuestDetail);
		// End

		// Calculation for total number of adult, child and infant
		$total_adult = 0;
		$total_child = 0;
		$total_infant = 0;
		for($i=1;$i<=$bookingData['no_of_rooms'];$i++){
			$total_adult += $bookingData['r'.$i.'adults'];
			$total_child += $bookingData['r'.$i.'child'];
			$total_infant += $bookingData['r'.$i.'infant'];
		}
		// End

		$bookingDetail['booking_id'] = $response->booking_id;
		$bookingDetail['property_id'] = $bookingData['property_id'];
		$bookingDetail['booking_status'] = $this->bookingStatus[$response->booking_status_code];
		$bookingDetail['property_guest_name'] = $bookingData['r1in1'].' '.$bookingData['r1f1'].' '.$bookingData['r1l1'];
		$bookingDetail['room_type_code'] = $bookingData['room_type_code'];
		$bookingDetail['room_type'] = $bookingData['room_type'];
		$bookingDetail['no_of_nights'] = $bookingData['no_of_nights'];
		$bookingDetail['check_in_date'] = $bookingData['check_in_date'];
		$bookingDetail['check_out_date'] = date("Y-m-d", strtotime("+".$bookingData['no_of_nights']." days", strtotime($bookingData['check_in_date'])));
		$bookingDetail['no_of_rooms'] = $bookingData['no_of_rooms'];
		$bookingDetail['buyer_ref'] = $this->partner_id;
		$bookingDetail['meal_type_code'] = $bookingData['meal_type_code'];
		$bookingDetail['country_passport'] = $bookingData['nation'];
		$bookingDetail['arrival_flight_info'] = $bookingData['arrival_flight_details'];
		$bookingDetail['departure_flight_info'] = $bookingData['departure_flight_details'];
		$bookingDetail['arrival_transfer'] = $bookingData['transfer_code_arrival'];
		$bookingDetail['departure_transfer'] = $bookingData['transfer_code_departure'];
		$bookingDetail['airport_handling'] = $bookingData['airport_handling'];
		$bookingDetail['late_check_out_time'] = ($bookingData['late_check_out'] != 0) ? $bookingData['late_check_out_time'] : 0;
		$bookingDetail['total_adult'] = $total_adult;
		$bookingDetail['total_child'] = $total_child;
		$bookingDetail['total_infant'] = $total_infant;
		$bookingDetail['comments'] = $bookingData['comments'];
		$bookingDetail['room_guest_detail'] = $roomGuestDetailJson;
		$bookingDetail['amend'] = 1;
		$bookingDetail['amend_reason'] = $bookingData['amend_reason'];
		$bookingDetails[] = $bookingDetail;
		$this->dbUpdate("oh_booking_details", $bookingDetails, "booking_id"); //Table Name, Data Array, Field Match In Where Condition
		$this->dbInsert("oh_booking_details_history", $bookingDetails);
	}
	
	function fetchBookingDetail($booking_id){
		$requestData = array(
						'booking_id' => $booking_id,
						'action' => 7
					);
		//Convert Request Data Array to Json String
		$jsonString = json_encode($requestData);
		
		//Send a Request and Get Response
		$jsonResponse = $this->sendRequest($jsonString);
		$response = json_decode($jsonResponse);
		return $response;
	}
	
	function fetchPropertyDetail($property_id){
		$requestData = array(
						'property_id' => $property_id,
						'action' => 5
					);
		//Convert Request Data Array to Json String
		$jsonString = json_encode($requestData);
		
		//Send a Request and Get Response
		$jsonResponse = $this->sendRequest($jsonString);
		$response = json_decode($jsonResponse);
		return $response;
	}
	
	function bookingCancel($booking_id, $reason){
		$requestData = array(
						'booking_id' => $booking_id,
						'reason' => $reason,
						'action' => 9
					);
		//Convert Request Data Array to Json String
		$jsonString = json_encode($requestData);
		
		//Send a Request and Get Response
		$jsonResponse = $this->sendRequest($jsonString);
		$response = json_decode($jsonResponse);
		return $response;
	}
	
	function roomHold(){
		$rooomType = array();
		$bookingData = $_SESSION['search_key'];
		$holdData['property_id'] = $bookingData['booking_property'];
		$holdData['check_in_date'] = $bookingData['check_in_date'];
		$holdData['no_of_nights'] = $bookingData['no_of_nights'];
		$holdData['no_of_rooms'] = $bookingData['no_of_rooms'];
		for($i = 0; $i < $bookingData['no_of_rooms']; $i++){
			$rooomType[$i]['room_type'] = $bookingData['room_category'];
		}
		$holdData['rooms']['room'] = $rooomType;
		$holdData['action'] = 10;

		//Convert Request Data Array to Json String
		$jsonString = json_encode($holdData);

		//Send a Request and Get Response
		$jsonResponse = $this->sendRequest($jsonString);
		$response = json_decode($jsonResponse);
		return $response;
	}
	
	function roomHoldRelease(){
		$releaseData['room_hold_token'] = $_SESSION['search_key']['room_hold_token'];
		$releaseData['action'] = 11;
		//Convert Request Data Array to Json String
		$jsonString = json_encode($releaseData);

		//Send a Request and Get Response
		$jsonResponse = $this->sendRequest($jsonString);
		$response = json_decode($jsonResponse);
		return $response;
	}
	
	function dbSelectCountry(){
		$country = array();
		$query = mysqli_query($this->conn, "SELECT cnt_code, cnt_name FROM oh_country_city GROUP BY cnt_name ORDER BY cnt_name");
		while($row = mysqli_fetch_assoc($query)){
			$country[] = $row;
		}
		return $country;
	}
	
	function dbInsert($tableName, $insertData){
		foreach($insertData AS $data){
			$keys = array_keys($data);
			$insertKeys = implode(", ", $keys);
			$values = array_values($data);
			$insertValues = "'".implode("','", $values)."'";
			mysqli_query($this->conn, "INSERT INTO ".$tableName."(".$insertKeys.") VALUES(".$insertValues.")");
		}
	}
	
	function dbUpdate($tableName, $updateData, $conditionField){
		foreach($updateData AS $data){
			$conditionValue = $data[$conditionField];
			$updateString = '';
			foreach($data AS $key=>$value){
				if($updateString != '')
					$updateString .= ", ";
				$updateString .= "$key = '$value'";
			}
			mysqli_query($this->conn, "UPDATE ".$tableName." SET ".$updateString." WHERE ".$conditionField."='".$conditionValue."'");
		}
	}
	
	function dbSelectFirst($tableName, $fields, $conditions){
		$dataArray = array();
		$query = mysqli_query($this->conn, "SELECT ".$fields." FROM ".$tableName." WHERE ".$conditions);
		$dataArray = mysqli_fetch_assoc($query);
		return $dataArray;
	}
	
	function dbSelectAll($tableName, $fields='*', $conditions = 1){
		$results = array();
		$query = mysqli_query($this->conn, "SELECT ".$fields." FROM ".$tableName." WHERE ".$conditions);
		while($row = mysqli_fetch_assoc($query)){
			$results[] = $row;
		}
		return $results;
	}

	function getCity($country_code){
		$query = mysqli_query($this->conn, "SELECT * FROM oh_country_city WHERE cnt_code = '".$country_code."' ORDER BY city_name");
		$returnData = array();
		while($result = mysqli_fetch_assoc($query))
			$returnData[] = $result;
		return $returnData;
	}
	
	function showPrice($room_rate, $no_of_nights){
		$rates = array();
		if($no_of_nights > 1){
			foreach($room_rate AS $roomrate){
				array_push($rates, $roomrate->room_rate_double->after_tax);
			}
		}else{
			array_push($rates, $room_rate->room_rate_double->after_tax);
		}
		switch($this->showPrice){
			case 0:
				return reset($rates);
			break;
			
			case 1:
				return end($rates);
			break;
			
			case 2:
				return min($rates);
			break;
			
			case 3:
				return max($rates);
			break;
			
			default:
				return reset($rates);
			break;
		}
	}
	
	function getBookingDetailByBookingId($booking_id){
		$query = mysqli_query($this->conn, "SELECT bd.*, op.property_name FROM `oh_booking_details` AS bd JOIN oh_property op ON op.id = bd.property_id WHERE booking_id = '".$booking_id."'");
		$result = array();
		return mysqli_fetch_assoc($query);
	}
	
	function getActionCount($requestAction = NULL){
		$totalRequestQuery = mysqli_query($this->conn, "SELECT COUNT(*) AS totalRequest FROM oh_request_history WHERE request_action = '".$requestAction."'");
		$totalRequestRows = mysqli_fetch_assoc($totalRequestQuery);
		return $totalRequestRows['totalRequest'];
	}
	
	function graphRowsData($month){
		$yearMonth = date("Y-".$month);
		$successQuery = mysqli_query($this->conn, "SELECT COUNT(*) AS success FROM oh_request_history WHERE status = 1 AND created LIKE '".$yearMonth."%'");
		$failureQuery = mysqli_query($this->conn, "SELECT COUNT(*) AS failure FROM oh_request_history WHERE status = 0 AND created LIKE '".$yearMonth."%'");
		$success = mysqli_fetch_assoc($successQuery);
		$failure = mysqli_fetch_assoc($failureQuery);
		$returnData['c'][]['v'] = date("F", strtotime($yearMonth));
		$returnData['c'][]['v'] = $success['success'];
		$returnData['c'][]['v'] = $failure['failure'];
		return $returnData;
	}
}
?>