<?php
$pageTitle = "Booking Details";
include("includes/header.php");
$booking_id = $_GET['booking_id'];
$bookingDetail = $dataQuery->getBookingDetailByBookingId($booking_id);
if(empty($bookingDetail)){
	header("Location:".BASE_URL);
}
$countryName = $dataQuery->dbSelectFirst("oh_country_city", "cnt_name", "cnt_code='".$bookingDetail['country_passport']."'");
?>
<style>
.display-booking-val{padding-top: 7px}
</style>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Booking
        <small>Room</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Availability</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Main row -->
      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title">Booking Details</h3>
		  <div class="box-tools pull-right">
            <a href="<?php echo BASE_URL.'cancel.php?booking_id='.$booking_id; ?>" class="btn btn-sm btn-default">Cancel</a>
            <a href="<?php echo BASE_URL.'amend.php?booking_id='.$booking_id; ?>" class="btn btn-sm btn-info">Amend</a>
          </div>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <div class="row">
			<div class="col-md-6">
				<div class="well bg-yellow text-cap-center">
					Booking ID: <?php echo $bookingDetail['booking_id']; ?>
				</div>
			</div>
			<div class="col-md-6">
				<div class="well bg-light-blue text-cap-center">
					Booking Status: <?php echo $bookingDetail['booking_status']; ?>
				</div>
			</div>
			<div class="form-horizontal" id="view-booking-detail">
				<!--div class="col-md-6">
					<div class="form-group">
						<label class="col-md-5 control-label">Seller:</label>
						<div class="col-md-7 display-booking-val">
							-
						</div>
					</div>
				</div>
				<<div class="col-md-6">
					<div class="form-group">
						<label class="col-md-5 control-label">Seller Ref:</label>
						<div class="col-md-7 display-booking-val">
							-
						</div>
					</div>
				</div>-->
				<div class="col-md-6">
					<div class="form-group">
						<label class="col-md-5 control-label">Property:</label>
						<div class="col-md-7 display-booking-val">
							<?php echo $bookingDetail['property_name']; ?>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label class="col-md-5 control-label">Booking Date:</label>
						<div class="col-md-7 display-booking-val">
							<?php echo date("D, d M Y", strtotime($bookingDetail['created'])); ?>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label class="col-md-5 control-label">Arrival Date:</label>
						<div class="col-md-7 display-booking-val">
							<?php echo date("D, d M Y", strtotime($bookingDetail['check_in_date'])); ?>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label class="col-md-5 control-label">Departure Date:</label>
						<div class="col-md-7 display-booking-val">
							<?php echo date("D, d M Y", strtotime($bookingDetail['check_out_date'])); ?>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label class="col-md-5 control-label">Room Type:</label>
						<div class="col-md-7 display-booking-val">
							<?php echo $bookingDetail['room_type']; ?>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label class="col-md-5 control-label">No. of Nights:</label>
						<div class="col-md-7 display-booking-val">
							<?php echo $bookingDetail['no_of_nights']; ?>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label class="col-md-5 control-label">No. of Rooms:</label>
						<div class="col-md-7 display-booking-val">
							<?php echo $bookingDetail['no_of_rooms']; ?>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label class="col-md-5 control-label">Arr./Dep. Transfer:</label>
						<div class="col-md-7 display-booking-val">
							<?php echo $dataQuery->transferCode[$bookingDetail['arrival_transfer']].'/'.$dataQuery->transferCode[$bookingDetail['departure_transfer']]; ?>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label class="col-md-5 control-label">Arrival Info:</label>
						<div class="col-md-7 display-booking-val">
							<?php echo ucfirst($bookingDetail['arrival_flight_info']); ?>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label class="col-md-5 control-label">Departure Info:</label>
						<div class="col-md-7 display-booking-val">
							<?php echo ucwords($bookingDetail['departure_flight_info']); ?>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label class="col-md-5 control-label">Meal Plan:</label>
						<div class="col-md-7 display-booking-val">
							<?php echo $dataQuery->mealPlan[$bookingDetail['meal_type_code']]; ?>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label class="col-md-5 control-label">Country of Passport:</label>
						<div class="col-md-7 display-booking-val">
							<?php echo $countryName['cnt_name']; ?>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label class="col-md-5 control-label">Late Checkout:</label>
						<div class="col-md-7 display-booking-val">
							<?php echo ($bookingDetail['late_check_out_time'] == 0) ? 'Not Required' : ($bookingDetail['late_check_out_time'].' PM'); ?>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label class="col-md-5 control-label">Airport Handling:</label>
						<div class="col-md-7 display-booking-val">
							<?php echo ($bookingDetail['airport_handling'] == 0) ? 'Not Required' : 'Yes, Required'; ?>
						</div>
					</div>
				</div>
				<div class="col-md-12">
					<div class="form-group view-pax-text-center bg-aqua">
						<div class="col-md-3">
							<div class="btn-block">
								Total Pax: <?php echo $bookingDetail['total_adult']+$bookingDetail['total_child']+$bookingDetail['total_infant']; ?>
							</div>
						</div>
						<div class="col-md-3">
							<div class="btn-block">
								Total Adult: <?php echo $bookingDetail['total_adult']; ?>
							</div>
						</div>
						<div class="col-md-3">
							<div class="btn-block">
								Total Children: <?php echo $bookingDetail['total_child']; ?>
							</div>
						</div>
						<div class="col-md-3">
							<div class="btn-block">
								Total Infant: <?php echo $bookingDetail['total_infant']; ?>
							</div>
						</div>
					</div>
				</div>
				<?php
				$rooomArr = json_decode($bookingDetail['room_guest_detail']);
				foreach($rooomArr AS $key=>$room){
				?>
				<div class="col-md-6">
					<div class="form-group">
						<label class="col-md-5 control-label">Room <?php echo ++$key; ?>:</label>
						<div class="col-md-7 display-booking-val">
							Adult: <?php echo $room->no_of_adult; ?>, Children: <?php echo $room->no_of_child; ?>, Infant: <?php echo $room->no_of_infant; ?>
						</div>
					</div>
				</div>
				<div class="col-md-6"><div class="form-group display-booking-val">&nbsp;</div></div>
				<?php
					$adultArr = $childArr = $infantArr = array();
					if($room->no_of_adult > 0){
						if($room->no_of_adult == 1)
							$adultArr[] = $room->guests->adult;
						else
							$adultArr = $room->guests->adult;
						foreach($adultArr AS $key=>$adult){ if($adult->first_name == ""){ continue; }
						?>
						<div class="col-md-6">
							<div class="form-group">
								<label class="col-md-5 control-label"><?php echo ($key==0) ? 'Adults' : ''; ?></label>
								<div class="col-md-7 display-booking-val">
									<?php echo $adult->initial_name.' '.$adult->first_name.' '.$adult->last_name; ?>
								</div>
							</div>
						</div>
						<div class="col-md-6"><div class="form-group display-booking-val">&nbsp;</div></div>
						<?php
						}
					}
					if($room->no_of_child > 0){
						if($room->no_of_child == 1)
							$childArr[] = $room->guests->child;
						else
							$childArr = $room->guests->child;
						foreach($childArr AS $key=>$child){
						?>
						<div class="col-md-6">
							<div class="form-group">
								<label class="col-md-5 control-label"><?php echo ($key==0) ? 'Childrens' : ''; ?></label>
								<div class="col-md-7 display-booking-val">
									<?php echo $child->initial_name.' '.$child->first_name.' '.$child->last_name.' - '.$child->age_or_dob; ?>
								</div>
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group display-booking-val">&nbsp;</div>
						</div>
						<?php
						}
					}
					if($room->no_of_infant > 0){
						if($room->no_of_infant == 1)
							$infantArr[] = $room->guests->infant;
						else
							$infantArr = $room->guests->infant;
						foreach($infantArr AS $key=>$infant){
						?>
						<div class="col-md-6">
							<div class="form-group">
								<label class="col-md-5 control-label"><?php echo ($key==0) ? 'Infant' : ''; ?></label>
								<div class="col-md-7 display-booking-val">
									<?php echo $infant->initial_name.' '.$infant->first_name.' '.$infant->last_name.' - '.$infant->age_or_dob; ?>
								</div>
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group display-booking-val">&nbsp;</div>
						</div>
						<?php
						}
					}
				} ?>
			</div>
          </div>
          <!-- /.row -->
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
      <!-- /.row (main row) -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php
include("includes/footer.php");
?>