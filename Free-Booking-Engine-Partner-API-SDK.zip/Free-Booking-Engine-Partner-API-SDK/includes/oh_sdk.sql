/*
SQLyog Community v12.2.4 (64 bit)
MySQL - 10.1.13-MariaDB : Database - oh_sdk
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

/*Table structure for table `oh_booking_details` */

DROP TABLE IF EXISTS `oh_booking_details`;

CREATE TABLE `oh_booking_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `booking_id` varchar(25) DEFAULT NULL,
  `property_id` int(11) DEFAULT NULL,
  `property_guest_name` varchar(150) DEFAULT NULL,
  `room_type_code` varchar(10) DEFAULT NULL,
  `room_type` varchar(30) DEFAULT NULL,
  `no_of_nights` int(11) DEFAULT NULL,
  `check_in_date` date DEFAULT NULL,
  `check_out_date` date DEFAULT NULL,
  `no_of_rooms` int(11) DEFAULT NULL,
  `buyer_ref` varchar(30) DEFAULT NULL,
  `meal_type_code` int(11) DEFAULT NULL,
  `country_passport` varchar(4) DEFAULT NULL,
  `arrival_flight_info` varchar(30) DEFAULT NULL,
  `departure_flight_info` varchar(30) DEFAULT NULL,
  `arrival_transfer` int(11) DEFAULT NULL,
  `departure_transfer` int(11) DEFAULT NULL,
  `airport_handling` int(11) DEFAULT NULL,
  `late_check_out_time` int(11) DEFAULT NULL,
  `comments` text,
  `booking_status` varchar(30) DEFAULT NULL,
  `total_adult` int(11) DEFAULT '0',
  `total_child` int(11) DEFAULT '0',
  `total_infant` int(11) DEFAULT '0',
  `room_guest_detail` text COMMENT 'rooms details in json format',
  `cancelled` tinyint(1) DEFAULT '0' COMMENT '1- Booking Cancelled',
  `amend` tinyint(1) DEFAULT '0' COMMENT '1- Booking Amend',
  `amend_reason` text,
  `created` datetime DEFAULT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `partner_allot` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

/*Table structure for table `oh_booking_details_history` */

DROP TABLE IF EXISTS `oh_booking_details_history`;

CREATE TABLE `oh_booking_details_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `booking_id` varchar(25) DEFAULT NULL,
  `property_id` int(11) DEFAULT NULL,
  `property_guest_name` varchar(150) DEFAULT NULL,
  `room_type_code` varchar(10) DEFAULT NULL,
  `room_type` varchar(30) DEFAULT NULL,
  `no_of_nights` int(11) DEFAULT NULL,
  `check_in_date` date DEFAULT NULL,
  `check_out_date` date DEFAULT NULL,
  `no_of_rooms` int(11) DEFAULT NULL,
  `buyer_ref` varchar(30) DEFAULT NULL,
  `meal_type_code` int(11) DEFAULT NULL,
  `country_passport` varchar(4) DEFAULT NULL,
  `arrival_flight_info` varchar(30) DEFAULT NULL,
  `departure_flight_info` varchar(30) DEFAULT NULL,
  `arrival_transfer` int(11) DEFAULT NULL,
  `departure_transfer` int(11) DEFAULT NULL,
  `airport_handling` int(11) DEFAULT NULL,
  `late_check_out_time` int(11) DEFAULT NULL,
  `comments` text,
  `booking_status` varchar(30) DEFAULT NULL,
  `total_adult` int(11) DEFAULT '0',
  `total_child` int(11) DEFAULT '0',
  `total_infant` int(11) DEFAULT '0',
  `room_guest_detail` text COMMENT 'rooms details in json format',
  `cancelled` tinyint(1) DEFAULT '0' COMMENT '1- Booking Cancelled',
  `amend` tinyint(1) DEFAULT '0' COMMENT '1- Booking Amend',
  `amend_reason` text,
  `created` datetime DEFAULT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

/*Table structure for table `oh_country_city` */

DROP TABLE IF EXISTS `oh_country_city`;

CREATE TABLE `oh_country_city` (
  `city_id` mediumint(9) unsigned NOT NULL AUTO_INCREMENT,
  `cnt_name` varchar(55) DEFAULT NULL,
  `cnt_code` char(2) DEFAULT NULL,
  `city_name` varchar(32) DEFAULT NULL,
  `city_code` char(3) NOT NULL,
  PRIMARY KEY (`city_id`),
  UNIQUE KEY `city_name` (`cnt_code`,`city_name`)
) ENGINE=InnoDB AUTO_INCREMENT=9312 DEFAULT CHARSET=latin1;

/*Data for the table `oh_country_city` */

insert  into `oh_country_city`(`city_id`,`cnt_name`,`cnt_code`,`city_name`,`city_code`) values 

(1,'Germany','DE','Aachen','AAH'),

(2,'Denmark','DK','Aalborg','AAL'),

(3,'Denmark','DK','Aarhus','AAR'),

(4,'Iran','IR','Abadan','ABD'),

(5,'Kiribati','KI','Abaiang','ABF'),

(6,'Russia','RU','Abakan~ Khakassia','ABA'),

(7,'Papua New Guinea','PG','Abau','ABW'),

(8,'Canada','CA','Abbotsford~ BC','YXX'),

(9,'Yemen','YE','Abbse','EAB'),

(10,'Chad','TD','Abeche','AEH'),

(11,'Kiribati','KI','Abemama Atoll','AEA'),

(12,'Ivory Coast','CI','Abengourou','OGO'),

(13,'MD USA','US','Aberdeen Proving Ground (Aberdee','APG'),

(14,'United Kingdom','GB','Aberdeen~ Scotland','ABZ'),

(15,'USA','US','Aberdeen~ SD','ABR'),

(16,'Ivory Coast','CI','Abidjan','ABJ'),

(17,'USA','US','Abilene~ TX','ABI'),

(19,'United Kingdom','GB','Abingdon~ England','ABB'),

(20,'USA','US','Abingdon~ VA','VJI'),

(21,'Australia','AU','Abingoon~ Queensland','ABG'),

(22,'Ivory Coast','CI','Aboisso','ABO'),

(23,'Chad','TD','Abou Deia','AOD'),

(24,'Mexico','MX','Abreojos','AJS'),

(25,'United Arab Emirates','AE','Abu Dhabi','AZI'),

(28,'Egypt','EG','Abu Simbel','ABS'),

(29,'Nigeria','NG','Abuja','ABV'),

(30,'Colombia','CO','Acandi','ACD'),

(31,'Mexico','MX','Acapulco','ACA'),

(32,'Colombia','CO','Acaricura','ARF'),

(33,'Venezuela','VE','Acarigua','AGV'),

(34,'Ghana','GH','Accra','ACC'),

(35,'Panama','PA','Achutupo','ACU'),

(36,'USA','US','Ada~ OK','ADT'),

(37,'USA','US','Adak Island~ AK','ADK'),

(38,'Turkey','TR','Adana','ADA'),

(40,'Ethiopia','ET','Addis Ababa','ADD'),

(41,'Australia','AU','Adelaide~ South Australia','ADL'),

(42,'Yemen','YE','Aden','ADE'),

(43,'Russia','RU','Adler/Sochi~ Krasnodar','AER'),

(44,'Algeria','DZ','Adrar','AZR'),

(45,'USA','US','Adrian~ MI','ADG'),

(46,'Indonesia','ID','Aek Godang','AEG'),

(47,'Papua New Guinea','PG','Afore','AFR'),

(48,'USA','US','Afton~ WY','AFO'),

(49,'Turkey','TR','Afyon','AFY'),

(50,'Niger','NE','Agades (Agadez)','AJY'),

(51,'Morocco','MA','Agadir','AGA'),

(52,'Guam','GU','Agana','NGM'),

(53,'India','IN','Agartala','IXA'),

(54,'India','IN','Agatti Island','AGX'),

(55,'Papua New Guinea','PG','Agaun','AUP'),

(56,'France','FR','Agen','AGF'),

(57,'South Africa','ZA','Aggeneys','AGZ'),

(58,'Australia','AU','Agnew~ Queensland','AGW'),

(59,'Argentina','AR','Ago','ING'),

(60,'India','IN','Agra','AGR'),

(61,'Greece','GR','Agrinion','AGQ'),

(62,'Puerto Rico','PR','Aguadilla','BQN'),

(63,'Mexico','MX','Aguascalientes','AGU'),

(64,'Japan','JP','Aguni','AGJ'),

(65,'India','IN','Ahmedabad','AMD'),

(66,'Honduras','HN','Ahuas','AHS'),

(67,'Iran','IR','Ahwaz','AWZ'),

(68,'USA','US','Aiken~ SC','AIK'),

(69,'Panama','PA','Ailigandi','AIL'),

(70,'Marshall Islands','MH','Ailinglapalap','AIP'),

(71,'Marshall Islands','MH','Ailuk~ Ine Island','AIM'),

(72,'USA','US','Ainsworth~ NE','ANW'),

(73,'Papua New Guinea','PG','Aiome','AIE'),

(74,'Mauritania','MR','Aioun el Atrouss','AEO'),

(75,'Australia','AU','Airlie Beach~ Queensland','WSY'),

(76,'Marshall Islands','MH','Airok','AIC'),

(77,'Guyana','GY','Aishalton','AHL'),

(78,'Papua New Guinea','PG','Aitape','ATP'),

(79,'Cook Islands','CK','Aitutaki','AIT'),

(80,'Papua New Guinea','PG','Aiyura','AYU'),

(81,'India','IN','Aizawl','AJL'),

(82,'France','FR','Ajaccio~ Corsica','AJA'),

(83,'United Arab Emirates','AE','Ajman City','QAJ'),

(84,'USA','US','Akhiok~ AK','AKK'),

(85,'USA','US','Akiachak~ AK','KKI'),

(86,'USA','US','Akiak~ AK','AKI'),

(87,'Gabon','GA','Akieni','AKE'),

(88,'Japan','JP','Akita','AXT'),

(89,'Mauritania','MR','Akjoujt','AJJ'),

(90,'Canada','CA','Aklavik~ NT','LAK'),

(91,'India','IN','Akola','AKD'),

(92,'USA','US','Akron~ CO','AKO'),

(93,'USA','US','Akron~ OH','CAK'),

(94,'Cyprus','CY','Akrotiri','AKT'),

(95,'China','CN','Aksu','AKU'),

(96,'Canada','CA','Akulivik~ QC','AKV'),

(97,'Nigeria','NG','Akure','AKR'),

(98,'Iceland','IS','Akureyri','AEY'),

(99,'USA','US','Akutan~ AK','KQA'),

(100,'United Arab Emirates','AE','Al Ain','AAN'),

(101,'Egypt','EG','Al Arish','AAC'),

(102,'Saudi Arabia','SA','Al Baha','ABT'),

(103,'Yemen','YE','Al Bayda','AYY'),

(104,'Yemen','YE','Al Ghaydah','AAY'),

(105,'Morocco','MA','Al Hoceima','AHU'),

(106,'Saudi Arabia','SA','Al Kharj Air Base','XWP'),

(107,'Syria','SY','Al Thaurah','SOR'),

(108,'Brazil','BR','Alagoinhas~ BA','QGS'),

(109,'Philippines','PH','Alah','AAV'),

(110,'USA','US','Alakanuk~ AK','AUK'),

(111,'USA','US','Alameda~ CA','NGZ'),

(112,'USA','US','Alamogordo~ NM','ALM'),

(114,'Mexico','MX','Alamos','XAL'),

(115,'USA','US','Alamosa~ CO','ALS'),

(116,'USA','US','Albany~ GA','NAB'),

(118,'USA','US','Albany~ NY','ALB'),

(119,'Australia','AU','Albany~ Western Australia','ALH'),

(120,'Italy','IT','Albenga','ALL'),

(121,'USA','US','Albert Lea~ MN','AEL'),

(122,'France','FR','Albi','LBI'),

(123,'Suriname','SR','Albina','ABN'),

(124,'USA','US','Albion~ NE','BVN'),

(125,'Yemen','YE','Albuq','BUK'),

(126,'USA','US','Albuquerque~ NM','ABQ'),

(127,'Australia','AU','Albury~ New South Wales','ABX'),

(128,'United Kingdom','GB','Alconbury~ England','AYH'),

(129,'Australia','AU','Alcoota~ Northern Territory','WCY'),

(130,'Russia','RU','Aldan~ Yakutia-Sakha','ADH'),

(131,'Channel Islands','GB','Alderney','ACI'),

(132,'Mauritania','MR','Aleg','LEG'),

(133,'Brazil','BR','Alegrete~ RS','ALQ'),

(134,'USA','US','Aleknagik~ AK','WKK'),

(135,'Brazil','BR','Alenquer~ PA','ALT'),

(136,'Syria','SY','Aleppo','ALP'),

(137,'Canada','CA','Alert Bay~ BC','YAL'),

(138,'Canada','CA','Alert~ NT','YLT'),

(139,'Peru','PE','Alerta','ALD'),

(140,'Norway','NO','Alesund (Aalesund)','AES'),

(141,'South Africa','ZA','Alexander Bay','ALJ'),

(142,'USA','US','Alexander City~ AL','ALX'),

(143,'New Zealand','NZ','Alexandra','ALR'),

(144,'USA','US','Alexandria Bay~ NY','AXB'),

(145,'Egypt','EG','Alexandria','ALY'),

(146,'USA','US','Alexandria~ LA','ESF'),

(148,'USA','US','Alexandria~ MN','AXN'),

(149,'Australia','AU','Alexandria~ Northern Territory','AXL'),

(150,'Greece','GR','Alexandroupolis','AXD'),

(151,'United Arab Emirates','AE','Alfujairah (Fujairah)','FJR'),

(152,'Algeria','DZ','Alger (Algiers)','ALG'),

(153,'Italy','IT','Alghero~ Sardinia','AHO'),

(154,'USA','US','Algona~ IA','AXG'),

(155,'Italy','IT','Alhegro/Sassari~ Sardinia','QSS'),

(156,'Djibouti','DJ','Ali Sabieh','AII'),

(157,'Spain','ES','Alicante','ALC'),

(158,'BC Canada','CA','Alice Arm/Silver City','ZAA'),

(159,'Australia','AU','Alice Springs~ Northern Territor','ASP'),

(160,'USA','US','Alice~ TX','ALI'),

(161,'USA','US','Aliceville~ AL','AIV'),

(162,'USA','US','Alitak~ AK','ALZ'),

(163,'Yemen','YE','Aljouf','AJO'),

(164,'India','IN','Allahabad','IXD'),

(165,'USA','US','Allakaket~ AK','AET'),

(166,'South Africa','ZA','Alldays','ADY'),

(167,'USA','US','Allentown~ PA','ABE'),

(168,'USA','US','Alliance~ NE','AIA'),

(169,'USA','US','Alma~ MI','AMN'),

(170,'Canada','CA','Alma~ QC','YTF'),

(171,'Kazakhstan','KZ','Almaty (Alma Ata)~ Alma Ata','ALA'),

(172,'Netherlands','NL','Almelo','QYL'),

(173,'Brazil','BR','Almenara~ MG','AMJ'),

(174,'Spain','ES','Almeria','LEI'),

(175,'India','IN','Along','IXV'),

(176,'Indonesia','ID','Alor Island','ARD'),

(177,'Malaysia','MY','Alor Setar','AOR'),

(178,'Gabon','GA','Alowe','AWE'),

(179,'France','FR','Alpe d\'Huez','AHZ'),

(180,'USA','US','Alpena~ MI','APN'),

(181,'Australia','AU','Alpha~ Queensland','ABH'),

(182,'USA','US','Alpine~ TX','ALE'),

(183,'Australia','AU','Alroy Downs~ Northern Territory','AYD'),

(184,'Brazil','BR','Alta Floresta','AFL'),

(185,'Canada','CA','Alta Lake~ BC','YAE'),

(186,'Norway','NO','Alta','ALF'),

(187,'Brazil','BR','Altamira~ PA','ATM'),

(188,'China','CN','Altay','AAT'),

(189,'Germany','DE','Altenburg','AOC'),

(190,'Switzerland','CH','Altenrhein','ACH'),

(191,'Brazil','BR','Alto do Parnaiba~ PI','APY'),

(192,'Mozambique','MZ','Alto Molocue','AME'),

(193,'Chile','CL','Alto Palena','WAP'),

(194,'Argentina','AR','Alto Rio Senguerr','ARR'),

(195,'Australia','AU','Alton Downs~ South Australia','AWN'),

(196,'USA','US','Alton~ IL/St. Louis~ MO','ALN'),

(197,'USA','US','Altoona~ PA','AOO'),

(198,'USA','US','Altus~ OK','LTS'),

(200,'Somalia','SO','Alula','ALU'),

(201,'USA','US','Alyeska/Girdwood~ AK','AQY'),

(202,'Papua New Guinea','PG','Ama','AMF'),

(203,'Indonesia','ID','Amahai','AHI'),

(204,'Colombia','CO','Amalfi','AFI'),

(205,'Japan','JP','Amami O Shima','ASJ'),

(206,'Papua New Guinea','PG','Amanab','AMU'),

(207,'USA','US','Amarillo~ TX','AMA'),

(209,'Australia','AU','Amata~ Northern Territory','AMT'),

(210,'Papua New Guinea','PG','Amazon Bay','AZB'),

(211,'Madagascar','MG','Ambanja','IVA'),

(212,'Ecuador','EC','Ambato','ATF'),

(213,'Madagascar','MG','Ambatolahy','AHY'),

(214,'Madagascar','MG','Ambatomainty','AMY'),

(215,'Madagascar','MG','Ambatondrazaka','WAM'),

(216,'Madagascar','MG','Ambilobe','AMB'),

(217,'USA','US','Ambler~ AK','ABL'),

(218,'Papua New Guinea','PG','Ambolin','AMG'),

(219,'Indonesia','ID','Ambon','AMQ'),

(220,'Kenya','KE','Amboseli','ASV'),

(221,'Papua New Guinea','PG','Ambunti','AUJ'),

(222,'USA','US','Amchitka~ AK','AHT'),

(223,'Chad','TD','Amchitka','AMC'),

(224,'Russia','RU','Amderma~ Arkhangelsk','AMV'),

(225,'Australia','AU','American River~ South Australia','RCN'),

(226,'USA','US','Americus~ GA','ACJ'),

(227,'Netherlands','NL','Amersfoort','QYM'),

(228,'USA','US','Amery~ WI','AHH'),

(229,'USA','US','Ames~ IA','AMW'),

(230,'USA','US','Amityville~ NY','AYZ'),

(231,'Jordan','JO','Amman','ADJ'),

(233,'Australia','AU','Ammaroo~ Northern Territory','AMX'),

(234,'USA','US','Amook~ AK','AOS'),

(235,'Canada','CA','Amos~ QC','YEY'),

(236,'Madagascar','MG','Ampanihy','AMP'),

(237,'India','IN','Amritsar','ATQ'),

(238,'Netherlands','NL','Amsterdam','AMS'),

(240,'French Polynesia','PF','Anaa','AAA'),

(241,'Venezuela','VE','Anaco','AAO'),

(242,'USA','US','Anacortes~ WA','OTS'),

(244,'Russia','RU','Anadyr~ Magadan','DYR'),

(245,'USA','US','Anaheim/Disneyland~ CA','ANA'),

(246,'Canada','CA','Anahim Lake~ BC','YAA'),

(247,'USA','US','Anaktuvuk Pass~ AK','AKP'),

(248,'Madagascar','MG','Analalava','HVA'),

(249,'India','IN','Anand','QNB'),

(250,'Russia','RU','Anapa','AAQ'),

(251,'Brazil','BR','Anapolis~ GO','APS'),

(252,'USA','US','Anchorage~ AK','ANC'),

(256,'Italy','IT','Ancona','AOI'),

(257,'Chile','CL','Ancud','ZUD'),

(258,'Peru','PE','Andahuaylas','ANS'),

(259,'Australia','AU','Andamooka~ South Australia','ADO'),

(260,'Madagascar','MG','Andapa','ZWA'),

(261,'USA','US','Anderson~ IN','AID'),

(262,'USA','US','Anderson~ SC','AND'),

(263,'Colombia','CO','Andes','ADN'),

(264,'Uzbekhistan','UZ','Andijon (Andizhan)~ Andijon','AZN'),

(265,'Andorra','AD','Andorra la Vella','ALV'),

(266,'United Kingdom','GB','Andover~ England','ADV'),

(267,'Norway','NO','Andoya','ANX'),

(268,'Greece','GR','Andravida','GVD'),

(269,'USA','US','Andrews~ SC','ADR'),

(270,'Madagascar','MG','Andriamena','WAD'),

(271,'Bahamas','BS','Andros Town~ Andros','ASD'),

(272,'Angola','AO','Andulo','ANL'),

(273,'British Virgin Islands','VG','Anegada','NGD'),

(274,'Vanuatu','VU','Aneityum','AUY'),

(275,'USA','US','Angel Fire~ NM','AXX'),

(276,'Sweden','SE','Angelholm (Helsingborg)','AGH'),

(277,'France','FR','Angers','ANE'),

(278,'Indonesia','ID','Anggi','AGD'),

(279,'USA','US','Angleton/Lake Jackson~ TX','LJN'),

(280,'Canada','CA','Angling Lake~ MB','YAX'),

(281,'Mozambique','MZ','Angoche (Antonio Enes)','ANO'),

(282,'USA','US','Angola~ IN','ANQ'),

(283,'USA','US','Angoon~ AK','AGN'),

(284,'Papua New Guinea','PG','Angoram','AGG'),

(285,'France','FR','Angouleme','ANG'),

(286,'Papua New Guinea','PG','Anguganak','AKG'),

(287,'Anguilla','AI','Anguilla','AXA'),

(288,'USA','US','Anguilla/Rolling Fork~ MS','RFK'),

(289,'Australia','AU','Angus Downs~ Northern Territory','ANZ'),

(290,'USA','US','Aniak~ AK','ANI'),

(291,'USA','US','Anita Bay~ AK','AIB'),

(292,'Vanuatu','VU','Aniwa','AWD'),

(293,'Comoros','KM','Anjouan','AJN'),

(294,'China','CN','Ankang','AKA'),

(295,'Turkey','TR','Ankara','ANK'),

(297,'Madagascar','MG','Ankavandra','JVA'),

(298,'Madagascar','MG','Ankazoabo','WAK'),

(299,'USA','US','Ann Arbor~ MI','ARB'),

(300,'Algeria','DZ','Annaba','AAE'),

(301,'Guyana','GY','Annai','NAI'),

(302,'Papua New Guinea','PG','Annanberg','AOB'),

(303,'USA','US','Annapolis~ MD','ANP'),

(304,'France','FR','Annecy','NCY'),

(305,'USA','US','Annette~ AK','ANN'),

(306,'USA','US','Anniston~ AL','ANB'),

(307,'Switzerland','CH','Annmasse','QNJ'),

(308,'China','CN','Anqing','AQG'),

(309,'Greenland','GL','Anqmaqssalik','AGM'),

(310,'China','CN','Anshan','AOG'),

(311,'Peru','PE','Anta','ATA'),

(312,'Madagascar','MG','Antalaha','ANM'),

(313,'Turkey','TR','Antalya','AYT'),

(314,'Madagascar','MG','Antananarivo','TNR'),

(315,'Australia','AU','Anthony Lagoon~ Northern Territo','AYL'),

(316,'USA','US','Anthony~ KS','ANY'),

(317,'Antigua and Barbuda','AG','Antigua (Saint John\'s)','ANU'),

(318,'USA','US','Antlers~ OK','ATE'),

(319,'Chile','CL','Antofagasta','ANF'),

(320,'Madagascar','MG','Antsalova','WAQ'),

(321,'Madagascar','MG','Antsirabe','ATJ'),

(322,'Madagascar','MG','Antsiranana (Diego Suarez)','DIE'),

(323,'Madagascar','MG','Antsohihy','WAI'),

(324,'Belgium','BE','Antwerpen (Antwerp)','ANR'),

(325,'Solomon Islands','SB','Anuha Island','ANH'),

(326,'Sri Lanka','LK','Anuradhapura','ADP'),

(327,'USA','US','Anvik~ AK','ANV'),

(328,'China','CN','Anyang','AYN'),

(329,'Japan','JP','Aomori','AOJ'),

(330,'USA','US','Apalachicola~ FL','AAF'),

(331,'Indonesia','ID','Apalapsili~ New Guinea','AAS'),

(332,'Colombia','CO','Apartado','APO'),

(333,'French Polynesia','PF','Apataki~ Tuamotu Archipelago','APK'),

(334,'Mexico','MX','Apatzingan','AZG'),

(335,'Netherlands','NL','Apeldoorn','QYP'),

(336,'Western Samoa','EH','Apia','FGI'),

(338,'Colombia','CO','Apiay','API'),

(339,'Bolivia','BO','Apolo','APB'),

(340,'Italy','IT','Appian Line','APJ'),

(341,'USA','US','Apple Valley~ CA','APV'),

(342,'USA','US','Appleton~ WI','ATW'),

(343,'Papua New Guinea','PG','April River','APR'),

(344,'Brazil','BR','Apucarana~ PR','APU'),

(345,'Jordan','JO','Aqaba','AQJ'),

(346,'Kazakhstan','KZ','Aqmola (Tselinograd)~ Aqmola','TSE'),

(347,'Kazakhstan','KZ','Aqtan (Shevchenko)~ Mangghystan','SCO'),

(348,'Kazakhstan','KZ','Aqtobe (Aktyubinsk)~ Aqtobe','AKX'),

(349,'Brazil','BR','Aracaju~ SE','AJU'),

(350,'Brazil','BR','Aracatuba~ SP','ARU'),

(351,'Romania','RO','Arad','ARW'),

(352,'Brazil','BR','Aragarcas~ GO','ARS'),

(353,'Papua New Guinea','PG','Aragip','ARP'),

(354,'Brazil','BR','Araguaina~ TO','AUX'),

(355,'Australia','AU','Aramac~ Queensland','AXC'),

(356,'Kiribati','KI','Aranuka','AAK'),

(357,'USA','US','Arapahoe~ NE','AHF'),

(358,'Brazil','BR','Arapongas~ PR','APX'),

(359,'Saudi Arabia','SA','Arar','RAE'),

(360,'Colombia','CO','Araracuara','ACR'),

(361,'Brazil','BR','Araraquara~ SP','AQA'),

(362,'Australia','AU','Ararat~ Victoria','ARY'),

(363,'Colombia','CO','Arauca','AUC'),

(364,'Colombia','CO','Arauquita','ARQ'),

(365,'Ethiopia','ET','Arawa','RAW'),

(366,'Brazil','BR','Araxa~ MG','AAX'),

(367,'Greece','GR','Araxos/Patras','GPA'),

(368,'Ethiopia','ET','Arba Mintch','AMH'),

(369,'Colombia','CO','Arboletas','ARO'),

(370,'USA','US','Arcadia~ CA','JAR'),

(371,'USA','US','Arcata/Eureka~ CA','ACV'),

(372,'Brazil','BR','Arcos~ MG','QRK'),

(373,'Canada','CA','Arctic Bay~ NT','YAB'),

(374,'Canada','CA','Arctic Red River~ NT','ZRR'),

(375,'USA','US','Arctic Village~ AK','ARC'),

(376,'New Zealand','NZ','Ardmore','AMZ'),

(377,'USA','US','Ardmore~ OK','ADM'),

(379,'Peru','PE','Arequipa','AQP'),

(380,'Canada','CA','Argentia~ NF','NWP'),

(381,'Australia','AU','Argyle Downs~ Western Australia','AGY'),

(382,'Burkina Faso','BF','Aribinda','XAR'),

(383,'Chile','CL','Arica','ARI'),

(384,'Colombia','CO','Arica','ACM'),

(385,'Brazil','BR','Aripuana~ MT','AIR'),

(386,'Brazil','BR','Ariquemes~ RO','AQM'),

(387,'Kazakhstan','KZ','Arkalyk','AYK'),

(388,'Russia','RU','Arkhangelsk~ Arkhangelsk','ARH'),

(389,'USA','US','Arlington Heights~ IL','JLH'),

(390,'USA','US','Arlington~ TX','WSK'),

(391,'Niger','NE','Arlit','RLT'),

(392,'Burkina Faso','BF','Arly','ARL'),

(393,'Colombia','CO','Armenia','AXM'),

(394,'Australia','AU','Armidale~ New South Wales','ARM'),

(395,'Canada','CA','Armstrong~ ON','YYW'),

(396,'Canada','CA','Arnes~ MB','YNR'),

(397,'Netherlands','NL','Arnhem','QAR'),

(398,'Marshall Islands','MH','Arno','AMR'),

(399,'Papua New Guinea','PG','Aroa','AOA'),

(400,'Papua New Guinea','PG','Arona','AON'),

(401,'Kiribati','KI','Arorae Island','AIS'),

(402,'Australia','AU','Arrabury~ Queensland','AAB'),

(403,'Brazil','BR','Arraias~ GO','AAI'),

(404,'Spain','ES','Arrecife~ Canary Islands','ACE'),

(405,'Indonesia','ID','Arso','ARJ'),

(406,'Greenland','GL','Arsuk','JRK'),

(407,'USA','US','Artesia~ NM','ATS'),

(408,'Bahamas','BS','Arthur\'s Town~ Cat','ATC'),

(409,'Uruguay','UY','Artigas','ATI'),

(410,'Uganda','UG','Arua','RUA'),

(411,'Aruba','AW','Aruba (Oranjestad)','AUA'),

(412,'Kiribati','KI','Arunka','RNK'),

(413,'Tanzania','TZ','Arusha','ARK'),

(414,'French Polynesia','PF','Arutha','AXR'),

(415,'Sweden','SE','Arvidsjaur','AJR'),

(416,'Japan','JP','Asahikawa','AKJ'),

(417,'Papua New Guinea','PG','Asapa','APP'),

(418,'Western Samoa','EH','Asau','AAU'),

(419,'Canada','CA','Asbestos Hill~ QC','YAF'),

(420,'USA','US','Asbury Park/Fort Monmouth~ NJ','ARX'),

(421,'St. Helena','SH','Ascension Island','ASI'),

(422,'Bolivia','BO','Ascension','ASC'),

(423,'Switzerland','CH','Ascona','ACO'),

(424,'Papua New Guinea','PG','Aseki','AEK'),

(425,'Ethiopia','ET','Asela','ALK'),

(426,'USA','US','Ash Flat~ AR','CVK'),

(427,'New Zealand','NZ','Ashburton','ASG'),

(428,'Canada','CA','Ashcroft~ BC','YZA'),

(429,'USA','US','Asheville~ NC','AVL'),

(430,'United Kingdom','GB','Ashford','LYM'),

(431,'Turkmenistan','TM','Ashgabat (Ashkhabad)~ Ahal','ASB'),

(432,'USA','US','Ashland~ WI','ASX'),

(433,'USA','US','Ashley~ ND','ASY'),

(434,'Papua New Guinea','PG','Asirim','ASZ'),

(435,'Eritrea','ER','Asmara','ASM'),

(436,'Ethiopia','ET','Asosa','ASO'),

(437,'USA','US','Aspen~ CO','ASE'),

(438,'Eritrea','ER','Assab','ASA'),

(439,'Brazil','BR','Assis~ SP','AIF'),

(440,'Egypt','EG','Assiut','ATZ'),

(441,'USA','US','Astoria~ OR','AST'),

(442,'Russia','RU','Astrakhan~ Astrakhan','ASF'),

(443,'Indonesia','ID','Astraksetra','AKQ'),

(444,'Greece','GR','Astypalea Island','JTY'),

(445,'Paraguay','PY','Asuncion','ASU'),

(446,'Egypt','EG','Aswan','ASW'),

(447,'Peru','PE','Atalaya','ATG'),

(448,'Indonesia','ID','Atambua','ABU'),

(449,'Yemen','YE','Ataq','AXK'),

(450,'Mauritania','MR','Atar','ATR'),

(451,'Indonesia','ID','Atauro','AUT'),

(452,'Sudan','SD','Atbara','ATB'),

(453,'Greece','GR','Athens (Athinai)','ATH'),

(454,'USA','US','Athens~ GA','AHN'),

(455,'USA','US','Athens~ TN','MMI'),

(456,'USA','US','Athens/Albany~ OH','ATO'),

(457,'Chad','TD','Ati','ATV'),

(458,'Brazil','BR','Atibaia~ SP','QTA'),

(459,'Canada','CA','Atikokan~ ON','YIB'),

(460,'Cook Islands','CK','Atiu','AIU'),

(461,'USA','US','Atka~ AK','AKB'),

(462,'Papua New Guinea','PG','Atkamba','ABP'),

(463,'USA','US','Atlanta (Marietta)~ GA','JGL'),

(464,'USA','US','Atlanta (Norcross)~ GA','JAO'),

(465,'USA','US','Atlanta~ GA','JAE'),

(469,'GA [HartsfieldInternational Airport]','US','Atlanta','ATL'),

(471,'USA','US','Atlantic City~ NJ','ACY'),

(475,'USA','US','Atlantic~ IA','AIO'),

(476,'USA','US','Atmautluak~ AK','ATT'),

(477,'Solomon Islands','SB','Atoifi','ATD'),

(478,'USA','US','Atqasuk~ AK','ATK'),

(479,'Japan','JP','Atsugi','NJA'),

(480,'Canada','CA','Attawapiskat~ ON','YAT'),

(481,'Laos','LA','Attopeu','AOU'),

(482,'USA','US','Attu Island~ AK','ATU'),

(483,'French Polynesia','PF','Atuona~ Marquesas Islands','AUQ'),

(484,'Kazakhstan','KZ','Atyrau (Guryev)~ Atyrau','GUW'),

(485,'Papua New Guinea','PG','Aua','AUI'),

(486,'Egypt','EG','Aub Rudeis','AUE'),

(487,'France','FR','Aubenas','OBS'),

(488,'USA','US','Auburn~ AL','AUO'),

(489,'USA','US','Auburn~ CA','AUN'),

(490,'USA','US','Auburn/Lewiston~ ME','LEW'),

(491,'New Zealand','NZ','Auckland','AKL'),

(493,'USA','US','Audubon~ IA','ADU'),

(494,'Germany','DE','Augsburg','AGB'),

(495,'USA','US','Augusta~ GA','AGS'),

(497,'USA','US','Augusta~ ME','AUG'),

(498,'Australia','AU','Augustus Downs~ Queensland','AUD'),

(499,'Solomon Islands','SB','Auki','AKS'),

(500,'Canada','CA','Aupaluk~ QC','YPJ'),

(501,'Marshall Islands','MH','Aur Atoll','AUL'),

(502,'India','IN','Aurangabad','IXU'),

(503,'France','FR','Aurillac','AUR'),

(504,'Australia','AU','Aurukun Mission~ Queensland','AUU'),

(505,'USA','US','Austin~ MN','AUM'),

(506,'USA','US','Austin~ NV','ASQ'),

(507,'USA','US','Austin~ TX','BSM'),

(510,'Australia','AU','Austral Downs~ Northern Territor','AWP'),

(511,'Australia','AU','Auvergne~ Northern Territory','AVG'),

(512,'USA','US','Ava~ MO','AOV'),

(513,'USA','US','Avalon (Catalina Island)~ CA','AVX'),

(516,'USA','US','Avalon (Catalina Island)~ CA Amp','TWH'),

(517,'Cook Islands','CK','Avarua','RAR'),

(518,'Italy','IT','Avellino','QVN'),

(519,'USA','US','Avenal~ CA','AVE'),

(520,'Italy','IT','Aviano','AVB'),

(521,'France','FR','Avignon','AVN'),

(522,'USA','US','Avon Park~ FL','AVO'),

(523,'USA','US','Avon~ CO','AVC'),

(524,'France','FR','Avoriaz','AVF'),

(525,'Solomon Islands','SB','Avu Avu','AVU'),

(526,'Papua New Guinea','PG','Awaba','AWB'),

(527,'Papua New Guinea','PG','Awar','AWR'),

(528,'Suriname','SR','Awaradam','AAJ'),

(529,'Ethiopia','ET','Awareh','AWH'),

(530,'Ethiopia','ET','Awassa','AWA'),

(531,'Ethiopia','ET','Axum','AXU'),

(532,'Colombia','CO','Ayacucho','AYC'),

(533,'Peru','PE','Ayacucho','AYP'),

(534,'Colombia','CO','Ayapel','AYA'),

(535,'Indonesia','ID','Ayawasi','AYW'),

(536,'USA','US','Ayer/Fort Devens~ MA','AYE'),

(537,'Australia','AU','Ayers Rock~ Northern Territory','AYQ'),

(538,'Cyprus','CY','Ayia Napa','QNP'),

(539,'Australia','AU','Ayr~ Queensland','AYR'),

(541,'Fiji','FJ','Ba','BFJ'),

(542,'South Africa','ZA','Babelegi','HBL'),

(543,'Indonesia','ID','Babo','BXB'),

(544,'Iran','IR','Babolsar','BBL'),

(545,'USA','US','Baca Grande~ CO','BCJ'),

(546,'Romania','RO','Bacau','BCM'),

(547,'Ethiopia','ET','Baco/Jinka','BCO'),

(548,'Philippines','PH','Bacolod','BCD'),

(549,'Spain','ES','Badajoz','BJZ'),

(550,'Indonesia','ID','Bade','BXD'),

(551,'Germany','DE','Baden Baden','ZCC'),

(552,'Pakistan','PK','Badin','BDN'),

(553,'Australia','AU','Badu Island~ Queensland','BDD'),

(554,'Cameroon','CM','Bafoussem','BFX'),

(555,'Philippines','PH','Bagana','BNQ'),

(556,'India','IN','Bagdogra','IXB'),

(557,'Brazil','BR','Bage~ RS','BGX'),

(558,'Iraq','IQ','Baghdad','BGT'),

(561,'Nepal','NP','Baglung','BGL'),

(562,'Canada','CA','Bagotville~ QC','YBG'),

(563,'Philippines','PH','Baguio','BAG'),

(564,'Ethiopia','ET','Bahar Dar','BJR'),

(565,'Pakistan','PK','Bahawalnagar','WGB'),

(566,'Pakistan','PK','Bahawalpur','BHV'),

(567,'Mexico','MX','Bahia Angeles','BHL'),

(568,'Argentina','AR','Bahia Blanca','BHI'),

(569,'Colombia','CO','Bahia Cupica','BHF'),

(570,'Colombia','CO','Bahia Solano','BSC'),

(571,'Bahrain','BH','Bahrain','BAH'),

(572,'Iran','IR','Bahregan','IAQ'),

(573,'Ecuador','EC','Baia de Caraquez','BHA'),

(574,'Romania','RO','Baia Mape','BAY'),

(575,'Papua New Guinea','PG','Baibara','BAP'),

(576,'Somalia','SO','Baidoa','BIB'),

(577,'Canada','CA','Baie-Comeau~ QC','YBC'),

(578,'Canada','CA','Baie Johan Beetz~ QC','YBJ'),

(579,'Papua New Guinea','PG','Baimuru','VMU'),

(580,'USA','US','Bainbridge~ GA','BGE'),

(581,'Papua New Guinea','PG','Baindoung','BDZ'),

(582,'Australia','AU','Bairnsdale~ Victoria','BSJ'),

(583,'Nepal','NP','Baitadi','BIT'),

(584,'Papua New Guinea','PG','Baiyer River','BYV'),

(585,'Indonesia','ID','Bajawa','BJW'),

(586,'Nepal','NP','Bajhang','BJH'),

(587,'Mozambique','MZ','Bajone','BJN'),

(588,'Nepal','NP','Bajura','BJU'),

(589,'Malaysia','MY','Bakalalan~ Sarawak','BKM'),

(590,'Senegal','SN','Bakel','BXE'),

(591,'USA','US','Baker City~ OR','BKE'),

(592,'Baker Island','US','Baker Island','BAR'),

(593,'Canada','CA','Baker Lake~ NT','YBK'),

(594,'USA','US','Bakersfield~ CA','BFL'),

(595,'Azerbaijan','AZ','Baki (Baku)~ Naxcivan','BAK'),

(596,'Iceland','IS','Bakkafjordur','BJD'),

(597,'Central African Republic','CF','Bakouma','BMF'),

(598,'Russia','RU','Balakovo~ Saratov','BWO'),

(599,'Solomon Islands','SB','Balalae','BAS'),

(600,'Panama','PA','Balboa','BLB'),

(601,'Panama','PA','Balboa/Fort Kobbe','HOW'),

(602,'Australia','AU','Balcanoona~ South Australia','LCN'),

(603,'Philippines','PH','Baler','BQA'),

(604,'Australia','AU','Balgo Hills~ Western Australia','BQW'),

(605,'Kazakhstan','KZ','Balhash','BXH'),

(606,'Cameroon','CM','Bali','BLC'),

(607,'Papua New Guinea','PG','Bali','BAJ'),

(608,'Turkey','TR','Balikesir','BZI'),

(609,'Indonesia','ID','Balikpapan','BPN'),

(610,'Papua New Guinea','PG','Balimo','OPU'),

(611,'Australia','AU','Ballina~ New South Wales','BNK'),

(612,'United Kingdom','GB','Ballykelly~ Northern Ireland','BOL'),

(613,'Chile','CL','Balmaceda','BBA'),

(614,'Australia','AU','Balranald~ New South Wales','BZD'),

(615,'Brazil','BR','Balsas~ MA','BSS'),

(616,'USA','US','Baltimore~ MD','BWI'),

(618,'Ecuador','EC','Baltra Island~ Galapagos','WGL'),

(619,'Germany','DE','Baltrum','BMR'),

(620,'India','IN','Balurghat','RGH'),

(621,'Mali','ML','Bamako','BKO'),

(622,'Central African Republic','CF','Bambari','BBY'),

(623,'Kenya','KE','Bamburi','BMQ'),

(624,'Cameroon','CM','Bamenda','BPC'),

(625,'Iran','IR','Bamerny','BMN'),

(626,'Canada','CA','Bamfield~ BC','YBF'),

(627,'Afghanistan','AF','Bamiyan','BIN'),

(628,'Papua New Guinea','PG','Bamu','BMZ'),

(629,'Laos','LA','Ban Houei Sai','QUI'),

(630,'Thailand','TH','Ban Mak Khaeng','BAO'),

(631,'Vietnam','VN','Ban Me Thout','BMV'),

(632,'Indonesia','ID','Banaina','NAF'),

(633,'Indonesia','ID','Banda Aceh (Kuturaja)','BTJ'),

(634,'Indonesia','ID','Bandanaira','NDA'),

(635,'Iran','IR','Bandar Abbas','BND'),

(636,'Indonesia','ID','Bandar Lampung','TKG'),

(637,'Iran','IR','Bandar Lengeh','BDH'),

(638,'Brunei','BN','Bandar Seri Begwan','BWN'),

(639,'Turkey','TR','Bandirma','BDM'),

(640,'USA','US','Bandon~ OR','BDY'),

(641,'Zaire','ZR','Bandundu','FDU'),

(642,'Indonesia','ID','Bandung','BDO'),

(643,'Canada','CA','Banff~ AB','YBA'),

(644,'Burkina Faso','BF','Banfora','BNR'),

(645,'India','IN','Bangalore','BLR'),

(646,'Central African Republic','CF','Bangassou','BGU'),

(647,'Thailand','TH','Bangkok','BKK'),

(648,'USA','US','Bangor~ ME','BGR'),

(649,'Central African Republic','CF','Bangui','BGF'),

(650,'Bosnia-Herzegovina','BA','Banja Luka','BNX'),

(651,'Indonesia','ID','Banjarmarsin','BDJ'),

(652,'Gambia','GM','Banjul','BJL'),

(653,'Australia','AU','Bankstown~ New South Wales','BWU'),

(654,'Vietnam','VN','Banmethuot','BWV'),

(655,'USA','US','Banning~ CA','BNG'),

(656,'Pakistan','PK','Bannu','BNP'),

(657,'Ireland','IE','Bantry','BYT'),

(658,'Papua New Guinea','PG','Banz','BNZ'),

(659,'China','CN','Baoshan','BSD'),

(660,'China','CN','Baotou','BAV'),

(661,'Papua New Guinea','PG','Bapi','BPD'),

(662,'USA','US','Bar Harbor~ ME','BHB'),

(663,'Cuba','CU','Baracoa','BCA'),

(664,'Dominican Republic','DO','Barahona','BRX'),

(665,'Solomon Islands','SB','Barakoma','VEV'),

(666,'Guyana','GY','Baramita','BMJ'),

(667,'USA','US','Baranof~ AK','BNF'),

(668,'Yemen','YE','Barat','TTV'),

(669,'Barbados','BB','(Bridgetown','BGI'),

(670,'Antigua and Barbuda','AG','Barbuda (Codrington)~ Barbuda Is','BBQ'),

(671,'Australia','AU','Barcaldine~ Queensland','BCI'),

(672,'Spain','ES','Barcelona','BCN'),

(673,'Venezuela','VE','Barcelona','BLA'),

(674,'France','FR','Barcelonnette','BAE'),

(675,'Brazil','BR','Barcelos~ AM','BAZ'),

(676,'Somalia','SO','Bardera','BSY'),

(677,'USA','US','Bardstown~ KY','BRY'),

(678,'Norway','NO','Bardufoss','BDU'),

(679,'Italy','IT','Bari','BRI'),

(680,'Venezuela','VE','Barinas','BNS'),

(681,'Malaysia','MY','Bario~ Sarawak','BBN'),

(682,'Bangladesh','BD','Barisal','BZL'),

(683,'Australia','AU','Barkly Downs~ Queensland','BKP'),

(684,'Russia','RU','Barnaul~ Altay','BAX'),

(685,'USA','US','Barnwell~ SC','BNL'),

(686,'India','IN','Baroda (Vadodara)','BDQ'),

(687,'Solomon Islands','SB','Barora','RRI'),

(688,'Venezuela','VE','Barquisimeto','BRM'),

(689,'Costa Rica','CR','Barra Colorado','BCL'),

(690,'Brazil','BR','Barra do Corda~ MA','BDC'),

(691,'Brazil','BR','Barra do Garcas~ MG','BPG'),

(692,'Brazil','BR','Barra do Pirai~ RJ','QBD'),

(693,'Brazil','BR','Barra Mansa~ RJ','QBN'),

(694,'Brazil','BR','Barra~ BA','BQQ'),

(695,'United Kingdom','GB','Barra~ Scotland','BRR'),

(696,'Colombia','CO','Barranca de Upi','BAC'),

(697,'Colombia','CO','Barrancabermeja','EJA'),

(698,'Colombia','CO','Barrancominas','NBB'),

(699,'Colombia','CO','Barranquilla','BAQ'),

(700,'USA','US','Barre/Montpelier~ VT','MPV'),

(701,'Brazil','BR','Barreiras~ BA','BRA'),

(702,'Brazil','BR','Barreirinhas~ MA','BRB'),

(703,'Brazil','BR','Barretos~ SP','BAT'),

(704,'United Kingdom','GB','Barrow-in-Furness','BWF'),

(705,'Australia','AU','Barrow Island~ Western Australia','BWB'),

(706,'USA','US','Barrow~ AK','BRW'),

(707,'USA','US','Barter Island~ AK','BTI'),

(708,'Germany','DE','Barth','BBH'),

(709,'Guyana','GY','Bartica','GFO'),

(710,'USA','US','Bartlesville~ OK','BVO'),

(711,'USA','US','Bartow~ FL','BOW'),

(712,'Zaire','ZR','Basankusu','BSU'),

(713,'Philippines','PH','Basco','BSO'),

(714,'Switzerland','CH','Basel','BSL'),

(715,'Switzerland/France','CH','Basel/Mulhouse','EAP'),

(716,'Zaire','ZR','Basongo','BAN'),

(717,'Iraq','IQ','Basra','BSR'),

(718,'Guadeloupe','GP','Basse-Terre','BBR'),

(719,'Myanmar','MM','Bassein','BSX'),

(720,'St. Kitts and Nevis','KN','Basseterre~ St. Kitts','SKB'),

(721,'USA','US','Bassett~ NE','RBE'),

(722,'France','FR','Bastia~ Corsica','BIA'),

(723,'Equatorial Guinea','GQ','Bata','BSG'),

(724,'Indonesia','ID','Batam~ Batu Besar','BTH'),

(725,'Central African Republic','CF','Batangafo','BTG'),

(726,'Australia','AU','Batavia Downs~ Queensland','BVW'),

(727,'Australia','AU','Batemans Bay~ New South Wales','QBW'),

(728,'USA','US','Batesville~ AR','BVX'),

(729,'USA','US','Batesville~ IN','HLB'),

(730,'Australia','AU','Bathurst Island~ Northern Territ','BRT'),

(731,'Canada','CA','Bathurst~ NB','ZBF'),

(732,'Australia','AU','Bathurst~ New South Wales','BHS'),

(733,'Turkey','TR','Batman','BAL'),

(734,'Algeria','DZ','Batna','BLJ'),

(735,'Indonesia','ID','Batom','BXM'),

(736,'LA USA','US','Baton Rouge','BTR'),

(737,'Cameroon','CM','Batouri','OUR'),

(738,'Norway','NO','Batsfjord','BJF'),

(739,'Cambodia','KH','Battambang','BBM'),

(740,'Sri Lanka','LK','Batticalca','BTC'),

(741,'USA','US','Battle Creek~ MI','BTL'),

(742,'USA','US','Battle Mountain~ NV','BAM'),

(743,'Indonesia','ID','Batu Licin','BTW'),

(744,'Georgia','GE','Batumi~ Abkhazia','BUS'),

(745,'Indonesia','ID','Baucau','BCH'),

(746,'Nigeria','NG','Bauchi','BCU'),

(747,'USA','US','Baudette~ MN','BDE'),

(748,'Brazil','BR','Bauru~ SP','BAU'),

(749,'Papua New Guinea','PG','Bawan','BWJ'),

(750,'USA','US','Bay City~ TX','BBC'),

(751,'New Zealand','NZ','Bay of Islands','BYO'),

(752,'Cuba','CU','Bayamo','BYM'),

(753,'Germany','DE','Bayreuth','BYU'),

(754,'USA','US','Baytown~ TX','HPY'),

(755,'Australia','AU','Beagle Bay~ Western Australia','BEE'),

(756,'Madagascar','MG','Bealanana','WBE'),

(757,'USA','US','Bear Creek~ AK','BCC'),

(758,'Canada','CA','Bearskin Lake~ ON','XBE'),

(759,'USA','US','Beatrice~ NE','BIE'),

(760,'Canada','CA','Beatton River~ BC','YZC'),

(761,'USA','US','Beatty~ NV','BTY'),

(762,'USA','US','Beaufort~ SC','BFT'),

(763,'USA','US','Beaumont~ TX','BMT'),

(764,'USA','US','Beaumont/Port Arthur~ TX','BPT'),

(765,'France','FR','Beauvais','BVA'),

(766,'USA','US','Beaver Creek~ CO','ZBV'),

(767,'Canada','CA','Beaver Creek~ YT','YXQ'),

(768,'USA','US','Beaver Falls~ PA','BFP'),

(769,'USA','US','Beaver Inlet~ AK','BVD'),

(770,'USA','US','Beaver~ AK','WBQ'),

(771,'Algeria','DZ','Bechar','CBH'),

(772,'USA','US','Beckley~ WV','BKW'),

(773,'Brazil','BR','Bededouro~ SP','QAU'),

(774,'Australia','AU','Bedford Downs~ Western Australia','BDW'),

(775,'USA','US','Bedford~ IN','BFR'),

(776,'USA','US','Bedford~ MA','BED'),

(777,'Australia','AU','Bedourie~ Queensland','BEU'),

(778,'Canada','CA','Bedwell Harbour~ BC','YBW'),

(779,'Israel','IL','Beer Sheba (Beersheba)','BEV'),

(780,'USA','US','Beeville~ TX','NIR'),

(781,'Madagascar','MG','Befandriana','WBD'),

(782,'Australia','AU','Bega~ New South Wales','QBE'),

(783,'Bangladesh','BD','Begamganj','BJP'),

(784,'Ethiopia','ET','Beica','BEI'),

(785,'Libya','LY','Beida','LAQ'),

(786,'Yemen','YE','Beidah','BYD'),

(787,'China','CN','Beihai','BHY'),

(788,'Yemen','YE','Beihan','BHN'),

(789,'China','CN','Beijing (Peking)','PEK'),

(791,'China','CN','Beijing','NAY'),

(792,'Mozambique','MZ','Beira','BEW'),

(793,'Lebanon','LB','Beirut','BEY'),

(794,'Algeria','DZ','Bejaia','BJA'),

(795,'Madagascar','MG','Bekily','OVA'),

(796,'Malaysia','MY','Belaga~ Sarawak','BLG'),

(797,'Brazil','BR','Belem~ PA','BEL'),

(798,'New Caledonia','NC','Belep~ Belep Islands','BMY'),

(799,'United Kingdom','GB','Belfast~ Northern Ireland','BFS'),

(801,'France','FR','Belfort','BOR'),

(802,'India','IN','Belgaum','IXG'),

(803,'Yugoslavia','YU','Belgrade (Beograd)','BEG'),

(804,'Yugoslavia','YU','Belgrade','BJY'),

(805,'Belize','BZ','Belize City','TZA'),

(807,'USA','US','Bell Island~ AK','KBE'),

(808,'Canada','CA','Bella Bella~ BC','ZEL'),

(809,'Canada','CA','Bella Coola~ BC','QBC'),

(810,'Uruguay','UY','Bella Union','BUV'),

(811,'Liberia','LR','Bella Yella','BYL'),

(812,'USA','US','Bellaire~ MI','ACB'),

(813,'India','IN','Bellary','BEP'),

(814,'Peru','PE','Bellavista','BLP'),

(815,'USA','US','Belle Chasse~ LA~ Heliport','BCS'),

(816,'USA','US','Belle Fourche~ SD','EFC'),

(817,'USA','US','Belleville~ IL','BLV'),

(818,'USA','US','Bellevue~ WA','BVU'),

(819,'USA','US','Bellingham~ WA','BLI'),

(820,'Solomon Islands','SB','Bellona','BNY'),

(821,'Italy','IT','Belluno','BLX'),

(822,'USA','US','Belmar/Farmingdale~ NJ','BLM'),

(823,'Brazil','BR','Belmonte~ BA','BVM'),

(824,'Ireland','IE','Belmullet','BLY'),

(825,'Brazil','BR','Belo Horizonte~ MG','BHZ'),

(828,'Madagascar','MG','Belo','BMD'),

(829,'Moldova','MD','Beltsy','BZY'),

(830,'United Kingdom','GB','Bembridge~ England','BBP'),

(831,'Guyana','GY','Bemichi','BCG'),

(832,'USA','US','Bemidji~ MN','BJI'),

(833,'Australia','AU','Benalla~ Victoria','BLN'),

(834,'Papua New Guinea','PG','Benawi','BWP'),

(835,'United Kingdom','GB','Benbecula~ Scotland','BEB'),

(836,'China','CN','Bengbu','BFU'),

(837,'Libya','LY','Benghazi','BEN'),

(838,'Indonesia','ID','Bengkulu~ Sumatra','BKS'),

(839,'Angola','AO','Benguela','BUG'),

(840,'Zaire','ZR','Beni','BNC'),

(841,'Nigeria','NG','Benin City','BNI'),

(842,'Brazil','BR','Benjamin Constant~ AM','QAV'),

(843,'Indonesia','ID','Benjina','BJK'),

(844,'USA','US','Bennettsville~ SC','BTN'),

(845,'Papua New Guinea','PG','Bensbach','BSP'),

(846,'United Kingdom','GB','Benson~ England','BEX'),

(847,'USA','US','Benson~ MN','BBB'),

(848,'Brazil','BR','Bento Goncalves~ RS','BGV'),

(849,'USA','US','Benton Harbor~ MI','BEH'),

(850,'Japan','JP','Beppu','BPU'),

(851,'St. Vincent and the Grenadines','VC','Bequia','BQU'),

(852,'Indonesia','ID','Berau','BEJ'),

(853,'Somalia','SO','Berbera','BBO'),

(854,'Central African Republic','CF','Berberati','BBT'),

(855,'USA','US','Berclair~ TX','NGT'),

(856,'Ukraine','UA','Berdyansk~ Zaporizhzhya','ERD'),

(857,'Papua New Guinea','PG','Bereina','BEA'),

(858,'Canada','CA','Berens River~ MB','YBV'),

(859,'Ivory Coast','CI','Beresy','BBV'),

(860,'Italy','IT','Bergamo','BGY'),

(861,'Norway','NO','Bergen','BGO'),

(862,'France','FR','Bergerac','EGC'),

(863,'USA','US','Berkeley~ CA','JBK'),

(864,'Norway','NO','Berlevag','BVG'),

(865,'Germany','DE','Berlin','BER'),

(869,'USA','US','Berlin~ NH','BML'),

(870,'Bolivia','BO','Bermejo','BJO'),

(871,'Bermuda','BM','Bermuda','NWU'),

(873,'Switzerland','CH','Bern (Berne)','BRN'),

(874,'Switzerland','CH','Bern','ZDJ'),

(875,'Madagascar','MG','Beroroha','WBO'),

(876,'Cameroon','CM','Bertoua','BTA'),

(877,'Kiribati','KI','Beru','BEZ'),

(878,'Madagascar','MG','Besalampy','BPY'),

(879,'USA','US','Bethel~ AK','BET'),

(881,'USA','US','Bethpage~ NY','BPA'),

(882,'Madagascar','MG','Betoiky','BKU'),

(883,'Australia','AU','Betoota~ Queensland','BTX'),

(884,'Cameroon','CM','Betou','BTB'),

(885,'USA','US','Bettles~ AK','BTT'),

(886,'Australia','AU','Beverley Springs~ Western Austra','BVZ'),

(887,'USA','US','Beverly~ MA','BVY'),

(888,'France','FR','Beziers','BZR'),

(889,'Nepal','NP','Bhadrapur','BDP'),

(890,'Nepal','NP','Bhairawa','BWA'),

(891,'Myanmar','MM','Bhamo','BMO'),

(892,'Nepal','NP','Bharatpur','BHR'),

(893,'India','IN','Bhatinda','BUP'),

(894,'India','IN','Bhavnagar','BHU'),

(895,'Nepal','NP','Bhojpur','BHP'),

(896,'India','IN','Bhopal','BHO'),

(897,'India','IN','Bhubaneswar','BBI'),

(898,'India','IN','Bhuj','BHJ'),

(899,'Indonesia','ID','Biak','BIK'),

(900,'Papua New Guinea','PG','Bialla','BAA'),

(901,'France','FR','Biarritz','BIQ'),

(902,'Papua New Guinea','PG','Biaru','BRP'),

(903,'Gabon','GA','Biawonque','BAW'),

(904,'Germany','DE','Bielefeld','BFE'),

(905,'Canada','CA','Big Bay Marina~ BC','YIG'),

(906,'Canada','CA','Big Bay~ BC','YYA'),

(907,'Vanuatu','VU','Big Bay','GBA'),

(908,'USA','US','Big Bear~ CA','RBF'),

(909,'Australia','AU','Big Bell~ Western Australia','BBE'),

(910,'USA','US','Big Creek~ AK','BIC'),

(911,'Belize','BZ','Big Creek','BGK'),

(912,'USA','US','Big Lake~ AK','BGQ'),

(913,'USA','US','Big Mountain~ AK','BMX'),

(914,'USA','US','Big Piney~ WY','BPI'),

(915,'USA','US','Big Rapids~ MI','WBR'),

(916,'USA','US','Big Spring~ TX','BGS'),

(918,'Canada','CA','Big Trout Lake~ ON','YTL'),

(919,'United Kingdom','GB','Biggin Hill~ England','BQH'),

(920,'India','IN','Bikaner','BKB'),

(921,'Marshall Islands','MH','Bikini Atoll','BII'),

(922,'India','IN','Bilaspur','PAB'),

(923,'Spain','ES','Bilbao','BIO'),

(924,'Iceland','IS','Bildudalur','BIU'),

(925,'Australia','AU','Billiluna Station~ Western Austr','BIW'),

(926,'USA','US','Billings~ MT','BIL'),

(927,'Denmark','DK','Billund','BLL'),

(928,'USA','US','Biloxi~ MS','BIX'),

(929,'Indonesia','ID','Bima','BMU'),

(930,'Papua New Guinea','PG','Bimin','BIZ'),

(931,'Bahamas','BS','Bimini (Alice Town)','BIM'),

(932,'Bahamas','BS','Bimini~ Bimini','NSB'),

(933,'NY USA','US','Binghamton','BGM'),

(934,'Papua New Guinea','PG','Biniguni','XBN'),

(935,'Malaysia','MY','Bintulu~ Sarawak','BTU'),

(936,'Indonesia','ID','Bintuni','NTI'),

(937,'Central African Republic','CF','Biraro','IRO'),

(938,'Nepal','NP','Biratnagar','BIR'),

(939,'USA','US','Birch Creek~ AK','KBC'),

(940,'Seychelles','SC','Bird Island','BDI'),

(941,'Australia','AU','Birdsville~ Queensland','BVI'),

(942,'Iran','IR','Birjand','XBJ'),

(943,'USA','US','Birmingham~ AL','ROE'),

(945,'United Kingdom','GB','Birmingham~ England','BHX'),

(946,'Niger','NE','Birni n\'Konni','BKN'),

(947,'USA','US','Bisbee~ AZ','BSQ'),

(948,'Saudi Arabia','SA','Bisha','BHH'),

(949,'Kyrgyzstan','KG','Bishkek (Frunze)~ Chuy','FRU'),

(950,'South Africa','ZA','Bisho','BIY'),

(951,'USA','US','Bishop~ CA','BIH'),

(952,'Algeria','DZ','Biskra','BSK'),

(953,'Philippines','PH','Bislig','BPH'),

(954,'USA','US','Bismarck~ ND','BIS'),

(955,'Guinea Bissau','GN','Bissau','BXO'),

(956,'Gabon','GA','Bitam','BMM'),

(957,'Germany','DE','Bitburg','BBJ'),

(958,'Macedonia','MK','Bitola','QBI'),

(959,'Australia','AU','Bizant~ Queensland','BZP'),

(960,'Canada','CA','Black Tickle~ NF','YBI'),

(961,'Australia','AU','Blackall~ Queensland','BKQ'),

(962,'United Kingdom','GB','Blackbush','BBS'),

(963,'United Kingdom','GB','Blackpool~ England','BLK'),

(964,'USA','US','Blacksburg~ VA','BCB'),

(965,'VA USA','US','Blackstone','BKT'),

(966,'Australia','AU','Blackwater~ Queensland','BLT'),

(967,'USA','US','Blackwell~ OK','BWL'),

(968,'Russia','RU','Blagoveschensk~ Amur','BQS'),

(969,'USA','US','Blaine~ WA','BWS'),

(970,'USA','US','Blairsville~ PA','BSI'),

(971,'USA','US','Blakeley Island~ WA','BYW'),

(972,'Canada','CA','Blanc Sablon~ QC','YBX'),

(973,'USA','US','Blanding~ UT','BDG'),

(974,'Malawi','MW','Blantyre','BLZ'),

(975,'New Zealand','NZ','Blenheim','BHE'),

(976,'USA','US','Block Island~ RI','BID'),

(977,'South Africa','ZA','Bloemfontein','BFN'),

(978,'Iceland','IS','Blonduos','BLO'),

(979,'Canada','CA','Bloodvein River~ MB','YDV'),

(980,'Australia','AU','Bloomfield~ Queensland','BFC'),

(981,'USA','US','Bloomington~ IL','BMI'),

(982,'USA','US','Bloomington~ IN','BMG'),

(983,'Canada','CA','Blubber Bay~ BC','XBB'),

(984,'USA','US','Blue Bell~ PA','BBX'),

(985,'USA','US','Blue Fox Bay~ AK','BFB'),

(986,'Fiji','FJ','Blue Lagoon','BXL'),

(987,'USA','US','Bluefield~ WV','BLF'),

(988,'Nicaragua','NI','Bluefields','BEF'),

(989,'Brazil','BR','Blumenau~ SC','BNU'),

(990,'USA','US','Blythe~ CA','BLH'),

(991,'USA','US','Blytheville~ AR','HKA'),

(993,'Sierra Leone','SL','Bo','KBS'),

(994,'Brazil','BR','Boa Vista~ RR','BVB'),

(995,'Papua New Guinea','PG','Boana','BNV'),

(996,'Papua New Guinea','PG','Boang','BOV'),

(997,'Cape Verde','CV','Boavista~ Boavista','BVC'),

(998,'Canada','CA','Bob Quinn Lake','YBO'),

(999,'Burkina Faso','BF','Bobo/Dioulasso','BOY'),

(1000,'Brazil','BR','Boca do Acre~ AM','BCR'),

(1001,'USA','US','Boca Raton~ FL','BCT'),

(1002,'Panama','PA','Bocas del Toro','BOC'),

(1003,'Germany','DE','Bochum','QBO'),

(1004,'Papua New Guinea','PG','Bodinumu','BNM'),

(1005,'Norway','NO','Bodo','BOO'),

(1006,'Germany','DE','Boeblingen','PHM'),

(1007,'Zaire','ZR','Boende','BNB'),

(1008,'USA','US','Bogalusa~ LA','BXA'),

(1009,'Burkina Faso','BF','Bogande','XBG'),

(1010,'Mauritania','MR','Boghe','BGH'),

(1011,'Colombia','CO','Bogota','BOG'),

(1012,'Bangladesh','BD','Bogra','BGG'),

(1013,'Australia','AU','Boigu Island~ Queensland','GIC'),

(1014,'USA','US','Boise~ ID','BOI'),

(1015,'Guinea','GN','Boke','BKJ'),

(1016,'Indonesia','ID','Bokondini','BUI'),

(1017,'Chad','TD','Bokoro','BKR'),

(1018,'Papua New Guinea','PG','Boku','BOQ'),

(1019,'Chad','TD','Bol','OTC'),

(1020,'Croatia','HR','Bol','BWK'),

(1021,'Indonesia','ID','Bolaang','BJG'),

(1022,'Australia','AU','Bollon~ Queensland','BLS'),

(1023,'Italy','IT','Bologna','BLQ'),

(1024,'Papua New Guinea','PG','Bolovip','BVP'),

(1025,'Australia','AU','Bolwarra~ Queensland','BCK'),

(1026,'Italy','IT','Bolzano (Bozen)','BZO'),

(1028,'Brazil','BR','Bom Jesus da Lapa~ BA','LAZ'),

(1029,'Zaire','ZR','Boma','BOA'),

(1030,'Papua New Guinea','PG','Bomai','BMH'),

(1031,'India','IN','Bombay','BOM'),

(1032,'Netherlands Antilles','NL','Bonaire (Kralendijk)','BON'),

(1033,'Nicaragua','NI','Bonanza','BZA'),

(1034,'Canada','CA','Bonaventure~ QC','YVB'),

(1035,'Ivory Coast','CI','Bondoukou','BDK'),

(1036,'Gabon','GA','Bongo','BGP'),

(1037,'Chad','TD','Bongor','OGR'),

(1038,'Germany','DE','Bonn','BNJ'),

(1039,'Canada','CA','Bonnyville~ AB','YBY'),

(1040,'Indonesia','ID','Bontang','BXT'),

(1041,'Sierra Leone','SL','Bonthe','BTE'),

(1042,'USA','US','Boone~ IA','BNW'),

(1043,'USA','US','Booneville~ MS','WDQ'),

(1044,'Gabon','GA','Boque','BGB'),

(1045,'French Polynesia','PF','Bora Bora~ Society Islands','BOB'),

(1046,'Brazil','BR','Borba','RBB'),

(1047,'France','FR','Bordeaux','BOD'),

(1048,'Canada','CA','Borden~ ON','YBN'),

(1049,'Algeria','DZ','Bordj Badji Mokhtar','BMW'),

(1050,'Iceland','IS','Borgarfjordur','BGJ'),

(1051,'USA','US','Borger~ TX','BGD'),

(1052,'Papua New Guinea','PG','Boridi','BPB'),

(1053,'Germany','DE','Borkum','BMK'),

(1054,'Sweden','SE','Borlange','BLE'),

(1055,'USA','US','Bornite~ AK','RLU'),

(1056,'Venezuela','VE','Borotou','BRZ'),

(1057,'USA','US','Borrego Springs~ CA','BXS'),

(1058,'Australia','AU','Borroloola~ Northern Territory','BOX'),

(1059,'Central African Republic','CF','Bossangoa','BSN'),

(1060,'Somalia','SO','Bossaso','BSA'),

(1061,'Central African Republic','CF','Bossembele','BEM'),

(1062,'Papua New Guinea','PG','Bosset','BSV'),

(1063,'USA','US','Bossier City~ LA','BAD'),

(1064,'Afghanistan','AF','Bost','BST'),

(1065,'USA','US','Boston~ MA','JBC'),

(1067,'USA','US','Boswell Bay~ AK','BSW'),

(1068,'Suriname','SR','Botopasie','BTO'),

(1069,'Brazil','BR','Botucatu~ SP','QCJ'),

(1070,'Algeria','DZ','Bou Saada','BUJ'),

(1071,'Ivory Coast','CI','Bouake','BYK'),

(1072,'Central African Republic','CF','Bouar','BOP'),

(1073,'Central African Republic','CF','Bouca','BCF'),

(1074,'USA','US','Boulder City~ NV','BLD'),

(1075,'USA','US','Boulder~ CO','WBU'),

(1076,'Australia','AU','Boulia~ Queensland','BQL'),

(1077,'Burkina Faso','BF','Boulsa','XBO'),

(1078,'Ivory Coast','CI','Bouna','BQO'),

(1079,'USA','US','Boundary~ AK','BYA'),

(1080,'Ivory Coast','CI','Boundiali','BXI'),

(1081,'Congo','CG','Boundji','BOE'),

(1082,'USA','US','Bountiful~ UT','BTF'),

(1083,'France','FR','Bourg St. Maurice','QBM'),

(1084,'France','FR','Bourges','BOU'),

(1085,'Australia','AU','Bourke~ New South Wales','BRK'),

(1086,'United Kingdom','GB','Bournemouth~ England','BOH'),

(1087,'Chad','TD','Bousso','OUT'),

(1088,'Mauritania','MR','Boutilimit','OTL'),

(1089,'Australia','AU','Bowen~ Queensland','ZBO'),

(1090,'KY USA','US','Bowling Green','BWG'),

(1091,'VA USA','US','Bowling Green/Fort A. P. Hill','APH'),

(1092,'USA','US','Bowman~ ND','BWM'),

(1093,'USA','US','Boxborough~ MA','BXC'),

(1094,'USA','US','Boyne Falls~ MI','BFA'),

(1095,'USA','US','Bozeman~ MT','BZN'),

(1096,'Central African Republic','CF','Bozoum','BOZ'),

(1097,'Libya','LY','Brack','QBF'),

(1098,'United Kingdom','GB','Bradford~ England','BRF'),

(1099,'USA','US','Bradford~ IL','BDF'),

(1100,'USA','US','Bradford~ PA','BFD'),

(1101,'USA','US','Brady~ TX','BBD'),

(1102,'Portugal','PT','Braga','BGZ'),

(1103,'Brazil','BR','Braganca~ PA','BCZ'),

(1104,'Portugal','PT','Braganca','BGC'),

(1105,'Papua New Guinea','PG','Brahman','BRH'),

(1106,'MN USA','US','Brainerd','BRD'),

(1107,'United Kingdom','GB','Braintree~ England','WXF'),

(1108,'Australia','AU','Brampton Island~ Queensland','BMP'),

(1109,'Canada','CA','Brandon~ MB','YBR'),

(1110,'United Kingdom','GB','Brandon','LKZ'),

(1111,'USA','US','Branson~ MO','ZBX'),

(1112,'Canada','CA','Brantford~ ON','YFD'),

(1113,'Brazil','BR','Brasilia~ DF','BSB'),

(1114,'Slovakia','SK','Bratislava','ZRG'),

(1116,'Russia','RU','Bratsk~ Irkutsk','BTK'),

(1117,'Germany','DE','Braunschweig','BWE'),

(1118,'USA','US','Brawley~ CA','BWC'),

(1119,'USA','US','Brazoria~ TX','BZT'),

(1120,'Congo','CG','Brazzaville','BZV'),

(1121,'USA','US','Breckenridge~ CO','QKB'),

(1122,'USA','US','Breckenridge~ TX','BKD'),

(1123,'Iceland','IS','Breiddalsvik','BXV'),

(1124,'Germany','DE','Bremen','XLW'),

(1126,'Germany','DE','Bremerhaven','BRV'),

(1127,'USA','US','Bremerton~ WA','PWT'),

(1128,'Italy','IT','Brescia','QBS'),

(1129,'France','FR','Brest','BES'),

(1130,'Belarus','BY','Brest~ Brest','BQT'),

(1131,'Brazil','BR','Breves~ PA','BVS'),

(1132,'USA','US','Brevig Mission~ AK','KTS'),

(1133,'Canada','CA','Brevoort~ NT','XAS'),

(1134,'Australia','AU','Brewarrina~ New South Wales','BWQ'),

(1135,'Russia','RU','Brezhnev','BZH'),

(1136,'Central African Republic','CF','Bria','BIV'),

(1137,'USA','US','Bridgeport~ CT','BDR'),

(1138,'USA','US','Bridgewater~ VA','VBW'),

(1139,'USA','US','Brigham City~ UT','BMC'),

(1140,'Australia','AU','Bright~ Victoria','BRJ'),

(1141,'Australia','AU','Brighton Downs~ Queensland','BHT'),

(1142,'United Kingdom','GB','Brighton~ England','BSH'),

(1143,'Italy','IT','Brindisi','BDS'),

(1144,'Australia','AU','Brisbane~ Queensland','BNE'),

(1145,'United Kingdom','GB','Bristol~ England','BRS'),

(1146,'USA','US','Britton~ SD','TTO'),

(1147,'France','FR','Brive-La-Gaillarde','BVE'),

(1148,'Czech Republic','CZ','Brno','BRQ'),

(1149,'USA','US','Broadus~ MT','BDX'),

(1150,'Canada','CA','Broadview~ SK','YDR'),

(1151,'Canada','CA','Brochet~ MB','YBT'),

(1152,'Canada','CA','Brockville~ ON','XBR'),

(1153,'USA','US','Broken Bow~ NE','BBW'),

(1154,'Australia','AU','Broken Hill~ New South Wales','BHQ'),

(1155,'Canada','CA','Bromont~ QC','ZBM'),

(1156,'Norway','NO','Bronnoysund (Broennoeysund)','BNN'),

(1157,'Canada','CA','Bronson Creek~ BC','YBM'),

(1158,'USA','US','Brookings~ OR','BOK'),

(1159,'USA','US','Brookings~ SD','BKX'),

(1160,'AK USA','US','Brooks Camp (Katmai National Par','BKF'),

(1161,'AK USA','US','Brooks Lodge (Katmai National Pa','RBH'),

(1162,'USA','US','Brooksville~ FL','BKV'),

(1163,'Australia','AU','Broome~ Western Australia','BME'),

(1164,'Canada','CA','Broughton Island~ NT','YVM'),

(1165,'TX USA','US','Brownsville','BRO'),

(1166,'USA','US','Brownwood~ TX','BWD'),

(1167,'Germany','DE','Bruggen','BGN'),

(1168,'Brazil','BR','Brumado~ BA','BMS'),

(1169,'Australia','AU','Brunette Downs~ Northern Territo','BTD'),

(1170,'USA','US','Brunswick~ GA','BQK'),

(1173,'USA','US','Brunswick~ ME','NHZ'),

(1174,'Honduras','HN','Brus Laguna','BHG'),

(1175,'Brazil','BR','Brusque~ SC','QAB'),

(1176,'Belgium','BE','Brussels (Bruxelles)','BRU'),

(1177,'USA','US','Bryan~ TX','CFD'),

(1178,'Russia','RU','Bryansk~ Bryansk','BZK'),

(1179,'USA','US','Bryce Canyon~ UT','BCE'),

(1180,'Fiji','FJ','Bua','BVF'),

(1181,'Guinea Bissau','GN','Bubaque','BQE'),

(1182,'Colombia','CO','Bucaramanga','BGA'),

(1183,'Liberia','LR','Buchanan','UCN'),

(1184,'Canada','CA','Buchans~ NF','YZM'),

(1185,'Romania','RO','Bucharest','BBU'),

(1188,'USA','US','Buckeye~ AZ','BXK'),

(1189,'USA','US','Buckland~ AK','BKC'),

(1190,'Hungary','HU','Budapest','BUD'),

(1191,'Iceland','IS','Budardalur','BQD'),

(1192,'Yugoslavia','YU','Budva','QBA'),

(1193,'Colombia','CO','Buenaventura','BUN'),

(1194,'Argentina','AR','Buenos Aires','AEP'),

(1197,'Costa Rica','CR','Buenos Aires','BAI'),

(1198,'Canada','CA','Buffalo Narrows~ SK','YVT'),

(1199,'Zimbabwe','ZW','Buffalo Range','BFO'),

(1200,'USA','US','Buffalo~ NY','BUF'),

(1201,'USA','US','Buffalo~ WY','BYG'),

(1202,'Russia','RU','Bugulma~ Tatarstan','UUA'),

(1203,'Papua New Guinea','PG','Buin','UBI'),

(1204,'Burundi','BI','Bujumbura','BJM'),

(1205,'Papua New Guinea','PG','Buka','BUA'),

(1206,'Zaire','ZR','Bukavu','BKY'),

(1207,'Uzbekhistan','UZ','Bukhoro (Bukhara)~ Bukhara','BHK'),

(1208,'Tanzania','TZ','Bukoba','BKZ'),

(1209,'Zimbabwe','ZW','Bulawayo','BUQ'),

(1210,'Ethiopia','ET','Bulchi','BCY'),

(1211,'Australia','AU','Bulimba~ Queensland','BIP'),

(1212,'Canada','CA','Bull Harbour~ BC','YBH'),

(1213,'UT USA','US','Bullfrog Basin (Glen Canyon NRA)','BFG'),

(1214,'USA','US','Bullhead City~ AZ','BHC'),

(1215,'Papua New Guinea','PG','Bulolo','BUL'),

(1216,'Zaire','ZR','Bumba','BMB'),

(1217,'Australia','AU','Bunbury~ Western Australia','BUY'),

(1218,'Australia','AU','Bundaberg~ Queensland','BDB'),

(1219,'Papua New Guinea','PG','Bundi','BNT'),

(1220,'Zaire','ZR','Bunia','BUX'),

(1221,'Ethiopia','ET','Buno Bedelle','XBL'),

(1222,'Indonesia','ID','Bunyu','BYQ'),

(1223,'Indonesia','ID','Buol~ New Guinea','UOL'),

(1224,'Oman','OM','Buraimi','RMB'),

(1225,'Somalia','SO','Burao','BUO'),

(1226,'USA','US','Burbank~ CA','BUR'),

(1227,'Fiji','FJ','Bureta','LEV'),

(1228,'Bulgaria','BG','Burgas (Bourgas)','BOJ'),

(1229,'Australia','AU','Burketown~ Queensland','BUC'),

(1230,'USA','US','Burley~ ID','BYI'),

(1231,'USA','US','Burlington~ IA','BRL'),

(1232,'USA','US','Burlington~ KS','UKL'),

(1233,'USA','US','Burlington~ MA','BBF'),

(1234,'Canada','CA','Burlington~ ON','ZBA'),

(1235,'USA','US','Burlington~ VT','BTV'),

(1236,'Australia','AU','Burnie (Wynyard)~ Tasmania','BWT'),

(1237,'Canada','CA','Burns Lake~ BC','YPZ'),

(1238,'USA','US','Burns~ OR','BNO'),

(1239,'Turkey','TR','Bursa','BTZ'),

(1240,'United Kingdom','GB','Burtonwood','BUT'),

(1241,'Canada','CA','Burwash Landing~ YT','YDB'),

(1242,'USA','US','Burwell~ NE','BUB'),

(1243,'United Kingdom','GB','Bury St. Edmunds~ England','BEQ'),

(1244,'Iran','IR','Bushehr','BUZ'),

(1245,'Philippines','PH','Busuanga','XCN'),

(1246,'Zaire','ZR','Buta','BZU'),

(1247,'Rwanda','RW','Butare','BTQ'),

(1248,'Kiribati','KI','Butaritari','BBG'),

(1249,'USA','US','Butler~ MO','BUM'),

(1250,'USA','US','Butler~ PA','BTP'),

(1251,'Indonesia','ID','Buton Babau','BUW'),

(1252,'USA','US','Butte~ MT','BTM'),

(1253,'Malaysia','MY','Butterworth','BWH'),

(1254,'South Africa','ZA','Butterworth','UTE'),

(1255,'Philippines','PH','Butuan','BXU'),

(1256,'Ivory Coast','CI','Buyo','BUU'),

(1257,'Brazil','BR','Buzios','BZC'),

(1258,'Poland','PL','Bydgoszcz','BZG'),

(1259,'Canada','CA','Byron Bay~ NT','YUK'),

(1260,'Australia','AU','Byron Bay~ Queensland','QYN'),

(1261,'Vietnam','VN','Ca Mau','CAH'),

(1262,'Peru','PE','Caballococha','LHC'),

(1263,'Venezuela','VE','Cabimas','CBS'),

(1264,'USA','US','Cabin Creek~ AK','CBZ'),

(1265,'Angola','AO','Cabinda','CAB'),

(1266,'Dominican Republic','DO','Cabo Rojo','CBJ'),

(1267,'USA','US','Cabool~ MO','TVB'),

(1268,'Brazil','BR','Caceres~ MG','CCX'),

(1269,'Brazil','BR','Cachoeira do Sul~ RS','QDB'),

(1270,'Brazil','BR','Cachoeira~ BA','CCQ'),

(1271,'USA','US','Cadillac~ MI','CAD'),

(1272,'France','FR','Caen','CFR'),

(1273,'Philippines','PH','Cagayan de Oro','CGY'),

(1274,'Philippines','PH','Cagayan de Sulu','CDY'),

(1275,'Italy','IT','Cagliari~ Sardinia','CAG'),

(1276,'USA','US','Cahokia~ IL/St. Louis~ MO','CPS'),

(1277,'France','FR','Cahors','ZAO'),

(1278,'Venezuela','VE','Caicara','CXA'),

(1279,'Australia','AU','Caiguma','CGV'),

(1280,'Australia','AU','Cairns~ Queensland','CNS'),

(1281,'Egypt','EG','Cairo','CAI'),

(1282,'USA','US','Cairo~ IL','CIR'),

(1283,'Brazil','BR','Caixas do Sul~ RS','QXJ'),

(1284,'Peru','PE','Cajamarca','CJA'),

(1285,'Nigeria','NG','Calabar','CBQ'),

(1286,'Venezuela','VE','Calabozo','CLZ'),

(1287,'France','FR','Calais','CQF'),

(1288,'Chile','CL','Calama','CJC'),

(1289,'Philippines','PH','Calapan','CPP'),

(1290,'Philippines','PH','Calbayog','CYP'),

(1291,'India','IN','Calcutta','CCU'),

(1292,'Brazil','BR','Caldas Novas~ GO','CLV'),

(1293,'USA','US','Caldwell~ NJ','CDW'),

(1294,'Panama','PA','Caledonia','CDE'),

(1295,'Chile','CL','Caleta Josefina','WCJ'),

(1296,'Argentina','AR','Caleta Olivia','CVI'),

(1297,'USA','US','Calexico~ CA','CXL'),

(1298,'Canada','CA','Calgary~ AB','YYC'),

(1299,'Colombia','CO','Cali','CLO'),

(1300,'India','IN','Calicut','CCJ'),

(1301,'USA','US','Calipatria~ CA','CLR'),

(1302,'GA USA','US','Callaway Gardens','CWG'),

(1303,'Australia','AU','Caloundra~ Queensland','CUD'),

(1304,'NY USA','US','Calverton','CTO'),

(1305,'France','FR','Calvi~ Corsica','CLY'),

(1306,'Brazil','BR','Camacari~ BA','QCC'),

(1307,'Cuba','CU','Camaguey','CMW'),

(1308,'Angola','AO','Camaxilo','CXM'),

(1309,'Canada','CA','Cambridge Bay~ NT','YCB'),

(1310,'Iceland','IS','Cambridge Highlands~ MA','DJS'),

(1311,'USA','US','Cambridge~ MA','JHY'),

(1312,'USA','US','Cambridge~ MD','CGE'),

(1313,'United Kingdom','GB','Cambridge','CBG'),

(1314,'USA','US','Camden~ AR','CDH'),

(1315,'Australia','AU','Camden~ New South Wales','CDU'),

(1316,'USA','US','Camden~ SC','CDN'),

(1317,'USA','US','Cameron~ MO','EZZ'),

(1318,'Brazil','BR','Cameta','CMT'),

(1319,'Australia','AU','Camfield~ Northern Territory','CFI'),

(1320,'Philippines','PH','Camiguin','CGM'),

(1321,'USA','US','Camilla~ GA','CXU'),

(1322,'Bolivia','BO','Camiri','CAM'),

(1323,'Brazil','BR','Camocim~ CE','CMC'),

(1324,'Australia','AU','Camooweal~ Queensland','CML'),

(1325,'USA','US','Camp Douglas~ WI','VOK'),

(1326,'USA','US','Camp Pohakuloa~ HI','BSF'),

(1327,'USA','US','Camp Roberts (San Miguel)~ CA','SYL'),

(1328,'AR USA','US','Camp Robinson (Little Rock)','RBM'),

(1329,'USA','US','Camp Springs~ MD','ADW'),

(1331,'Canada','CA','Campbell River~ BC','YBL'),

(1333,'Pakistan','PK','Campbellpore','CWP'),

(1334,'United Kingdom','GB','Campbeltown','CAL'),

(1335,'Mexico','MX','Campeche','CPE'),

(1336,'Brazil','BR','Campina Grande~ PB','CPV'),

(1337,'Brazil','BR','Campinas~ SP','CPQ'),

(1338,'Brazil','BR','Campo Bom~ RS','QCD'),

(1339,'Brazil','BR','Campo do Arag','CMP'),

(1340,'Brazil','BR','Campo Grande~ MS','CGR'),

(1341,'USA','US','Campo~ CA','CZZ'),

(1342,'Brazil','BR','Campos do Jordao','QJO'),

(1343,'Brazil','BR','Campos~ RJ','CAW'),

(1344,'Vietnam','VN','Can Tho','VCA'),

(1345,'Brazil','BR','Cana Brava~ PA','NBV'),

(1346,'USA','US','Canadian~ TX','HHF'),

(1347,'Venezuela','VE','Canaima','CAJ'),

(1348,'Turkey','TR','Canakkale','CKZ'),

(1349,'Mexico','MX','Cananea','CNA'),

(1350,'Costa Rica','CR','Canas','CSC'),

(1351,'Brazil','BR','Canavieiras~ BA','CNV'),

(1352,'Australia','AU','Canberra~ Australian Capital Ter','CBR'),

(1353,'Mexico','MX','Cancun','CUN'),

(1354,'Somalia','SO','Candala','CXN'),

(1355,'Colombia','CO','Candilejas','CJD'),

(1356,'USA','US','Candle~ AK','CDL'),

(1357,'Brazil','BR','Canelas~ RS','QCN'),

(1358,'Angola','AO','Cangamba','CNZ'),

(1359,'France','FR','Cannes','CEQ'),

(1360,'Brazil','BR','Canoas~ RS','QNS'),

(1361,'Australia','AU','Canobie~ Queensland','CBY'),

(1362,'Brazil','BR','Canoinhas~ SC','QNH'),

(1363,'USA','US','Canon City~ CO','CNE'),

(1364,'St. Vincent and the Grenadines','VC','Canouan Island','CIW'),

(1365,'Kiribati','KI','Canton Island','CIS'),

(1366,'USA','US','Canton~ IL','CTK'),

(1367,'Haiti','HT','Cap Haitien','CAP'),

(1368,'Senegal','SN','Cap Skirring','CSK'),

(1369,'Canada','CA','Cape Dorset~ NT','YTE'),

(1370,'Canada','CA','Cape Dyer~ NT','YVN'),

(1371,'Bahamas','BS','Cape Eleuthera','CEL'),

(1372,'Australia','AU','Cape Flattery','CQP'),

(1373,'USA','US','Cape Girardeau~ MO','CGI'),

(1374,'Papua New Guinea','PG','Cape Gloucester','CGC'),

(1375,'Canada','CA','Cape Hooper~ NT','YUZ'),

(1376,'USA','US','Cape Lisburne~ AK','LUR'),

(1377,'USA','US','Cape May (Wildwood)~ NJ','WWD'),

(1378,'USA','US','Cape Newenham~ AK','EHM'),

(1379,'Liberia','LR','Cape Palmas','CPA'),

(1380,'Canada','CA','Cape Parry~ NT','ZUE'),

(1381,'USA','US','Cape Pole~ AK','CZP'),

(1382,'USA','US','Cape Romanzof~ AK','CZF'),

(1383,'Papua New Guinea','PG','Cape Rooney','CPN'),

(1384,'USA','US','Cape Sarichef~ AK','CSH'),

(1385,'USA','US','Cape Spencer~ AK','CSP'),

(1386,'Vietnam','VN','Cape St. Jacques','CSJ'),

(1387,'Canada','CA','Cape St. James~ BC','YCJ'),

(1388,'South Africa','ZA','Cape Town','CPT'),

(1390,'Papua New Guinea','PG','Cape Vogel','CVL'),

(1391,'USA','US','Cape Yakataga~ AK','CYT'),

(1392,'Australia','AU','Cape York~ Queensland','ABM'),

(1393,'Canada','CA','Cape Young~ NT','YUI'),

(1394,'Italy','IT','Capri','PRJ'),

(1395,'Colombia','CO','Capurgana','CPB'),

(1396,'Colombia','CO','Caquetania','CQT'),

(1397,'India','IN','Car Nicobar','CBD'),

(1398,'Venezuela','VE','Caracas','CCS'),

(1399,'Brazil','BR','Carajas~ PA','CKS'),

(1400,'Romania','RO','Caransebes','CSB'),

(1401,'Brazil','BR','Carauari~ AM','CAF'),

(1402,'Brazil','BR','Caravelas~ BA','CRQ'),

(1403,'USA','US','Carbondale/Murphysboro~ IL','MDH'),

(1404,'France','FR','Carcassonne','CCF'),

(1405,'United Kingdom','GB','Cardiff','CWL'),

(1406,'Canada','CA','Caribou Island~ ON','YCI'),

(1407,'USA','US','Caribou~ ME','CAR'),

(1408,'Colombia','CO','Carimagua','CCO'),

(1409,'United Kingdom','GB','Carlisle','CAX'),

(1410,'USA','US','Carlsbad~ CA','CLD'),

(1411,'USA','US','Carlsbad~ NM','CNM'),

(1412,'Australia','AU','Carlton Hill~ Western Australia','CRY'),

(1413,'Guatemala','GT','Carmelita','CMM'),

(1414,'Argentina','AR','Carmen de Patagones','CPG'),

(1415,'Australia','AU','Carnarvon~ Western Australia','CVQ'),

(1416,'Central African Republic','CF','Carnot','CRF'),

(1417,'Brazil','BR','Carolina~ MA','CLN'),

(1418,'Venezuela','VE','Carora','VCR'),

(1419,'Canada','CA','Carp~ ON','YRP'),

(1420,'Australia','AU','Carpentaria Downs~ Queensland','CFP'),

(1421,'Grenada','GD','Carriacou','CRU'),

(1422,'Ireland','IE','Carrickfinn','CFN'),

(1423,'Costa Rica','CR','Carrillo','RIK'),

(1424,'USA','US','Carrizo Springs~ TX','CZT'),

(1425,'USA','US','Carroll~ IA','CIN'),

(1426,'USA','US','Carrollton~ GA','CTJ'),

(1427,'USA','US','Carson City~ NV','CSN'),

(1428,'Colombia','CO','Cartagena de Indias','CTG'),

(1429,'Colombia','CO','Cartago','CRC'),

(1430,'USA','US','Cartersville~ GA','VPC'),

(1431,'Panama','PA','Carti','CTE'),

(1432,'Canada','CA','Cartierville~ QC','YCV'),

(1433,'Canada','CA','Cartwright~ NF','YRF'),

(1434,'Brazil','BR','Caruaru~ PE','CAU'),

(1435,'Venezuela','VE','Carupano','CUP'),

(1436,'Colombia','CO','Caruru','CUO'),

(1437,'Brazil','BR','Carutapera~ MA','CTP'),

(1438,'USA','US','Casa Grande~ AZ','CGZ'),

(1439,'Morocco','MA','Casablanca','CMN'),

(1441,'Mexico','MX','Casas Grandes','NCG'),

(1442,'USA','US','Cascade Locks~ OR','CZK'),

(1443,'Brazil','BR','Cascavel~ PR','CAC'),

(1444,'Philippines','PH','Casiguran','CGG'),

(1445,'Australia','AU','Casino~ New South Wales','CSI'),

(1446,'Venezuela','VE','Casiqua','CUV'),

(1447,'USA','US','Casper~ WY','CPR'),

(1448,'Brazil','BR','Cassilandia~ MG','CSS'),

(1449,'Fiji','FJ','Castaway','CST'),

(1450,'Ireland','IE','Castlebar','CLB'),

(1451,'Canada','CA','Castlegar~ BC','YCG'),

(1452,'France','FR','Castres','DCM'),

(1453,'Chile','CL','Castro','WCA'),

(1454,'Brazil','BR','Castunhal~ PA','QHL'),

(1455,'Colombia','CO','Casuarito','CSR'),

(1456,'Bahamas','BS','Cat Cay','CXY'),

(1457,'Bahamas','BS','Cat Island','CAT'),

(1458,'Canada','CA','Cat Lake~ ON','YAC'),

(1459,'Honduras','HN','Catacamas','CAA'),

(1460,'Brazil','BR','Cataguases~ MG','QCS'),

(1461,'Brazil','BR','Catalao~ GO','TLZ'),

(1462,'Argentina','AR','Catamarca','CTC'),

(1463,'Brazil','BR','Catanduva~ SP','QDE'),

(1464,'Italy','IT','Catania~ Sicily','CTA'),

(1465,'Italy','IT','Catanzaro','QCZ'),

(1466,'Philippines','PH','Catarman','CRM'),

(1467,'Mexico','MX','Catavina','CTV'),

(1468,'Australia','AU','Cattle Creek','CTR'),

(1469,'Philippines','PH','Cauayan','CYZ'),

(1470,'Colombia','CO','Caucasia','CAQ'),

(1471,'Argentina','AR','Caviahue','CVH'),

(1472,'Brazil','BR','Caxias do Sul~ RS','CXJ'),

(1473,'Belize','BZ','Caye Chapel','CYC'),

(1474,'French Guyana','GF','Cayenne','CAY'),

(1475,'Cayman Islands','KY','Cayman Brac~ Cayman Brac','CYB'),

(1476,'Cuba','CU','Cayo Largo del Sur','CYO'),

(1477,'Colombia','CO','Cazombo','CAV'),

(1478,'Philippines','PH','Cebu','CEB'),

(1479,'USA','US','Cedar City~ UT','CDC'),

(1480,'USA','US','Cedar Key~ FL','CDK'),

(1481,'USA','US','Cedar Rapids~ IA','CID'),

(1482,'Mexico','MX','Cedros Island','CDI'),

(1483,'Australia','AU','Ceduna~ South Australia','CED'),

(1484,'USA','US','Celina~ OH','CQA'),

(1485,'USA','US','Center Island~ WA','CWS'),

(1486,'USA','US','Centerville~ IA','TVK'),

(1487,'USA','US','Centerville~ TN','GHM'),

(1488,'USA','US','Central~ AK','CEM'),

(1489,'USA','US','Centralia~ IL','ENL'),

(1490,'Canada','CA','Centralia~ ON','YCE'),

(1491,'Indonesia','ID','Cepu','CPF'),

(1492,'Argentina','AR','Ceres','CRR'),

(1493,'Chile','CL','Cerro Sombrero','SMB'),

(1494,'Australia','AU','Cessnock~ New South Wales','CES'),

(1495,'Peru','PE','Chachapoyas','CHH'),

(1496,'USA','US','Chadron~ NE','CDR'),

(1497,'Iran','IR','Chah Bahar','ZBR'),

(1498,'Chile','CL','Chaiten','WCH'),

(1499,'Afghanistan','AF','Chakcharan','CCN'),

(1500,'USA','US','Chalkyitsik~ AK','CIK'),

(1501,'USA','US','Challis~ ID','CHL'),

(1502,'France','FR','Chambery','CMF'),

(1503,'IL USA','US','Champaign (Urbana)','CMI'),

(1504,'Chile','CL','Chanaral','CNR'),

(1505,'USA','US','Chandalar Lake~ AK','WCR'),

(1506,'India','IN','Chandigarh','IXC'),

(1507,'USA','US','Chandler~ AZ','CHD'),

(1509,'Taiwan','TW','Chang Hua','CJE'),

(1510,'China','CN','Changchun','CGQ'),

(1511,'China','CN','Changde','CGD'),

(1512,'China','CN','Changsha','CSX'),

(1513,'Panama','PA','Changuinola','CHX'),

(1514,'China','CN','Changzhi','CIH'),

(1515,'China','CN','Changzhou','CZX'),

(1516,'Greece','GR','Chania (Khania)','CHQ'),

(1517,'USA','US','Chanute~ KS','CNU'),

(1518,'China','CN','Chaoyang','CHG'),

(1519,'Colombia','CO','Chaparral','CPL'),

(1520,'Brazil','BR','Chapeco~ SC','XAP'),

(1521,'Canada','CA','Chapleau~ ON','YLD'),

(1522,'Argentina','AR','Charata','CNT'),

(1523,'Turkmenistan','TM','Charjeu (Chardzhou)~ Lebap','CRZ'),

(1524,'Belgium','BE','Charleroi','CRL'),

(1525,'USA','US','Charles City~ IA','CCY'),

(1526,'USA','US','Charleston~ SC','JZI'),

(1527,'SC USA','US','Charleston','CHS'),

(1528,'USA','US','Charleston~ WV','CRW'),

(1529,'St. Kitts and Nevis','KN','Charlestown~ Nevis','NEV'),

(1530,'Australia','AU','Charleville~ Queensland','CTL'),

(1531,'USA','US','Charlevoix~ MI','CVX'),

(1532,'Canada','CA','Charlo~ NB','YCL'),

(1533,'U.S. Virgin Islands','US','Charlotte Amalie~ Seaplane Base','SPB'),

(1534,'U.S. Virgin Islands','US','Charlotte Amalie~ St. Thomas','STT'),

(1535,'USA','US','Charlotte~ NC','CLT'),

(1536,'VA USA','US','Charlottesville','CHO'),

(1537,'Canada','CA','Charlottetown~ NF','YHG'),

(1538,'Canada','CA','Charlottetown~ PE','YYG'),

(1539,'Brazil','BR','Charquedas~ RS','QDA'),

(1540,'Australia','AU','Charters Towers~ Queensland','CXT'),

(1541,'USA','US','Chase City~ VA','CXE'),

(1542,'France','FR','Chateauroux','CHR'),

(1543,'New Zealand','NZ','Chatham Island','CHT'),

(1544,'USA','US','Chatham~ AK','CYM'),

(1545,'USA','US','Chatham~ MA','CQX'),

(1546,'Canada','CA','Chatham~ NB','YCH'),

(1547,'Canada','CA','Chatham~ ON','XCM'),

(1548,'USA','US','Chattanooga~ TN','CHA'),

(1549,'Nepal','NP','Chaurjhari','CJR'),

(1550,'Portugal','PT','Chaves','CHV'),

(1551,'Russia','RU','Cheboksary~ Chuvashia','CSY'),

(1552,'USA','US','Chefornak~ AK','CYF'),

(1553,'USA','US','Chehalis~ WA','CLS'),

(1554,'South Korea','KR','Cheju','JSP'),

(1557,'Russia','RU','Chelyabinsk~ Chelyabinsk','CEK'),

(1558,'USA','US','Chena Hot Springs~ AK','CEX'),

(1559,'China','CN','Chengdu','CTU'),

(1560,'China','CN','Chengteh','CEH'),

(1561,'USA','US','Cheraw~ SC','HCW'),

(1562,'France','FR','Cherbourg','CER'),

(1563,'Ukraine','UA','Cherkasy~ Cherkasy','CKC'),

(1564,'Ukraine','UA','Chernihiv (Chernigov)~ Chernihiv','CEJ'),

(1565,'Ukraine','UA','Chernivtsi (Chernovtsy)~ Cherniv','CWC'),

(1566,'USA','US','Chernofski Harbor~ AK','KCN'),

(1567,'Bahamas','BS','Cherokee Sound','CQZ'),

(1568,'USA','US','Cherokee Village~ AR','CKK'),

(1569,'USA','US','Cherokee~ IA','CKP'),

(1570,'USA','US','Cherokee~ OK','CKA'),

(1571,'Australia','AU','Cherrabun~ Western Australia','CBC'),

(1572,'Australia','AU','Cherribah~ Queensland','CRH'),

(1573,'USA','US','Cherry Point~ NC','NKT'),

(1574,'USA','US','Chesapeake~ OH/Huntington~ WV','HTW'),

(1575,'USA','US','Chesapeake~ VA','CPK'),

(1576,'United Kingdom','GB','Chester','CEG'),

(1577,'Canada','CA','Chesterfield Inlet~ NT','YCS'),

(1578,'Mexico','MX','Chetumal','CTM'),

(1579,'Canada','CA','Chetwynd~ BC','YCQ'),

(1580,'USA','US','Chevak~ AK','VAK'),

(1581,'USA','US','Cheyenne~ WY','CYS'),

(1583,'Thailand','TH','Chiang Mai','CNX'),

(1584,'Thailand','TH','Chiang Rai','CEI'),

(1585,'Taiwan','TW','Chiayi','CYI'),

(1586,'Canada','CA','Chibougamau~ QC','YMT'),

(1587,'USA','US','Chicago (West Chicago)~ IL','DPA'),

(1588,'USA','US','Chicago (Wheeling)~ IL','PWK'),

(1589,'USA','US','Chicago~ IL','ORD'),

(1593,'USA','US','Chicago/Aurora~ IL','AUZ'),

(1594,'USA','US','Chicago/Schaumburg~ IL','JMH'),

(1595,'USA','US','Chicago/Waukegan~ IL','UGN'),

(1596,'Mexico','MX','Chichen Itza','CZA'),

(1597,'USA','US','Chickasha~ OK','CHK'),

(1598,'USA','US','Chicken~ AK','CKX'),

(1599,'Peru','PE','Chiclayo','CIX'),

(1600,'USA','US','Chico~ CA','CIC'),

(1601,'Belgium','BE','Chievres','CHE'),

(1602,'China','CN','Chifeng','CIF'),

(1603,'USA','US','Chignik~ AK','KCQ'),

(1607,'Colombia','CO','Chigorodo','IGO'),

(1608,'Mexico','MX','Chihuahua','CUU'),

(1609,'Pakistan','PK','Chilas','CHB'),

(1610,'USA','US','Childress~ TX','CDS'),

(1611,'Chile','CL','Chile Chico','CCH'),

(1612,'Canada','CA','Chilko Lake~ BC','CJH'),

(1613,'Australia','AU','Chillagoe~ Queensland','LLG'),

(1614,'Chile','CL','Chillan','YAI'),

(1615,'USA','US','Chillicothe~ OH','RZT'),

(1616,'Canada','CA','Chilliwack~ BC','YCW'),

(1617,'USA','US','Chiloquin~ OR','CHZ'),

(1618,'Peru','PE','Chimbote','CHM'),

(1619,'Papua New Guinea','PG','Chimbu/Kundiawa','CMU'),

(1620,'USA','US','China Lake~ CA','NID'),

(1621,'Chile','CL','Chinchilla','CCL'),

(1622,'USA','US','Chincoteague~ VA','WAL'),

(1623,'Mozambique','MZ','Chinde','INE'),

(1624,'Zambia','ZM','Chingola','CGJ'),

(1625,'Mauritania','MR','Chinguitti','CGT'),

(1626,'South Korea','KR','Chinhae','CHF'),

(1627,'South Korea','KR','Chinju','HIN'),

(1628,'USA','US','Chino~ CA','CNO'),

(1629,'Greece','GR','Chios','JKH'),

(1630,'Zambia','ZM','Chipata','CIP'),

(1631,'Guatemala','GT','Chiquimula','CIQ'),

(1632,'USA','US','Chisana~ AK','CZN'),

(1633,'Canada','CA','Chisasibi~ QC','YKU'),

(1634,'Moldova','MD','Chisinau (Kishiney~Kishinev)','KIV'),

(1635,'USA','US','Chistochina~ AK','CZO'),

(1636,'Russia','RU','Chita~ Chita','HTA'),

(1637,'Angola','AO','Chitato','PGI'),

(1638,'USA','US','Chitina~ AK','CXC'),

(1639,'Malawi','MW','Chitipa','CII'),

(1640,'Japan','JP','Chitose~ Sapporo','CTS'),

(1641,'Pakistan','PK','Chitral','CJL'),

(1642,'Bangladesh','BD','Chittagong','CGP'),

(1643,'Colombia','CO','Chivolo','IVO'),

(1644,'Solomon Islands','SB','Choiseul Bay','CHY'),

(1645,'France','FR','Cholet','CET'),

(1646,'USA','US','Chomley~ AK','CIV'),

(1647,'China','CN','Chongqing','CKG'),

(1648,'South Korea','KR','Chonju','CHN'),

(1649,'New Zealand','NZ','Christchurch','CHC'),

(1650,'Greenland','GL','Christianshab','JCH'),

(1651,'Virgin Islands','US','Christiansted~ St. Croix Seaplan','SSB'),

(1652,'U.S. Virgin Islands','US','Christiansted~ St. Croix','STX'),

(1653,'Australia','AU','Christmas Creek~ Western Austral','CXQ'),

(1654,'Kiribati','KI','Christmas Island (Kiritimati)~ L','CXI'),

(1655,'Australia','AU','Christmas Island~ Christmas Isla','XCH'),

(1656,'USA','US','Chuathbaluk~ AK','CHU'),

(1657,'Bahamas','BS','Chub Cay~ Berry','CCZ'),

(1658,'Switzerland','CH','Chur','ZDT'),

(1659,'Canada','CA','Churchill Falls~ NF','ZUM'),

(1660,'Canada','CA','Churchill~ MB','YYQ'),

(1661,'Fiji','FJ','Cicia','ICI'),

(1662,'Cuba','CU','Ciego de Avila','AVI'),

(1663,'Cuba','CU','Cienfuegos','CFG'),

(1664,'Indonesia','ID','Cilacap~ Java','CXP'),

(1665,'Colombia','CO','Cimitarra','CIM'),

(1666,'USA','US','Cincinnati~ OH','LUK'),

(1667,'USA','US','Circle Hot Springs~ AK','CHP'),

(1668,'USA','US','Circle~ AK','IRC'),

(1669,'Indonesia','ID','Cirebon','CBN'),

(1670,'Mexico','MX','Ciudad Acuna','ACN'),

(1671,'Venezuela','VE','Ciudad Bolivar','CBL'),

(1672,'Mexico','MX','Ciudad Constitucion','CUA'),

(1673,'Mexico','MX','Ciudad de Mexico (Mexico City)','VXX'),

(1675,'Mexico','MX','Ciudad del Carmen','CME'),

(1676,'Paraguay','PY','Ciudad del Este','AGT'),

(1677,'Venezuela','VE','Ciudad Guayana','CGU'),

(1678,'Mexico','MX','Ciudad Juarez','CJS'),

(1679,'Mexico','MX','Ciudad Mante','MMC'),

(1680,'Mexico','MX','Ciudad Obregon','CEN'),

(1681,'Mexico','MX','Ciudad Victoria','CVM'),

(1682,'Spain','ES','Ciudadela','QIU'),

(1683,'USA','US','Claremont~ NH','CNH'),

(1684,'USA','US','Clarinda~ IA','ICL'),

(1685,'USA','US','Clarks Point~ AK','CLP'),

(1686,'USA','US','Clarksburg~ WV','CKB'),

(1687,'USA','US','Clarksdale~ MS','CKM'),

(1688,'USA','US','Clarksville~ TN','CKV'),

(1689,'USA','US','Clay Center~ KS','CYW'),

(1690,'USA','US','Clayton~ NM','CAO'),

(1691,'USA','US','Clear Lake~ AK','CKE'),

(1692,'USA','US','Clear Lake/Lavon~ TX','CLC'),

(1693,'USA','US','Clearwater~ FL','CLW'),

(1694,'USA','US','Clemson~ SC','CEU'),

(1695,'France','FR','Clermont-Ferrand','CFE'),

(1696,'Australia','AU','Clermont~ Queensland','CMQ'),

(1697,'Australia','AU','Cleve~ South Australia','CVC'),

(1698,'USA','US','Cleveland~ MS','RNV'),

(1699,'USA','US','Cleveland~ OH','BKL'),

(1702,'USA','US','Cleveland~ TN','HDI'),

(1703,'Australia','AU','Clifton Hills~ South Australia','CFH'),

(1704,'USA','US','Clifton/Morenci~ AZ','CFT'),

(1705,'Canada','CA','Clinton Creek~ YT','YLM'),

(1706,'Canada','CA','Clinton Point~ NT','YUH'),

(1707,'USA','US','Clinton~ IA','CWI'),

(1708,'USA','US','Clinton~ NC','CTZ'),

(1709,'USA','US','Clinton~ OK','CSM'),

(1711,'USA','US','Clintonville~ WI','CLI'),

(1712,'Australia','AU','Cloncurry~ Queensland','CNJ'),

(1713,'Argentina','AR','Clorinda','CLX'),

(1714,'USA','US','Clovis~ NM','CVS'),

(1716,'Canada','CA','Cluff Lake~ SK','XCL'),

(1717,'Romania','RO','Cluj Napoca','CLJ'),

(1718,'Australia','AU','Cluny~ Queensland','CZY'),

(1719,'Canada','CA','Clyde River~ NT','YCY'),

(1720,'USA','US','Coalinga~ CA','CLG'),

(1721,'Brazil','BR','Coari~ AM','CIZ'),

(1722,'USA','US','Coatesville~ PA','CTH'),

(1723,'Mexico','MX','Coatzacoalcos','QTZ'),

(1724,'Guatemala','GT','Coban','CBV'),

(1725,'Australia','AU','Cobar~ New South Wales','CAZ'),

(1726,'Bolivia','BO','Cobija','CIJ'),

(1727,'Ecuador','EC','Coca','OCC'),

(1728,'Bolivia','BO','Cochabamba','CBB'),

(1729,'India','IN','Cochin','COK'),

(1730,'Chile','CL','Cochrane','LGR'),

(1731,'Canada','CA','Cochrane~ ON','YCN'),

(1732,'USA','US','Cocoa Beach~ FL','XMR'),

(1734,'USA','US','Cocoa~ FL','COI'),

(1735,'Australia','AU','Coconut Island~ Queensland','CNC'),

(1736,'Australia','AU','Cocos Islands~ Cocos (Keeling) I','CCK'),

(1737,'Colombia','CO','Codazzi','DZI'),

(1738,'USA','US','Cody~ WY','COD'),

(1739,'Australia','AU','Coen~ Queensland','CUQ'),

(1740,'USA','US','Coeur d\'Alene~ ID','COE'),

(1741,'USA','US','Coffee Point~ AK','CFA'),

(1742,'USA','US','Coffeyville~ KS','CFV'),

(1743,'USA','US','Coffman Cove~ AK','KCC'),

(1744,'Australia','AU','Coffs Harbour~ New South Wales','CFS'),

(1745,'France','FR','Cognac','CNG'),

(1746,'India','IN','Coimbatore','CJB'),

(1747,'Portugal','PT','Coimbra','CBP'),

(1748,'Australia','AU','Colac~ Victoria','XCO'),

(1749,'Brazil','BR','Colatina~ ES','QCH'),

(1750,'USA','US','Colby~ KS','CBK'),

(1751,'USA','US','Cold Bay~ AK','CDB'),

(1752,'Canada','CA','Cold Lake~ AB','YOD'),

(1753,'USA','US','Coldfoot~ AK','CXF'),

(1754,'USA','US','Coleman~ TX','COM'),

(1755,'Mexico','MX','Colima','CLQ'),

(1756,'United Kingdom','GB','Coll Island','COL'),

(1757,'Australia','AU','Collarenebri~ New South Wales','CRB'),

(1758,'USA','US','College Park~ MD','CGS'),

(1759,'USA','US','College Station~ TX','CLL'),

(1760,'Australia','AU','Collie~ Western Australia','CIE'),

(1761,'Canada','CA','Collins Bay~ SK','YKC'),

(1762,'Australia','AU','Collinsville~ Queensland','KCE'),

(1763,'France','FR','Colmar','CMR'),

(1764,'Sri Lanka','LK','Colombo','CMB'),

(1766,'Cuba','CU','Colon','QCO'),

(1767,'Panama','PA','Colon','ONX'),

(1768,'Argentina','AR','Colonia Catriel','CCT'),

(1769,'Argentina','AR','Colonia Sarmien','OLN'),

(1770,'Uruguay','UY','Colonia','CYR'),

(1771,'Micronesia','FM','Colonia~ Yap Island','YAP'),

(1772,'USA','US','Colonial Williamsburg~ VA','VCW'),

(1773,'United Kingdom','GB','Colonsay Island~ Scotland','CSA'),

(1774,'USA','US','Colorado Creek~ AK','KCR'),

(1775,'USA','US','Colorado Springs~ CO','AFF'),

(1776,'CO USA','US','Colorado Springs','COS'),

(1777,'CO USA','US','Colorado Springs/Fort Carson','FCS'),

(1778,'United Kingdom','GB','Coltishall','CLF'),

(1779,'USA','US','Colton~ CA','RTO'),

(1780,'USA','US','Columbia~ CA','COA'),

(1781,'USA','US','Columbia~ MO','COU'),

(1782,'USA','US','Columbia~ SC','CAE'),

(1785,'USA','US','Columbia/Mount Pleasant~ TN','MRC'),

(1786,'USA','US','Columbus~ GA','CSG'),

(1788,'USA','US','Columbus~ IN','CLU'),

(1789,'USA','US','Columbus~ MS','UBS'),

(1791,'USA','US','Columbus~ NE','OLU'),

(1792,'USA','US','Columbus~ NM','CUS'),

(1793,'USA','US','Columbus~ OH','OSU'),

(1796,'MS USA','US','Columbus/West Point/Starkville','GTR'),

(1797,'Canada','CA','Colville Lake~ NT','YCK'),

(1798,'USA','US','Colville River~ AK','KCO'),

(1799,'Honduras','HN','Comayagua','XPL'),

(1800,'Bangladesh','BD','Comilla','CLA'),

(1801,'Italy','IT','Comiso','CIY'),

(1802,'Argentina','AR','Comodoro Rivadavia','CRD'),

(1803,'Canada','CA','Comox~ BC','YQQ'),

(1804,'USA','US','Compton~ CA','CPM'),

(1805,'Guinea','GN','Conakry','CKY'),

(1806,'Brazil','BR','Conceicao~ PB','CDJ'),

(1807,'Chile','CL','Concepcion','CCP'),

(1808,'Bolivia','BO','Concepcion','CEP'),

(1809,'USA','US','Concord~ CA','CCR'),

(1810,'USA','US','Concord~ NH','CON'),

(1811,'Argentina','AR','Concordia','COC'),

(1812,'Brazil','BR','Concordia~ AM','CCI'),

(1813,'USA','US','Concordia~ KS','CNK'),

(1814,'Australia','AU','Condobolin~ New South Wales','CBX'),

(1815,'Colombia','CO','Condoto','COG'),

(1816,'Brazil','BR','Confreza','CFO'),

(1817,'Bahamas','BS','Congo Town','COX'),

(1818,'Ireland','IE','Connaught','CNN'),

(1819,'USA','US','Connellsville~ PA','WKC'),

(1820,'USA','US','Connersville~ IN','CEV'),

(1821,'Brazil','BR','Conquista~ MG','COQ'),

(1822,'USA','US','Conroe~ TX','CXO'),

(1823,'Brazil','BR','Conselheiro Lafaiete~ MG','QDF'),

(1824,'Romania','RO','Constanta','CND'),

(1825,'Algeria','DZ','Constantine','CZL'),

(1826,'Dominican Republic','DO','Constanza','COZ'),

(1827,'Panama','PA','Contadora','OTD'),

(1828,'Peru','PE','Contamana','CTF'),

(1829,'USA','US','Conway~ SC','HYW'),

(1830,'Australia','AU','Coober Pedy~ South Australia','CPD'),

(1831,'India','IN','Cooch Behar','COH'),

(1832,'Australia','AU','Cooinda~ Northern Territory','CDA'),

(1833,'USA','US','Cook~ MN','CQM'),

(1834,'Australia','AU','Cooktown~ Queensland','CTN'),

(1835,'Australia','AU','Coolah~ New South Wales','CLH'),

(1836,'Australia','AU','Coolawanyah~ Western Australia','COY'),

(1837,'Australia','AU','Coolibah~ Northern Territory','COB'),

(1838,'Australia','AU','Coolullah','WCO'),

(1839,'Australia','AU','Cooma~ New South Wales','OOM'),

(1840,'Australia','AU','Coonabarabran~ New South Wales','COJ'),

(1841,'Australia','AU','Coonamble~ New South Wales','CNB'),

(1842,'Canada','CA','Coop Point~ MB','YCP'),

(1843,'USA','US','Cooper Landing~ AK','JLA'),

(1844,'Australia','AU','Coorabie','CRJ'),

(1845,'Australia','AU','Cootamundra~ New South Wales','CMD'),

(1846,'Honduras','HN','Copan','RUY'),

(1847,'Chile','CL','Copiapo','CPO'),

(1848,'USA','US','Copper Center~ AK','CZC'),

(1849,'USA','US','Copper Mountain~ CO','QCE'),

(1850,'Canada','CA','Coppermine~ NT','YCO'),

(1851,'Chile','CL','Coquimbo','COW'),

(1852,'Canada','CA','Coral Harbour~ NT','YZS'),

(1853,'Panama','PA','Corazon de Jesus','CZJ'),

(1854,'USA','US','Corcoran~ CA','CRO'),

(1855,'USA','US','Cordele~ GA','CKF'),

(1856,'Australia','AU','Cordillo Downs~ South Australia','ODL'),

(1857,'Argentina','AR','Cordoba','COR'),

(1858,'Spain','ES','Cordoba','ODB'),

(1859,'USA','US','Cordova~ AK','CKU'),

(1861,'USA','US','Corinth~ MS','CRX'),

(1862,'United Kingdom','GB','Coritgo Blanco','CTB'),

(1863,'Ireland','IE','Cork','ORK'),

(1864,'Nicaragua','NI','Corn Island','RNI'),

(1865,'Brazil','BR','Cornelio Procopio~ PR','CKO'),

(1866,'USA','US','Corner Bay~ AK','CBA'),

(1867,'Canada','CA','Cornwall~ ON','YCC'),

(1868,'Venezuela','VE','Coro','CZE'),

(1869,'New Zealand','NZ','Coromandel','CMV'),

(1870,'Canada','CA','Coronation~ AB','YCT'),

(1871,'Australia','AU','Corowa~ New South Wales','CWW'),

(1872,'Belize','BZ','Corozal','CZH'),

(1873,'Colombia','CO','Corozal','CZU'),

(1874,'USA','US','Corpus Christi~ TX','NGW'),

(1878,'Argentina','AR','Corrientes','CNQ'),

(1879,'TX USA','US','Corsicana','CRS'),

(1880,'Canada','CA','Cortes Bay~ BC','YCF'),

(1881,'USA','US','Cortez~ CO','CEZ'),

(1882,'Italy','IT','Cortina d\'Ampezzo','CDF'),

(1883,'USA','US','Cortland~ NY','CTX'),

(1884,'Brazil','BR','Corumba~ SP','CMG'),

(1885,'USA','US','Corvallis~ OR','CVO'),

(1886,'Portugal','PT','Corvo Island~ Azores','CVU'),

(1887,'Brazil','BR','Costa Marques~ RO','CQS'),

(1888,'Philippines','PH','Cotabato','CBO'),

(1889,'Brazil','BR','Cotia~ SP','QOI'),

(1890,'Costa Rica','CR','Coto 47','OTR'),

(1891,'Benin','BJ','Cotonou','COO'),

(1892,'USA','US','Cottonwood~ AZ','CTW'),

(1893,'USA','US','Cotulla~ TX','COT'),

(1894,'USA','US','Council Bluffs~ IA','CBF'),

(1895,'USA','US','Council~ AK','CIL'),

(1896,'France','FR','Courcheval','CVF'),

(1897,'Canada','CA','Courtenay~ BC','YCA'),

(1898,'Colombia','CO','Covenas','CVE'),

(1899,'United Kingdom','GB','Coventry','CVT'),

(1900,'Portugal','PT','Covilha','COV'),

(1901,'OH USA','US','Covington~ KY/Cincinnati','CVG'),

(1902,'Australia','AU','Cowarie~ South Australia','CWR'),

(1903,'Australia','AU','Cowell~ South Australia','CCW'),

(1904,'Canada','CA','Cowley~ AB','YYM'),

(1905,'Australia','AU','Cowra~ New South Wales','CWT'),

(1906,'Bangladesh','BD','Cox\'s Bazar','CXB'),

(1907,'Chile','CL','Coyhaique','GXQ'),

(1908,'Honduras','HN','Coyoles','CYL'),

(1909,'USA','US','Cozad~ NE','CZD'),

(1910,'Mexico','MX','Cozumel','CZM'),

(1911,'South Africa','ZA','Cradock','CDO'),

(1912,'USA','US','Crafton Island~ AK','CJI'),

(1913,'Vanuatu','VU','Craig Cove','CCV'),

(1914,'USA','US','Craig~ AK','CGA'),

(1915,'USA','US','Craig~ CO','CIG'),

(1916,'Romania','RO','Craiova','CRA'),

(1917,'Canada','CA','Cranbrook~ BC','YXC'),

(1918,'USA','US','Crane Island~ WA','CKR'),

(1919,'USA','US','Crane~ TX','CCG'),

(1920,'Colombia','CO','Cravo Norte','RAV'),

(1921,'USA','US','Crawfordsville~ IN','CFJ'),

(1922,'Canada','CA','Cree Lake~ SK','YFN'),

(1923,'USA','US','Crescent City~ CA','CEC'),

(1924,'USA','US','Cresco~ IA','CJJ'),

(1925,'Australia','AU','Cresswell Downs~ Northern Territ','CSD'),

(1926,'CO USA','US','Crested Butte','CSE'),

(1927,'Canada','CA','Creston~ BC','YCZ'),

(1928,'USA','US','Creston~ IA','CSQ'),

(1929,'USA','US','Crestview~ FL','CEW'),

(1930,'Brazil','BR','Crisciuma~ SC','CCM'),

(1931,'France','FR','Croisette','JCA'),

(1932,'Australia','AU','Croker Island~ Northern Territor','CKI'),

(1933,'United Kingdom','GB','Cromarty','CRN'),

(1934,'USA','US','Crooked Creek~ AK','CJX'),

(1936,'Bahamas','BS','Crooked Island~ Crooked','CRI'),

(1937,'USA','US','Crookston~ MN','CKN'),

(1938,'USA','US','Cross City~ FL','CTY'),

(1939,'Canada','CA','Cross Lake~ MB','YCR'),

(1940,'USA','US','Crossett~ AR','CRT'),

(1941,'USA','US','Crossville~ TN','CSV'),

(1942,'Italy','IT','Crotone','CRV'),

(1943,'CA USA','US','Crow\'s Landing','NRC'),

(1944,'Australia','AU','Croydon~ Queensland','CDQ'),

(1945,'Brazil','BR','Cruz Alta~ RS','CZB'),

(1946,'U.S. Virgin Islands','US','Cruz Bay~ St. John','SJF'),

(1947,'Brazil','BR','Cruzeiro do Sul~ AC','CZS'),

(1948,'USA','US','Crystal Lake~ PA','CYE'),

(1949,'Mozambique','MZ','Cuamba (Nova Freixo)','FXO'),

(1950,'USA','US','Cuba~ MO','UBX'),

(1951,'USA','US','Cube Cove~ AK','CUW'),

(1952,'Philippines','PH','Cubi Point','NCP'),

(1953,'Colombia','CO','Cucuta','CUC'),

(1954,'India','IN','Cuddapah','CDP'),

(1955,'Australia','AU','Cue~ Western Australia','CUY'),

(1956,'Ecuador','EC','Cuenca','CUE'),

(1957,'Brazil','BR','Cuiaba~ MT','CGB'),

(1958,'Angola','AO','Cuito Cuanavale','CTI'),

(1959,'Puerto Rico','PR','Culebra','CPX'),

(1960,'Mexico','MX','Culiacan','CUL'),

(1961,'Philippines','PH','Culion','CUJ'),

(1962,'Canada','CA','Cullaton Lake~ NT','YCU'),

(1963,'USA','US','Culver City~ CA','CVR'),

(1964,'Venezuela','VE','Cumana','CUM'),

(1965,'USA','US','Cumberland~ MD','CBE'),

(1966,'USA','US','Cumberland~ WI','UBE'),

(1967,'Guatemala','GT','Cuneo','CUF'),

(1968,'Australia','AU','Cunnamulla~ Queensland','CMA'),

(1969,'Netherlands Antilles','NL','Curacao (Willemstad)','CUR'),

(1970,'Brazil','BR','Curitiba~ PR','CWB'),

(1971,'Brazil','BR','Curitibaos','QCR'),

(1972,'Brazil','BR','Currais Novos~ RN','QCB'),

(1973,'Colombia','CO','Currillo','CUI'),

(1974,'Brazil','BR','Cururupu~ MA','CPU'),

(1975,'Argentina','AR','Curuzu Cuatia','UZU'),

(1976,'USA','US','Cushing~ OK','CUH'),

(1977,'Argentina','AR','Cutral-Co','CUT'),

(1978,'Peru','PE','Cuzco','CUZ'),

(1979,'Poland','PL','Czestochowa','CZW'),

(1980,'Vietnam','VN','Da Lat','DLI'),

(1981,'Vietnam','VN','Da Nang','DAD'),

(1982,'Venezuela','VE','Dabajoro','DJV'),

(1983,'Sudan','SD','Dabba','DDD'),

(1984,'Pakistan','PK','Dadu','DDU'),

(1985,'Philippines','PH','Daet','DTE'),

(1986,'USA','US','Daggett~ CA','DAG'),

(1987,'USA','US','Dahl Creek~ AK','DCK'),

(1988,'VA USA','US','Dahlgren','DGN'),

(1989,'Australia','AU','Dajarra~ Queensland','DJR'),

(1990,'Senegal','SN','Dakar','DKR'),

(1991,'Morocco','MA','Dakhla (Villa Cisneros)~ Western','VIL'),

(1992,'Turkey','TR','Dalaman','DLM'),

(1993,'Pakistan','PK','Dalbandin','DBA'),

(1994,'Papua New Guinea','PG','Dalbertis','DLB'),

(1995,'Australia','AU','Dalby~ Queensland','DBY'),

(1996,'USA','US','Dalhart~ TX','DHT'),

(1997,'China','CN','Dalian','DLC'),

(1998,'USA','US','Dallas~ TX','ADS'),

(2006,'USA','US','Dallas/Fort Worth~ TX','DFW'),

(2007,'Ivory Coast','CI','Daloa','DJO'),

(2008,'USA','US','Dalton~ GA','DNN'),

(2009,'Australia','AU','Daly River~ Northern Territory','DVR'),

(2010,'Australia','AU','Daly Waters~ Northern Territory','DYW'),

(2011,'India','IN','Daman','NMB'),

(2012,'Syria','SY','Damascus','DAM'),

(2013,'Saudi Arabia','SA','Damman','QDM'),

(2014,'Australia','AU','Dampier~ Western Australia','KTA'),

(2015,'Ivory Coast','CI','Danane','DNC'),

(2016,'USA','US','Danbury~ CT','DXR'),

(2018,'China','CN','Dandong','DDG'),

(2019,'Nepal','NP','Dang','DNP'),

(2020,'USA','US','Danger Bay~ AK','DGB'),

(2021,'Belize','BZ','Dangriga','DGA'),

(2022,'Canada','CA','Daniel\'s Harbour~ NF','YDH'),

(2023,'USA','US','Dansville~ NY','DSV'),

(2024,'USA','US','Danville~ IL','DNV'),

(2025,'USA','US','Danville~ KY','DVK'),

(2026,'USA','US','Danville~ VA','DAN'),

(2027,'India','IN','Daparizo','DAE'),

(2028,'Tanzania','TZ','Dar es Salaam','DAR'),

(2029,'Nepal','NP','Darchula','DAP'),

(2030,'New Zealand','NZ','Dargaville','DGR'),

(2031,'India','IN','Darjeeling','DAI'),

(2032,'Australia','AU','Darnley Island~ Queensland','NLF'),

(2033,'Papua New Guinea','PG','Daru','DAU'),

(2034,'Sierra Leone','SL','Daru','DSL'),

(2035,'Afghanistan','AF','Darwaz','DAZ'),

(2036,'Australia','AU','Darwin~ Northern Territory','DRW'),

(2037,'Turkmenistan','TM','Dashhowuz (Tashauz)~ Dashhowuz','TAZ'),

(2038,'Indonesia','ID','Datadawai','DTD'),

(2039,'Yemen','YE','Dathina','DAH'),

(2040,'China','CN','Datong','DAT'),

(2041,'Australia','AU','Dauan Island~ Queensland','DAJ'),

(2042,'Latvia','LV','Daugavpils','DGP'),

(2043,'Papua New Guinea','PG','Daup','DAF'),

(2044,'Canada','CA','Dauphin~ MB','YDN'),

(2045,'Philippines','PH','Davao City','DVO'),

(2046,'Australia','AU','Davenport Downs~ Queensland','DVP'),

(2047,'USA','US','Davenport~ IA','DVN'),

(2048,'Panama','PA','David','DAV'),

(2049,'Canada','CA','Davis Inlet~ NF','YDI'),

(2050,'Canada','CA','Dawson Creek~ BC','YDQ'),

(2051,'Canada','CA','Dawson~ YT','YDA'),

(2052,'China','CN','Daxian','DAX'),

(2053,'Australia','AU','Daydream Island~ Queensland','DDI'),

(2054,'China','CN','Dayong','DYG'),

(2055,'USA','US','Dayton~ OH','MGY'),

(2058,'USA','US','Daytona Beach~ FL','DAB'),

(2059,'USA','US','De Kalb Taylor~ IL','DKB'),

(2060,'USA','US','De Ridder~ LA','DRI'),

(2061,'Bahamas','BS','Deadman\'s Cay~ Long','LGI'),

(2062,'Canada','CA','Dean River~ BC','YRD'),

(2063,'USA','US','Dearborn~ MI','DEO'),

(2064,'Canada','CA','Dease Lake~ BC','YDL'),

(2065,'CA USA','US','Death Valley National Monument','DTH'),

(2066,'France','FR','Deauville','DOL'),

(2067,'Papua New Guinea','PG','Debapare','DBP'),

(2068,'Papua New Guinea','PG','Deboyne','DOY'),

(2069,'Ethiopia','ET','Debra Marcos','DBM'),

(2070,'Ethiopia','ET','Debra Tabor','DBT'),

(2071,'Hungary','HU','Debrecen','DEB'),

(2072,'USA','US','Decatur Island~ WA','DTR'),

(2073,'USA','US','Decatur~ AL','DCU'),

(2074,'USA','US','Decatur~ IL','DEC'),

(2075,'USA','US','Decatur~ IN','DCR'),

(2076,'Canada','CA','Deception~ QC','YGY'),

(2077,'USA','US','Decorah~ IA','DEH'),

(2078,'Burkina Faso','BF','Dedougou','DGU'),

(2079,'USA','US','Deep Bay~ AK','WDB'),

(2080,'Canada','CA','Deer Lake~ NF','YDF'),

(2081,'Canada','CA','Deer Lake~ ON','YVZ'),

(2082,'USA','US','Deer Park~ NY','DPK'),

(2083,'USA','US','Deering~ AK','DRG'),

(2084,'USA','US','Defiance~ OH','DFI'),

(2085,'Ethiopia','ET','Degahbur','DGC'),

(2086,'India','IN','Dehradun','DED'),

(2087,'Syria','SY','Deirezzur','DEZ'),

(2088,'USA','US','Del Rio~ TX','DRT'),

(2090,'USA','US','Delaware~ OH','DLZ'),

(2091,'India','IN','Delhi','DEL'),

(2092,'Australia','AU','Delissaville~ Northern Territory','DLV'),

(2093,'Australia','AU','Delta Downs~ Queensland','DDN'),

(2094,'USA','US','Delta Junction~ AK','DJN'),

(2095,'USA','US','Delta Junction/Fort Greely~ AK','BIG'),

(2096,'USA','US','Delta~ UT','DTA'),

(2097,'Ethiopia','ET','Dembidollo','DEM'),

(2098,'USA','US','Deming~ NM','DMN'),

(2099,'Netherlands','NL','Den Haag (The Hague)/Hilversum','HAG'),

(2100,'Australia','AU','Denham~ Western Australia','DNM'),

(2101,'Australia','AU','Deniliquin~ New South Wales','DNQ'),

(2102,'USA','US','Denison~ IA','DNS'),

(2103,'Turkey','TR','Denizli','DNZ'),

(2104,'Seychelles','SC','Dennis Island','DEI'),

(2105,'Indonesia','ID','Denpasar/Bali','DPS'),

(2106,'USA','US','Denton~ TX','DTO'),

(2107,'USA','US','Denver~ CO','APA'),

(2111,'USA','US','Denver/Aurora~ CO','BFK'),

(2112,'USA','US','Denver/Broomfield~ CO','BJC'),

(2113,'Pakistan','PK','Dera Ismail Khan','DSK'),

(2114,'Australia','AU','Derby~ Western Australia','DRB'),

(2115,'Papua New Guinea','PG','Derim','DER'),

(2116,'Libya','LY','Derna','DNF'),

(2117,'USA','US','Des Moines~ IA','DSM'),

(2118,'Canada','CA','Desolation Sound~ BC','YDS'),

(2119,'Seychelles','SC','Desroches','DES'),

(2120,'Ethiopia','ET','Dessie','DSE'),

(2121,'USA','US','Destin~ FL','DSI'),

(2122,'USA','US','Detroit Lakes~ MN','DTL'),

(2123,'USA','US','Detroit~ MI','DET'),

(2124,'MI [Detroit Metropolitan Wayne County] USA','US','Detroit','DTW'),

(2127,'France','FR','Deux Alpes','DXA'),

(2128,'Romania','RO','Deva','DVA'),

(2129,'Netherlands','NL','Deventer','QYV'),

(2130,'USA','US','Devils Lake~ ND','DVL'),

(2131,'Australia','AU','Devonport~ Tasmania','DPO'),

(2132,'Canada','CA','Dewar Lakes~ NT','YUW'),

(2133,'USA','US','Dexter~ MO','DXE'),

(2134,'Saudi Arabia','SA','Dhahran','DHA'),

(2135,'Bangladesh','BD','Dhaka','DAC'),

(2136,'Yemen','YE','Dhala','DHL'),

(2137,'Yemen','YE','Dhamar','DMR'),

(2138,'India','IN','Dhanbad','DBD'),

(2139,'Nepal','NP','Dhangarhi','DHI'),

(2140,'India','IN','Dharamsala','DHM'),

(2141,'Brazil','BR','Diadema~ SP','QDW'),

(2142,'Australia','AU','Diamantina Lakes~ Queensland','DYM'),

(2143,'Brazil','BR','Diamantino~ MT','DMT'),

(2144,'Brazil','BR','Dianopolis~ GO','DNO'),

(2145,'Burkina Faso','BF','Diapaga','DIP'),

(2146,'Oman','OM','Dibaa','BYB'),

(2147,'India','IN','Dibrugarh','DIB'),

(2148,'USA','US','Dickinson~ ND','DIK'),

(2149,'Burkina Faso','BF','Diebougou','XDE'),

(2150,'British Indian Ocean Territory','VG','Diego Garcia','NKW'),

(2151,'France','FR','Dieppe','DPE'),

(2152,'USA','US','Dietrich~ AK','DTK'),

(2153,'Canada','CA','Digby~ NS','YDG'),

(2154,'France','FR','Dijon','DIJ'),

(2155,'East Timor','TP','Dili','DIL'),

(2156,'Zaire','ZR','Dili','DIC'),

(2157,'USA','US','Dillingham~ AK','DLG'),

(2158,'USA','US','Dillon~ MT','DLN'),

(2159,'USA','US','Dillon~ SC','DLL'),

(2160,'Vanuatu','VU','Dillons Bay','DLY'),

(2161,'India','IN','Dimapur','DMU'),

(2162,'Bangladesh','BD','Dinajpur','DNJ'),

(2163,'Papua New Guinea','PG','Dinangat','DNU'),

(2164,'France','FR','Dinard/Pleurtuit','DNR'),

(2165,'Sudan','SD','Dinder','DNX'),

(2166,'Papua New Guinea','PG','Dios','DOS'),

(2167,'Philippines','PH','Dipolog','DPL'),

(2168,'Ethiopia','ET','Dire Dawa','DIR'),

(2169,'Australia','AU','Dirranbandi~ Queensland','DRN'),

(2170,'Brazil','BR','Divinopolis~ MG','DIQ'),

(2171,'Oman','OM','Diwan of Royal Court','DIW'),

(2172,'Australia','AU','Dixie~ Queensland','DXD'),

(2173,'Turkey','TR','Diyarbakir','DIY'),

(2174,'Congo','CG','Djambala','DJM'),

(2175,'Algeria','DZ','Djanet','DJG'),

(2176,'Indonesia','ID','Djayapura (Jayapura)','DJJ'),

(2177,'Tunisia','TN','Djerba (Jerba)','DJE'),

(2178,'Burkina Faso','BF','Djibo','XDJ'),

(2179,'Djibouti','DJ','Djibouti','JIB'),

(2180,'Suriname','SR','Djoemoe','DOE'),

(2181,'Benin','BJ','Djougou','DJA'),

(2182,'United Arab Emirates','AE','Dnata','XGD'),

(2183,'Ukraine','UA','Dnipropetrovs\'k (Dnepropetrovsk)','DNK'),

(2184,'Madagascar','MG','Doany','DOA'),

(2185,'Indonesia','ID','Dobo~ Aru Islands','DOB'),

(2186,'Canada','CA','Doc Creek','YDX'),

(2187,'USA','US','Dodge City~ KS','DDC'),

(2188,'Tanzania','TZ','Dodoima','DDM'),

(2189,'Tanzania','TZ','Dodoma','DOD'),

(2190,'Qatar','QA','Doha','DOH'),

(2191,'Papua New Guinea','PG','Doini','DOI'),

(2192,'Canada','CA','Dolbeau-St. Methode~ QC','YDO'),

(2193,'France','FR','Dole','DLE'),

(2194,'Congo','CG','Dolisie','DIS'),

(2195,'USA','US','Dolomi~ AK','DLO'),

(2196,'Nepal','NP','Dolpa','DOP'),

(2197,'Brazil','BR','Dom Pedrito~ RS','QDP'),

(2198,'Dominica','DO','Dominica (Roseau)','DCF'),

(2200,'United Kingdom','GB','Doncaster','DCS'),

(2201,'Ukraine','UA','Donetsk~ Donets\'k','DOK'),

(2202,'Australia','AU','Dongara~ Western Australia','DOX'),

(2203,'Sudan','SD','Dongola','DOG'),

(2204,'Australia','AU','Doomadgee Mission~ Queensland','DMD'),

(2205,'USA','US','Dora Bay~ AK','DOF'),

(2206,'Puerto Rico','PR','Dorado','DDP'),

(2207,'Burkina Faso','BF','Dori','DOR'),

(2208,'Austria','AT','Dornbirn','QDI'),

(2209,'United Kingdom','GB','Dornoch','DOC'),

(2210,'Papua New Guinea','PG','Dorobisoro','DOO'),

(2211,'Djibouti','DJ','Dorra','DOZ'),

(2212,'Germany','DE','Dortmund','DTM'),

(2213,'Australia','AU','Dorunda Station~ Queensland','DRD'),

(2214,'Guatemala','GT','Dos Lagunas','DON'),

(2215,'USA','US','Dothan~ AL','DHN'),

(2216,'Cameroon','CM','Douala','DLA'),

(2217,'USA','US','Douglas~ AZ','DGL'),

(2218,'USA','US','Douglas~ GA','DQH'),

(2219,'USA','US','Douglas~ WY','DGW'),

(2220,'USA','US','Douglas/Bisbee~ AZ','DUG'),

(2221,'Brazil','BR','Dourados~ MG','DOU'),

(2222,'USA','US','Dover~ DE','DOV'),

(2223,'USA','US','Dover/Cheswold~ DE','DVX'),

(2224,'USA','US','Downey~ CA','JDY'),

(2225,'Greece','GR','Drama','DRM'),

(2226,'Canada','CA','Drayton~ AB','YDC'),

(2227,'Germany','DE','Dresden','DRS'),

(2228,'Suriname','SR','Drietabbetje','DRJ'),

(2229,'USA','US','Driftwood Bay~ AK','DFB'),

(2230,'Australia','AU','Drumduff~ Queensland','DFP'),

(2231,'USA','US','Drummond Island~ MI','DRE'),

(2232,'USA','US','Drummond~ MT','DRU'),

(2233,'Canada','CA','Dryden~ ON','YHD'),

(2234,'Cameroon','CM','Dschang','DSC'),

(2235,'USA','US','Du Bois~ PA','DUJ'),

(2236,'United Arab Emirates','AE','Dubai','DXB'),

(2237,'Australia','AU','Dubbo~ New South Wales','DBO'),

(2238,'USA','US','Dublin~ GA','DBN'),

(2239,'Ireland','IE','Dublin','DUB'),

(2240,'USA','US','Dublin~ VA','PSK'),

(2241,'USA','US','Dubois~ ID','DBS'),

(2242,'Croatia','HR','Dubrovnik','DBV'),

(2243,'USA','US','Dubuque~ IA','DBQ'),

(2244,'USA','US','Duck~ NC','DUF'),

(2245,'Germany','DE','Duesseldorf (Dusseldorf)','DUS'),

(2247,'Germany','DE','Duesseldorf/Koeln Area','NRW'),

(2248,'USA','US','Dugway Proving Ground~ UT','DPG'),

(2249,'Germany','DE','Duisburg','DUI'),

(2250,'Australia','AU','Dulkaninna~ South Australia','DLK'),

(2251,'USA','US','Duluth~ MN','DLH'),

(2253,'Philippines','PH','Dumaguete','DGT'),

(2254,'Indonesia','ID','Dumai','DUM'),

(2255,'USA','US','Dumas~ TX','DUX'),

(2256,'Papua New Guinea','PG','Dumpu','DPU'),

(2257,'Australia','AU','Dunbar~ Queensland','DNB'),

(2258,'Bahamas','BS','Duncan Town~ Ragged','DCT'),

(2259,'Canada','CA','Duncan~ BC','DUQ'),

(2260,'USA','US','Duncan~ OK','DUC'),

(2261,'Greenland','GL','Dundas','DUN'),

(2262,'United Kingdom','GB','Dundee','DND'),

(2263,'Angola','AO','Dundo','DUE'),

(2264,'New Zealand','NZ','Dunedin','DUD'),

(2265,'China','CN','Dunhuang','DNH'),

(2266,'Australia','AU','Dunk Island~ Queensland','DKI'),

(2267,'USA','US','Dunkirk~ NY','DKK'),

(2268,'Brazil','BR','Duque de Caixas~ RJ','QDQ'),

(2269,'USA','US','Durango~ CO','AMK'),

(2271,'Mexico','MX','Durango','DGO'),

(2272,'USA','US','Durant~ OK','DUA'),

(2273,'South Africa','ZA','Durban','DUR'),

(2274,'Australia','AU','Durham Downs~ Queensland','DHD'),

(2275,'Australia','AU','Durrie~ Queensland','DRR'),

(2276,'Tajikistan','TJ','Dushanbe~ Karotegin','DYU'),

(2277,'USA','US','Dutch Harbor (Unalaska)~ AK','DUT'),

(2278,'USA','US','Dwight~ IL','DTG'),

(2279,'Australia','AU','Dysart~ Queensland','DYA'),

(2280,'Mayotte','YT','Dzaoudzi (Mamoudzou)','DZA'),

(2281,'USA','US','Eagle Grove~ IA','EAG'),

(2282,'USA','US','Eagle Lake~ TX','ELA'),

(2283,'USA','US','Eagle Pass~ TX','EGP'),

(2284,'USA','US','Eagle River~ WI','EGV'),

(2285,'USA','US','Eagle~ AK','EAA'),

(2286,'Canada','CA','Earlton~ ON','YXR'),

(2287,'USA','US','East Fork~ AK','EFO'),

(2288,'Greenland','GL','East Greenland','CNP'),

(2289,'USA','US','East Hampton~ NY','HTO'),

(2290,'USA','US','East Hartford~ CT','EHT'),

(2291,'South Africa','ZA','East London','ELS'),

(2292,'Canada','CA','East Main~ QC','ZEM'),

(2293,'United Kingdom','GB','East Midlands (Derby)','EMA'),

(2294,'USA','US','East Stroudsburg~ PA','ESP'),

(2295,'USA','US','East Tawas~ MI','ECA'),

(2296,'USA','US','Eastland~ TX','ETN'),

(2297,'USA','US','Eastman~ GA','EZM'),

(2298,'USA','US','Easton~ MD','ESN'),

(2299,'USA','US','Easton~ WA','ESW'),

(2300,'USA','US','Eastsound~ WA','ESD'),

(2301,'USA','US','Eau Claire~ WI','EAU'),

(2302,'Marshall Islands','MH','Ebadon','EBN'),

(2303,'Cameroon','CM','Ebolowa','EBW'),

(2304,'Australia','AU','Echuca~ New South Wales','ECH'),

(2305,'Sudan','SD','Ed Dabba','DEA'),

(2306,'United Kingdom','GB','Eday','EOI'),

(2307,'Australia','AU','Eden~ New South Wales','QDN'),

(2308,'USA','US','Edenton~ NC','EDE'),

(2309,'USA','US','Edgewood Arsenal~ MD','EDG'),

(2310,'United Kingdom','GB','Edinburgh~ Scotland','EDI'),

(2311,'Canada','CA','Edmonton~ AB','YEG'),

(2315,'USA','US','Edna Bay~ AK','EDA'),

(2316,'Canada','CA','Edson~ AB','YET'),

(2317,'Australia','AU','Edward River~ Queensland','EDR'),

(2318,'USA','US','Edwards~ CA','EDW'),

(2319,'USA','US','Eek~ AK','EEK'),

(2320,'Papua New Guinea','PG','Efogi','EFG'),

(2321,'Greenland','GL','Egedesminde','JEG'),

(2322,'USA','US','Egegik~ AK','BSZ'),

(2324,'Iceland','IS','Egilsstadir','EGS'),

(2325,'Papua New Guinea','PG','Eia','EIA'),

(2326,'United Kingdom','GB','Eight Fathombight','EFB'),

(2327,'Israel','IL','Ein Yahav','EIY'),

(2328,'Australia','AU','Einasleigh~ Queensland','EIH'),

(2329,'Netherlands','NL','Eindhoven','EIN'),

(2330,'Brazil','BR','Eirunepe~ AM','ERN'),

(2331,'Guyana','GY','Ekereku','EKE'),

(2332,'Kazakhstan','KZ','Ekibastuz','EKB'),

(2333,'USA','US','Ekuk~ AK','KKU'),

(2334,'USA','US','Ekwok~ AK','KEK'),

(2335,'Egypt','EG','El Arish','EAH'),

(2336,'Colombia','CO','El Banco','ELB'),

(2337,'Colombia','CO','El Barge','EBG'),

(2338,'Argentina','AR','El Bolson','EHL'),

(2339,'Algeria','DZ','El Borma','EBM'),

(2340,'USA','US','El Cajon~ CA','CJN'),

(2341,'USA','US','El Campo~ TX','ECE'),

(2342,'USA','US','El Centro~ CA','NJK'),

(2343,'USA','US','El Centro/Imperial~ CA','IPL'),

(2344,'Colombia','CO','El Charco','ECR'),

(2345,'Sudan','SD','El Debba','EDB'),

(2346,'USA','US','El Dorado~ AR','ELD'),

(2347,'USA','US','El Dorado~ KS','EDK'),

(2348,'Venezuela','VE','El Dorado','EOR'),

(2349,'Colombia','CO','El Encanto','ECO'),

(2350,'Sudan','SD','El Fasher','ELF'),

(2351,'Sudan','SD','El Geneina','EGN'),

(2352,'Algeria','DZ','El Golea','ELG'),

(2353,'Mauritania','MR','El Gouera','ZLG'),

(2354,'Argentina','AR','El Maiten','EMX'),

(2355,'Egypt','EG','El Minya','EMY'),

(2356,'USA','US','El Monte~ CA','EMT'),

(2357,'Guatemala','GT','El Naranjo','ENJ'),

(2358,'Sudan','SD','El Obeid','EBD'),

(2359,'Algeria','DZ','El Oued','ELU'),

(2360,'USA','US','El Paso~ TX','ELP'),

(2361,'Panama','PA','El Porvenir','PVE'),

(2362,'Panama','PA','El Real','ELE'),

(2363,'Colombia','CO','El Recreo','ELJ'),

(2364,'Chile','CL','El Salvador','ESR'),

(2365,'Venezuela','VE','El Vigia','VIG'),

(2366,'Colombia','CO','El Yopal','EYP'),

(2367,'Israel','IL','Elat','ETH'),

(2368,'Turkey','TR','Elazig','EZS'),

(2369,'Italy','IT','Elba Island','EBA'),

(2370,'Australia','AU','Elcho Island~ Northern Territory','ELC'),

(2371,'Argentina','AR','Eldorado','ELO'),

(2372,'Kenya','KE','Eldoret','EDL'),

(2373,'USA','US','Eldred Rock~ AK','ERO'),

(2374,'USA','US','Elfin Cove~ AK','ELV'),

(2375,'USA','US','Elim~ AK','ELI'),

(2377,'Papua New Guinea','PG','Eliptamin','EPT'),

(2378,'Russia','RU','Elista~ Kalmykia','ESL'),

(2379,'Kenya','KE','Eliye Springs','EYS'),

(2380,'NC USA','US','Elizabeth City','ECG'),

(2381,'USA','US','Elizabethtown~ KY','EKX'),

(2382,'USA','US','Elk City~ OK','ELK'),

(2383,'Australia','AU','Elkedra~ Northern Territory','EKD'),

(2384,'USA','US','Elkhart~ IN','EKI'),

(2385,'USA','US','Elkhart~ KS','EHA'),

(2386,'USA','US','Elkin~ NC','ZEF'),

(2387,'WV USA','US','Elkins','EKN'),

(2388,'USA','US','Elko~ NV','EKO'),

(2389,'Somalia','SO','Ell','HCM'),

(2390,'USA','US','Ellamar~ AK','ELW'),

(2391,'USA','US','Ellensburg~ WA','ELN'),

(2392,'Canada','CA','Elliot Lake~ ON','YEL'),

(2393,'South Africa','ZA','Ellisras','ELL'),

(2394,'USA','US','Elmira~ NY','ELM'),

(2395,'Venezuela','VE','Elorza','EOZ'),

(2396,'USA','US','Ely~ MN','LYU'),

(2397,'USA','US','Ely~ NV','ELY'),

(2398,'Vanuatu','VU','Emae','EAE'),

(2399,'Papua New Guinea','PG','Embessa','EMS'),

(2400,'Germany','DE','Emden','EME'),

(2401,'Australia','AU','Emerald~ Queensland','EMD'),

(2402,'USA','US','Emeryville~ CA','JEM'),

(2403,'USA','US','Emigrant Gap~ CA','BLU'),

(2404,'Papua New Guinea','PG','Emirau','EMI'),

(2405,'Switzerland','CH','Emmen','XWD'),

(2406,'USA','US','Emmetsburg~ IA','EGQ'),

(2407,'USA','US','Emmonak~ AK','EMK'),

(2408,'Canada','CA','Emo~ ON','EMO'),

(2409,'South Africa','ZA','Empangeni','EMG'),

(2410,'USA','US','Emporia~ KS','EMP'),

(2411,'USA','US','Emporia~ VA','EMV'),

(2412,'Sudan','SD','En Nahud','NUD'),

(2413,'Indonesia','ID','Enarotali','EWI'),

(2414,'Paraguay','PY','Encarnacion','ENO'),

(2415,'Indonesia','ID','Ende','ENE'),

(2416,'Australia','AU','Eneabba~ Western Australia','ENB'),

(2417,'Papua New Guinea','PG','Engati','EGA'),

(2418,'USA','US','English Bay~ AK','KEB'),

(2419,'USA','US','Enid~ OK','WDG'),

(2421,'Russia','RU','Enisejsk','EIE'),

(2422,'Marshall Islands','MH','Enitewok','ENT'),

(2423,'Canada','CA','Ennadai Lake~ NT','YEI'),

(2424,'UK','GB','Enniskillen~ Northern Ireland','ENK'),

(2425,'Finland','FI','Enontekio (Enontekioe)','ENF'),

(2426,'Netherlands','NL','Enschede','ENS'),

(2427,'Mexico','MX','Ensenada','ESE'),

(2428,'China','CN','Enshi','ENH'),

(2429,'USA','US','Enterprise~ AL','ETS'),

(2430,'Nigeria','NG','Enugu','ENU'),

(2431,'Congo','CG','Epena','EPN'),

(2432,'USA','US','Ephrata~ WA','EPH'),

(2433,'Vanuatu','VU','Epi','EPI'),

(2434,'France','FR','Epinal','EPL'),

(2435,'Cyprus','CY','Episkopi','EPK'),

(2436,'Honduras','HN','Erandique','EDQ'),

(2437,'Papua New Guinea','PG','Erave','ERE'),

(2438,'Cyprus','CY','Ercan','ECN'),

(2439,'Brazil','BR','Erechim~ RS','ERM'),

(2440,'Armenia','AM','Erevan (Yerevan)','EVN'),

(2441,'Germany','DE','Erfurt','ERF'),

(2442,'Turkey','TR','Erhac','EHC'),

(2443,'USA','US','Erie~ PA','ERI'),

(2444,'Somalia','SO','Erigavo','ERA'),

(2445,'Australia','AU','Erldunda~ Northern Territory','EDD'),

(2446,'Australia','AU','Ernabella~ South Australia','ERB'),

(2447,'Australia','AU','Eromanga~ Queensland','ERG'),

(2448,'Morocco','MA','Errachidia','ERH'),

(2449,'USA','US','Errol~ NH','ERR'),

(2450,'Papua New Guinea','PG','Erume','ERU'),

(2451,'Turkey','TR','Erzincan','ERC'),

(2452,'Turkey','TR','Erzurum','ERZ'),

(2453,'Papua New Guinea','PG','Esa Ala','ESA'),

(2454,'Denmark','DK','Esbjerg','EBJ'),

(2455,'USA','US','Escanaba~ MI','ESC'),

(2456,'Sweden','SE','Eskilstuna','EKT'),

(2457,'Canada','CA','Eskimo Point (Arviat)~ NT','YEK'),

(2458,'Turkey','TR','Eskisehir','ESK'),

(2459,'Ecuador','EC','Esmeraldas','ESM'),

(2460,'USA','US','Espanola~ NM','ESO'),

(2461,'Cape Verde','CV','Esperadinha~ Brava','BVR'),

(2462,'Australia','AU','Esperance~ Western Australia','EPR'),

(2463,'Honduras','HN','Esperanza','LEZ'),

(2464,'Brazil','BR','Espinosa~ MG','ESI'),

(2465,'Vanuatu','VU','Espirito Santo','SON'),

(2466,'Argentina','AR','Esquel','EQS'),

(2467,'Canada','CA','Esquimalt~ BC','YPF'),

(2468,'Germany','DE','Essen','ESS'),

(2469,'USA','US','Essington (Philadelphia)~ PA','PSQ'),

(2470,'Canada','CA','Estevan Point~ BC','YEP'),

(2471,'Canada','CA','Estevan~ SK','YEN'),

(2472,'USA','US','Estherville~ IA','EST'),

(2473,'Australia','AU','Etadunna~ South Australia','ETD'),

(2474,'Tonga','TO','Eua','EUA'),

(2475,'Australia','AU','Eucla~ Western Australia','EUC'),

(2476,'USA','US','Eufaula~ AL','EUF'),

(2477,'USA','US','Eugene~ OR','EUG'),

(2478,'USA','US','Eunice~ LA','UCE'),

(2479,'USA','US','Eureka~ CA','EKA'),

(2480,'Canada','CA','Eureka~ NT','YEU'),

(2481,'USA','US','Eureka~ NV','EUE'),

(2482,'Australia','AU','Eva Downs~ Northern Territory','EVD'),

(2483,'USA','US','Evadale~ TX','EVA'),

(2484,'Australia','AU','Evans Head~ New South Wales','EVH'),

(2485,'USA','US','Evanston~ WY','EVW'),

(2486,'USA','US','Evansville~ IN','EVV'),

(2487,'USA','US','Eveleth~ MN','EVM'),

(2488,'Norway','NO','Evenes','EVE'),

(2489,'USA','US','Everett~ WA','PAE'),

(2490,'France','FR','Evreux','EVX'),

(2491,'USA','US','Ewa~ HI','NAX'),

(2492,'Indonesia','ID','Ewer','EWE'),

(2493,'Congo','CG','Ewo','EWO'),

(2494,'USA','US','Excursion Inlet~ AK','EXI'),

(2495,'United Kingdom','GB','Exeter','EXT'),

(2496,'United Kingdom','GB','Exmouth','EXM'),

(2497,'Mauritania','MR','F\'derik','FGD'),

(2498,'French Polynesia','PF','Faatte','FAC'),

(2499,'Burkina Faso','BF','Fada Ngourma','FNG'),

(2500,'Norway','NO','Fagernes','VDB'),

(2501,'Iceland','IS','Fagurholsmyri','FAG'),

(2502,'United Kingdom','GB','Fair Isle','FIE'),

(2503,'USA','US','Fairbanks~ AK','EIL'),

(2507,'AK USA','US','Fairbanks/Fort Wainwright','FBK'),

(2508,'USA','US','Fairbury~ NE','FBY'),

(2509,'USA','US','Fairfield~ CA','SUU'),

(2510,'USA','US','Fairfield~ IA','FFL'),

(2511,'USA','US','Fairfield~ IL','FWC'),

(2512,'United Kingdom','GB','Fairford~ England','FFD'),

(2513,'USA','US','Fairmont~ MN','FRM'),

(2514,'USA','US','Fairmont~ NE','FMZ'),

(2515,'Pakistan','PK','Faisalabad','LYP'),

(2516,'Afghanistan','AF','Faizabad','FBD'),

(2517,'Puerto Rico','PR','Fajardo','FAJ'),

(2518,'French Polynesia','PF','Fakahina','FHZ'),

(2519,'French Polynesia','PF','Fakarava~ Society Islands','FAV'),

(2520,'United Kingdom','GB','Fakenham~ England','FKH'),

(2521,'Indonesia','ID','Fakfak (Fak Fak)~ New Guinea','FKQ'),

(2522,'Canada','CA','Falher~ AB','YOE'),

(2523,'USA','US','Fallon~ NV','FLX'),

(2525,'USA','US','Falls Bay~ AK','FLJ'),

(2526,'USA','US','Falls City~ NE','FNB'),

(2527,'Australia','AU','Falls Creek','FLC'),

(2528,'USA','US','Falmouth~ MA','FMH'),

(2529,'USA','US','False Island~ AK','FAK'),

(2530,'USA','US','False Pass~ AK','KFP'),

(2531,'Papua New Guinea','PG','Fane','FNE'),

(2532,'French Polynesia','PF','Fangatau','FGU'),

(2533,'Madagascar','MG','Farafangana','RVA'),

(2534,'Afghanistan','AF','Farah','FAH'),

(2535,'Guinea','GN','Faranah','FAA'),

(2536,'USA','US','Farewell~ AK','FWL'),

(2537,'Uzbekhistan','UZ','Farghona (Fergana)~ Farghona','FEG'),

(2538,'USA','US','Fargo~ ND','FAR'),

(2539,'USA','US','Faribault~ MN','FBL'),

(2540,'Bangladesh','BD','Fariopur','FDP'),

(2541,'USA','US','Farmington~ MO','FAM'),

(2542,'USA','US','Farmington~ NM','FMN'),

(2543,'USA','US','Farmville~ VA','FVX'),

(2544,'United Kingdom','GB','Farnborough~ England','FAB'),

(2545,'Portugal','PT','Faro','FAO'),

(2546,'Canada','CA','Faro~ YT','ZFA'),

(2547,'Ireland','IE','Farranfore','KFF'),

(2548,'Norway','NO','Farsund','FAN'),

(2549,'Iceland','IS','Faskrudsfjordur','FAS'),

(2550,'Liberia','LR','Fassama','WHC'),

(2551,'Chad','TD','Faya','FYT'),

(2552,'USA','US','Fayetteville~ AR','FYV'),

(2553,'USA','US','Fayetteville~ NC','POB'),

(2554,'NC USA','US','Fayetteville','FAY'),

(2555,'USA','US','Fayetteville~ TN','FYM'),

(2556,'USA','US','Fentress~ VA','NFE'),

(2557,'Solomon Islands','SB','Fera Island','FRE'),

(2558,'Papua New Guinea','PG','Feramin','FRQ'),

(2559,'MN USA','US','Fergus Falls','FFM'),

(2560,'Kenya','KE','Fergusons Gulf','FER'),

(2561,'Ivory Coast','CI','Ferkessedougou','FEK'),

(2562,'Brazil','BR','Fernando de Noronha~ FN','FEN'),

(2563,'Morocco','MA','Fes (Fez)','FEZ'),

(2564,'USA','US','Festus~ MO','FES'),

(2565,'United Kingdom','GB','Fetlar Island','FEA'),

(2566,'Madagascar','MG','Fianarantsoa','WFI'),

(2567,'South Africa','ZA','Ficksburg','FCB'),

(2568,'France','FR','Figari~ Corsica','FSC'),

(2569,'Paraguay','PY','Filadelfia','FLM'),

(2570,'USA','US','Fillmore~ UT','FIL'),

(2571,'United Kingdom','GB','Filton','FZO'),

(2572,'USA','US','Fin Creek~ AK','FNK'),

(2573,'Ethiopia','ET','Fincha','FNH'),

(2574,'USA','US','Findlay~ OH','FDY'),

(2575,'Australia','AU','Finke~ Northern Territory','FIK'),

(2576,'Australia','AU','Finley~ New South Wales','FLY'),

(2577,'Papua New Guinea','PG','Finschhafen','FIN'),

(2578,'USA','US','Fire Cove~ AK','FIC'),

(2579,'Italy','IT','Firenze (Florence)','FLR'),

(2580,'USA','US','Fishers Island~ NY','FID'),

(2581,'USA','US','Fitchburg~ MA','FIT'),

(2582,'American Samoa','AS','Fitiuta Village','FAQ'),

(2583,'American Samoa','AS','Fitiuta','FTI'),

(2584,'USA','US','Fitzgerald~ GA','FZG'),

(2585,'Australia','AU','Fitzroy Crossing~ Western Austra','FIZ'),

(2586,'USA','US','Five Fingers~ AK','FIV'),

(2587,'USA','US','Five Mile~ AK','FMC'),

(2588,'USA','US','Flagstaff~ AZ','FLG'),

(2589,'USA','US','Flat~ AK','FLT'),

(2590,'Iceland','IS','Flateyri','FLI'),

(2591,'USA','US','Flaxman~ AK','FXM'),

(2592,'USA','US','Flemingsburg~ KY','FGX'),

(2593,'Germany','DE','Flensburg','FLF'),

(2594,'Canada','CA','Flin Flon~ MB','YFO'),

(2595,'Australia','AU','Flinders Island~ Tasmania','FLS'),

(2596,'USA','US','Flint~ MI','FNT'),

(2597,'USA','US','Flippin~ AR','FLP'),

(2598,'USA','US','Florence~ SC','FLO'),

(2599,'Colombia','CO','Florencia','FLA'),

(2600,'Guatemala','GT','Flores','FRS'),

(2601,'Brazil','BR','Floriano~ PI','FLB'),

(2602,'Brazil','BR','Florianopolis~ SC','FLN'),

(2603,'Norway','NO','Floro','FRO'),

(2604,'United Kingdom','GB','Flotta Isle','FLH'),

(2605,'Norway','NO','Foerde (Forde)','FDE'),

(2606,'Italy','IT','Foggia','FOG'),

(2607,'USA','US','Foley~ AL','NBJ'),

(2609,'Canada','CA','Fond-du-Lac~ SK','ZFD'),

(2610,'USA','US','Fond du Lac~ WI','FLD'),

(2611,'France','FR','Font Romeu','QZF'),

(2612,'Australia','AU','Forbes~ New South Wales','FRB'),

(2613,'USA','US','Forest City~ IA','FXY'),

(2614,'USA','US','Forest Park~ GA','FOP'),

(2615,'Canada','CA','Forestville~ QC','YFE'),

(2616,'Italy','IT','Forli','FRL'),

(2617,'Argentina','AR','Formosa','FMA'),

(2618,'United Kingdom','GB','Forres','FSS'),

(2619,'USA','US','Forrest City~ AR','FCY'),

(2620,'Australia','AU','Forrest~ Western Australia','FOS'),

(2621,'Australia','AU','Forster~ New South Wales','FOT'),

(2622,'Martinique','MQ','Fort-de-France','FDF'),

(2623,'Canada','CA','Fort Albany~ ON','YFA'),

(2624,'USA','US','Fort Belvoir~ VA','DAA'),

(2625,'USA','US','Fort Benning (Columbus)~ GA','LSF'),

(2627,'USA','US','Fort Bliss (El Paso)~ TX','BIF'),

(2628,'USA','US','Fort Bragg~ CA','FOB'),

(2629,'USA','US','Fort Bragg~ NC','FBG'),

(2630,'USA','US','Fort Bridger~ WY','FBR'),

(2631,'USA','US','Fort Campbell (Clarksville)~ TN ','EOD'),

(2632,'USA','US','Fort Campbell (Hopkinsville)~ KY','HOP'),

(2633,'USA','US','Fort Chaffee~ AR','CCA'),

(2634,'Canada','CA','Fort Chipewyan~ AB','YPY'),

(2635,'CO USA','US','Fort Collins/Loveland','FNL'),

(2636,'Madagascar','MG','Fort Dauphin','FTU'),

(2637,'USA','US','Fort Dodge~ IA','FOD'),

(2638,'USA','US','Fort Eustis~ VA','FAF'),

(2639,'Canada','CA','Fort Frances~ ON','YAG'),

(2640,'Canada','CA','Fort Franklin~ NT','YWJ'),

(2641,'USA','US','Fort Frederick~ AK','PFD'),

(2642,'Canada','CA','Fort Good Hope~ NT','YGH'),

(2643,'USA','US','Fort Hood (Killeen)~ TX','HLR'),

(2645,'Canada','CA','Fort Hope~ ON','YFH'),

(2646,'AZ USA','US','Fort Huachuca/Sierra Vista','FHU'),

(2647,'USA','US','Fort Hunter/Liggett/Jolon~ CA','HGT'),

(2648,'USA','US','Fort Indiantown Gap (Anvle)~ PA ','MUI'),

(2649,'CA USA','US','Fort Irwin/Barstow','BYS'),

(2650,'FL USA','US','Fort Jefferson (Dry Tortugas Nat','RBN'),

(2651,'USA','US','Fort Knox~ KY','FTK'),

(2652,'USA','US','Fort Lauderdale~ FL','FXE'),

(2653,'FL USA','US','Fort Lauderdale','FLL'),

(2654,'USA','US','Fort Leavenworth~ KS','FLV'),

(2655,'USA','US','Fort Leonard Wood~ MO','TBN'),

(2656,'USA','US','Fort Lewis (Tacoma)~ WA','GRF'),

(2657,'Canada','CA','Fort Liard~ NT','YJF'),

(2658,'USA','US','Fort Madison~ IA','FMS'),

(2659,'Canada','CA','Fort McMurray~ AB','YMM'),

(2660,'Canada','CA','Fort McPherson~ NT','ZFM'),

(2661,'USA','US','Fort Meade (Odenton)~ MD','FME'),

(2662,'USA','US','Fort Myers~ FL','FMY'),

(2664,'Canada','CA','Fort Nelson~ BC','YYE'),

(2665,'Canada','CA','Fort Norman~ NT','ZFN'),

(2666,'USA','US','Fort Ord/Monterey~ CA','OAR'),

(2667,'USA','US','Fort Pierce~ FL','FPR'),

(2668,'USA','US','Fort Polk~ LA','POE'),

(2669,'Canada','CA','Fort Providence~ NT','YJP'),

(2670,'Canada','CA','Fort Reliance~ NT','YFL'),

(2671,'Canada','CA','Fort Resolution~ NT','YFR'),

(2672,'USA','US','Fort Richardson (Anchorage)~ AK ','FRN'),

(2673,'USA','US','Fort Riley (Junction City)~ KS','FRI'),

(2674,'Congo','CG','Fort Rousset','FTX'),

(2675,'USA','US','Fort Rucker (Ozark)~ AL','OZR'),

(2676,'USA','US','Fort Rucker/Ozark~ AL','HEY'),

(2678,'USA','US','Fort Scott~ KS','FSK'),

(2679,'Canada','CA','Fort Severn~ ON','YER'),

(2680,'USA','US','Fort Sheridan~ IL','FSN'),

(2681,'USA','US','Fort Sill~ OK','FSI'),

(2682,'Canada','CA','Fort Simpson~ NT','YFS'),

(2683,'USA','US','Fort Smith~ AR','FSM'),

(2684,'Canada','CA','Fort Smith~ NT','YSM'),

(2685,'Canada','CA','Fort St. James~ BC','YJM'),

(2686,'Canada','CA','Fort St. John~ BC','YXJ'),

(2687,'USA','US','Fort Stockton~ TX','FST'),

(2688,'USA','US','Fort Sumner~ NM','FSU'),

(2689,'FL USA','US','Fort Walton Beach (Valparaiso)','VPS'),

(2690,'USA','US','Fort Wayne~ IN','FWA'),

(2692,'United Kingdom','GB','Fort William','FWM'),

(2693,'USA','US','Fort Worth~ TX','FWH'),

(2698,'USA','US','Fort Yukon~ AK','FYU'),

(2699,'USA','US','Fort Zucker/Ozark~ AL','FHK'),

(2700,'Brazil','BR','Fortaleza~ CE','FOR'),

(2701,'USA','US','Fortuna Ledge~ AK','FTL'),

(2702,'Australia','AU','Fossil Downs~ Western Australia','FSL'),

(2703,'USA','US','Fosston~ MN','FSE'),

(2704,'USA','US','Fostoria~ OH','FZI'),

(2705,'Gabon','GA','Fougamou','FOU'),

(2706,'United Kingdom','GB','Foula~ Shetland Islands','FOA'),

(2707,'Cameroon','CM','Foumban','FOM'),

(2708,'New Zealand','NZ','Fox Glacier','FGL'),

(2709,'Canada','CA','Fox Harbour/St. Lewis~ NF','YFX'),

(2710,'USA','US','Fox~ AK','FOX'),

(2711,'Liberia','LR','Foya','FOY'),

(2712,'Brazil','BR','Foz do Iguacu (Iguassu Falls)~ P','IGU'),

(2713,'Brazil','BR','Franca~ SP','FRC'),

(2714,'Gabon','GA','Franceville','MVB'),

(2715,'Brazil','BR','Francisco Beltrao~ PR','FBE'),

(2716,'Botswana','BW','Francistown','FRW'),

(2717,'USA','US','Frankfort~ IN','FKR'),

(2718,'USA','US','Frankfort~ KY','FFT'),

(2719,'Germany','DE','Frankfurt','FRF'),

(2721,'USA','US','Franklin~ PA','FKL'),

(2722,'VA USA','US','Franklin','FKN'),

(2723,'New Zealand','NZ','Franz Josef','WHO'),

(2724,'USA','US','Frederick~ MD','FDK'),

(2725,'USA','US','Frederick~ OK','FDR'),

(2726,'USA','US','Fredericksburg~ VA','EZF'),

(2727,'Canada','CA','Fredericton~ NB','YFC'),

(2728,'Greenland','GL','Frederikshab','JFR'),

(2729,'Denmark','DK','Frederikshavn','QFH'),

(2730,'U.S. Virgin Islands','US','Frederiksted~ St. Croix','JCD'),

(2731,'Bahamas','BS','Freeport~ Grand Bahama','FPO'),

(2732,'USA','US','Freeport~ IL','FEP'),

(2733,'Sierra Leone','SL','Freetown','HGS'),

(2736,'Seychelles','SC','Fregate Island','FRK'),

(2737,'Germany','DE','Freiburg','QFB'),

(2738,'France','FR','Frejus','FRJ'),

(2739,'Australia','AU','Fremantle~ Western Australia','JFM'),

(2740,'USA','US','Fremont~ NE','FET'),

(2741,'USA','US','French Lick~ IN','FRH'),

(2742,'USA','US','Frenchville~ ME','WFK'),

(2743,'USA','US','Fresh Water Bay~ AK','FRP'),

(2744,'USA','US','Fresno~ CA','FCH'),

(2746,'Guinea','GN','Fria','FIG'),

(2747,'USA','US','Friday Harbor~ WA','FRD'),

(2748,'Germany','DE','Friedrichshafen','FDH'),

(2749,'Germany','DE','Fritzlar','FRZ'),

(2750,'USA','US','Front Royal~ VA','FRR'),

(2751,'Italy','IT','Frosinone','QFR'),

(2752,'USA','US','Fryeburg~ ME','FRY'),

(2753,'Germany','DE','Fuerstenfeldbruck','FEL'),

(2754,'Spain','ES','Fuerteventura/Puerto del Rosario','FUE'),

(2755,'Japan','JP','Fukue','FUJ'),

(2756,'Japan','JP','Fukui','FKJ'),

(2757,'Japan','JP','Fukuoka~ Kyoshu','FUK'),

(2758,'Japan','JP','Fukushima','FKS'),

(2759,'Papua New Guinea','PG','Fulleborn','FUB'),

(2760,'USA','US','Fullerton~ CA','FUL'),

(2761,'USA','US','Fulton~ MO','FTT'),

(2762,'Papua New Guinea','PG','Fuma','FUM'),

(2763,'Tuvalu','TV','Funafuti','FUN'),

(2764,'Portugal','PT','Funchal~ Madeira','FNC'),

(2765,'Colombia','CO','Fundacion','FDA'),

(2766,'USA','US','Funter Bay~ AK','FNR'),

(2767,'China','CN','Fuoshan','FUO'),

(2768,'Chile','CL','Futaleufu','FFU'),

(2769,'Wallis and Futuna Islands','WF','Futuna Island','FTA'),

(2770,'Wallis and Futuna Islands','WF','Futuna','FUT'),

(2771,'China','CN','Fuyang','FUG'),

(2772,'China','CN','Fuyun','FYN'),

(2773,'China','CN','Fuzhou','FOC'),

(2774,'USA','US','Gabbs~ NV','GAB'),

(2775,'Tunisia','TN','Gabes','GAE'),

(2776,'Botswana','BW','Gaborone','GBE'),

(2777,'USA','US','Gadsden~ AL','GAD'),

(2778,'Tunisia','TN','Gafsa','GAF'),

(2779,'Indonesia','ID','Gag Island','GAV'),

(2780,'USA','US','Gage~ OK','GAG'),

(2781,'Canada','CA','Gagetown~ NB','YCX'),

(2782,'Ivory Coast','CI','Gagnoa','GGN'),

(2783,'Canada','CA','Gagnon~ QC','YGA'),

(2784,'USA','US','Gainesville~ FL','GNV'),

(2785,'USA','US','Gainesville~ GA','GVL'),

(2786,'USA','US','Gainesville~ TX','GLE'),

(2787,'USA','US','Gaithersburg~ MD','GAI'),

(2788,'USA','US','Gakona~ AK','GAK'),

(2789,'Sri Lanka','LK','Gal Oya','GOY'),

(2790,'Ecuador','EC','Galapagos Islands~ Galapagos','GPS'),

(2791,'USA','US','Galax/Hillsville~ VA','HLX'),

(2792,'USA','US','Galbraith Lake~ AK','GBH'),

(2793,'Somalia','SO','Galcaio','GLK'),

(2794,'Indonesia','ID','Galela','GLX'),

(2795,'USA','US','Galena~ AK','GAL'),

(2796,'USA','US','Galesburg~ IL','GBG'),

(2797,'USA','US','Galion~ OH','GQQ'),

(2798,'Somalia','SO','Galkayo','GBY'),

(2799,'Sweden','SE','Gallivare','GEV'),

(2800,'USA','US','Gallup~ NM','GUP'),

(2801,'USA','US','Galveston~ TX','GLS'),

(2802,'Ireland','IE','Galway','GWY'),

(2803,'Colombia','CO','Gamarra','GRA'),

(2804,'Gabon','GA','Gamba','GAX'),

(2805,'Ethiopia','ET','Gambela','GMB'),

(2806,'USA','US','Gambell~ AK','GAM'),

(2807,'Congo','CG','Gamboma','GMM'),

(2808,'Australia','AU','Gamboola~ Queensland','GBP'),

(2809,'Maldives','MV','Addu City','GAN'),

(2810,'Zaire','ZR','Gandajika','GDJ'),

(2811,'Canada','CA','Gander~ NF','YQX'),

(2812,'USA','US','Ganes Creek~ AK','GEK'),

(2813,'Myanmar','MM','Gangaw','GAW'),

(2814,'Canada','CA','Ganges Harbor~ BC','YGG'),

(2815,'China','CN','Ganzhou','KOW'),

(2816,'Mali','ML','Gao','GAQ'),

(2817,'Burkina Faso','BF','Gaoua','XGA'),

(2818,'France','FR','Gap','GAT'),

(2819,'Algeria','DZ','Gara Djebilet','GBB'),

(2820,'Panama','PA','Garachine','GHE'),

(2821,'Papua New Guinea','PG','Garaina','GAR'),

(2822,'Brazil','BR','Garanhuns~ PE','QGB'),

(2823,'Papua New Guinea','PG','Garasa','GRL'),

(2824,'Somalia','SO','Garbaharey','GBM'),

(2825,'Somalia','SO','Garde','GGR'),

(2826,'USA','US','Garden City~ KS','GCK'),

(2827,'USA','US','Garden City~ NY','JHC'),

(2828,'Canada','CA','Garden Hill~ MB','GHL'),

(2829,'Australia','AU','Garden Point~ Northern Territory','GPN'),

(2830,'Afghanistan','AF','Gardez','GRG'),

(2831,'USA','US','Gardner~ MA','GDM'),

(2832,'Somalia','SO','Gardo','GSR'),

(2833,'Kenya','KE','Garissa','GAS'),

(2834,'Germany','DE','Garmisch-Partenkirchen','ZEI'),

(2835,'Cameroon','CM','Garoua','GOU'),

(2836,'Canada','CA','Garrow Lake','GOW'),

(2837,'Papua New Guinea','PG','Garuahi','GRH'),

(2838,'Brazil','BR','Garulhos~ SP','QCV'),

(2839,'USA','US','Gary~ IN','GYY'),

(2840,'Australia','AU','Gascoyne Junction~ Western Austr','GSC'),

(2841,'Papua New Guinea','PG','Gasmata Island','GMI'),

(2842,'Canada','CA','Gaspe~ QC','YGP'),

(2843,'Saudi Arabia','SA','Gassim','ELQ'),

(2844,'Papua New Guinea','PG','Gasuke','GBC'),

(2845,'USA','US','Gatlinburg/Sevierville~ TN','GKT'),

(2846,'Colombia','CO','Gaviotas','WWN'),

(2847,'Sweden','SE','Gavle','GVX'),

(2848,'India','IN','Gaya','GAY'),

(2849,'USA','US','Gaylord~ MI','GLR'),

(2850,'Australia','AU','Gayndah~ Queensland','GAH'),

(2851,'Turkey','TR','Gaziantep','GZT'),

(2852,'Zaire','ZR','Gbadolite','BDT'),

(2853,'Sierra Leone','SL','Gbangbatok','GBK'),

(2854,'Poland','PL','Gdansk','GDN'),

(2855,'Indonesia','ID','Gebe','GEB'),

(2856,'Cyprus','CY','Gecitkale','GEC'),

(2857,'Sudan','SD','Gedaref','GSU'),

(2858,'Australia','AU','Geelong~ Victoria','GEX'),

(2859,'Germany','DE','Geilenkirchen','GKE'),

(2860,'Norway','NO','Geilo','DLD'),

(2862,'Tanzania','TZ','Geita','GIT'),

(2863,'Ethiopia','ET','Geladi','GLC'),

(2864,'Zaire','ZR','Gemana','GMA'),

(2865,'Ethiopia','ET','Genda Wuha','ETE'),

(2866,'Argentina','AR','General Pico','GPO'),

(2867,'Argentina','AR','General Roca','GNR'),

(2868,'Philippines','PH','General Santos','GES'),

(2869,'Argentina','AR','General Villega','VGS'),

(2870,'Switzerland','CH','Geneva','GVA'),

(2871,'Indonesia','ID','Genjem','GNJ'),

(2872,'Italy','IT','Genoa (Genova)','GOA'),

(2873,'Malaysia','MY','Genting','GTB'),

(2874,'Bahamas','BS','George Town~ Exuma','GGT'),

(2875,'South Africa','ZA','George','GRJ'),

(2876,'Guyana','GY','Georgetown','GEO'),

(2877,'USA','US','Georgetown~ DE','GED'),

(2878,'Australia','AU','Georgetown~ Queensland','GTT'),

(2879,'USA','US','Georgetown~ SC','GGE'),

(2880,'Canada','CA','Geraldton~ ON','YGQ'),

(2881,'Australia','AU','Geraldton~ Western Australia','GET'),

(2882,'Canada','CA','Germansen~ BC','YGS'),

(2883,'Spain','ES','Gerona','GRO'),

(2884,'Canada','CA','Gethsemani~ QC','ZGS'),

(2885,'USA','US','Gettysburg~ PA','GTY'),

(2886,'Solomon Islands','SB','Geva','GEF'),

(2887,'Papua New Guinea','PG','Gewoya','GEW'),

(2888,'Libya','LY','Ghadames','LTD'),

(2889,'Botswana','BW','Ghanzi','GNZ'),

(2890,'Algeria','DZ','Ghardaia','GHA'),

(2891,'Libya','LY','Ghat','GHT'),

(2892,'Afghanistan','AF','Ghazni','GZI'),

(2893,'Belgium','BE','Ghent (Gent)','GNE'),

(2894,'Ethiopia','ET','Ghimbi','GHD'),

(2895,'Ethiopia','ET','Ghinnir','GNN'),

(2896,'Australia','AU','Gibb River~ Western Australia','GBV'),

(2897,'Gibraltar','GI','Gibraltar','GIB'),

(2898,'Japan','JP','Gifu','QGU'),

(2899,'Spain','ES','Gijon','QIJ'),

(2900,'USA','US','Gila Bend~ AZ','GBN'),

(2901,'Colombia','CO','Gilgal','GGL'),

(2902,'Pakistan','PK','Gilgit','GIL'),

(2903,'Canada','CA','Gillam~ MB','YGX'),

(2904,'USA','US','Gillette~ WY','GCC'),

(2905,'Canada','CA','Gillies Bay (Texada)~ BC','YGB'),

(2906,'Canada','CA','Gimli~ MB','YGM'),

(2907,'Colombia','CO','Giradot','GIR'),

(2908,'New Zealand','NZ','Gisborne','GIS'),

(2909,'Rwanda','RW','Gisenyi','GYI'),

(2910,'Burundi','BI','Gitenga','GID'),

(2911,'South Africa','ZA','Giyana','GIY'),

(2912,'Saudi Arabia','SA','Gizan','GIZ'),

(2913,'Solomon Islands','SB','Gizo','GZO'),

(2914,'Canada','CA','Gjoa Haven~ NT','YHK'),

(2915,'USA','US','Glacier Creek~ AK','KGZ'),

(2916,'Canada','CA','Gladman Point~ NT','YUR'),

(2917,'Australia','AU','Gladstone~ Queensland','GLT'),

(2918,'USA','US','Gladwin~ MI','GDW'),

(2919,'USA','US','Glasgow~ KY','GLW'),

(2920,'USA','US','Glasgow~ MT','GSG'),

(2922,'United Kingdom','GB','Glasgow~ Scotland','GLA'),

(2923,'Australia','AU','Glen Innes~ New South Wales','GLI'),

(2924,'USA','US','Glendale~ AZ','GEU'),

(2925,'USA','US','Glendale~ WV','GWV'),

(2926,'USA','US','Glendale/Los Angeles~ CA','JGX'),

(2927,'USA','US','Glendale/Phoenix~ AZ','LUF'),

(2928,'USA','US','Glendive~ MT','GDV'),

(2929,'Australia','AU','Glengyle~ Queensland','GLG'),

(2930,'USA','US','Glennallen~ AK','GLQ'),

(2931,'Australia','AU','Glenormiston','GLM'),

(2932,'USA','US','Glens Falls~ NY','GFL'),

(2933,'USA','US','Glenview~ IL','NBU'),

(2934,'USA','US','Glenwood Springs~ CO','GWS'),

(2935,'USA','US','Globe~ AZ','GAZ'),

(2936,'United Kingdom','GB','Gloucester','GLO'),

(2937,'India','IN','Goa','GOI'),

(2938,'Ethiopia','ET','Goba','GOB'),

(2939,'Argentina','AR','Gobernador dos Gregores','GGS'),

(2940,'Ethiopia','ET','Gode','GDE'),

(2941,'Canada','CA','Goderich~ ON','YGD'),

(2942,'Greenland','GL','Godhavn','JGO'),

(2943,'Canada','CA','Gods Narrows~ MB','YGO'),

(2944,'Canada','CA','Gods River~ MB','ZGI'),

(2945,'Greenland','GL','Godthab/Nuuk','GOH'),

(2946,'Brazil','BR','Goiania~ GO','GYN'),

(2947,'USA','US','Gold Beach~ OR','GOL'),

(2948,'Australia','AU','Gold Coast (Coolangatta)~ Queens','OOL'),

(2949,'USA','US','Golden Horn~ AK','GDH'),

(2951,'USA','US','Goldsboro-Wayne~ NC','GWW'),

(2952,'USA','US','Goldsboro~ NC','GSB'),

(2953,'Costa Rica','CR','Golfito','GLF'),

(2954,'Norway','NO','Goll','GLL'),

(2955,'China','CN','Golmud','GOQ'),

(2956,'USA','US','Golovin~ AK','GLV'),

(2957,'Zaire','ZR','Goma','GOM'),

(2958,'Papua New Guinea','PG','Gonaila','GOE'),

(2959,'Ethiopia','ET','Gondar','GDQ'),

(2960,'USA','US','Gooding~ ID','GNG'),

(2961,'USA','US','Goodland~ KS','GLD'),

(2962,'USA','US','Goodnews Bay~ AK','GNU'),

(2963,'USA','US','Goodyear~ AZ','GYR'),

(2964,'Australia','AU','Goondiwindi~ Queensland','GOO'),

(2965,'Canada','CA','Goose Bay~ NF','YYR'),

(2966,'Canada','CA','Goose','YYP'),

(2967,'China','CN','Gora','GOC'),

(2968,'India','IN','Gorakhpur','GOP'),

(2969,'Central African Republic','CF','Gordil','GDI'),

(2970,'Australia','AU','Gordon Downs~ Western Australia','GDD'),

(2971,'USA','US','Gordon~ NE','GRN'),

(2972,'USA','US','Gordonsville~ VA','GVE'),

(2973,'Canada','CA','Gore Bay~ ON','YZE'),

(2974,'Ethiopia','ET','Gore','GOR'),

(2975,'Canada','CA','Gorge Harbor~ BC','YGE'),

(2976,'Nepal','NP','Gorkha','GKH'),

(2977,'Bulgaria','BG','Gorna','GOZ'),

(2978,'Papua New Guinea','PG','Goroka','GKA'),

(2979,'Burkina Faso','BF','Gorom Gorom','XGG'),

(2980,'Indonesia','ID','Gorontalo','GTO'),

(2981,'Australia','AU','Gosford~ New South Wales','GOS'),

(2982,'USA','US','Goshen~ IN','GSH'),

(2983,'Germany','DE','Goslar','ZET'),

(2984,'Sweden','SE','Goteborg (Gothenburg)','GOT'),

(2985,'Sweden','SE','Goteborg','GSE'),

(2986,'Slovakia','SK','Gottwaldov','GTW'),

(2987,'Australia','AU','Goulburn Island~ Northern Territ','GBL'),

(2988,'Australia','AU','Goulburn~ New South Wales','GUL'),

(2989,'Morocco','MA','Goulimime','GLN'),

(2990,'Central African Republic','CF','Gounda','GDA'),

(2991,'Mali','ML','Goundam','GUD'),

(2992,'Brazil','BR','Governador Valadares~ MG','GVR'),

(2993,'Bahamas','BS','Governors Harbour~ Eleuthera','GHB'),

(2994,'Argentina','AR','Goya','OYA'),

(2995,'Malta','MT','Gozo','GZM'),

(2996,'Honduras','HN','Gracias','GAC'),

(2997,'Portugal','PT','Graciosa Island~ Azores','GRW'),

(2998,'Australia','AU','Grafton~ New South Wales','GFN'),

(2999,'Spain','ES','Granada','GRX'),

(3000,'USA','US','Granby~ CO','GNY'),

(3001,'Bahamas','BS','Grand Bahama Island~ Grand Baham','GBI'),

(3002,'USA','US','Grand Canyon~ AZ','JGC'),

(3005,'Cayman Islands','KY','Grand Cayman~ Grand Cayman','GCM'),

(3006,'Liberia','LR','Grand Cess','GRC'),

(3007,'Canada','CA','Grand Forks~ BC','ZGF'),

(3008,'USA','US','Grand Forks~ ND','GFK'),

(3009,'USA','US','Grand Island~ NE','GRI'),

(3010,'USA','US','Grand Junction~ CO','GJT'),

(3011,'USA','US','Grand Ledge~ MI','GJI'),

(3012,'USA','US','Grand Marais~ MN','GRM'),

(3013,'USA','US','Grand Rapids~ MI','GRR'),

(3014,'MN USA','US','Grand Rapids','GPZ'),

(3015,'Turks & Caicos','TC','Grand Turk~ Grand Turk Is.','GDT'),

(3016,'Canada','CA','Grande Cache~ AB','YGC'),

(3017,'Canada','CA','Grande Prairie~ AB','YQU'),

(3018,'USA','US','Grandview (Kansas City)~ MO','GVW'),

(3019,'USA','US','Granite Mountain~ AK','GMT'),

(3020,'Australia','AU','Granites~ Northern Territory','GTS'),

(3021,'USA','US','Grant~ NE','GGF'),

(3022,'USA','US','Grants~ NM','GNT'),

(3023,'USA','US','Grantsburg~ WI','GTG'),

(3024,'Canada','CA','Granville Lake~ MB','XGL'),

(3025,'France','FR','Granville','GFR'),

(3026,'USA','US','Grass Valley~ CA','WKP'),

(3027,'USA','US','Grayling~ AK','KGX'),

(3028,'Austria','AT','Graz','GRZ'),

(3029,'Australia','AU','Great Aussie Hole','BPR'),

(3030,'New Zealand','NZ','Great Barrier Island','GBZ'),

(3031,'USA','US','Great Barrington~ MA','GBR'),

(3032,'USA','US','Great Bend~ KS','GBD'),

(3033,'USA','US','Great Falls~ MT','GTF'),

(3035,'Bahamas','BS','Great Harbour Cay~ Berry','GHC'),

(3036,'Australia','AU','Great Keppel Island~ Queensland','GKL'),

(3037,'USA','US','Greeley~ CO','GXY'),

(3038,'USA','US','Green Bay~ WI','GRB'),

(3039,'Jamaica','JM','Green Island','GNI'),

(3040,'Solomon Islands','SB','Green Isle','GEI'),

(3041,'Papua New Guinea','PG','Green River','GVI'),

(3042,'USA','US','Green River~ UT','RVR'),

(3043,'Bahamas','BS','Green Turtle Cay','GTC'),

(3044,'USA','US','Greenbrier (Lewisburg)~ WV','LWB'),

(3045,'USA','US','Greeneville~ TN','GCY'),

(3046,'USA','US','Greenfield~ IA','GFZ'),

(3047,'USA','US','Greenfield~ IN','GFD'),

(3048,'USA','US','Greenfield~ MA','URE'),

(3049,'USA','US','Greensboro (Baltimore)~ MD','GBO'),

(3050,'NC USA','US','Greensboro/High Point','GSO'),

(3051,'Australia','AU','Greenvale~ Queensland','GVP'),

(3052,'USA','US','Greenville~ IL','GRE'),

(3053,'USA','US','Greenville~ MS','GLH'),

(3054,'USA','US','Greenville~ NC','PGV'),

(3055,'USA','US','Greenville~ SC','GDC'),

(3057,'USA','US','Greenville~ TX','GVT'),

(3058,'SC USA','US','Greenville/Spartanburg (Greer)','GSP'),

(3059,'Canada','CA','Greenway Sound~ BC','YGN'),

(3060,'USA','US','Greenwood~ MS','GWO'),

(3061,'Canada','CA','Greenwood~ NS','YZX'),

(3062,'USA','US','Greenwood~ SC','GRD'),

(3063,'Australia','AU','Gregory Downs~ Queensland','GGD'),

(3064,'Grenada','GD','Grenada (Grenville)','GND'),

(3065,'Switzerland','CH','Grenchen','ZHI'),

(3066,'Australia','AU','Grenfell~ New South Wales','GFE'),

(3067,'France','FR','Grenoble','GNB'),

(3068,'USA','US','Greybull~ WY','GEY'),

(3069,'New Zealand','NZ','Greymouth','GMN'),

(3070,'Australia','AU','Griffith~ New South Wales','GFF'),

(3071,'United Kingdom','GB','Grimsby','GSY'),

(3072,'Iceland','IS','Grimsey','GRY'),

(3073,'USA','US','Grinnell~ IA','GGI'),

(3074,'Canada','CA','Grise Fiord~ NT','YGZ'),

(3075,'Netherlands','NL','Groningen','GRQ'),

(3076,'Greenland','GL','Gronnedal','JGR'),

(3077,'Australia','AU','Groote Eylandt~ Northern Territo','GTE'),

(3078,'Namibia','LC','Grootfontein','GFY'),

(3079,'Italy','IT','Grosseto','GRS'),

(3080,'USA','US','Groton (New London)~ CT','GON'),

(3081,'Russia','RU','Groznyy (Grozny~Groznyj)~ Cheche','GRV'),

(3082,'Iceland','IS','Grundarfjordur','GUU'),

(3083,'USA','US','Grundy~ VA','GDY'),

(3084,'Colombia','CO','Guacamayas','GCA'),

(3085,'Mexico','MX','Guadalajara','GDL'),

(3086,'Solomon Islands','SB','Guadalcanal','GSI'),

(3087,'USA','US','Guadalupe~ TX','GDP'),

(3088,'Brazil','BR','Guaira~ PR','QGA'),

(3089,'Brazil','BR','Guajara-Mirim~ RO','GJM'),

(3090,'Honduras','HN','Gualaco','GUO'),

(3091,'Argentina','AR','Gualeguaychu','GHU'),

(3092,'Guam','GU','Guam','NRV'),

(3093,'Guam','GU','Guam~ Andersen Island','UAM'),

(3095,'Colombia','CO','Guamal','GAA'),

(3096,'Honduras','HN','Guanaja Island','GJA'),

(3097,'Brazil','BR','Guanambi~ BA','GNM'),

(3098,'Venezuela','VE','Guanare','GUQ'),

(3099,'China','CN','Guangzhou (Canton)','CAN'),

(3100,'Cuba','CU','Guantanamo','NBW'),

(3102,'Colombia','CO','Guapi','GPI'),

(3103,'Costa Rica','CR','Guapiles','GPL'),

(3104,'Brazil','BR','Guarapuava~ PR','GPB'),

(3105,'Brazil','BR','Guaratingueta~ SP','GUJ'),

(3106,'Papua New Guinea','PG','Guari','GUG'),

(3107,'Venezuela','VE','Guasqualito','GDO'),

(3108,'Guatemala','GT','Guatemala City','GUA'),

(3109,'Ecuador','EC','Guayaquil','GYE'),

(3110,'Bolivia','BO','Guayaramerin','GYA'),

(3111,'Mexico','MX','Guaymas','GYM'),

(3112,'Colombia','CO','Guerima','GMC'),

(3113,'Channel Islands','GB','Guernsey','GCI'),

(3114,'Mexico','MX','Guerrero Negro','GUB'),

(3115,'Germany','DE','Guetersloh (Gutersloh)','GUT'),

(3116,'Ivory Coast','CI','Guiglo','GGO'),

(3117,'China','CN','Guilin','KWL'),

(3118,'Brazil','BR','Guimaraes~ MA','GMS'),

(3119,'Venezuela','VE','Guiria','GUI'),

(3120,'China','CN','Guiyang','KWE'),

(3121,'Pakistan','PK','Gujrat','GRT'),

(3122,'USA','US','Gulf Shores~ AL','GUF'),

(3123,'USA','US','Gulfport/Biloxi~ MS','GPT'),

(3124,'Papua New Guinea','PG','Gulgubip','GLP'),

(3125,'USA','US','Gulkana~ AK','GKN'),

(3126,'Uganda','UG','Gulu','ULU'),

(3127,'India','IN','Guna','GUX'),

(3128,'Australia','AU','Gunnedah~ New South Wales','GUH'),

(3129,'USA','US','Gunnison~ CO','GUC'),

(3130,'Indonesia','ID','Gunungsitoli','GNS'),

(3131,'Saudi Arabia','SA','Gurayat','URY'),

(3132,'Papua New Guinea','PG','Gurney/Alotau','GUR'),

(3133,'Brazil','BR','Gurupi~ GO','GRP'),

(3134,'Papua New Guinea','PG','Gusap','GAP'),

(3135,'Nigeria','NG','Gusau','QUS'),

(3136,'Israel','IL','Gush Katif','GHK'),

(3137,'USA','US','Gustavus~ AK','GST'),

(3138,'AK USA','US','Gustavus/Bartlett Cove','BQV'),

(3139,'USA','US','Guthrie Center~ IA','GCT'),

(3140,'USA','US','Guthrie~ OK','GOK'),

(3141,'India','IN','Guwahati (Gauhati)','GAU'),

(3142,'USA','US','Guymon~ OK','GUY'),

(3143,'Myanmar','MM','Gwa Burma','GWA'),

(3144,'Pakistan','PK','Gwadar','GWD'),

(3145,'India','IN','Gwalior','GWL'),

(3146,'Zimbabwe','ZW','Gweru','GWE'),

(3147,'USA','US','Gwinn/Marquette~ MI','SAW'),

(3148,'USA','US','Gwinner~ ND','GWR'),

(3149,'Azerbaijan','AZ','Gyandzha','KVD'),

(3150,'Australia','AU','Gympie~ Queensland','GYP'),

(3151,'Armenia','AM','Gyumri (Leninakan)','LWN'),

(3152,'Tonga','TO','Haapai','HPA'),

(3153,'Japan','JP','Hachijo Jima Island','HAC'),

(3154,'Japan','JP','Hachinohe','HHE'),

(3155,'Chad','TD','Hadjer','OUM'),

(3156,'Saudi Arabia','SA','Hafr Albatin','HBT'),

(3157,'USA','US','Hagerstown~ MD','HGR'),

(3158,'Sweden','SE','Hagfors','HFS'),

(3159,'Germany','DE','Hahn','HHN'),

(3160,'Vietnam','VN','Hai Phong','HPH'),

(3161,'Israel','IL','Haifa','HFA'),

(3162,'China','CN','Haikou','HAK'),

(3163,'Saudi Arabia','SA','Hail','HAS'),

(3164,'China','CN','Hailar','HLD'),

(3165,'Canada','CA','Haines Junction~ YT','YHT'),

(3166,'USA','US','Haines~ AK','HNS'),

(3167,'Canada','CA','Hakai Pass','YHC'),

(3168,'Japan','JP','Hakodate~ Hokkaido','HKD'),

(3169,'South Africa','ZA','Halali','HAL'),

(3170,'USA','US','Half Moon Bay~ CA','HAF'),

(3171,'Canada','CA','Halifax~ NS','YWF'),

(3174,'Canada','CA','Hall Beach~ NT','YUX'),

(3175,'Australia','AU','Halls Creek~ Western Australia','HCQ'),

(3176,'Sweden','SE','Halmstad','HAD'),

(3177,'Iran','IR','Hamadan','HDM'),

(3178,'Norway','NO','Hamar','HMR'),

(3179,'Germany','DE','Hamburg','XFW'),

(3181,'China','CN','Hami','HMI'),

(3182,'Australia','AU','Hamilton Island~ Queensland','HTI'),

(3183,'USA','US','Hamilton~ AL','HAB'),

(3184,'New Zealand','NZ','Hamilton','HLZ'),

(3185,'USA','US','Hamilton~ OH','HAO'),

(3186,'Canada','CA','Hamilton~ ON','YHM'),

(3187,'Australia','AU','Hamilton~ Victoria','HLT'),

(3188,'Germany','DE','Hamm','ZNB'),

(3189,'Norway','NO','Hammerfest','HFT'),

(3190,'USA','US','Hampton~ IA','HPT'),

(3191,'USA','US','Hampton~ VA','LFI'),

(3192,'USA','US','Hana~ HI','HNM'),

(3193,'USA','US','Hanalei~ HI','AOW'),

(3194,'USA','US','Hanapepe~ HI','PAK'),

(3195,'USA','US','Hancock~ MI','CMX'),

(3196,'China','CN','Hangzhou','HGH'),

(3197,'China','CN','Hankow','HKW'),

(3198,'USA','US','Hanksville~ UT','HVE'),

(3199,'USA','US','Hanna~ WY','HNX'),

(3200,'Germany','DE','Hannover','HAJ'),

(3201,'Vietnam','VN','Hanoi','HAN'),

(3202,'USA','US','Hanus Bay~ AK','HBC'),

(3203,'China','CN','Hanzhong','HZG'),

(3204,'French Polynesia','PF','Hao Island','HOI'),

(3205,'Zimbabwe','ZW','Harare','HRE'),

(3206,'China','CN','Harbin','HRB'),

(3207,'Bahamas','BS','Harbour Island','HBI'),

(3208,'Somalia','SO','Hargeisa','HGA'),

(3209,'USA','US','Harlan~ IA','HNR'),

(3210,'USA','US','Harlingen~ TX','HRL'),

(3211,'USA','US','Harlowton~ MT','HWQ'),

(3212,'USA','US','Harold~ FL','NZX'),

(3213,'Canada','CA','Harrington Harbour~ QC','YHR'),

(3214,'USA','US','Harrisburg (Middletown)~ PA','MDT'),

(3215,'USA','US','Harrisburg~ IL','HSB'),

(3216,'USA','US','Harrisburg~ PA','HAR'),

(3217,'South Africa','ZA','Harrismith','HRS'),

(3218,'USA','US','Harrison~ AR','HRO'),

(3219,'United Kingdom','GB','Harrogate','HRT'),

(3220,'USA','US','Hartford~ CT','HFD'),

(3221,'USA','US','Hartford~ WI','HXF'),

(3222,'USA','US','Hartford/Springfield CT','BDL'),

(3223,'Canada','CA','Hartley Bay~ BC','YTB'),

(3224,'USA','US','Hartsville~ SC','HVS'),

(3225,'Bulgaria','BG','Haskovo','HKV'),

(3226,'Belgium','BE','Hasselt','QHA'),

(3227,'Algeria','DZ','Hassi Messaoud','HME'),

(3228,'Algeria','DZ','Hassi Rmel','HRM'),

(3229,'USA','US','Hastings~ NE','HSI'),

(3230,'Norway','NO','Hasvik','HAA'),

(3231,'Japan','JP','Hateruma','HTR'),

(3232,'United Kingdom','GB','Hatfield~ England','HTF'),

(3233,'Colombia','CO','Hato Corozal','HTZ'),

(3234,'USA','US','Hatteras~ NC','HNC'),

(3235,'USA','US','Hattiesburg~ MS','HBG'),

(3236,'Thailand','TH','Hatyai (Hat Yai)','HDY'),

(3237,'Papua New Guinea','PG','Hatzfeldthaven','HAZ'),

(3238,'Norway','NO','Haugesund','HAU'),

(3239,'USA','US','Havasupai~ AZ','HAE'),

(3240,'United Kingdom','GB','Haverfordwest~ Wales','HAW'),

(3241,'China','CN','Havilar','WDY'),

(3242,'Canada','CA','Havre St. Pierre~ QC','YGV'),

(3243,'USA','US','Havre~ MT','HVR'),

(3244,'Papua New Guinea','PG','Hawabango','HWA'),

(3245,'USA','US','Hawi~ HI','UPP'),

(3246,'USA','US','Hawk Inlet~ AK','HWI'),

(3247,'Australia','AU','Hawker~ South Australia','HWK'),

(3248,'USA','US','Hawthorne~ CA','HHR'),

(3249,'USA','US','Hawthorne~ NV','HTH'),

(3250,'Canada','CA','Hay River~ NT','YHY'),

(3251,'Australia','AU','Hay~ New South Wales','HXX'),

(3252,'USA','US','Haycock~ AK','HAY'),

(3253,'Papua New Guinea','PG','Hayfields','HYF'),

(3254,'Australia','AU','Hayman Island~ Queensland','HIS'),

(3255,'USA','US','Hays~ KS','HYS'),

(3256,'USA','US','Hayward~ CA','HWD'),

(3257,'USA','US','Hayward~ WI','HYR'),

(3258,'France','FR','Hazebrouck','HZB'),

(3259,'USA','US','Hazlehurst~ GA','AZE'),

(3260,'USA','US','Hazleton~ PA','HZL'),

(3261,'Australia','AU','Headingly~ Queensland','HIP'),

(3262,'USA','US','Healy Lake~ AK','HKB'),

(3263,'Canada','CA','Hearst~ ON','YHF'),

(3264,'Australia','AU','Heathlands~ Queensland','HAT'),

(3265,'USA','US','Heber Springs~ AR','HBZ'),

(3266,'USA','US','Hebron~ NE','HJH'),

(3267,'Netherlands','NL','Heerenveen','QYZ'),

(3268,'China','CN','Hefei','HFE'),

(3269,'Myanmar','MM','Heho','HEH'),

(3270,'Germany','DE','Heide/Buesum','HEI'),

(3271,'Germany','DE','Heidelberg','HDB'),

(3273,'China','CN','Heihe','HEK'),

(3274,'Papua New Guinea','PG','Heiweni','HNI'),

(3275,'USA','US','Helena~ MT','HLN'),

(3276,'USA','US','Helena/West Helena~ AR','HEE'),

(3277,'Australia','AU','Helenvale','HLV'),

(3278,'Germany','DE','Helgoland','HGL'),

(3279,'Sweden','SE','Helsingbor','JLD'),

(3280,'Sweden','SE','Helsingborg','JHE'),

(3281,'Finland','FI','Helsinki','HEM'),

(3283,'USA','US','Hemet~ CA','HMT'),

(3284,'Australia','AU','Henbury~ Northern Territory','HRY'),

(3285,'United Kingdom','GB','Hendon~ England','HEN'),

(3286,'Netherlands','NL','Hengelo','QYH'),

(3287,'China','CN','Hengyang','HNY'),

(3288,'Papua New Guinea','PG','Henyamya','MYX'),

(3289,'Myanmar','MM','Henzada','HEB'),

(3290,'Greece','GR','Heraklion (Iraklion)~ Crete','HER'),

(3291,'Afghanistan','AF','Herat','HEA'),

(3292,'USA','US','Hereford~ TX','HRX'),

(3293,'USA','US','Herendeen Bay~ AK','HED'),

(3294,'Germany','DE','Heringsdorf','HDF'),

(3295,'USA','US','Herington~ KS','HRU'),

(3296,'USA','US','Herlong~ CA','AHC'),

(3297,'Australia','AU','Hermannsburg~ Northern Territory','HMG'),

(3298,'USA','US','Hermiston~ OR','HES'),

(3299,'Mexico','MX','Hermosillo','HMO'),

(3300,'Australia','AU','Heron Island~ Queensland','HRN'),

(3301,'Colombia','CO','Herrera','HRR'),

(3302,'Australia','AU','Hervey Bay~ Queensland','HVB'),

(3303,'Bosnia-Herzegovina','BA','Herzegovina','HNO'),

(3304,'USA','US','Hibbing~ MN','HIB'),

(3305,'USA','US','Hickory~ NC','HKY'),

(3306,'USA','US','Hidden Falls~ AK','HDA'),

(3307,'New Caledonia','NC','Hienghene','HNG'),

(3308,'Spain','ES','Hierro~ Canary Islands','WNT'),

(3309,'Canada','CA','High Level~ AB','YOJ'),

(3310,'Canada','CA','High Prairie~ AB','ZHP'),

(3311,'United Kingdom','GB','High Wycombe','HYC'),

(3312,'Australia','AU','Highbury','HIG'),

(3313,'USA','US','Highgate~ VT','FSO'),

(3314,'Venezuela','VE','Higuerote','HIU'),

(3315,'French Polynesia','PF','Hikueru','HHZ'),

(3316,'USA','US','Hill City~ KS','HLC'),

(3317,'USA','US','Hillsboro (Portland)~ OR','HIO'),

(3318,'USA','US','Hillsboro~ WI','HBW'),

(3319,'Australia','AU','Hillside~ Western Australia','HLL'),

(3320,'USA','US','Hilo~ HI','ITO'),

(3321,'USA','US','Hilton Head Island~ SC','HHH'),

(3322,'Netherlands','NL','Hilversum (The Hague)','QYI'),

(3323,'Australia','AU','Hinchinbrooke Island~ Queensland','HNK'),

(3324,'USA','US','Hinesville~ GA','LIY'),

(3325,'Japan','JP','Hiroshima','HIW'),

(3327,'India','IN','Hissar','HSS'),

(3328,'French Polynesia','PF','Hiva Oa~ Marquesas Islands','HIX'),

(3329,'Papua New Guinea','PG','Hivaro','HIT'),

(3330,'South Africa','ZA','Hluhluwe','HLW'),

(3331,'Vietnam','VN','Ho Chi Minh City (Saigon) ','SGN'),

(3332,'USA','US','Hobart Bay~ AK','HBH'),

(3333,'USA','US','Hobart~ OK','HBR'),

(3334,'Australia','AU','Hobart~ Tasmania','HBA'),

(3335,'USA','US','Hobbs~ NM','HBB'),

(3337,'Yemen','YE','Hodeida','HOD'),

(3338,'Germany','DE','Hof','HOQ'),

(3339,'USA','US','Hoffmann/Camp Mackall~ NC','HFF'),

(3340,'Iceland','IS','Hofn','HFN'),

(3341,'Saudi Arabia','SA','Hofuf','HOF'),

(3342,'USA','US','Hogatza~ AK','HGZ'),

(3343,'Austria','AT','Hohenems','HOH'),

(3344,'China','CN','Hohhot','HET'),

(3345,'New Zealand','NZ','Hokitika','HKK'),

(3346,'Kenya','KE','Hola','HOA'),

(3347,'USA','US','Holdrege~ NE','HDE'),

(3348,'Cuba','CU','Holguin','HOG'),

(3349,'USA','US','Holikachu~ AK','HOL'),

(3350,'USA','US','Holikachuk~ AK','HDL'),

(3351,'USA','US','Holland~ MI','HLM'),

(3352,'USA','US','Hollis~ AK','HYL'),

(3353,'USA','US','Hollister~ CA','HLI'),

(3354,'USA','US','Hollywood~ FL','HWO'),

(3355,'Canada','CA','Holman~ NT','YHI'),

(3356,'Iceland','IS','Holmavik','HVK'),

(3357,'Greenland','GL','Holsteinsborg','JHS'),

(3358,'USA','US','Holy Cross~ AK','HCR'),

(3359,'United Kingdom','GB','Holyhead~ Wales','HLY'),

(3360,'Myanmar','MM','Homalin','HOX'),

(3361,'Australia','AU','Home Hill~ Queensland','HMH'),

(3362,'USA','US','Homer~ AK','HOM'),

(3363,'USA','US','Homeshore~ AK','HMS'),

(3364,'USA','US','Homestead~ FL','HST'),

(3365,'Belarus','BY','Homyel (Gomel)~ Homyel','GME'),

(3366,'USA','US','Hondo~ TX','HDO'),

(3367,'Hong Kong','HK','Hong Kong','HHP'),

(3369,'Solomon Islands','SB','Honiara~ Guadalcanal Is.','HIR'),

(3370,'Papua New Guinea','PG','Honinabi','HNN'),

(3371,'Norway','NO','Honningsvag','HVG'),

(3372,'USA','US','Honolulu~ HI','NPS'),

(3375,'Australia','AU','Hook Island','HIH'),

(3376,'Australia','AU','Hookers Creek~ Northern Territor','HOK'),

(3377,'USA','US','Hoonah~ AK','HNH'),

(3378,'USA','US','Hooper Bay~ AK','HPB'),

(3379,'Australia','AU','Hope Vale~ Queensland','HPE'),

(3380,'Canada','CA','Hope~ BC','YHE'),

(3381,'Canada','CA','Hopedale~ NF','YHO'),

(3382,'South Africa','ZA','Hopetown','HTU'),

(3383,'USA','US','Hopkinsville~ KY','HVC'),

(3384,'USA','US','Hoquiam~ WA','HQM'),

(3385,'Wallis and Futuna Islands','WF','Horn Island','HID'),

(3386,'Canada','CA','Hornepayne~ ON','YHN'),

(3387,'Australia','AU','Horsham~ Victoria','HSM'),

(3388,'Portugal','PT','Horta (Faial Island)~ Azores','HOR'),

(3389,'Papua New Guinea','PG','Hoskins','HKN'),

(3390,'USA','US','Hot Springs~ AR','HOT'),

(3391,'USA','US','Hot Springs~ SD','HSR'),

(3392,'USA','US','Hot Springs~ VA','HSP'),

(3393,'China','CN','Hotan','HTN'),

(3394,'New Caledonia','NC','Houailo','HLU'),

(3395,'Laos','LA','Houeisay','HOE'),

(3396,'USA','US','Houghton Lake~ MI','HTL'),

(3397,'USA','US','Houlton~ ME','HUL'),

(3398,'USA','US','Houma~ LA','HUM'),

(3399,'Libya','LY','Houn','HUQ'),

(3400,'USA','US','Houston~ TX','AAP'),

(3415,'TX Heliport USA','US','Houston/The Woodlands','JWL'),

(3416,'United Kingdom','GB','Hoy Island','HOY'),

(3417,'Belarus','BY','Hrodna (Grodna)~ Hrodna','GNA'),

(3418,'Taiwan','TW','Hsin Chu','HSO'),

(3419,'Thailand','TH','Hua Hin','HHQ'),

(3420,'French Polynesia','PF','Huahine~ Society Islands','HUH'),

(3421,'Taiwan','TW','Hualien','HUN'),

(3422,'Angola','AO','Huambo (Nova Lisboa)','NOV'),

(3423,'China','CN','Huanghua','HHA'),

(3424,'China','CN','Huangyan','HYN'),

(3425,'Peru','PE','Huanuco','HUU'),

(3426,'India','IN','Hubli','HBX'),

(3427,'Sweden','SE','Hudiksvall','HUV'),

(3428,'Canada','CA','Hudson\'s Hope~ BC','YNH'),

(3429,'Canada','CA','Hudson Bay~ SK','YHB'),

(3430,'Vietnam','VN','Hue','HUI'),

(3431,'Guatemala','GT','Huehuetenango','HUG'),

(3432,'Australia','AU','Hughenden~ Queensland','HGD'),

(3433,'USA','US','Hughes~ AK','HUS'),

(3434,'USA','US','Hugo~ OK','HUJ'),

(3435,'USA','US','Hugoton~ KS','HQG'),

(3436,'China','CN','Huizhow','HUZ'),

(3437,'Canada','CA','Hull (Ottawa)~ QC','YND'),

(3438,'USA','US','Hull~ AK','HUK'),

(3439,'United Kingdom','GB','Hull~ England','LCF'),

(3440,'Sweden','SE','Hultsfred','HLF'),

(3441,'Puerto Rico','PR','Humacao','HUC'),

(3443,'United Kingdom','GB','Humberside','HUY'),

(3444,'Australia','AU','Humbert River','HUB'),

(3445,'USA','US','Humboldt~ NE','HBO'),

(3446,'Ethiopia','ET','Humera','HUE'),

(3447,'USA','US','Huntingburg~ IN','HNB'),

(3448,'USA','US','Huntingdon~ TN','HZD'),

(3449,'USA','US','Huntington~ IN','HHG'),

(3450,'USA','US','Huntington~ WV','HTS'),

(3451,'USA','US','Huntsville~ TX','HTV'),

(3452,'AL USA','US','Huntsville/Decatur','HSV'),

(3453,'Egypt','EG','Hurghada','HRG'),

(3454,'USA','US','Huron~ SD','HON'),

(3455,'Iceland','IS','Husavik','HZK'),

(3456,'USA','US','Huslia~ AK','HSL'),

(3457,'USA','US','Hutchinson~ KS','HUT'),

(3458,'USA','US','Hutchinson~ MN','HCD'),

(3459,'Iceland','IS','Hvammstangi','HVM'),

(3460,'Zimbabwe','ZW','Hwange National Park','HWN'),

(3461,'Zimbabwe','ZW','Hwange','WKI'),

(3463,'MA USA','US','Hyannis','HYA'),

(3464,'USA','US','Hydaburg~ AK','HYG'),

(3465,'USA','US','Hyder~ AK','WHD'),

(3466,'India','IN','Hyderabad','HYD'),

(3467,'Pakistan','PK','Hyderabad','HDD'),

(3468,'Papua New Guinea','PG','Ialibu','IAL'),

(3469,'Papua New Guinea','PG','Iamalele','IMA'),

(3470,'Romania','RO','Iasi','IAS'),

(3471,'Nigeria','NG','Ibadan','IBA'),

(3472,'Colombia','CO','Ibague','IBE'),

(3473,'Peru','PE','Iberia','IBP'),

(3474,'Spain','ES','Ibiza~ Balearic Islands','IBZ'),

(3475,'Mozambique','MZ','Ibo','IBO'),

(3476,'Papua New Guinea','PG','Iboki','IBI'),

(3477,'Venezuela','VE','Icabaru','ICA'),

(3478,'Brazil','BR','Icoaraci~ PA','QDO'),

(3479,'USA','US','Icy Bay~ AK','ICY'),

(3480,'USA','US','Ida Grove~ IA','IDG'),

(3481,'USA','US','Idaho Falls~ ID','IDA'),

(3482,'Zaire','ZR','Idiofa','IDF'),

(3483,'Sweden','SE','Idre','IDB'),

(3484,'Japan','JP','Iejima','IEJ'),

(3485,'Australia','AU','Iffley~ Queensland','IFF'),

(3486,'Russia','RU','Igarka~ Krasnoyarsk','IAA'),

(3487,'USA','US','Igiugig~ AK','IGG'),

(3488,'Canada','CA','Igloolik~ NT','YGT'),

(3489,'Canada','CA','Ignace~ ON','ZUC'),

(3490,'Brazil','BR','Iguatu','QIG'),

(3491,'Argentina','AR','Iguazu','IGR'),

(3492,'Gabon','GA','Iguela','IGE'),

(3493,'Madagascar','MG','Ihosy','IHO'),

(3494,'Papua New Guinea','PG','Ihu','IHU'),

(3495,'Brazil','BR','Ijui~ RS','IJU'),

(3496,'Zaire','ZR','Ikela','IKL'),

(3497,'Japan','JP','Iki','IKI'),

(3498,'Madagascar','MG','Ilaka','ILK'),

(3499,'France','FR','Ile d\'Yeu','IDY'),

(3500,'New Caledonia','NC','Ile des Pins (Isle of Pines)','ILP'),

(3501,'New Caledonia','NC','Ile Quen','IOU'),

(3502,'Zaire','ZR','Ilebo','PFR'),

(3503,'Canada','CA','Iles-de-la-Madeleine~ QC','YGR'),

(3504,'Canada','CA','Ilford~ MB','ILF'),

(3505,'Brazil','BR','Ilha Solteira~ MS','ILB'),

(3506,'Brazil','BR','Ilheus~ BA','IOS'),

(3507,'USA','US','Iliamna~ AK','ILI'),

(3508,'Philippines','PH','Iligan','IGN'),

(3509,'Indonesia','ID','Illaga','ILA'),

(3510,'Germany','DE','Illishiem','ILH'),

(3511,'Algeria','DZ','Illizi','VVZ'),

(3512,'Philippines','PH','Iloilo','ILO'),

(3513,'Nigeria','NG','Ilorin','ILR'),

(3514,'Indonesia','ID','Ilu~ New Guinea','IUL'),

(3515,'Guyana','GY','Imbaimadai','IMB'),

(3516,'USA','US','Immokalee~ FL','IMM'),

(3517,'Papua New Guinea','PG','Imonda','IMD'),

(3518,'Brazil','BR','Imperatriz~ MA','IMP'),

(3519,'USA','US','Imperial Beach~ CA','NRS'),

(3520,'USA','US','Imperial~ NE','IML'),

(3521,'Congo','CG','Impfondo','ION'),

(3522,'India','IN','Imphal','IMF'),

(3523,'Algeria','DZ','In Guezzam','INF'),

(3524,'Algeria','DZ','In Salah','INZ'),

(3525,'Bahamas','BS','Inagua (Matthew Town)~ Great Ina','IGA'),

(3526,'Indonesia','ID','Inanwatan','INX'),

(3527,'South Korea','KR','Inchon','JCN'),

(3528,'Papua New Guinea','PG','Indagen','IDN'),

(3529,'Ethiopia','ET','Indaselassie','SHC'),

(3530,'Belize','BZ','Independence','INB'),

(3531,'USA','US','Independence~ IA','IIB'),

(3532,'USA','US','Independence~ KS','IDP'),

(3533,'USA','US','Indian Springs~ NV','INS'),

(3534,'USA','US','Indiana~ PA','IDI'),

(3535,'USA','US','Indianapolis~ IN','HFY'),

(3539,'USA','US','Indianola~ MS','IDL'),

(3540,'India','IN','Indore','IDR'),

(3541,'Australia','AU','Indulkana~ South Australia','IDK'),

(3542,'Marshall Islands','MH','Ine Island','IMI'),

(3543,'Argentina','AR','Ingeniero Jacobacci','IGB'),

(3544,'Canada','CA','Ingenika~ BC','WWU'),

(3545,'Australia','AU','Ingham~ Queensland','IGH'),

(3546,'Germany','DE','Ingolstadt','ZNQ'),

(3547,'Mozambique','MZ','Inhambane','INH'),

(3548,'Mozambique','MZ','Inhaminga','IMG'),

(3549,'Ireland','IE','Inisheer','INQ'),

(3550,'Ireland','IE','Inishmaan','IIA'),

(3551,'Ireland','IE','Inishmore','IOR'),

(3552,'Australia','AU','Injune~ Queensland','INJ'),

(3553,'Australia','AU','Inkerman~ Queensland','IKP'),

(3554,'Australia','AU','Innamincka~ South Australia','INM'),

(3555,'Australia','AU','Innisfail~ Queensland','IFL'),

(3556,'Austria','AT','Innsbruck','INN'),

(3557,'Zaire','ZR','Inongo','INO'),

(3558,'Switzerland','CH','Interlaken','ZTJ'),

(3559,'USA','US','International Falls~ MN','INL'),

(3560,'Solomon Islands','SB','Inus','IUS'),

(3561,'Canada','CA','Inuvik~ NT','YEV'),

(3562,'New Zealand','NZ','Invercargill','IVC'),

(3563,'Australia','AU','Inverell~ New South Wales','IVR'),

(3564,'Canada','CA','Inverlake~ SK','TIL'),

(3565,'United Kingdom','GB','Inverness~ Scotland','INV'),

(3566,'Australia','AU','Inverway~ Northern Territory','IVW'),

(3567,'USA','US','Inyokern~ CA','IYK'),

(3568,'Greece','GR','Ioannina','IOA'),

(3569,'Papua New Guinea','PG','Iokea','IOK'),

(3570,'Papua New Guinea','PG','Ioma','IOP'),

(3571,'USA','US','Iowa City~ IA','IOW'),

(3572,'USA','US','Iowa Falls~ IA','IFA'),

(3573,'Brazil','BR','Ipatinga','IPN'),

(3574,'Colombia','CO','Ipiales','IPI'),

(3575,'Brazil','BR','Ipiau~ BA','IPU'),

(3576,'Philippines','PH','Ipil','IPE'),

(3577,'Brazil','BR','Ipiranga','IPG'),

(3578,'Malaysia','MY','Ipoh','IPH'),

(3579,'Vanuatu','VU','Ipota','IPA'),

(3580,'United Kingdom','GB','Ipswich','IPW'),

(3581,'Canada','CA','Iqaluit (Frobisher Bay)','YFB'),

(3582,'Chile','CL','Iquique','IQQ'),

(3583,'Peru','PE','Iquitos','IQT'),

(3584,'USA','US','Iraan~ TX','IRB'),

(3585,'Jordan','JO','Irbio','QIR'),

(3586,'Brazil','BR','Irece~ BA','IRE'),

(3587,'Tanzania','TZ','Iringa','IRI'),

(3588,'Honduras','HN','Iriona','IRN'),

(3589,'Russia','RU','Irkutsk~ Irkutsk','IKT'),

(3590,'USA','US','Iron Mountain/Kingsford~ MI','IMT'),

(3591,'USA','US','Ironwood~ MI','IWD'),

(3592,'USA','US','Irving~ TX','SBG'),

(3593,'USA','US','Isabel Pass~ AK','ISL'),

(3594,'Canada','CA','Isachsen~ NT','YIC'),

(3595,'Iceland','IS','Isafjordur','IFJ'),

(3596,'Italy','IT','Ischia','ISH'),

(3597,'Colombia','CO','Iscuande','ISD'),

(3598,'Iran','IR','Isfahan','IFN'),

(3599,'Bangladesh','BD','Ishhurdi','IRD'),

(3600,'Japan','JP','Ishigaki','ISG'),

(3601,'Zaire','ZR','Isiro','IRP'),

(3602,'Australia','AU','Isisford~ Queensland','ISI'),

(3603,'Chile','CL','Isla de Pascua~ Easter Is.','IPC'),

(3604,'Mexico','MX','Isla Mujers','ISJ'),

(3605,'Pakistan','PK','Islamabad','ISB'),

(3606,'Canada','CA','Island Lake/Garden Hill','YIV'),

(3607,'United Kingdom','GB','Islay','ILY'),

(3608,'United Kingdom','GB','Isle of Man','IOM'),

(3609,'United Kingdom','GB','Isle of Skye','SKL'),

(3610,'USA','US','Islip~ NY','ISP'),

(3611,'Turkey','TR','Istanbul','IST'),

(3612,'Brazil','BR','Itabuna~ BA','ITN'),

(3613,'Brazil','BR','Itacoiatiara~ AM','ITA'),

(3614,'Brazil','BR','Itaituba~ PA','ITB'),

(3615,'Brazil','BR','Itajai~ SC','ITJ'),

(3616,'Brazil','BR','Itambacuri~ MG','ITI'),

(3617,'Brazil','BR','Itaqui~ RS','ITQ'),

(3618,'USA','US','Ithaca~ NY','ITH'),

(3619,'Papua New Guinea','PG','Itokama','ITK'),

(3620,'Brazil','BR','Itsjuba~ SC','QDS'),

(3621,'Brazil','BR','Itubera~ BA','ITE'),

(3622,'Finland','FI','Ivalo','IVL'),

(3623,'Yugoslavia','YU','Ivangrad','IVG'),

(3624,'Ukraine','UA','Ivano-Frankivs\'k','IFO'),

(3625,'USA','US','Ivanof Bay~ AK','KIB'),

(3626,'USA','US','Ivishak~ AK','IVH'),

(3627,'Canada','CA','Ivujivik~ QC','YIK'),

(3628,'Japan','JP','Iwakuni~ Honshu Is.','IWA'),

(3631,'Japan','JP','Iwami','IWJ'),

(3632,'Japan','JP','Iwo Jima','IWO'),

(3633,'Mexico','MX','Ixtapa/Zihuatanejo','ZIH'),

(3634,'Mexico','MX','Ixtepec','IZT'),

(3635,'Russia','RU','Izhevsk~ Udmurtia','IJK'),

(3636,'Turkey','TR','Izmir','IZM'),

(3639,'Japan','JP','Izumo','IZO'),

(3640,'India','IN','Jabalpur','JLR'),

(3641,'Marshall Islands','MH','Jabat','JAT'),

(3642,'Australia','AU','Jabiru~ Northern Territory','JAB'),

(3643,'Marshall Islands','MH','Jabor Jaluit','UIT'),

(3644,'Brazil','BR','Jacareacanga~ PR','JCR'),

(3645,'Haiti','HT','Jachel','JAK'),

(3646,'USA','US','Jackpot~ NV','KPT'),

(3647,'USA','US','Jackson~ KY','JKL'),

(3648,'USA','US','Jackson~ MI','JXN'),

(3649,'USA','US','Jackson~ MN','MJQ'),

(3650,'USA','US','Jackson~ MS','HKS'),

(3652,'USA','US','Jackson~ TN','MKL'),

(3653,'USA','US','Jackson~ WY','JAC'),

(3654,'USA','US','Jacksonville~ AR','LRF'),

(3655,'FL (Towers Field) USA','US','Jacksonville','NIP'),

(3656,'USA','US','Jacksonville~ FL','NZC'),

(3660,'USA','US','Jacksonville~ IL','IJX'),

(3661,'USA','US','Jacksonville~ NC','OAJ'),

(3662,'Congo','CG','Jacob','YKS'),

(3663,'Pakistan','PK','Jacobabad','JAG'),

(3664,'Brazil','BR','Jacobina~ BA','JCM'),

(3665,'Papua New Guinea','PG','Jacouinot Bay','JAQ'),

(3666,'Spain','ES','Jaen','ENM'),

(3667,'Sri Lanka','LK','Jaffna','JAF'),

(3668,'USA','US','Jaffrey~ NH','AFN'),

(3669,'India','IN','Jagdalpur','JGB'),

(3670,'India','IN','Jaipur','JAI'),

(3671,'India','IN','Jaisalmer','JSA'),

(3672,'Indonesia','ID','Jakarta','HLP'),

(3675,'Greenland','GL','Jakobshavn','JAV'),

(3676,'India','IN','Jaladhar','QJU'),

(3677,'Afghanistan','AF','Jalalabad','JAA'),

(3678,'Mexico','MX','Jalapa','JAL'),

(3679,'Angola','AO','Jamba','JMB'),

(3680,'Indonesia','ID','Jambi','DJB'),

(3681,'Bulgaria','BG','Jambol','JAM'),

(3682,'USA','US','Jamestown~ ND','JMS'),

(3683,'USA','US','Jamestown~ NY','JHW'),

(3684,'India','IN','Jammu','IXJ'),

(3685,'India','IN','Jamnagar','JGA'),

(3686,'India','IN','Jamshedpur','IXW'),

(3687,'Nepal','NP','Janakpur','JKR'),

(3688,'Australia','AU','Jandakot~ Western Australia','JAD'),

(3689,'USA','US','Janesville~ WI','JVL'),

(3690,'Brazil','BR','Januaria~ MG','JNA'),

(3691,'Panama','PA','Jaque','JQE'),

(3692,'Brazil','BR','Jaragua do Sul~ SC','QJA'),

(3693,'Canada','CA','Jasper~ AB','YJA'),

(3694,'USA','US','Jasper~ GA','JZP'),

(3695,'USA','US','Jasper~ TN','APT'),

(3696,'USA','US','Jasper~ TX','JAS'),

(3697,'Peru','PE','Jauja','JAU'),

(3698,'Saudi Arabia','SA','Jeddah','JED'),

(3699,'USA','US','Jefferson City~ MO','JEF'),

(3700,'USA','US','Jefferson~ IA','EFW'),

(3701,'USA','US','Jeffersonville~ IN','JVY'),

(3702,'Marshall Islands','MH','Jeh','JEJ'),

(3703,'Canada','CA','Jenny Lind Island~ NT','YUQ'),

(3704,'Canada','CA','Jenpeg~ MB','ZJG'),

(3705,'Brazil','BR','Jequie~ BA','JEQ'),

(3706,'Haiti','HT','Jeremie','JEE'),

(3707,'Spain','ES','Jerez de la Frontera','JRZ'),

(3709,'Channel Islands','GB','Jersey','JER'),

(3710,'Israel','IL','Jerusalem','JRS'),

(3711,'Italy','IT','Jesolo','JLO'),

(3712,'Bangladesh','BD','Jessore','JSR'),

(3713,'USA','US','Jesup~ GA','JES'),

(3714,'Azerbaijan','AZ','Jevlach~ Naxcivan','EVL'),

(3715,'India','IN','Jeypore','PYB'),

(3716,'Brazil','BR','Ji Parana~ RO','JPR'),

(3717,'China','CN','Jiamusi','JMU'),

(3718,'China','CN','Jian','KNC'),

(3719,'China','CN','Jiayuguan','JGN'),

(3720,'Algeria','DZ','Jijel','GJL'),

(3721,'Peru','PE','Jijiga','JIJ'),

(3722,'China','CN','Jilin','JIL'),

(3723,'Australia','AU','Jimdabyne~ New South Wales','QJD'),

(3724,'Ethiopia','ET','Jimma','JIM'),

(3725,'China','CN','Jinan','TNA'),

(3726,'China','CN','Jingdezhen','JDZ'),

(3727,'China','CN','Jinghong','JHG'),

(3728,'China','CN','Jining','JNG'),

(3729,'Uganda','UG','Jinja','JIN'),

(3730,'China','CN','Jinjiang','JJN'),

(3731,'China','CN','Jinquan','CHW'),

(3732,'China','CN','Jinzhou','JNZ'),

(3733,'Ecuador','EC','Jipijapa','JIP'),

(3734,'Nepal','NP','Jiri','JIR'),

(3735,'China','CN','Jiujiang','JIU'),

(3736,'Pakistan','PK','Jiwani','JIW'),

(3737,'Brazil','BR','Joacaba~ SC','JCB'),

(3738,'Brazil','BR','Joao Pessoa~ PB','JPA'),

(3739,'India','IN','Jodhpur','JDH'),

(3740,'Finland','FI','Joensuu','JOE'),

(3741,'South Africa','ZA','Johannesburg','GCJ'),

(3745,'USA','US','John Day~ OR','JDA'),

(3746,'Canada','CA','Johnny Mountain~ BC','YJO'),

(3747,'USA','US','Johnson City~ TX','JCY'),

(3748,'Canada','CA','Johnson Point~ NT','YUN'),

(3749,'Johnston Atoll','US','Johnston Island','JON'),

(3750,'USA','US','Johnstown~ PA','JST'),

(3751,'Malaysia','MY','Johor Bahru','JHB'),

(3752,'Brazil','BR','Joinville~ SC','JOI'),

(3753,'USA','US','Joliet~ IL','JOT'),

(3754,'Philippines','PH','Jolo','JOL'),

(3755,'Nepal','NP','Jomsom','JMO'),

(3756,'USA','US','Jonesboro~ AR','JBR'),

(3757,'Sweden','SE','Jonkoping','JKG'),

(3758,'USA','US','Joplin~ MO','JLN'),

(3759,'USA','US','Jordan~ MT','JDN'),

(3760,'India','IN','Jorhat','JRH'),

(3761,'Nigeria','NG','Jos','JOS'),

(3762,'Argentina','AR','Jose de San Martin','JSM'),

(3763,'Papua New Guinea','PG','Josephstaal','JOP'),

(3764,'Saudi Arabia','SA','Jouf','AJF'),

(3765,'Lebanon','LB','Jounieh','GJN'),

(3766,'France','FR','Juan-les-Pins','JLP'),

(3767,'Peru','PE','Juanjui','JJI'),

(3768,'Brazil','BR','Juara','JUA'),

(3769,'Brazil','BR','Juazeiro do Norte~ CE','JDO'),

(3770,'Sudan','SD','Juba','JUB'),

(3771,'Saudi Arabia','SA','Jubail','QJB'),

(3772,'Brazil','BR','Juina~ MG','JIA'),

(3773,'Germany','DE','Juist','JUI'),

(3774,'Brazil','BR','Juiz do Fora~ MG','JDF'),

(3775,'Argentina','AR','Jujuy','JUJ'),

(3776,'Australia','AU','Julia Creek~ Queensland','JCK'),

(3777,'Peru','PE','Juliaca','JUL'),

(3778,'Greenland','GL','Julianehab','JJU'),

(3779,'Nepal','NP','Jumla','JUM'),

(3780,'USA','US','Junction~ TX','JCT'),

(3781,'Australia','AU','Jundah~ Queensland','JUN'),

(3782,'USA','US','Juneau~ AK','JSE'),

(3784,'USA','US','Juneau~ WI','UNU'),

(3785,'Argentina','AR','Junin','JNI'),

(3786,'USA','US','Jupiter~ FL','UTX'),

(3787,'Colombia','CO','Jurado','JUO'),

(3788,'Australia','AU','Jurien Bay~ Western Australia','JUR'),

(3789,'Brazil','BR','Juruena~ MG','JRN'),

(3790,'Honduras','HN','Juticalpa','JUT'),

(3791,'China','CN','Juzhow','JUZ'),

(3792,'Botswana','BW','Jwaneng','JWA'),

(3793,'Finland','FI','Jyvaskyla (Jyvaeskylae)','JYV'),

(3794,'USA','US','Kaanapali~ HI','HKP'),

(3795,'Indonesia','ID','Kabaena','KBT'),

(3796,'Sierra Leone','SL','Kabala','KBA'),

(3797,'Uganda','UG','Kabalega Falls/Murchison Falls','MUD'),

(3798,'Uganda','UG','Kabalega','KBG'),

(3799,'Zaire','ZR','Kabalo','KBO'),

(3800,'Zaire','ZR','Kabinda','KBN'),

(3801,'Ethiopia','ET','Kabri Dar','ABK'),

(3802,'Afghanistan','AF','Kabul (Khabul)','KBL'),

(3803,'Papua New Guinea','PG','Kabwum','KBM'),

(3804,'Zambia','ZM','Kacma','KMZ'),

(3805,'Nigeria','NG','Kaduna','KAD'),

(3806,'Mauritania','MR','Kaedi','KED'),

(3807,'Cameroon','CM','Kaele','KLE'),

(3808,'Papua New Guinea','PG','Kagi','KGW'),

(3809,'Japan','JP','Kagoshima~ Kyushu','KOJ'),

(3810,'Papua New Guinea','PG','Kagua','AGK'),

(3811,'USA','US','Kahului~ HI','OGG'),

(3812,'Papua New Guinea','PG','Kaiapit','KIA'),

(3813,'Guyana','GY','Kaieteur','KAI'),

(3814,'New Zealand','NZ','Kaikohe','KKO'),

(3815,'New Zealand','NZ','Kaikorua','KBZ'),

(3816,'India','IN','Kailashahar','IXH'),

(3817,'USA','US','Kailua/Kona~ HI','KOA'),

(3818,'Indonesia','ID','Kaimana','KNG'),

(3819,'Papua New Guinea','PG','Kaintiba','KZF'),

(3820,'USA','US','Kaiser/Lake Ozark~ MO','AIZ'),

(3821,'Germany','DE','Kaiserslautern','KLT'),

(3822,'New Zealand','NZ','Kaitaia','KAT'),

(3823,'Finland','FI','Kajaani','KAJ'),

(3824,'USA','US','Kake~ AK','KAE'),

(3825,'USA','US','Kakhonak~ AK','KNK'),

(3826,'USA','US','Kakiovik~ AK','KKF'),

(3827,'Zambia','ZM','Kalabo','KLB'),

(3828,'USA','US','Kalakaket~ AK','KKK'),

(3829,'Greece','GR','Kalamata','KLX'),

(3830,'MI USA','US','Kalamazoo','AZO'),

(3831,'Pakistan','PK','Kalat','KBH'),

(3832,'USA','US','Kalaupapa~ HI','LUP'),

(3833,'Australia','AU','Kalbarri~ Western Australia','KAX'),

(3834,'Zaire','ZR','Kalemie','FMI'),

(3835,'Myanmar','MM','Kalemyo','KMV'),

(3836,'Australia','AU','Kalgoorlie~ Western Australia','KGI'),

(3837,'Philippines','PH','Kalibo','KLO'),

(3838,'Zaire','ZR','Kalima','KLY'),

(3839,'Russia','RU','Kaliningrad~ Kaliningrad','KGD'),

(3840,'USA','US','Kalispell~ MT','FCA'),

(3841,'Australia','AU','Kalkurung','KFG'),

(3842,'Sweden','SE','Kalmar','KLR'),

(3843,'Kenya','KE','Kalokol','KLK'),

(3844,'Australia','AU','Kalpowar~ Queensland','KPP'),

(3845,'USA','US','Kalskag~ AK','KLG'),

(3846,'USA','US','Kaltag~ AK','KAL'),

(3847,'Australia','AU','Kalumburu~ Western Australia','UBU'),

(3848,'Ukraine','UA','Kam\'yanets\'-Podil\'s\'kyy~ Khmel\'n','KCP'),

(3849,'India','IN','Kamalpur','IXQ'),

(3850,'Australia','AU','Kamaran Downs~ Queensland','KDS'),

(3851,'Yemen','YE','Kamaran Island','KAM'),

(3852,'Guyana','GY','Kamarang','KAR'),

(3853,'Australia','AU','Kambalda~ Western Australia','KDB'),

(3854,'Indonesia','ID','Kambuaya','KBX'),

(3855,'Rwanda','RW','Kamembe','KME'),

(3856,'Syria','SY','Kameshli','KAC'),

(3857,'Australia','AU','Kamileroi~ Queensland','KML'),

(3858,'Papua New Guinea','PG','Kamina','KMF'),

(3859,'Zaire','ZR','Kamina','KMN'),

(3860,'Papua New Guinea','PG','Kamiraba','KJU'),

(3861,'Canada','CA','Kamloops~ BC','YKA'),

(3862,'Venezuela','VE','Kammarata','KTV'),

(3863,'Uganda','UG','Kampala (Entebbe)','EBB'),

(3864,'Uganda','UG','Kampala','KLA'),

(3865,'Cambodia','KH','Kampot','KMT'),

(3866,'USA','US','Kamuela~ HI','MUE'),

(3867,'Papua New Guinea','PG','Kamulai','KAQ'),

(3868,'Papua New Guinea','PG','Kamusi','KUW'),

(3869,'USA','US','Kanab~ UT','KNB'),

(3870,'Papua New Guinea','PG','Kanabea','KEX'),

(3871,'Papua New Guinea','PG','Kanainj','KNE'),

(3872,'Zaire','ZR','Kananga','KGA'),

(3873,'Japan','JP','Kanazawa City','QKW'),

(3874,'Afghanistan','AF','Kandahar','KDH'),

(3875,'Fiji','FJ','Kandavu','KDV'),

(3876,'Papua New Guinea','PG','Kandep','KDP'),

(3877,'Benin','BJ','Kandi','KDC'),

(3878,'India','IN','Kandla','IXY'),

(3879,'Papua New Guinea','PG','Kandrian','KDR'),

(3880,'HI USA','US','Kaneohe','NGF'),

(3881,'Angola','AO','Kangamba','KGT'),

(3882,'Iran','IR','Kangan','KNR'),

(3883,'Canada','CA','Kangiqsualujjuaq~ QC','XGR'),

(3884,'Canada','CA','Kangiqsujuaq (Maricourt)~ QC','YMC'),

(3885,'Canada','CA','Kangiqsujuaq~ QC','YWB'),

(3886,'Canada','CA','Kangirsuk~ QC','YAS'),

(3888,'South Korea','KR','Kangnung','KAG'),

(3889,'Zaire','ZR','Kaniama','KNM'),

(3890,'USA','US','Kankakee~ IL','IKK'),

(3891,'Guinea','GN','Kankan','KNN'),

(3892,'Nigeria','NG','Kano','KAN'),

(3893,'India','IN','Kanpur','KNU'),

(3894,'USA','US','Kansas City~ KS','KCK'),

(3895,'USA','US','Kansas City~ MO','MKC'),

(3897,'Burkina Faso','BF','Kantchari','XKA'),

(3898,'Papua New Guinea','PG','Kanua','KTK'),

(3899,'Taiwan','TW','Kaohsiung','KHH'),

(3900,'Senegal','SN','Kaolack','KLC'),

(3901,'USA','US','Kapalua (Lahaina)~ HI','JHM'),

(3902,'Zaire','ZR','Kapanga','KAP'),

(3903,'Malaysia','MY','Kapit~ Sarawak','KPI'),

(3904,'Canada','CA','Kapuskasing~ ON','YYU'),

(3905,'Papua New Guinea','PG','Kar Kar','KRX'),

(3906,'Pakistan','PK','Karachi','KHI'),

(3907,'China','CN','Karamay','KRY'),

(3908,'Guyana','GY','Karanambo','KRM'),

(3909,'Guyana','GY','Karasabai','KRG'),

(3910,'Namibia','LC','Karasburg','KAS'),

(3911,'Papua New Guinea','PG','Karato','KAF'),

(3912,'Papua New Guinea','PG','Karawari','KRJ'),

(3913,'Bulgaria','BG','Kardjali','KDG'),

(3914,'Estonia','EE','Kardla','KDL'),

(3915,'Zimbabwe','ZW','Kariba','KAB'),

(3916,'Papua New Guinea','PG','Karimui','KMR'),

(3917,'Greece','GR','Karlovasi','ZKR'),

(3918,'Czech Republic','CZ','Karlovy Vary','KLV'),

(3919,'Sweden','SE','Karlskoga','KSK'),

(3920,'Germany','DE','Karlsruhe','QKA'),

(3921,'Sweden','SE','Karlstad','KSD'),

(3922,'USA','US','Karluk Lake~ AK','KKL'),

(3923,'USA','US','Karluk~ AK','KYK'),

(3924,'Malawi','MW','Karonga','KGJ'),

(3925,'Papua New Guinea','PG','Karoola','KXR'),

(3926,'Greece','GR','Karpathos','AOK'),

(3927,'Indonesia','ID','Karubaga','KBF'),

(3928,'Australia','AU','Karumba~ Queensland','KRB'),

(3929,'Denmark','DK','Karup','KRP'),

(3930,'USA','US','Kasaan~ AK','KXA'),

(3931,'Zambia','ZM','Kasaba Bay','ZKB'),

(3932,'Canada','CA','Kasabonika~ ON','XKS'),

(3933,'Zambia','ZM','Kasama','KAA'),

(3934,'Botswana','BW','Kasane','BBK'),

(3935,'Papua New Guinea','PG','Kasanombe','KSB'),

(3936,'Canada','CA','Kaschechewan~ QC','ZKE'),

(3937,'Zaire','ZR','Kasenga','KEC'),

(3938,'Uganda','UG','Kasese','KSE'),

(3939,'China','CN','Kashi','KHG'),

(3940,'USA','US','Kasigluk~ AK','KUK'),

(3941,'Suriname','SR','Kasikasima','KCB'),

(3942,'Zaire','ZR','Kasongo Lunda','KGN'),

(3943,'Greece','GR','Kasos Island~ Crete','KSJ'),

(3944,'Sudan','SD','Kassala','KSL'),

(3945,'Germany','DE','Kassel','KSF'),

(3946,'Greece','GR','Kastelorizo','KZS'),

(3947,'Greece','GR','Kastoria','KSO'),

(3948,'Malawi','MW','Kasungu','KBQ'),

(3949,'Australia','AU','Katanning~ Western Australia','KNI'),

(3950,'Australia','AU','Katherine~ Northern Territory','KTR'),

(3951,'Nepal','NP','Kathmandu','KTM'),

(3952,'Guyana','GY','Kato','KTO'),

(3953,'Poland','PL','Katowice','KTW'),

(3954,'Indonesia','ID','Kau','KAZ'),

(3955,'Finland','FI','Kauhajoki','KHJ'),

(3956,'Fiji','FJ','Kauhava','KAU'),

(3957,'French Polynesia','PF','Kaukura','KKR'),

(3958,'Lithuania','LT','Kaunas','KUN'),

(3959,'Greece','GR','Kavalla (Kavala)','KVA'),

(3960,'Venezuela','VE','Kavanayen','KAV'),

(3961,'Papua New Guinea','PG','Kavieng','KVG'),

(3962,'USA','US','Kavik~ AK','VIK'),

(3963,'Central African Republic','CF','Kawadjia','KWD'),

(3964,'New Zealand','NZ','Kawau Island','KUI'),

(3965,'Papua New Guinea','PG','Kawito','KWO'),

(3966,'Myanmar','MM','Kawthaung','KAW'),

(3967,'Burkina Faso','BF','Kaya','XKY'),

(3968,'USA','US','Kayenta~ AZ','PBY'),

(3970,'Mali','ML','Kayes','KYS'),

(3971,'Turkey','TR','Kayseri','ASR'),

(3972,'Russia','RU','Kazan~ Tatarstan','KZN'),

(3973,'USA','US','Kearney~ NE','EAR'),

(3974,'Indonesia','ID','Kebar','KEQ'),

(3975,'Senegal','SN','Kedougou','KGG'),

(3976,'Kenya','KE','Keekorok','WPW'),

(3977,'USA','US','Keene~ NH','EEN'),

(3978,'Namibia','LC','Keetmanshoop','KMP'),

(3979,'Greece','GR','Kefalonia (Kefallinia)','EFL'),

(3980,'Canada','CA','Kegaska~ QC','ZKG'),

(3981,'Papua New Guinea','PG','Keglsugl','KEG'),

(3982,'Indonesia','ID','Keisah','KEA'),

(3983,'USA','US','Kekana~ Kauai~ HI','BKH'),

(3984,'Ethiopia','ET','Kelafo','LFO'),

(3985,'Indonesia','ID','Kelila','LLN'),

(3986,'Congo','CG','Kelle','KEE'),

(3987,'Canada','CA','Kelowna~ BC','YLW'),

(3988,'USA','US','Kelp Bay~ AK','KLP'),

(3989,'Canada','CA','Kelsey~ MB','KES'),

(3990,'USA','US','Kelso~ WA','KLS'),

(3991,'Germany','DE','Kelsterbach','QLH'),

(3992,'Indonesia','ID','Keluang','KLQ'),

(3993,'Russia','RU','Kemerovo~ Kemerovo','KEJ'),

(3994,'Finland','FI','Kemi','KEM'),

(3995,'USA','US','Kemmerer~ WY','EMM'),

(3996,'Australia','AU','Kempsey~ New South Wales','KPS'),

(3997,'USA','US','Kenai~ AK','DRF'),

(3999,'Indonesia','ID','Kendari','KDI'),

(4000,'Sierra Leone','SL','Kenema','KEN'),

(4001,'Myanmar','MM','Kengtung','KET'),

(4002,'Mali','ML','Kenieba','KNZ'),

(4003,'Malaysia','MY','Keningau','KGU'),

(4004,'Morocco','MA','Kenitra','NNA'),

(4005,'USA','US','Kennett~ MO','KNT'),

(4006,'Saudi Arabia','SA','Kenny Cove','KNY'),

(4007,'Canada','CA','Kenora~ ON','YQK'),

(4008,'USA','US','Kenosha~ WI','ENW'),

(4009,'USA','US','Kentland~ IN','KKT'),

(4011,'USA','US','Keokuk~ IA','EOK'),

(4012,'Indonesia','ID','Kepi','KEI'),

(4013,'Japan','JP','Kerama','KJP'),

(4014,'Australia','AU','Kerang~ Victoria','KRA'),

(4015,'Ukraine','UA','Kerch~ Krym (Crimea)','KHC'),

(4016,'Papua New Guinea','PG','Kerema','KMA'),

(4017,'Kenya','KE','Kericho','KEY'),

(4018,'New Zealand','NZ','Kerikeri (Bay of Islands)','KKE'),

(4019,'Indonesia','ID','Kerinci~ Samatra','KRC'),

(4020,'Kenya','KE','Kerio Valley','KRV'),

(4021,'Greece','GR','Kerkyra~ Corfu','CFU'),

(4022,'Iran','IR','Kerman','KER'),

(4023,'Iran','IR','Kermanshah','KSH'),

(4024,'TX USA','US','Kerrville','ERV'),

(4025,'Malaysia','MY','Kerteh','KTE'),

(4026,'Papua New Guinea','PG','Kerua','KRU'),

(4027,'India','IN','Keshod','IXK'),

(4028,'Indonesia','ID','Ketapang~ Borneo','KTG'),

(4029,'USA','US','Ketchikan~ AK','WFB'),

(4031,'USA','US','Kewanee~ IL','EZI'),

(4032,'Canada','CA','Key Lake~ SK','YKJ'),

(4033,'USA','US','Key Largo~ FL','OCA'),

(4035,'USA','US','Key West~ FL','EYW'),

(4037,'USA','US','Keystone~ CO','QKS'),

(4038,'Russia','RU','Khabarovsk~ Khabarovsk','KHV'),

(4039,'India','IN','Khajuraho','HJR'),

(4040,'Saudi Arabia','SA','Khalid Military City','XWG'),

(4041,'Saudi Arabia','SA','Khamis Mushayat (Abha)','AHB'),

(4042,'Saudi Arabia','SA','Khamis Muskayt','KMX'),

(4043,'Myanmar','MM','Khamti','KHM'),

(4044,'Iran','IR','Khaneh','KHA'),

(4045,'Iran','IR','Khark','KHK'),

(4046,'Ukraine','UA','Kharkiv (Kharkov)~ Kharkiv','HRK'),

(4047,'Sudan','SD','Khartoum','KRT'),

(4048,'Oman','OM','Khasab','KHS'),

(4049,'Sudan','SD','Khashm el Girba','GBU'),

(4050,'Bulgaria','BG','Khaskovo','KHO'),

(4051,'Ukraine','UA','Kherson~ Mykolayiv','KHE'),

(4052,'Ukraine','UA','Khmel\'nyts\'kyy (Khmel\'nitskiy)~ ','HMJ'),

(4053,'Thailand','TH','Khon Kaen','KKC'),

(4054,'Laos','LA','Khong','KOG'),

(4055,'Nepal','NP','Khost','KHT'),

(4056,'India','IN','Khowai','IXN'),

(4057,'Tajikistan','TJ','Khujand (Khudzhand)~ Khujand','LBD'),

(4058,'Bangladesh','BD','Khulna','KHL'),

(4059,'Pakistan','PK','Khuzdar','KDD'),

(4060,'Afghanistan','AF','Khwahan','KWH'),

(4061,'Botswana','BW','Khwai River Landing','KHW'),

(4062,'USA','US','Kiana~ AK','IAN'),

(4063,'Cyprus','CY','Kibris','KII'),

(4064,'Germany','DE','Kiel','KEL'),

(4065,'Papua New Guinea','PG','Kieta','KIE'),

(4066,'Mauritania','MR','Kiffa','KFA'),

(4067,'Rwanda','RW','Kigali','KGL'),

(4068,'Tanzania','TZ','Kigoma','TKQ'),

(4069,'Japan','JP','Kikaiga Shima','KKX'),

(4070,'Papua New Guinea','PG','Kikinonda','KIZ'),

(4071,'Papua New Guinea','PG','Kikori','KRI'),

(4072,'Zaire','ZR','Kikwit','KKW'),

(4073,'Tanzania','TZ','Kilaguni','ILU'),

(4074,'Marshall Islands','MH','Kili Island','KIO'),

(4075,'Tanzania','TZ','Kilimanjaro','JRO'),

(4076,'Ireland','IE','Kilkenny','KKY'),

(4077,'USA','US','Kill Devil Hills~ NC','FFA'),

(4078,'Canada','CA','Killaloe~ ON','YXI'),

(4079,'Ireland','IE','Killarney/Kerry County','KIR'),

(4080,'USA','US','Killeen~ TX','ILE'),

(4081,'Canada','CA','Killiniq (Killinek) Island~ NT','XBW'),

(4082,'Tanzania','TZ','Kilwa','KIY'),

(4083,'Zaire','ZR','Kilwa','KIL'),

(4084,'Indonesia','ID','Kimam','KMM'),

(4085,'NE USA','US','Kimball','IBM'),

(4086,'Canada','CA','Kimberley~ BC','YQE'),

(4087,'South Africa','ZA','Kimberley','KIM'),

(4088,'Australia','AU','Kimberly Downs~ Western Australi','KBD'),

(4089,'Congo','CG','Kindamba','KNJ'),

(4090,'Canada','CA','Kindersley~ SK','YKY'),

(4091,'Zaire','ZR','Kindu','KND'),

(4092,'United Kingdom','GB','King\'s Lynn~ England','KNF'),

(4093,'USA','US','King City~ CA','KIC'),

(4094,'USA','US','King Cove~ AK','KVC'),

(4095,'Australia','AU','King Island~ Tasmania','KNS'),

(4096,'USA','US','King of Prussia~ PA','KPD'),

(4097,'USA','US','King Salmon~ AK','AKN'),

(4098,'Australia','AU','Kingaroy~ Queensland','KGY'),

(4099,'Canada','CA','Kingfisher Lake~ ON','KIF'),

(4100,'USA','US','Kingman~ AZ','IGM'),

(4101,'Australia','AU','Kings Canyon~ Northern Territory','KBJ'),

(4102,'Australia','AU','Kings Creek Station','KCS'),

(4103,'Australia','AU','Kingscote (Kangaroo Island)~ Sou','KGC'),

(4104,'Jamaica','JM','Kingston','KIN'),

(4106,'Canada','CA','Kingston~ ON','YGK'),

(4107,'St. Vincent St. Vincent and the Grenadines','VC','Kingstown','SVD'),

(4108,'USA','US','Kingsville~ TX','NQI'),

(4109,'Taiwan','TW','Kinmen','KNH'),

(4110,'Zaire','ZR','Kinshasa','FIH'),

(4112,'USA','US','Kinston~ NC','ISO'),

(4113,'USA','US','Kipnuk~ AK','IIK'),

(4115,'Papua New Guinea','PG','Kira','KIQ'),

(4116,'Solomon Islands','SB','Kirakira','IRA'),

(4117,'Zaire','ZR','Kiri','KRZ'),

(4118,'Norway','NO','Kirkenes','KKN'),

(4119,'Australia','AU','Kirkimbie','KBB'),

(4120,'Canada','CA','Kirkland Lake~ ON','YKX'),

(4121,'USA','US','Kirksville~ MO','IRK'),

(4122,'Iraq','IQ','Kirkuk','KIK'),

(4123,'United Kingdom','GB','Kirkwall~ Orkney Islands~ Scotla','KOI'),

(4124,'Russia','RU','Kirov~ Kirov','KVX'),

(4125,'Ukraine','UA','Kirovohrad (Kirovograd)~ Kirovoh','KGO'),

(4126,'Sweden','SE','Kiruna','KRN'),

(4127,'Zaire','ZR','Kirundu','KRE'),

(4128,'Israel','IL','Kiryat Shmona','KSW'),

(4129,'Zaire','ZR','Kisangani','FKI'),

(4130,'Papua New Guinea','PG','Kisengan','KSG'),

(4131,'Iran','IR','Kish Island','KIH'),

(4132,'Somalia','SO','Kismayu','KMU'),

(4133,'Guinea','GN','Kissidougou','KSI'),

(4134,'USA','US','Kissimmee/Orlando~ FL','ISM'),

(4135,'Kenya','KE','Kisumu','KIS'),

(4136,'Japan','JP','Kita-Daito','KTD'),

(4137,'Japan','JP','Kita Kyushu','KKJ'),

(4138,'Kenya','KE','Kitale','KTL'),

(4139,'Papua New Guinea','PG','Kitava','KVE'),

(4140,'Canada','CA','Kitchener Lake~ BC','YKF'),

(4141,'Greece','GR','Kithira','KIT'),

(4142,'Canada','CA','Kitimat~ BC','YKI'),

(4143,'USA','US','Kitoi~ AK','KKB'),

(4144,'Canada','CA','Kitsault~ BC','JIT'),

(4145,'Finland','FI','Kittila','KTT'),

(4146,'Zambia','ZM','Kitwe','KIW'),

(4147,'Kenya','KE','Kiunga','KIU'),

(4148,'Papua New Guinea','PG','Kiunga','UNG'),

(4149,'USA','US','Kivalina~ AK','KVL'),

(4150,'Papua New Guinea','PG','Kiwai Island','KWX'),

(4151,'Kenya','KE','Kiwayu','KWY'),

(4152,'USA','US','Kizhuyak~ AK','KZH'),

(4153,'USA','US','Klag Bay~ AK','KBK'),

(4154,'Austria','AT','Klagenfurt','KLU'),

(4155,'Lithuania','LT','Klaipeda','KLJ'),

(4156,'USA','US','Klamath Falls~ OR','LMT'),

(4157,'USA','US','Klawock~ AK','KLW'),

(4158,'South Africa','ZA','Kleinzee','KLZ'),

(4159,'Canada','CA','Klemtu~ BC','YKT'),

(4160,'South Africa','ZA','Klerksdorp','KXE'),

(4161,'Canada','CA','Knee Lake~ MB','YKE'),

(4162,'USA','US','Knob Noster~ MO','SZL'),

(4163,'Ireland','IE','Knock/Connaught','NOC'),

(4164,'Belgium','BE','Knokke-Heist/Zoute','KNO'),

(4165,'USA','US','Knox~ IN','OXI'),

(4166,'USA','US','Knoxville~ IA','OXV'),

(4167,'USA','US','Knoxville~ TN','DKX'),

(4169,'Japan','JP','Kobe','UKB'),

(4170,'Denmark','DK','Kobenhavn (Copenhagen)','CPH'),

(4172,'USA','US','Kobuk~ AK','OBU'),

(4173,'Japan','JP','Kochi','KCZ'),

(4174,'USA','US','Kodiak~ AK','ADQ'),

(4176,'Germany','DE','Koeln (Koln~Cologne)','QKU'),

(4178,'Germany','DE','Koeln (Koln~Cologne)/Bonn','CGN'),

(4179,'Thailand','TH','Koh Samui','USM'),

(4180,'Pakistan','PK','Kohat','OHT'),

(4181,'Papua New Guinea','PG','Koinambe','KMB'),

(4182,'South Africa','ZA','Koingnaas','KIG'),

(4183,'Thailand','TH','Koke Kathiem/Lop Buri','KKM'),

(4184,'Finland','FI','Kokkola','KOK'),

(4185,'Papua New Guinea','PG','Kokoda','KKD'),

(4186,'USA','US','Kokomo~ IN','OKK'),

(4187,'Indonesia','ID','Kokonao','KOX'),

(4188,'Papua New Guinea','PG','Kokoro','KOR'),

(4189,'USA','US','Kokrines~ AK','KKS'),

(4190,'Kazakhstan','KZ','Kokshetau (Kokchetav)~ Kokshetau','KOV'),

(4191,'Papua New Guinea','PG','Kol','KQL'),

(4192,'Senegal','SN','Kolda','KDA'),

(4193,'India','IN','Kolhapur','KLH'),

(4194,'USA','US','Koliganek~ AK','KGK'),

(4195,'Zaire','ZR','Kolwezi','KWZ'),

(4196,'Papua New Guinea','PG','Komaco','HOC'),

(4197,'Japan','JP','Komatsu','KMQ'),

(4198,'Papua New Guinea','PG','Komo-Manda','KOM'),

(4199,'Greece','GR','Komotini','ZKT'),

(4200,'Papua New Guinea','PG','Kompiam','KPM'),

(4201,'Cambodia','KH','Kompong-Chhnang','KZC'),

(4202,'Cambodia','KH','Kompong-Thom','KZK'),

(4203,'Cambodia','KH','Kompongsom','KOS'),

(4204,'Russia','RU','Komsomolsk Na Amure~ Khabarovsk','KXK'),

(4205,'Guyana','GY','Konawaruk','KKG'),

(4206,'New Caledonia','NC','Kone','KNQ'),

(4207,'Papua New Guinea','PG','Konge','KGB'),

(4208,'USA','US','Kongiganak~ AK','KKH'),

(4209,'Gabon','GA','Kongoboumba','GKO'),

(4210,'Zaire','ZR','Kongolo','KOO'),

(4211,'Indonesia','ID','Kono','KCI'),

(4212,'Germany','DE','Konstanz','QKZ'),

(4213,'Vietnam','VN','Kontum','KON'),

(4214,'Turkey','TR','Konya','KYA'),

(4215,'Australia','AU','Koolatah~ Queensland','KOH'),

(4216,'Australia','AU','Koolburra~ Queensland','KKP'),

(4217,'Australia','AU','Koonibba~ South Australia','KQB'),

(4218,'Iceland','IS','Kopasker','OPA'),

(4219,'Papua New Guinea','PG','Kopiago','KPA'),

(4220,'Ivory Coast','CI','Korhogo','HGO'),

(4221,'China','CN','Korla','KRL'),

(4222,'Fiji','FJ','Koro','KXF'),

(4223,'Papua New Guinea','PG','Koroba','KDE'),

(4224,'Fiji','FJ','Korolevu','KVU'),

(4225,'Palau','PW','Koror','ROR'),

(4226,'Belgium','BE','Kortrijk','KJK'),

(4227,'Greece','GR','Kos~ Kos Island','KGS'),

(4228,'USA','US','Kosciusko~ MS','OSX'),

(4229,'Slovakia','SK','Kosice','KSC'),

(4230,'Papua New Guinea','PG','Kosipe','KSP'),

(4231,'Micronesia','FM','Kosrae Island','KSA'),

(4232,'Sudan','SD','Kosti','KST'),

(4233,'Poland','PL','Koszalin','OSZ'),

(4234,'Malaysia','MY','Kota Bharu','KBR'),

(4235,'Malaysia','MY','Kota Kinabalu~ East','BKI'),

(4236,'Ethiopia','ET','Kota','OTA'),

(4237,'India','IN','Kota','KTU'),

(4238,'Indonesia','ID','Kotabangun','KOD'),

(4239,'Indonesia','ID','Kotabaru','KBU'),

(4240,'Zaire','ZR','Kotakoli','KLI'),

(4241,'USA','US','Kotlik~ AK','KOT'),

(4242,'USA','US','Kotzebue~ AK','OTZ'),

(4243,'Gabon','GA','Koulamoutou','KOU'),

(4244,'New Caledonia','NC','Koumac','KOC'),

(4245,'Central African Republic','CF','Koumala','KOL'),

(4246,'Guinea','GN','Koundara','SBI'),

(4247,'French Guyana','GF','Kourou','QKR'),

(4248,'Cameroon','CM','Koutaba','KOB'),

(4249,'Mali','ML','Koutiala','KTX'),

(4250,'Finland','FI','Kouvola','UTI'),

(4251,'Australia','AU','Kowanyama~ Queensland','KWM'),

(4252,'USA','US','Koyuk~ AK','KKA'),

(4253,'USA','US','Koyukuk~ AK','KYU'),

(4254,'Greece','GR','Kozani','KZI'),

(4255,'Thailand','TH','Krabi','KBV'),

(4256,'Cambodia','KH','Krakor','KZD'),

(4257,'Poland','PL','Krakow','KRK'),

(4258,'Ukraine','UA','Kramatorsk~ Donets\'k','KRQ'),

(4259,'Sweden','SE','Kramfors','KRF'),

(4260,'Russia','RU','Krasnodar~ Krasnodar','KRR'),

(4261,'Turkmenistan','TM','Krasnodovsk~ Balkan','KRW'),

(4262,'Russia','RU','Krasnoyarsk~ Krasnoyarsk','KJA'),

(4263,'Cambodia','KH','Kratie','KTI'),

(4264,'Germany','DE','Krefeld','QKF'),

(4265,'Ukraine','UA','Kremenchuk (Kremenchug)~ Poltava','KHU'),

(4266,'Cameroon','CM','Kribi','KBI'),

(4267,'Norway','NO','Kristiansand','KRS'),

(4268,'Sweden','SE','Kristianstad','KID'),

(4269,'Norway','NO','Kristiansund','KSU'),

(4270,'Ukraine','UA','Krivyy Rih (Krivoy Rog)~ Dniprop','KWG'),

(4271,'Morocco','MA','Ksar Es Souk','SEK'),

(4272,'Brunei','BN','Kuala Belait','KUB'),

(4273,'Malaysia','MY','Kuala Lumpur~ Peninsular','KUL'),

(4274,'Malaysia','MY','Kuala Terengganu','TGG'),

(4275,'Malaysia','MY','Kuantan','KUA'),

(4276,'Australia','AU','Kubin Island','KUG'),

(4277,'Malaysia','MY','Kuching~ East','KCH'),

(4278,'Malaysia','MY','Kudat~ Sabah','KUD'),

(4279,'Libya','LY','Kufrah','AKF'),

(4280,'Angola','AO','Kuito','SVP'),

(4281,'Solomon Islands','SB','Kukundu','KUE'),

(4282,'Australia','AU','Kulgera~ Northern Territory','KGR'),

(4283,'USA','US','Kulik Lake~ AK','LKK'),

(4284,'India','IN','Kulu','KUU'),

(4285,'Greenland','GL','Kulusuk Island','KUS'),

(4286,'Japan','JP','Kumamoto','KMJ'),

(4287,'Ghana','GH','Kumasi','KMS'),

(4288,'Japan','JP','Kume Jima','UEO'),

(4289,'Papua New Guinea','PG','Kumgim','KGM'),

(4290,'Afghanistan','AF','Kunduz','UND'),

(4291,'Taiwan','TW','Kung Kuan','VKK'),

(4292,'China','CN','Kunming','KMG'),

(4293,'South Korea','KR','Kunsan','KUV'),

(4294,'Australia','AU','Kununurra~ Western Australia','KNX'),

(4295,'Finland','FI','Kuopio','KUO'),

(4296,'Finland','FI','Kuorevisi','KEV'),

(4297,'Indonesia','ID','Kupang','KOE'),

(4298,'USA','US','Kuparuk~ AK','UUK'),

(4299,'Papua New Guinea','PG','Kupiano','KUP'),

(4300,'China','CN','Kuqa','KCA'),

(4301,'Afghanistan','AF','Kuran','KUR'),

(4302,'Russia','RU','Kurgan~ Kurgan','KRO'),

(4303,'Papua New Guinea','PG','Kuri','KUQ'),

(4304,'Kiribati','KI','Kuria','KUC'),

(4305,'Russia','RU','Kursk~ Kursk','URS'),

(4306,'South Africa','ZA','Kuruman','KMH'),

(4307,'Australia','AU','Kurundi~ Northern Territory','KRD'),

(4308,'Guyana','GY','Kurupung','KPG'),

(4309,'Solomon Islands','SB','Kurwina','KWV'),

(4310,'South Korea','KR','Kusan','KUZ'),

(4311,'Japan','JP','Kushimoto','KUJ'),

(4312,'Japan','JP','Kushiro','KUH'),

(4313,'Georgia','GE','Kutaisi','KUT'),

(4314,'Canada','CA','Kuujjuaq (Fort Chimo)~ QC','YVP'),

(4315,'QC Canada','CA','Kuujjuarapik  - Poste de la Bale','YGW'),

(4316,'Finland','FI','Kuusamo','KAO'),

(4317,'Kuwait','KW','Kuwait','KWI'),

(4318,'Solomon Islands','SB','Kwai Harbour','KWR'),

(4319,'Marshall Islands','MH','Kwajalein','KWA'),

(4320,'South Korea','KR','Kwang Yun','QUN'),

(4321,'South Korea','KR','Kwangju','KWJ'),

(4322,'USA','US','Kwethluk~ AK','KWT'),

(4323,'USA','US','Kwigillingok~ AK','KWK'),

(4324,'Myanmar','MM','Kyaukpyu','KYP'),

(4325,'Myanmar','MM','Kyauktaw','KYT'),

(4326,'Japan','JP','Kyoto','UKY'),

(4327,'Ukraine','UA','Kyyiv (Kiev)~ Kiev','KBP'),

(4329,'Russia','RU','Kyzyl~ Tuva','CMJ'),

(4331,'France','FR','La Baule','LBY'),

(4332,'Honduras','HN','La Ceiba','LCE'),

(4333,'Colombia','CO','La Chorrera','LCR'),

(4334,'Cuba','CU','La Coloma','LCL'),

(4335,'Spain','ES','La Coruna','LCG'),

(4336,'USA','US','La Crosse~ WI/Winona~ MN','LSE'),

(4337,'Guadeloupe','GP','La Desirade','DSD'),

(4338,'Venezuela','VE','La Fria','LFR'),

(4339,'USA','US','La Grande~ OR','LGD'),

(4340,'Canada','CA','La Grande~ QC','YAR'),

(4343,'USA','US','La Grange~ GA','LGC'),

(4344,'Venezuela','VE','La Guaira','LAG'),

(4345,'Cuba','CU','La Habana (Havana)','HAV'),

(4346,'USA','US','La Junta~ CO','LHX'),

(4347,'France','FR','La Llagone','QZG'),

(4348,'Canada','CA','La Macaza~ QC','YFJ'),

(4349,'Spain','ES','La Munoza','QLM'),

(4350,'Spain','ES','La Palma~ Canary Islands','PLP'),

(4351,'Mexico','MX','La Paz','LAP'),

(4352,'Bolivia','BO','La Paz','LPB'),

(4353,'Colombia','CO','La Pedrera','LPD'),

(4354,'France','FR','La Plagne','PLG'),

(4355,'Argentina','AR','La Plata','LPG'),

(4356,'USA','US','La Porte~ IN','LPO'),

(4357,'Colombia','CO','La Primavera','LPE'),

(4358,'Argentina','AR','La Rioja','IRJ'),

(4359,'France','FR','La Roche','EDM'),

(4360,'France','FR','La Rochelle','LRH'),

(4361,'Dominican Republic','DO','La Romana','LRM'),

(4362,'Canada','CA','La Ronge~ SK','YVC'),

(4363,'Canada','CA','La Sarre~ QC','SSQ'),

(4364,'Chile','CL','La Serena','LSC'),

(4365,'Canada','CA','La Tabatiere~ QC','ZLT'),

(4366,'USA','US','La Touche~ AK','LTU'),

(4367,'Canada','CA','La Tuque~ QC','YLQ'),

(4368,'Honduras','HN','La Union','LUI'),

(4369,'USA','US','La Verne~ CA','POC'),

(4370,'Germany','DE','Laarbruch','LRC'),

(4371,'Morocco','MA','Laayoune','EUN'),

(4372,'Gabon','GA','Labamba','WNQ'),

(4373,'Fiji','FJ','Labasa','LBS'),

(4374,'Guinea','GN','Labe','LEK'),

(4375,'Brazil','BR','Laberal','LBR'),

(4376,'Papua New Guinea','PG','Lablab','LAB'),

(4377,'USA','US','Labouchere Bay~ AK','WLB'),

(4378,'Indonesia','ID','Labuan Bajo','LBJ'),

(4379,'Malaysia','MY','Labuan~ Sabah','LBU'),

(4380,'Indonesia','ID','Labuha','LAH'),

(4381,'Canada','CA','Lac Brochet~ MB','XLB'),

(4382,'Canada','CA','Lac La Biche~ AB','YLB'),

(4383,'Canada','CA','Lac La Martre~ NT','YLE'),

(4384,'USA','US','Laconia~ NH','LCI'),

(4385,'Argentina','AR','Lacumbre','LCM'),

(4386,'Suriname','SR','Ladouanie','LDO'),

(4387,'Australia','AU','Lady Elliott Island','LYT'),

(4388,'Canada','CA','Lady Franklin~ NT','YUJ'),

(4389,'South Africa','ZA','Ladysmith','LAY'),

(4390,'USA','US','Ladysmith~ WI','RCX'),

(4391,'Papua New Guinea','PG','Lae','LAC'),

(4393,'Marshall Islands','MH','Lae Island','LML'),

(4394,'USA','US','Lafayette~ IN','LAF'),

(4395,'USA','US','Lafayette~ LA','LFT'),

(4396,'Brazil','BR','Lages~ SC','LAJ'),

(4397,'Algeria','DZ','Laghouat','LOO'),

(4398,'Ecuador','EC','Lago Agrio','LGQ'),

(4399,'Nigeria','NG','Lagos','LOS'),

(4400,'Mexico','MX','Lagos de Moreno','LOM'),

(4401,'Venezuela','VE','Lagunillas','LGY'),

(4402,'Malaysia','MY','Lahad Datu~ Sabah','LDU'),

(4403,'Pakistan','PK','Lahore','LHE'),

(4404,'Germany','DE','Lahr','LHA'),

(4405,'Chad','TD','Lai','LTC'),

(4406,'Papua New Guinea','PG','Laiagam','LGM'),

(4407,'Brazil','BR','Lajeado~ RS','QLB'),

(4408,'Kenya','KE','Lake Baringo','LBN'),

(4409,'USA','US','Lake Charles~ LA','CWF'),

(4411,'Australia','AU','Lake Evella~ Northern Territory','LEL'),

(4412,'USA','US','Lake Geneva~ WI','XES'),

(4413,'Canada','CA','Lake Harbour~ NT','YLC'),

(4414,'USA','US','Lake Havasu City~ AZ','HII'),

(4416,'Tanzania','TZ','Lake Manyara','LKY'),

(4417,'USA','US','Lake Minchumina~ AK','LMA'),

(4418,'Papua New Guinea','PG','Lake Murray','LMY'),

(4419,'Australia','AU','Lake Nash~ Northern Territory','LNH'),

(4420,'USA','US','Lake Placid~ NY','LKP'),

(4421,'Kenya','KE','Lake Rudolf','LKU'),

(4422,'USA','US','Lake Tahoe (South Lake Tahoe)~ C','TVL'),

(4423,'Fiji','FJ','Lakeba','LKB'),

(4424,'Australia','AU','Lakefield~ Queensland','LFP'),

(4425,'USA','US','Lakehurst~ NJ','NEL'),

(4426,'Australia','AU','Lakeland Downs','LKD'),

(4427,'USA','US','Lakeland~ FL','LAL'),

(4428,'United Kingdom','GB','Lakenheath','XLK'),

(4429,'USA','US','Lakeside~ TX','LKS'),

(4430,'USA','US','Lakeview~ OR','LKV'),

(4431,'Norway','NO','Lakselv','LKL'),

(4432,'Ethiopia','ET','Lalibella','LLI'),

(4433,'Bangladesh','BD','Lalmonirhat','LLJ'),

(4434,'Western Samoa','EH','Lalomalava','LAV'),

(4435,'Vanuatu','VU','Lamap','LPM'),

(4436,'USA','US','Lamar~ CO','LAA'),

(4437,'USA','US','Lamar~ MO','LLU'),

(4438,'Papua New Guinea','PG','Lamassa','LMG'),

(4439,'Gabon','GA','Lambarene','LBQ'),

(4440,'Vanuatu','VU','Lamen Bay','LNB'),

(4441,'Italy','IT','Lamezia Terme','SUF'),

(4442,'Nepal','NP','Lamidanda','LDN'),

(4443,'Thailand','TH','Lampang','LPT'),

(4444,'Italy','IT','Lampedusa~ Lampedusa Island','LMP'),

(4445,'Kenya','KE','Lamu','LAU'),

(4446,'USA','US','Lanai City~ HI','LNY'),

(4447,'USA','US','Lancaster~ CA','RZH'),

(4448,'USA','US','Lancaster~ PA','LNS'),

(4449,'USA','US','Lancaster/Palmdale~ CA','WJF'),

(4450,'USA','US','Land O\'Lakes~ WI','LNL'),

(4451,'USA','US','Lander~ WY','LND'),

(4452,'United Kingdom','GB','Lands End~ England','LEQ'),

(4453,'Germany','DE','Landshot','QLG'),

(4454,'Canada','CA','Langara~ BC','YLA'),

(4455,'Germany','DE','Langeoog','LGO'),

(4456,'Indonesia','ID','Langgur/Tual','LUV'),

(4457,'Papua New Guinea','PG','Langimar','LNM'),

(4458,'Malaysia','MY','Langkawi','LGK'),

(4459,'Nepal','NP','Langtang','LTG'),

(4460,'France','FR','Lannion','LAI'),

(4461,'Canada','CA','Lansdowne House~ ON','YLH'),

(4462,'Australia','AU','Lansdowne Station~ Western Austr','LDW'),

(4463,'South Africa','ZA','Lanseria','HLA'),

(4464,'USA','US','Lansing~ MI','LAN'),

(4465,'China','CN','Lanzhou','LHW'),

(4467,'Philippines','PH','Laoag','LAO'),

(4468,'Finland','FI','Lappeenranta','LPP'),

(4469,'Philippines','PH','Lapu-Lapu~ Mactan Island','NOP'),

(4470,'USA','US','Laramie~ WY','LAR'),

(4471,'Indonesia','ID','Larantuka','LKA'),

(4472,'USA','US','Laredo~ TX','LRD'),

(4473,'Greece','GR','Larisa','LRA'),

(4474,'Pakistan','PK','Larkana','LKW'),

(4475,'Cyprus','CY','Larnaca','LCA'),

(4476,'USA','US','Larned~ KS','LQR'),

(4477,'USA','US','Larsen Bay~ AK','KLN'),

(4478,'Costa Rica','CR','Las Canas','LCS'),

(4479,'USA','US','Las Cruces~ NM','LRU'),

(4480,'Colombia','CO','Las Gaviotas','LGT'),

(4481,'Argentina','AR','Las Heras','LHS'),

(4482,'Somalia','SO','Las Koreh','LKR'),

(4483,'Honduras','HN','Las Limas','LLH'),

(4484,'Argentina','AR','Las Lomitas','LLS'),

(4485,'Spain','ES','Las Palmas/Gran Canaria~ Canary ','LPA'),

(4486,'Venezuela','VE','Las Piedras','LSP'),

(4487,'Cuba','CU','Las Tunas','VTU'),

(4488,'USA','US','Las Vegas~ NM','LVS'),

(4489,'USA','US','Las Vegas~ NV','LAS'),

(4493,'Myanmar','MM','Lashio','LSH'),

(4494,'Gabon','GA','Lastourville','LTL'),

(4495,'Syria','SY','Latakia','LTK'),

(4496,'USA','US','Lathrop Wells~ NV','LTH'),

(4497,'Italy','IT','Latina','QLT'),

(4498,'Australia','AU','Latrobe','LTB'),

(4499,'USA','US','Latrobe~ PA','LBE'),

(4500,'Fiji','FJ','Laucala Island','LUC'),

(4501,'Australia','AU','Launceston~ Tasmania','LST'),

(4502,'Australia','AU','Laura Station~ Queensland','LUT'),

(4503,'Australia','AU','Laura~ Queensland','LUU'),

(4504,'USA','US','Laurel~ MS','LUL'),

(4505,'USA','US','Laurel/Hattiesburg~ MS','PIB'),

(4506,'Colombia','CO','Lauribe','LAT'),

(4507,'Canada','CA','Laurie River~ MB','LRQ'),

(4508,'Switzerland','CH','Lausanne','QLS'),

(4509,'Austria','AT','Lauterach','QLX'),

(4510,'France','FR','Laval','LVA'),

(4511,'Australia','AU','Laverton~ Western Australia','LVO'),

(4512,'Brazil','BR','Lavras~ MG','QLW'),

(4513,'Malaysia','MY','Lawas~ Sarawak','LWY'),

(4514,'Australia','AU','Lawn Hill~ Queensland','LWH'),

(4515,'USA','US','Lawrence~ KS','LWC'),

(4517,'USA','US','Lawrence~ MA','LWM'),

(4518,'USA','US','Lawrenceville~ GA','LZU'),

(4519,'USA','US','Lawrenceville~ IL','LWV'),

(4520,'USA','US','Lawrenceville~ VA','LVL'),

(4521,'USA','US','Lawton~ OK','LAW'),

(4522,'Mexico','MX','Lazaro Cardenas','LZC'),

(4523,'France','FR','Le Castellet','CTT'),

(4524,'France','FR','Le Havre','LEH'),

(4525,'France','FR','Le Mans','LME'),

(4526,'USA','US','Le Mars~ IA','LRJ'),

(4527,'France','FR','Le Puy','LPY'),

(4528,'France','FR','Le Touquet','LTQ'),

(4529,'USA','US','Leadville~ CO','LXV'),

(4530,'Canada','CA','Leaf Rapids~ MB','YLR'),

(4531,'Australia','AU','Learmouth (Exmouth)~ Western Aus','LEA'),

(4532,'Lesotho','LS','Lebakeng','LEF'),

(4533,'USA','US','Lebanon~ NH','LEB'),

(4534,'Canada','CA','Lebel-sur-Quevillon~ QC','YLS'),

(4535,'Italy','IT','Lecce','LCC'),

(4536,'Gabon','GA','Leconi','LEO'),

(4537,'United Kingdom','GB','Leeds/Bradford','LBA'),

(4538,'USA','US','Leesburg~ FL','LEE'),

(4539,'USA','US','Leesburg~ VA','JYO'),

(4540,'Australia','AU','Leeton~ New South Wales','QLE'),

(4541,'Netherlands','NL','Leeuwarden','LWR'),

(4542,'Philippines','PH','Legaspi','LGP'),

(4543,'Colombia','CO','Leguizamo','LGZ'),

(4544,'India','IN','Leh','IXL'),

(4545,'Papua New Guinea','PG','Lehu','LHP'),

(4546,'Australia','AU','Leigh Creek~ South Australia','LGH'),

(4547,'Australia','AU','Leinster~ Western Australia','LER'),

(4548,'Germany','DE','Leipzig','LEJ'),

(4549,'Papua New Guinea','PG','Leitre','LTF'),

(4550,'Congo','CG','Lekana','LKC'),

(4551,'Norway','NO','Leknes','LKN'),

(4552,'Netherlands','NL','Lelystad','LEY'),

(4553,'USA','US','Lemmon~ SD','LEM'),

(4554,'Greece','GR','Lemnos (Limnos)','LXS'),

(4555,'USA','US','Lemoore~ CA','NLC'),

(4556,'Papua New Guinea','PG','Lengbati','LNC'),

(4557,'Burkina Faso','BF','Leo','XLU'),

(4558,'Mexico','MX','Leon','LEN'),

(4560,'USA','US','Leonardtown~ MD','LTW'),

(4561,'Australia','AU','Leonora~ Western Australia','LNO'),

(4562,'Brazil','BR','Leopoldina~ MG','LEP'),

(4563,'Indonesia','ID','Lereh','LHI'),

(4564,'Lesotho','LS','Leribe','LRB'),

(4565,'Greece','GR','Leros','LRS'),

(4566,'United Kingdom','GB','Lerwick~ Shetland Islands','SCS'),

(4569,'Haiti','HT','Les Cayes','CYA'),

(4570,'France','FR','Les Sables','LSO'),

(4571,'Guadeloupe','GP','Les Saintes/Terre de Haut','LSS'),

(4572,'Papua New Guinea','PG','Lese','LNG'),

(4573,'Lesotho','LS','Lesobeng','LES'),

(4574,'Canada','CA','Lethbridge~ AB','YQL'),

(4575,'Guyana','GY','Lethem','LTM'),

(4576,'Colombia','CO','Leticia','LET'),

(4577,'USA','US','Levelock~ AK','KLL'),

(4578,'USA','US','Lewiston~ ID','LWS'),

(4579,'USA','US','Lewistown~ MT','LWT'),

(4580,'Indonesia','ID','Lewoleba','LWE'),

(4581,'USA','US','Lexington Blue Grass Depot~ KY','LSD'),

(4582,'USA','US','Lexington~ KY','LEX'),

(4583,'USA','US','Lexington~ NC','EXX'),

(4584,'USA','US','Lexington~ NE','LXN'),

(4585,'USA','US','Lexington~ OK','HMY'),

(4586,'China','CN','Lhasa','LXA'),

(4587,'Indonesia','ID','Lhok Sukon','LSX'),

(4588,'Indonesia','ID','Lhokseumawe','LSW'),

(4589,'China','CN','Lianyungang (Xinpu)','LYG'),

(4590,'Canada','CA','Liard River~ BC','YZL'),

(4591,'Zaire','ZR','Libenge','LIE'),

(4592,'USA','US','Liberal~ KS','LBL'),

(4593,'Costa Rica','CR','Liberia','LIR'),

(4594,'Kenya','KE','Liboi','LBK'),

(4595,'Gabon','GA','Libreville','LBV'),

(4596,'Mozambique','MZ','Lichinga (Vila Cabral)','VXC'),

(4597,'Sweden','SE','Lidkoping','LDK'),

(4598,'Belgium','BE','Liege (Luttich)','LGG'),

(4599,'Latvia','LV','Liepaja','LPX'),

(4600,'New Caledonia','NC','Lifou (Lifu)~ Loyalty Islands','LIF'),

(4601,'Australia','AU','Lightning Ridge~ New South Wales','LHG'),

(4602,'USA','US','Lihue~ HI','LIH'),

(4603,'Marshall Islands','MH','Likiep','LIK'),

(4604,'Malawi','MW','Likoma Island','LIX'),

(4605,'India','IN','Lilabari','IXI'),

(4606,'France','FR','Lille','LIL'),

(4607,'Malawi','MW','Lilongwe','LLW'),

(4608,'Peru','PE','Lima','LIM'),

(4609,'USA','US','Lima~ OH','AOH'),

(4611,'Cyprus','CY','Limassol','QLI'),

(4612,'Malaysia','MY','Limbang~ Sarawak','LMN'),

(4613,'Australia','AU','Limbunya~ Northern Territory','LIB'),

(4614,'South Africa','ZA','Lime Acres','LMR'),

(4615,'USA','US','Lime Village~ AK','LVD'),

(4616,'Ireland','IE','Limerick','LMK'),

(4617,'USA','US','Limestone~ ME','LIZ'),

(4618,'France','FR','Limoges','LIG'),

(4619,'USA','US','Limon~ CO','LIC'),

(4620,'Costa Rica','CR','Limon','LIO'),

(4621,'Honduras','HN','Limon','LMH'),

(4622,'USA','US','Lincoln River~ AK','LRK'),

(4623,'USA','US','Lincoln~ NE','LNK'),

(4624,'NE USA','US','Lincoln','AYJ'),

(4625,'Australia','AU','Linda Downs','LLP'),

(4626,'Australia','AU','Lindeman Island~ Queensland','LDC'),

(4627,'USA','US','Linden~ NJ','LDJ'),

(4628,'Tanzania','TZ','Lindi','LDI'),

(4629,'Papua New Guinea','PG','Linga Linga','LGN'),

(4630,'Sweden','SE','Linkoping','LPI'),

(4631,'Brazil','BR','Lins~ SP','LIP'),

(4632,'Austria','AT','Linz','LNZ'),

(4633,'Russia','RU','Lipetsk~ Lipetsk','LPK'),

(4634,'Zaire','ZR','Lisala','LIQ'),

(4635,'Portugal','PT','Lisboa (Lisbon)','LIS'),

(4636,'Taiwan','TW','Lishan','LHN'),

(4637,'Australia','AU','Lismore~ Queensland','LSY'),

(4638,'Australia','AU','Lissadel~ Western Australia','LLL'),

(4639,'USA','US','Little America~ UT','XLA'),

(4640,'Cayman Islands','KY','Little Cayman','LYB'),

(4641,'USA','US','Little Diomede Island~ AK','DIO'),

(4642,'USA','US','Little Falls~ MN','LXL'),

(4643,'Canada','CA','Little Grand Rapids~ MB','ZGR'),

(4644,'USA','US','Little Naukati~ AK','WLN'),

(4645,'USA','US','Little Port Walker~ AK','LPW'),

(4646,'USA','US','Little Rock~ AR','LIT'),

(4647,'China','CN','Liuzhou','LZH'),

(4648,'USA','US','Livermore~ CA','LVK'),

(4649,'United Kingdom','GB','Liverpool~ England','LPL'),

(4650,'Canada','CA','Liverpool~ NS','YAU'),

(4651,'USA','US','Livingood~ AK','LIV'),

(4652,'USA','US','Livingston~ MT','LVM'),

(4653,'Zambia','ZM','Livingstone (Maramba)','LVI'),

(4654,'Australia','AU','Lizard Island~ Queensland','LZR'),

(4655,'Slovenia','SI','Ljubljana','LJU'),

(4656,'Canada','CA','Lloydminster~ AB','YLL'),

(4657,'Taiwan','TW','Lo Tung','LOB'),

(4658,'Papua New Guinea','PG','Loani','LNQ'),

(4659,'Botswana','BW','Lobatze','LOQ'),

(4660,'Switzerland','CH','Locarno','ZJI'),

(4661,'United Kingdom','GB','Lochgilphead','LPH'),

(4662,'USA','US','Lock Haven~ PA','LHV'),

(4663,'Australia','AU','Lock~ South Australia','LOC'),

(4664,'Australia','AU','Lockhart Rivers~ Queensland','IRG'),

(4665,'USA','US','Lockport/Chicago/Romeoville~ IL ','JLK'),

(4667,'Yemen','YE','Lodar','LDR'),

(4668,'Zaire','ZR','Lodja','LJA'),

(4669,'Kenya','KE','Lodwar','LOK'),

(4670,'Thailand','TH','Loei','LOE'),

(4671,'Norway','NO','Loen','LOF'),

(4672,'USA','US','Logan~ UT','LGU'),

(4673,'USA','US','Logansport~ IN','GGP'),

(4674,'Myanmar','MM','Loikaw','LIW'),

(4675,'Ecuador','EC','Loja','LOH'),

(4676,'Kenya','KE','Lolyangalani','LOY'),

(4677,'Togo','TG','Lome','LFW'),

(4678,'USA','US','Lompoc~ CA','LPC'),

(4680,'Papua New Guinea','PG','Londolovit','LNV'),

(4681,'United Kingdom','GB','London','STN'),

(4682,'United Kingdom','GB','London~ England','LCY'),

(4687,'USA','US','London~ KY','LOZ'),

(4688,'USA','US','London~ OH','UYF'),

(4689,'Canada','CA','London~ ON','YXU'),

(4690,'United Kingdom','GB','Londonderry~ Northern Ireland','LDY'),

(4691,'Brazil','BR','Londrina~ PR','LDB'),

(4692,'Vanuatu','VU','Londrore','LNE'),

(4693,'USA','US','Lone Rock~ WI','LNR'),

(4694,'USA','US','Lonely~ AK','LNI'),

(4695,'Indonesia','ID','Long Apung','LPU'),

(4696,'USA','US','Long Beach~ CA','LGB'),

(4698,'USA','US','Long Island (Farmingdale)~ NY','FRG'),

(4699,'USA','US','Long Island~ AK','LIJ'),

(4700,'Malaysia','MY','Long Lama','LLM'),

(4701,'Malaysia','MY','Long Lellang','LGL'),

(4702,'Malaysia','MY','Long Paisa~ Sabah','GSA'),

(4703,'Malaysia','MY','Long Semado~ Sarawak','LSM'),

(4704,'Malaysia','MY','Long Seridan~ Sarawak','ODN'),

(4705,'Malaysia','MY','Long Sukang','LSU'),

(4706,'Vietnam','VN','Long Xuyen','XLO'),

(4707,'Vanuatu','VU','Longana','LOD'),

(4708,'Indonesia','ID','Longbawan','LBW'),

(4709,'Canada','CA','Longpoint Lake~ ON','YLX'),

(4710,'Australia','AU','Longreach~ Queensland','LRE'),

(4711,'Canada','CA','Longstaff Bluff~ NT','YUV'),

(4712,'USA','US','Longview~ TX','GGG'),

(4713,'USA','US','Longview~ WA','LOG'),

(4714,'Colombia','CO','Lopez de Micay','LMX'),

(4715,'USA','US','Lopez~ WA','LPS'),

(4716,'Congo','CG','Loque','LCO'),

(4717,'Pakistan','PK','Lora Lai','LRG'),

(4718,'Australia','AU','Lord Howe Island~ New South Wale','LDH'),

(4719,'USA','US','Lordsburg~ NM','LSB'),

(4720,'Mexico','MX','Loreto','LTO'),

(4721,'Colombia','CO','Lorica','LRI'),

(4722,'France','FR','Lorient','LRT'),

(4723,'USA','US','Loring~ AK','WLR'),

(4724,'Germany','DE','Lorrach','QLO'),

(4725,'Australia','AU','Lorraine~ Queensland','LOA'),

(4726,'USA','US','Los Alamos~ NM','LAM'),

(4727,'USA','US','Los Angeles (City of Industry)~ ','JID'),

(4728,'USA','US','Los Angeles~ CA','JBP'),

(4729,'USA','US','Los Angeles (Van Nuys)~ CA','VNY'),

(4739,'Chile','CL','Los Angeles','LSQ'),

(4740,'USA','US','Los Banos~ CA','LSN'),

(4741,'Mexico','MX','Los Cabos (San Jose del Cabo)','SJD'),

(4742,'Costa Rica','CR','Los Chiles','LSL'),

(4743,'Argentina','AR','Los Menucos','LMD'),

(4744,'Mexico','MX','Los Mochis','LMM'),

(4745,'Venezuela','VE','Los Roques','LRV'),

(4746,'Croatia','HR','Losinj','LSZ'),

(4747,'USA','US','Lost Harbor~ AK','LHB'),

(4748,'USA','US','Lost River~ AK','LSR'),

(4749,'Papua New Guinea','PG','Losuia','LSA'),

(4750,'Australia','AU','Lotusvale~ Queensland','LTV'),

(4751,'South Africa','ZA','Louis Trichardt','LCD'),

(4752,'USA','US','Louisa~ VA','LOW'),

(4753,'USA','US','Louisburg~ NC','LFN'),

(4754,'USA','US','Louisville~ KY','LOU'),

(4757,'USA','US','Louisville~ MS','LMS'),

(4758,'France','FR','Lourdes/Tarbes','LDE'),

(4759,'USA','US','Loveland~ CO','LLD'),

(4760,'USA','US','Lovelock~ NV','LOL'),

(4761,'Papua New Guinea','PG','Lowai','LWI'),

(4762,'Mozambique','MZ','Luabo','LBM'),

(4763,'Angola','AO','Luanda','LAD'),

(4764,'Laos','LA','Luang Namtha','LXG'),

(4765,'Laos','LA','Luang Prabang','LPQ'),

(4766,'Angola','AO','Luau','UAL'),

(4767,'Angola','AO','Lubango (Sa da Bandeira)','SDD'),

(4768,'USA','US','Lubbock~ TX','LBB'),

(4770,'Zaire','ZR','Lubumbashi','FBM'),

(4771,'Italy','IT','Lucca','LCV'),

(4772,'Slovakia','SK','Lucenec','LUE'),

(4773,'Switzerland','CH','Lucerne','QLJ'),

(4774,'India','IN','Lucknow','LKO'),

(4775,'India','IN','Ludhiana','LUH'),

(4776,'USA','US','Ludington~ MI','LDM'),

(4777,'Germany','DE','Luebeck (Lubeck)','LBC'),

(4778,'Namibia','LC','Luederitz (Luderitz)','LUD'),

(4779,'Angola','AO','Luena (Luso)','LUO'),

(4780,'USA','US','Lufkin~ TX','LFK'),

(4781,'Switzerland','CH','Lugano','LUG'),

(4782,'Somalia','SO','Lugh Ganane','LGX'),

(4783,'Ukraine','UA','Luhansk~ Luhansk','VSG'),

(4784,'Zaire','ZR','Luiza','LZA'),

(4785,'Nepal','NP','Lukla','LUA'),

(4786,'Zambia','ZM','Lukulu','LXU'),

(4787,'Sweden','SE','Lulea','LLA'),

(4788,'Angola','AO','Lumbala','GGC'),

(4789,'USA','US','Lumberton~ NC','LBT'),

(4790,'Papua New Guinea','PG','Lumi','LMI'),

(4791,'Guyana','GY','Lumid Pau','LUB'),

(4792,'Indonesia','ID','Lunyuk','LYK'),

(4793,'China','CN','Luoyang','LYA'),

(4794,'Zaire','ZR','Luozi','LZI'),

(4795,'Canada','CA','Lupin~ NT','QQV'),

(4796,'Zambia','ZM','Lusaka','LUN'),

(4797,'Zaire','ZR','Lusambo','LBO'),

(4798,'Zaire','ZR','Lusanga','LUS'),

(4799,'South Africa','ZA','Lusikisiki','LUJ'),

(4800,'USA','US','Lusk~ WY','LSK'),

(4801,'Ukraine','UA','Luts\'k~ Volyn','UCK'),

(4802,'Indonesia','ID','Luwuk','LUW'),

(4803,'Luxembourg','LU','Luxembourg','LUX'),

(4804,'China','CN','Luxi','LUM'),

(4805,'Egypt','EG','Luxor','LXR'),

(4806,'China','CN','Luzhou~ Sichuan','LZO'),

(4807,'Philippines','PH','Luzon','CRK'),

(4808,'Ukraine','UA','Lviv (Lwow~Lvov)~ L\'viv','LWO'),

(4809,'Canada','CA','Lyall Harbour~ BC','YAJ'),

(4810,'Sweden','SE','Lycksele','LYC'),

(4811,'United Kingdom','GB','Lydd','LYX'),

(4812,'USA','US','Lynchburg~ VA','LYH'),

(4813,'Australia','AU','Lyndhurst~ Queensland','LTP'),

(4814,'USA','US','Lyndonville~ VT','LLX'),

(4815,'United Kingdom','GB','Lyneham~ England','LYE'),

(4816,'Canada','CA','Lynn Lake~ MB','YYL'),

(4817,'France','FR','Lyon','LYN'),

(4819,'USA','US','Lyons~ KS','LYO'),

(4820,'Canada','CA','Lytton~ BC','YLY'),

(4821,'Central African Republic','CF','M\'Bala','MMQ'),

(4822,'Angola','AO','M\'banza Congo','SSY'),

(4823,'Jordan','JO','Maan','MPQ'),

(4824,'Netherlands','NL','Maastricht','MST'),

(4825,'Guyana','GY','Mabaruma','USI'),

(4826,'Australia','AU','Mabuiag Island~ Queensland','UBB'),

(4827,'Brazil','BR','Macae~ RJ','MEA'),

(4828,'Colombia','CO','Macanal','NAD'),

(4829,'Brazil','BR','Macapa~ PA','MCP'),

(4830,'Ecuador','EC','Macara','MRR'),

(4831,'Ecuador','EC','Macas','XMS'),

(4832,'Macao','MO','Macau (Macao)','QMP'),

(4833,'Australia','AU','MacDonald Downs','MNW'),

(4834,'Brazil','BR','Maceio~ AL','MCZ'),

(4835,'Guinea','GN','Macenta','MCA'),

(4836,'Ecuador','EC','Machala','MCH'),

(4837,'United Kingdom','GB','Machrihanish~ Scotland','GQJ'),

(4838,'Canada','CA','Mackar Inlet~ NT','YUU'),

(4839,'Australia','AU','Mackay~ Queensland','MKY'),

(4840,'Canada','CA','Mackenzie~ BC','YZY'),

(4841,'USA','US','Mackinac Island~ MI','MCD'),

(4842,'USA','US','Macksville~ KS','MVH'),

(4843,'Canada','CA','MacMillan Pass~ YT','XMP'),

(4844,'USA','US','Macomb~ IL','MQB'),

(4845,'USA','US','Macon~ GA','MAC'),

(4847,'Jordan','JO','Madaba','QMD'),

(4848,'Papua New Guinea','PG','Madang','MAG'),

(4849,'USA','US','Madera~ CA','MAE'),

(4850,'Madagascar','MG','Madirovalo','WMV'),

(4851,'USA','US','Madison~ CT','MPE'),

(4852,'USA','US','Madison~ IN','MDN'),

(4853,'USA','US','Madison~ MN','DXX'),

(4854,'USA','US','Madison~ SD','XMD'),

(4855,'USA','US','Madison~ WI','MSN'),

(4856,'India','IN','Madras','MAA'),

(4857,'USA','US','Madras~ OR','MDJ'),

(4858,'Spain','ES','Madrid','MAD'),

(4860,'India','IN','Madurai','IXM'),

(4861,'Thailand','TH','Mae Hong Son','HGN'),

(4862,'Thailand','TH','Mae Sot','MAQ'),

(4863,'Vanuatu','VU','Maewo','MWF'),

(4864,'South Africa','ZA','Mafeking','MFK'),

(4865,'South Africa','ZA','Mafeteng','MFC'),

(4866,'Tanzania','TZ','Mafia Island','MFA'),

(4867,'Brazil','BR','Mafra~ SC','QMF'),

(4868,'Jordan','JO','Mafraq','OMF'),

(4869,'Russia','RU','Magadan~ Magadan','GDX'),

(4870,'Mozambique','MZ','Maganja da Costa','MJS'),

(4871,'Colombia','CO','Maganque','MGN'),

(4872,'Bolivia','BO','Magdalena','MGD'),

(4873,'Russia','RU','Magnitogorsk~ Chelyabinsk','MQF'),

(4874,'USA','US','Magnolia~ AR','AGO'),

(4875,'Myanmar','MM','Magwe','MWQ'),

(4876,'Madagascar','MG','Mahajanga (Majunga)','MJN'),

(4877,'Madagascar','MG','Mahanoro','VVB'),

(4878,'Guyana','GY','Mahdia','MHA'),

(4879,'Seychelles','SC','Mahe~ Mahe Is.','SEZ'),

(4880,'Nepal','NP','Mahendranagar','XMG'),

(4881,'Belarus','BY','Mahilyow (Mogilev)~ Mahiliow','MVQ'),

(4882,'Spain','ES','Mahon (Menorca)~ Balearic Island','MAH'),

(4883,'Kiribati','KI','Maiana','MNK'),

(4884,'Colombia','CO','Maicao','MCJ'),

(4885,'Nigeria','NG','Maiduguri','MIU'),

(4886,'Guyana','GY','Maikwak','VEG'),

(4887,'Afghanistan','AF','Maimana','MMZ'),

(4888,'Canada','CA','Main Duck~ ON','YDK'),

(4889,'Australia','AU','Mainoru~ Northern Territory','MIZ'),

(4890,'Madagascar','MG','Maintirano','MXT'),

(4891,'Germany','DE','Mainz','QMZ'),

(4892,'Cape Verde','CV','Maio~ Maio','MMO'),

(4893,'Venezuela','VE','Maiquetia','MQV'),

(4894,'Brazil','BR','Mairiporu~ SP','QMC'),

(4895,'Australia','AU','Maitland~ New South Wales','MTL'),

(4896,'Ethiopia','ET','Maji','MJI'),

(4897,'Marshall Islands','MH','Majkin','MJE'),

(4898,'Saudi Arabia','SA','Majma','MJH'),

(4899,'Marshall Islands','MH','Majuro','MAJ'),

(4900,'Congo','CG','Makabana','KMK'),

(4901,'Ethiopia','ET','Makale','MQX'),

(4902,'French Polynesia','PF','Makemo','MKP'),

(4903,'Russia','RU','Makhachkala~ Dagestan','MCX'),

(4904,'Kiribati','KI','Makin','MTK'),

(4905,'Papua New Guinea','PG','Makini','MPG'),

(4906,'Morocco','MA','Makkah','QCA'),

(4907,'Canada','CA','Makkovik~ NF','YFT'),

(4909,'Malawi','MW','Makokola','CMK'),

(4910,'Gabon','GA','Makokou','MKU'),

(4911,'Congo','CG','Makoua','MKJ'),

(4912,'Taiwan','TW','Makung','MZG'),

(4913,'Nigeria','NG','Makurdi','MDI'),

(4914,'South Africa','ZA','Mala Mala','AAM'),

(4915,'Philippines','PH','Malabang','MLP'),

(4916,'Equatorial Guinea','GQ','Malabo','SSG'),

(4917,'Malaysia','MY','Malacca (Melaka)','MKZ'),

(4918,'USA','US','Malad City~ ID','MLD'),

(4919,'Spain','ES','Malaga','AGP'),

(4920,'Madagascar','MG','Malaimbandy','WML'),

(4921,'Sudan','SD','Malakal','MAK'),

(4922,'Papua New Guinea','PG','Malalaua','MLQ'),

(4923,'Indonesia','ID','Malang','MLG'),

(4924,'Angola','AO','Malange (Malanje)','MEG'),

(4925,'Argentina','AR','Malargue','LGS'),

(4926,'Panama','PA','Malatupo','MPP'),

(4927,'Turkey','TR','Malatva','MLX'),

(4928,'Philippines','PH','Malay','MPH'),

(4929,'India','IN','Malda','LDA'),

(4930,'USA','US','Malden~ MO','MAW'),

(4931,'Maldives','MV','Male City','MLE'),

(4932,'Papua New Guinea','PG','Malekolon','MKN'),

(4933,'Indonesia','ID','Maliana','MPT'),

(4934,'Kenya','KE','Malindi','MYD'),

(4935,'Australia','AU','Mallacoota~ Victoria','XMC'),

(4936,'Sweden','SE','Malmo','HMA'),

(4940,'Marshall Islands','MH','Maloelap','MAV'),

(4941,'Fiji','FJ','Malololailai','PTF'),

(4942,'Malta','MT','Malta','MLA'),

(4943,'USA','US','Malta~ MT','MLK'),

(4944,'Papua New Guinea','PG','Mamai','MAP'),

(4945,'Philippines','PH','Mamburao','MBO'),

(4946,'Cameroon','CM','Mamfe','MMF'),

(4947,'Panama','PA','Mamitupo','MPI'),

(4948,'USA','US','Mammoth Lakes~ CA','MMH'),

(4949,'Madagascar','MG','Mampikony','WMP'),

(4950,'Indonesia','ID','Mamuju','MJU'),

(4951,'Ivory Coast','CI','Man','MJC'),

(4952,'Fiji','FJ','Mana','MNF'),

(4953,'Indonesia','ID','Manado','MDC'),

(4954,'Nicaragua','NI','Managua','MGA'),

(4955,'Madagascar','MG','Manakara','WVK'),

(4956,'Madagascar','MG','Mananara','WMR'),

(4957,'Nepal','NP','Manang','NGX'),

(4958,'Madagascar','MG','Mananjary','MNJ'),

(4959,'Papua New Guinea','PG','Manare','MRM'),

(4960,'USA','US','Manassas~ VA','MNZ'),

(4961,'Belize','BZ','Manatee','MZE'),

(4962,'Burma','MM','Manaung','MGU'),

(4963,'Brazil','BR','Manaus~ AM','MAO'),

(4964,'United Kingdom','GB','Manchester~ England','MAN'),

(4966,'USA','US','Manchester~ NH','MHT'),

(4967,'Madagascar','MG','Mandabe','WMD'),

(4968,'Myanmar','MM','Mandalay','MDL'),

(4969,'Kenya','KE','Mandera','NDE'),

(4970,'Jamaica','JM','Mandeville','MVJ'),

(4971,'Gabon','GA','Mandji','KMD'),

(4972,'Australia','AU','Mandora~ Western Australia','MQA'),

(4973,'Madagascar','MG','Mandritsara','WMA'),

(4974,'Gabon','GA','Manea','MGO'),

(4975,'Papua New Guinea','PG','Manetai','MVI'),

(4976,'Solomon Islands','SB','Manga','MGP'),

(4977,'Cook Islands','CK','Mangaia','MGS'),

(4978,'India','IN','Mangalore','IXE'),

(4979,'French Polynesia','PF','Mangareva~ Gambier Islands','GMR'),

(4980,'Malawi','MW','Mangochi','MAI'),

(4981,'Indonesia','ID','Mangole','MAL'),

(4982,'Bahamas','BS','Mangrove Cay','MAY'),

(4983,'Indonesia','ID','Mangunjaya','MJY'),

(4984,'USA','US','Manhattan~ KS','MHK'),

(4985,'Brazil','BR','Manicore~ AM','MNX'),

(4986,'French Polynesia','PF','Manihi','XMH'),

(4987,'Cook Islands','CK','Manihiki Island','MHX'),

(4988,'Philippines','PH','Manila','MNL'),

(4989,'USA','US','Manila~ AR','MXA'),

(4991,'Australia','AU','Maningrida~ Northern Territory','MNG'),

(4992,'USA','US','Manistee~ MI','MBL'),

(4993,'USA','US','Manistique~ MI','ISQ'),

(4994,'Canada','CA','Manitouwadge~ ON','YMG'),

(4995,'Canada','CA','Manitowaning~ ON','YEM'),

(4996,'USA','US','Manitowoc~ WI','MTW'),

(4997,'Canada','CA','Maniwaki~ QC','YMW'),

(4998,'Colombia','CO','Manizales','MZL'),

(4999,'Madagascar','MG','Manja','MJA'),

(5000,'Australia','AU','Manjimup~ Western Australia','MJP'),

(5001,'USA','US','Mankato~ MN','MKT'),

(5002,'USA','US','Manley Hot Springs~ AK','MLY'),

(5003,'Australia','AU','Manners Creek~ Northern Territor','MFP'),

(5004,'Germany','DE','Mannheim','MHG'),

(5005,'USA','US','Manokotak~ AK','KMO'),

(5006,'Indonesia','ID','Manokwari','MKW'),

(5007,'Zaire','ZR','Manono','MNO'),

(5008,'Zambia','ZM','Mansa','MNS'),

(5009,'Pakistan','PK','Mansehra','HRA'),

(5010,'USA','US','Mansfield~ OH','MFD'),

(5011,'New Zealand','NZ','Mansion House','KWU'),

(5012,'United Kingdom','GB','Manston~ England','MSE'),

(5013,'Ecuador','EC','Manta','MEC'),

(5014,'USA','US','Manteo~ NC','MEO'),

(5015,'USA','US','Manti~ UT','NTJ'),

(5016,'Papua New Guinea','PG','Manumu','UUU'),

(5017,'Papua New Guinea','PG','Manus Island','MAS'),

(5018,'USA','US','Manville~ NJ','JVI'),

(5019,'Mexico','MX','Manzanillo','ZLO'),

(5020,'Cuba','CU','Manzanillo','MZO'),

(5021,'Swaziland','SZ','Manzini','MTS'),

(5022,'Chad','TD','Mao','AMO'),

(5023,'Western Samoa','EH','Maota','MXS'),

(5024,'Canada','CA','Maple Bay~ BC','YAQ'),

(5025,'Papua New Guinea','PG','Mapoda','MPF'),

(5026,'Papua New Guinea','PG','Mapua','MPU'),

(5027,'Mozambique','MZ','Maputo','MPM'),

(5028,'Argentina','AR','Maquinchao','MQD'),

(5029,'USA','US','Maquoketa~ IA','OQW'),

(5030,'Argentina','AR','Mar del Plata','MDQ'),

(5031,'Kenya','KE','Mara Lodges','MRE'),

(5032,'Brazil','BR','Maraba~ PA','MAB'),

(5033,'Venezuela','VE','Maracaibo','MAR'),

(5034,'Venezuela','VE','Maracay','MYC'),

(5035,'Niger','NE','Maradi','MFQ'),

(5036,'Kiribati','KI','Marakei','MZK'),

(5037,'Papua New Guinea','PG','Maramuni','MWI'),

(5038,'USA','US','Marana~ AZ','MZJ'),

(5039,'USA','US','Marathon~ FL','MTH'),

(5040,'Canada','CA','Marathon~ ON','YSP'),

(5041,'Solomon Islands','SB','Marau','RUS'),

(5042,'Papua New Guinea','PG','Marawaka','MWG'),

(5043,'Spain','ES','Marbella','QRL'),

(5044,'Australia','AU','Marble Bar~ Western Australia','MBB'),

(5045,'USA','US','Marble Canyon~ AZ','MYH'),

(5046,'Honduras','HN','Marcala','MRJ'),

(5047,'USA','US','Marco Island~ FL','MRK'),

(5048,'Japan','JP','Marcus Islands','MUS'),

(5049,'New Caledonia','NC','Mare~ Loyalty Islands','MEE'),

(5050,'Yemen','YE','Mareb','MYN'),

(5051,'Australia','AU','Mareeba~ Queensland','HRJ'),

(5053,'USA','US','Marfa~ TX','MRF'),

(5054,'Australia','AU','Margaret River~ Western Australi','MGV'),

(5055,'Papua New Guinea','PG','Margarina','MGG'),

(5056,'Venezuela','VE','Margarita Island','MRX'),

(5057,'South Africa','ZA','Margate','MGH'),

(5058,'Venezuela','VE','Margarita porlamar ','PMV'),

(5059,'USA','US','Marguerite Bay~ AK','RTE'),

(5060,'Czech Republic','CZ','Marianske Lazne','MKA'),

(5061,'Slovenia','SI','Maribor','MBX'),

(5062,'Guadeloupe','GP','Marie Galante','GBJ'),

(5063,'Finland','FI','Mariehamn (Maarianhamina)','MHQ'),

(5064,'USA','US','Marietta~ GA','NCQ'),

(5067,'Brazil','BR','Marilia~ SP','MII'),

(5068,'Italy','IT','Marina di Massa','QMM'),

(5069,'Philippines','PH','Marinduque','MRQ'),

(5070,'Brazil','BR','Maringa~ PR','MGF'),

(5071,'Australia','AU','Marion Downs~ Queensland','MXD'),

(5072,'USA','US','Marion~ IL','MWA'),

(5073,'USA','US','Marion~ IN','MZZ'),

(5074,'USA','US','Marion~ OH','MNN'),

(5075,'Suriname','SR','Maripasoula','MPY'),

(5076,'Colombia','CO','Mariquita','MQU'),

(5077,'Paraguay','PY','Mariscal Estigarribia','ESG'),

(5078,'Ukraine','UA','Mariupol (Zhdanov)~ Donets\'k','MPW'),

(5079,'USA','US','Marks~ MS','MMS'),

(5080,'Australia','AU','Marla~ South Australia','MRP'),

(5081,'USA','US','Marlborough~ MA','MXG'),

(5082,'Oman','OM','Marmul','OMM'),

(5083,'Madagascar','MG','Maroantsetra','WMN'),

(5084,'Papua New Guinea','PG','Maron','MNP'),

(5085,'Australia','AU','Maroochydore (Sunshine Coast)~ Q','MCY'),

(5086,'Cameroon','CM','Maroua','MVR'),

(5087,'Australia','AU','Marqua~ Northern Territory','MQE'),

(5088,'USA','US','Marquette~ MI','MQT'),

(5089,'Morocco','MA','Marrakech','RAK'),

(5090,'Australia','AU','Marree~ South Australia','RRE'),

(5091,'Mozambique','MZ','Marromeu','RRM'),

(5092,'Libya','LY','Marsa Brega','LMQ'),

(5093,'Egypt','EG','Marsa Matrum (Mersa Matruh)','MUH'),

(5094,'Kenya','KE','Marsabit','RBT'),

(5095,'France','FR','Marseille','MRS'),

(5096,'Bahamas','BS','Marsh Harbour~ Abaco','MHH'),

(5097,'USA','US','Marshall~ AK','MLL'),

(5098,'USA','US','Marshall~ MN','MML'),

(5099,'USA','US','Marshall~ MO','MHL'),

(5100,'USA','US','Marshall~ TX','ASL'),

(5101,'USA','US','Marshalltown~ IA','MIW'),

(5102,'USA','US','Marshfield~ WI','MFI'),

(5103,'MA USA','US','Martha\'s Vineyard (Vineyard Have','MVY'),

(5104,'WV USA','US','Martinsburg','MRB'),

(5105,'Malaysia','MY','Marudi~ Sarawak','MUR'),

(5106,'Canada','CA','Mary\'s Harbour~ NF','YMH'),

(5107,'Turkmenistan','TM','Mary~ Mary','MYP'),

(5108,'Australia','AU','Maryborough~ Queensland','MBH'),

(5109,'USA','US','Marysville~ CA','BAB'),

(5111,'USA','US','Maryville~ MO','EVU'),

(5112,'Papua New Guinea','PG','Masa','MBV'),

(5113,'Israel','IL','Masada','MTZ'),

(5114,'Indonesia','ID','Masalembo','MSI'),

(5115,'Indonesia','ID','Masamba','MXB'),

(5116,'Tanzania','TZ','Masasi','XMI'),

(5117,'Philippines','PH','Masbate','MBT'),

(5118,'Algeria','DZ','Mascara','MUW'),

(5119,'Lesotho','LS','Maseru','MSU'),

(5120,'Iran','IR','Mashad','MHD'),

(5121,'Zaire','ZR','Masi Manimba','MSM'),

(5122,'Uganda','UG','Masindi','KCU'),

(5123,'Oman','OM','Masirah','MSH'),

(5124,'USA','US','Mason City~ IA','MCW'),

(5125,'Eritrea','ER','Massawa','MSW'),

(5126,'USA','US','Massena~ NY','MSS'),

(5127,'Congo','CG','Massendjo','MSX'),

(5128,'Canada','CA','Massett~ BC','ZMT'),

(5129,'New Zealand','NZ','Masterton','MRO'),

(5130,'Bahamas','BS','Mastic Point','MSK'),

(5131,'Zimbabwe','ZW','Masvingo','FTV'),

(5133,'Zaire','ZR','Matadi','MAT'),

(5134,'Canada','CA','Matagami~ QC','YNM'),

(5135,'USA','US','Matagorda~ TX','MGI'),

(5136,'French Polynesia','PF','Mataiva','MVT'),

(5137,'Indonesia','ID','Matak','MWK'),

(5138,'Senegal','SN','Matam','MAX'),

(5139,'New Zealand','NZ','Matamata','MTA'),

(5140,'Mexico','MX','Matamoros','MAM'),

(5141,'Canada','CA','Matane~ QC','YME'),

(5142,'Cuba','CU','Matanzas','QMA'),

(5143,'Indonesia','ID','Mataram','AMI'),

(5144,'Philippines','PH','Mati','MXI'),

(5145,'Brazil','BR','Mato Grosso~ MG','MTG'),

(5146,'Lesotho','LS','Matsaile','MSG'),

(5147,'Japan','JP','Matsumoto','MMJ'),

(5148,'Japan','JP','Matsuyama~ Skikoku','MYJ'),

(5149,'Guyana','GY','Matthews Ridge','MWJ'),

(5150,'USA','US','Mattoon/Charleston~ IL','MTO'),

(5151,'Brazil','BR','Matupa','MBK'),

(5152,'Venezuela','VE','Maturin','MUN'),

(5153,'Cook Islands','CK','Mauke','MUK'),

(5154,'Myanmar','MM','Maulmyine (Moulmein)','MNU'),

(5155,'Indonesia','ID','Maumere','MOF'),

(5156,'Botswana','BW','Maun','MUB'),

(5157,'French Polynesia','PF','Maupiti~ Society Islands','MAU'),

(5158,'Mauritius','MU','Mauritius','MRU'),

(5159,'Brazil','BR','Maves','MBZ'),

(5160,'USA','US','Maxton~ NC','MXE'),

(5161,'USA','US','May Creek~ AK','MYK'),

(5162,'Papua New Guinea','PG','May River','MRH'),

(5163,'Bahamas','BS','Mayaguana~ Mayaguana','MYG'),

(5164,'Puerto Rico','PR','Mayaguez','MAZ'),

(5165,'Cuba','CU','Mayajiqua','MJG'),

(5166,'Yemen','YE','Mayfaah','MFY'),

(5167,'Canada','CA','Mayo~ YT','YMA'),

(5168,'Gabon','GA','Mayoumba','MYB'),

(5169,'USA','US','Mayport~ FL','NRB'),

(5170,'Afghanistan','AF','Mazar i Sharif','MZR'),

(5171,'Mexico','MX','Mazatlan','MZT'),

(5172,'Swaziland','SZ','Mbabane','QMN'),

(5173,'Solomon Islands','SB','Mbambanakira','MBU'),

(5174,'Zaire','ZR','Mbandaka','MDK'),

(5175,'Uganda','UG','Mbarara','MBQ'),

(5176,'Tanzania','TZ','Mbeya','MBI'),

(5177,'Gabon','GA','Mbigou','MBC'),

(5178,'Central African Republic','CF','Mboki','MKI'),

(5179,'Mauritania','MR','Mbout','MBR'),

(5180,'Zaire','ZR','Mbuji-Mayi','MJM'),

(5181,'USA','US','McAlester~ OK','MLC'),

(5182,'USA','US','McAllen~ TX','MFE'),

(5183,'Australia','AU','McArthur River~ Northern Territo','MCV'),

(5184,'USA','US','McCall~ ID','MYL'),

(5185,'USA','US','McCarthy~ AK','MXY'),

(5186,'USA','US','McComb~ MS','MCB'),

(5187,'USA','US','McCook~ NE','MCK'),

(5188,'USA','US','McCord~ AK','KMC'),

(5189,'USA','US','McGrath~ AK','MCG'),

(5190,'USA','US','McKinley Park~ AK','MCL'),

(5191,'USA','US','McMinnville~ OR','MMV'),

(5192,'USA','US','McMinnville~ TN','RNC'),

(5193,'USA','US','McPherson~ KS','MPR'),

(5194,'USA','US','McRae~ GA','MQW'),

(5195,'Canada','CA','Meadow Lake~ SK','YLJ'),

(5196,'USA','US','Meadville~ PA','MEJ'),

(5197,'Indonesia','ID','Medan','MES'),

(5198,'Colombia','CO','Medellin','MDE'),

(5200,'USA','US','Medford~ OR','MFR'),

(5201,'USA','US','Medford~ WI','MDF'),

(5202,'USA','US','Medfra~ AK','MDR'),

(5203,'Canada','CA','Medicine Hat~ AB','YXH'),

(5204,'Saudi Arabia','SA','Medina (Madinah)','MED'),

(5205,'USA','US','Medina~ CA','MND'),

(5206,'Gabon','GA','Medouneu','MDV'),

(5207,'Australia','AU','Meekatharra~ Western Australia','MKR'),

(5208,'France','FR','Megeve','MVV'),

(5209,'Nepal','NP','Meghauli','MEY'),

(5210,'Norway','NO','Mehamn','MEH'),

(5211,'China','CN','Meixian','MXZ'),

(5212,'Palau','PW','Mejit Island','MJB'),

(5213,'Gabon','GA','Mekambo','MKB'),

(5214,'Ethiopia','ET','Mekane Salem','MKS'),

(5215,'Morocco','MA','Meknes','MEK'),

(5216,'USA','US','Mekoryuk~ AK','MYU'),

(5217,'Indonesia','ID','Melangguane','MNA'),

(5218,'USA','US','Melbourne~ FL','MLB'),

(5219,'Australia','AU','Melbourne~ Victoria','MEB'),

(5222,'Guatemala','GT','Melchor de Mencos','MCR'),

(5223,'USA','US','Melfa~ VA','MFV'),

(5224,'Chad','TD','Melfi','MEF'),

(5225,'Morocco','MA','Spanish Morocco Melilla','MLN'),

(5226,'Belize','BZ','Melinda','MDB'),

(5227,'Uruguay','UY','Melo','MLZ'),

(5228,'Japan','JP','Memanbetsu','MMB'),

(5229,'USA','US','Memphis~ TN','MEM'),

(5230,'Ethiopia','ET','Mena','MZX'),

(5231,'France','FR','Mende','MEN'),

(5232,'Ecuador','EC','Mendez','MZD'),

(5233,'Ethiopia','ET','Mendi','NDM'),

(5234,'Papua New Guinea','PG','Mendi','MDU'),

(5235,'Argentina','AR','Mendoza','MDZ'),

(5236,'USA','US','Menominee~ MI','MNM'),

(5237,'Angola','AO','Menongue','SPP'),

(5238,'Indonesia','ID','Merauke','MKQ'),

(5239,'USA','US','Merced~ CA','MER'),

(5241,'Argentina','AR','Mercedes','MDX'),

(5242,'USA','US','Mercury~ NV','DRA'),

(5243,'Indonesia','ID','Merdey','RDE'),

(5244,'France','FR','Meribel','MFX'),

(5245,'Mexico','MX','Merida','MID'),

(5246,'Venezuela','VE','Merida','MRD'),

(5247,'USA','US','Meridian~ MS','MEI'),

(5249,'MS USA','US','Meridian','JYD'),

(5250,'Australia','AU','Merimbula~ New South Wales','MIM'),

(5251,'Australia','AU','Merluna~ Queensland','MLV'),

(5252,'Sudan','SD','Merowe','MWE'),

(5253,'USA','US','Merrill~ WI','RRL'),

(5254,'Canada','CA','Merritt~ BC','YMB'),

(5255,'Canada','CA','Merry Island~ BC','YMR'),

(5256,'Malaysia','MY','Mersing','MEP'),

(5257,'Australia','AU','Merty~ South Australia','RTY'),

(5258,'France','FR','Merville/Calonne','FQT'),

(5259,'Turkey','TR','Merzifon','MZH'),

(5260,'USA','US','Mesa~ AZ','MSC'),

(5261,'USA','US','Mesquite~ TX','HQZ'),

(5262,'Italy','IT','Messina','QME'),

(5263,'South Africa','ZA','Messina','MEZ'),

(5264,'Ethiopia','ET','Metekel','MKD'),

(5265,'USA','US','Metlakatla~ AK','MTM'),

(5267,'USA','US','Metter~ GA','MHP'),

(5268,'France','FR','Metz','MZM'),

(5269,'France','FR','Metz/Nancy','ETZ'),

(5270,'Indonesia','ID','Meulaboh','MEQ'),

(5271,'Gabon','GA','Mevang','MVG'),

(5272,'Mexico','MX','Mexicali','MXL'),

(5273,'USA','US','Meyers Chuck~ AK','WMK'),

(5274,'Zambia','ZM','Mfuwe','MFU'),

(5275,'USA','US','Miami~ FL','MPB'),

(5281,'USA','US','Miami~ OK','MIO'),

(5282,'USA','US','Miami/Fort Lauderdale/West Palm ','MFW'),

(5283,'Madagascar','MG','Miandrivazo','ZVA'),

(5284,'Pakistan','PK','Mianwali','MWD'),

(5285,'USA','US','Michigan City~ IN','MGC'),

(5286,'Turks & Caicos','TC','Middle Caicos','MDS'),

(5287,'Australia','AU','Middlemount~ Queensland','MMM'),

(5288,'USA','US','Middleton Island~ AK','MDO'),

(5289,'USA','US','Middletown~ OH','MWO'),

(5290,'Canada','CA','Midland~ ON','YEE'),

(5291,'USA','US','Midland~ TX','MDD'),

(5292,'USA','US','Midland/Odessa~ TX','MAF'),

(5293,'USA','US','middway Islands','MDY'),

(5294,'Gabon','GA','Miele Mimbale','GIM'),

(5295,'Finland','FI','Mikkeli','MIK'),

(5296,'Greece','GR','Mikonos','JMK'),

(5297,'Italy','IT','Milano (Milan)','LIN'),

(5300,'Italy','IT','Milano','SWK'),

(5301,'United Kingdom','GB','Mildenhall~ England','GXH'),

(5302,'United Kingdom','GB','Mildenhall','MHZ'),

(5303,'Australia','AU','Mildura~ Victoria','MQL'),

(5304,'USA','US','Miles City~ MT','MLS'),

(5305,'New Zealand','NZ','Milford Sound','MFN'),

(5306,'USA','US','Milford~ UT','MLF'),

(5307,'Marshall Islands','MH','Mili Island','MIJ'),

(5308,'USA','US','Milledgeville~ GA','MLJ'),

(5309,'Australia','AU','Millicent~ South Australia','MLR'),

(5310,'Australia','AU','Millingimbi~ Northern Territory','MGT'),

(5311,'USA','US','Millington~ TN','NQA'),

(5312,'USA','US','Millinocket~ ME','MLT'),

(5313,'USA','US','Millville~ NJ','MIV'),

(5314,'Greece','GR','Milos','MLO'),

(5315,'United Kingdom','GB','Milton Keynes','KYN'),

(5316,'USA','US','Milton~ FL','NFJ'),

(5318,'USA','US','Milwaukee~ WI','MKE'),

(5320,'Brazil','BR','Minacu','MQH'),

(5321,'Canada','CA','Minaki~ ON','YMI'),

(5322,'Australia','AU','Minalton~ South Australia','XML'),

(5323,'Japan','JP','Minami Daito Jima~ Okinawa','MMD'),

(5324,'Mexico','MX','Minatitlan','MTT'),

(5325,'USA','US','Minchumina~ AK','MHM'),

(5326,'USA','US','Minden~ NV','MEV'),

(5327,'Papua New Guinea','PG','Mindik','MXK'),

(5328,'Indonesia','ID','Mindiptana','MDP'),

(5329,'USA','US','Mineral Wells~ TX','CWO'),

(5331,'Russia','RU','Mineralniye Vody~ Stavropol','MRV'),

(5332,'Canada','CA','Miners Bay~ BC','YAV'),

(5333,'Australia','AU','Miners Lake','MRL'),

(5334,'Canada','CA','Mingan~ QC','YLP'),

(5335,'Papua New Guinea','PG','Minj','MZN'),

(5336,'Nigeria','NG','Minna','MXJ'),

(5337,'USA','US','Minneapolis~ MN','MIC'),

(5340,'MN USA','US','Minneapolis/St. Paul','MSP'),

(5341,'Sri Lanka','LK','Minneriya','MNH'),

(5342,'Australia','AU','Minnipa~ South Australia','MIN'),

(5343,'WI USA','US','Minocqua/Woodruff','ARV'),

(5344,'USA','US','Minot~ ND','MIB'),

(5346,'Belarus','BY','Minsk~ Minsk','MSQ'),

(5347,'USA','US','Minto~ AK','MNT'),

(5348,'Gabon','GA','Minvoul','MVX'),

(5349,'St. Pierre & Miquelon','PM','Miquelon','MQC'),

(5350,'Brazil','BR','Miracema do Norte~ GO','NTM'),

(5351,'Colombia','CO','Miraflores','MFS'),

(5352,'Argentina','AR','Miramar','MJR'),

(5353,'Australia','AU','Miranda Downs~ Queensland','MWY'),

(5354,'Ukraine','UA','Mirgorod~ Poltava','MXR'),

(5355,'Malaysia','MY','Miri~ Sarawak','MYY'),

(5356,'Colombia','CO','Miriti','MIX'),

(5357,'Russia','RU','Mirnyy~ Yakutia-Sakha','MJZ'),

(5358,'Pakistan','PK','Mirpur Khas','MPD'),

(5359,'Pakistan','PK','Mirpur','QML'),

(5360,'Japan','JP','Misawa','MSJ'),

(5361,'Papua New Guinea','PG','Misima','MIS'),

(5362,'Hungary','HU','Miskolc','MCQ'),

(5363,'USA','US','Missoula~ MT','MSO'),

(5364,'Libya','LY','Misurata','MRA'),

(5365,'Australia','AU','Mitchell Plateau','MIH'),

(5366,'Australia','AU','Mitchell River','MXQ'),

(5367,'Australia','AU','Mitchell~ Queensland','MTQ'),

(5368,'USA','US','Mitchell~ SD','MHE'),

(5369,'Cook Islands','CK','Mitiaro','MOI'),

(5370,'Israel','IL','Mitspeh Ramona','MIP'),

(5371,'Colombia','CO','Mitu','MVP'),

(5372,'Gabon','GA','Mitzic','MZC'),

(5373,'Japan','JP','Miyake Jima','MYE'),

(5374,'Japan','JP','Miyako Jima~ Ryuku','MMY'),

(5375,'Papua New Guinea','PG','Miyanmin','MPX'),

(5376,'Japan','JP','Miyazaki','KMI'),

(5377,'Ethiopia','ET','Mizan Teferi','MTF'),

(5378,'South Africa','ZA','Mkambati','MBM'),

(5379,'South Africa','ZA','Mkuze','MZQ'),

(5380,'South Africa','ZA','Mmabatho~ Bophuthatswana','MBD'),

(5381,'Norway','NO','Mo i Rana','MQN'),

(5382,'Cuba','CU','Moa','MOA'),

(5383,'USA','US','Moab~ UT','CNY'),

(5384,'Gabon','GA','Moabi','MGX'),

(5385,'Fiji','FJ','Moala','MFJ'),

(5386,'Indonesia','ID','Moanamani','ONI'),

(5387,'Gabon','GA','Moanda','MFF'),

(5388,'Zaire','ZR','Moanda','MNB'),

(5389,'Zaire','ZR','Moba','BDV'),

(5390,'USA','US','Moberly~ MO','MBY'),

(5391,'USA','US','Mobile~ AL','MOB'),

(5393,'USA','US','Mobridge~ SD','MBG'),

(5394,'Mozambique','MZ','Mocimboa da Praia','MZB'),

(5395,'Brazil','BR','Mococa~ SP','QOA'),

(5396,'USA','US','Modesto~ CA','MOD'),

(5397,'Germany','DE','Moenchengladbach (Monchengladbac','MGL'),

(5398,'Pakistan','PK','Moenjodaro (Mohenjo Daro)','MJD'),

(5399,'Somalia','SO','Mogadishu (Mogadiscio)','MGQ'),

(5400,'Brazil','BR','Mogi das Crazes~ SP','QMI'),

(5401,'India','IN','Mohanbari','MOH'),

(5402,'Comoros','KM','Moheli','NWA'),

(5403,'USA','US','Mojave~ CA','MHV'),

(5404,'Lesotho','LS','Mokhotlong','MKH'),

(5405,'Papua New Guinea','PG','Moki','MJJ'),

(5406,'South Korea','KR','Mokpo','MPK'),

(5407,'USA','US','Mokuleia~ HI','HDH'),

(5408,'Namibia','LC','Mokuti','OKU'),

(5409,'Norway','NO','Molde','MOL'),

(5410,'USA','US','Moline~ IL','MLI'),

(5411,'USA','US','Molokai/Hoolehua (Kaunakakai)~ H','MKK'),

(5412,'Mozambique','MZ','Moma','MMW'),

(5413,'Kenya','KE','Mombasa','MBA'),

(5414,'Myanmar','MM','Momeik','MOE'),

(5415,'Colombia','CO','Mompus','MMP'),

(5416,'USA','US','Monahans~ TX','MIF'),

(5417,'Tunisia','TN','Monastir','MIR'),

(5418,'Japan','JP','Monbetsu','MBE'),

(5419,'Mexico','MX','Monclova','LOV'),

(5420,'Canada','CA','Moncton~ NB','YQM'),

(5421,'Colombia','CO','Monfort','MFB'),

(5422,'Myanmar','MM','Monghsat','MOG'),

(5423,'Chad','TD','Mongo','MVO'),

(5424,'Zambia','ZM','Mongu','MNR'),

(5425,'Malawi','MW','Monkey Island','MYZ'),

(5426,'Australia','AU','Monkey Mia~ Western Australia','MJK'),

(5427,'Guyana','GY','Monkey Mountain','MYM'),

(5428,'Australia','AU','Monkira~ Queensland','ONR'),

(5429,'Solomon Islands','SB','Mono','MNY'),

(5430,'USA','US','Monroe~ LA','MLU'),

(5431,'USA','US','Monroe~ NC','EQY'),

(5432,'USA','US','Monroeville~ AL','MVC'),

(5433,'Liberia','LR','Monrovia','ROB'),

(5435,'Belgium','BE','Mons','QMO'),

(5436,'Canada','CA','Mont-Joli~ QC','YYY'),

(5437,'Canada','CA','Montague Harbor~ BC','YMF'),

(5438,'USA','US','Montague~ CA','SIY'),

(5439,'USA','US','Montauk~ NY','MTP'),

(5440,'Brazil','BR','Monte Alegre~ PA','MTE'),

(5441,'Monaco','MC','Monte Carlo','MCM'),

(5442,'Brazil','BR','Monte Dourado','MEU'),

(5443,'Colombia','CO','Monte Libano','MTB'),

(5444,'Jamaica','JM','Montego Bay','MBJ'),

(5445,'Brazil','BR','Montenegro~ RS','QGF'),

(5446,'Mozambique','MZ','Montepuez','MTU'),

(5447,'USA','US','Monterey~ CA','MRY'),

(5448,'Colombia','CO','Monteria','MTR'),

(5449,'Mexico','MX','Monterrey','MTY'),

(5451,'Colombia','CO','Monterrey','MOY'),

(5452,'Argentina','AR','Montes Caseros','MCS'),

(5453,'Brazil','BR','Montes Claros~ MG','MOC'),

(5454,'Uruguay','UY','Montevideo','MVD'),

(5455,'USA','US','Montevideo~ MN','MVE'),

(5456,'USA','US','Montgomery~ AL','MGM'),

(5459,'AL USA','US','Montgomery','DMF'),

(5460,'USA','US','Montgomery~ NY','MGJ'),

(5461,'USA','US','Monticello~ IA','MXO'),

(5462,'USA','US','Monticello~ KY','EKQ'),

(5463,'USA','US','Monticello~ NY','MSV'),

(5464,'USA','US','Monticello~ UT','MXC'),

(5465,'France','FR','Montlucon','MCU'),

(5466,'Australia','AU','Monto~ Queensland','MNQ'),

(5467,'France','FR','Montpellier','MPL'),

(5468,'Canada','CA','Montreal~ QC','YUL'),

(5473,'Switzerland','CH','Montreux','ZJP'),

(5474,'USA','US','Montrose~ CO','MTJ'),

(5475,'Montserrat','GB','Montserrat (Plymouth)','MNI'),

(5476,'Australia','AU','Moolawatana~ South Australia','MWT'),

(5477,'Australia','AU','Moomba','MOO'),

(5478,'Australia','AU','Moorabbin~ Victoria','MBW'),

(5479,'Australia','AU','Mooraberrie~ Queensland','OOR'),

(5480,'French Polynesia','PF','Moorea~ Society Islands','MOZ'),

(5481,'Canada','CA','Moose Jaw~ SK','YMJ'),

(5482,'Canada','CA','Moosonee~ ON','YMO'),

(5483,'Mali','ML','Mopti','MZI'),

(5484,'Sweden','SE','Mora','MXX'),

(5485,'Madagascar','MG','Morafenobe','TVA'),

(5486,'Australia','AU','Moranbah~ Queensland','MOV'),

(5487,'Australia','AU','Morawa~ Western Australia','MWB'),

(5488,'Australia','AU','Mordak','MRT'),

(5489,'Australia','AU','Moree~ New South Wales','MRZ'),

(5490,'Papua New Guinea','PG','Morehead','MHY'),

(5491,'Mexico','MX','Morelia','MLM'),

(5492,'Australia','AU','Moreton~ Queensland','MET'),

(5493,'USA','US','Morganton~ NC','MRN'),

(5494,'WV USA','US','Morgantown','MGW'),

(5495,'Colombia','CO','Morichal','MHF'),

(5496,'Japan','JP','Morioka','HNA'),

(5498,'France','FR','Morlaix','MXN'),

(5499,'Australia','AU','Morney Plains~ Queensland','OXY'),

(5500,'Australia','AU','Mornington Island~ Queensland','ONG'),

(5501,'Papua New Guinea','PG','Morobe','OBM'),

(5502,'Madagascar','MG','Morombe','MXM'),

(5503,'Spain','ES','Moron de la Frontera','OZP'),

(5504,'Madagascar','MG','Morondava','MOQ'),

(5505,'Comoros','KM','Moroni','YVA'),

(5507,'Indonesia','ID','Morotai Island','OTI'),

(5508,'USA','US','Morrilton~ AR','MPJ'),

(5509,'USA','US','Morris~ MN','MOX'),

(5510,'USA','US','Morristown~ NJ','MMU'),

(5511,'USA','US','Morristown~ TN','MOR'),

(5512,'USA','US','Morrisville/Stowe~ VT','MVL'),

(5513,'Australia','AU','Moruya~ New South Wales','MYA'),

(5514,'Russia','RU','Moscow (Moskva)~ Moscow','BKA'),

(5519,'USA','US','Moscow~ MS','NJW'),

(5520,'USA','US','Moser Bay~ AK','KMY'),

(5521,'USA','US','Moses Lake~ WA','MWH'),

(5523,'Tanzania','TZ','Moshi','QSI'),

(5524,'Norway','NO','Mosjoen','MJF'),

(5525,'Colombia','CO','Mosquera','MQR'),

(5526,'Bahamas','BS','Moss Town~ Exuma','MWX'),

(5527,'South Africa','ZA','Mossel Bay','MZY'),

(5528,'Brazil','BR','Mossoro~ RN','MVF'),

(5529,'Bosnia-Herzegovina','BA','Mostar','OMO'),

(5530,'Cape Verde','CV','Mosteiros','MTI'),

(5531,'Malaysia','MY','Mostyn','MZS'),

(5532,'Iraq','IQ','Mosul','OSM'),

(5533,'Vanuatu','VU','Mota Lava','MTV'),

(5534,'New Zealand','NZ','Motueka','MZP'),

(5535,'Mauritania','MR','Moudjeria','MOM'),

(5536,'Papua New Guinea','PG','Mougulu','GUV'),

(5537,'Gabon','GA','Mouila','MJL'),

(5538,'Canada','CA','Mould Bay~ NT','YMD'),

(5539,'USA','US','Moultrie~ GA','MGR'),

(5541,'Chad','TD','Moundou','MQQ'),

(5542,'Papua New Guinea','PG','Mount Aue','UAE'),

(5543,'Australia','AU','Mount Barnett~ Western Australia','MBN'),

(5544,'USA','US','Mount Carmel~ IL','AJG'),

(5545,'USA','US','Mount Clemens~ MI','NFB'),

(5547,'New Zealand','NZ','Mount Cook','GTN'),

(5549,'Australia','AU','Mount Gambier~ South Australia','MGB'),

(5550,'Australia','AU','Mount Gunson~ South Australia','GSN'),

(5551,'USA','US','Mount Holly~ NJ','LLY'),

(5552,'Australia','AU','Mount Hotham~ Victoria','MHU'),

(5553,'Australia','AU','Mount Isa~ Queensland','ISA'),

(5554,'Australia','AU','Mount Magnet~ Western Australia','MMG'),

(5555,'Falkland Islands','FK','Mount Pleasant','MPN'),

(5556,'USA','US','Mount Pleasant~ IA','MPZ'),

(5557,'USA','US','Mount Pleasant~ MI','MOP'),

(5558,'USA','US','Mount Pleasant~ TX','MPS'),

(5559,'USA','US','Mount Pleasant~ UT','MSD'),

(5560,'USA','US','Mount Pocono~ PA','MPO'),

(5561,'USA','US','Mount Shasta~ CA','MHS'),

(5562,'USA','US','Mount Union~ PA','MUU'),

(5563,'USA','US','Mount Vernon~ IL','MVN'),

(5564,'USA','US','Mount Vernon~ WA','MVW'),

(5565,'USA','US','Mount Wilson~ CA','MWS'),

(5566,'USA','US','Mountain Home~ AR','WMH'),

(5567,'USA','US','Mountain Home~ ID','MUO'),

(5568,'Australia','AU','Mountain Valley','MNV'),

(5569,'USA','US','Mountain View~ CA','NUQ'),

(5570,'USA','US','Mountain Village~ AK','MOU'),

(5571,'Nepal','NP','Mountain','MWP'),

(5572,'France','FR','Moutiers','QMU'),

(5573,'Congo','CG','Mouyondzi','MUY'),

(5574,'Ethiopia','ET','Moyale','MYS'),

(5575,'Kenya','KE','Moyale','OYL'),

(5576,'Uganda','UG','Moyo','OYG'),

(5577,'Peru','PE','Moyobamba','MBP'),

(5578,'Namibia','LC','Mpacha','MPA'),

(5579,'Australia','AU','Mt. Buffalo','MBF'),

(5580,'Australia','AU','Mt. Cavenagh~ Northern Territory','MKV'),

(5581,'Australia','AU','Mt. Full Stop','MFL'),

(5582,'Australia','AU','Mt. Goldworthy~ Western Australi','GLY'),

(5583,'Papua New Guinea','PG','Mt. Hagen','HGU'),

(5584,'Australia','AU','Mt. House~ Western Australia','MHO'),

(5585,'Australia','AU','Mt. Sanford~ Northern Territory','MTD'),

(5586,'Australia','AU','Mt. Swan~ Northern Territory','MSF'),

(5587,'Tanzania','TZ','Mtwara','MYW'),

(5588,'Australia','AU','Muccan~ Western Australia','MUQ'),

(5589,'Brazil','BR','Mucuri~ BA','MVS'),

(5590,'China','CN','Mudanjiang','MDG'),

(5591,'Australia','AU','Mudgee~ New South Wales','DGE'),

(5592,'Germany','DE','Muenchen (Munchen~Munich)','MUC'),

(5594,'Germany','DE','Muenster (Munster)','MSR'),

(5595,'Germany','DE','Muenster (Munster)/Osnabrueck (O','FMO'),

(5596,'New Caledonia','NC','Mueo','PDC'),

(5597,'Ethiopia','ET','Mui','MUJ'),

(5598,'Malaysia','MY','Mukah~ Sarawak','MKM'),

(5599,'Yemen','YE','Mukalla','MKX'),

(5600,'Yemen','YE','Mukeiras','UKR'),

(5601,'Indonesia','ID','Muko Muko','MPC'),

(5602,'Colombia','CO','Mulatos','ULS'),

(5603,'Mexico','MX','Mulege','MUG'),

(5604,'Australia','AU','Mulga Park~ Northern Territory','MUP'),

(5605,'France','FR','Mulhouse','MLH'),

(5606,'Indonesia','ID','Mulia','LII'),

(5607,'Australia','AU','Mulka~ South Australia','MVK'),

(5608,'United Kingdom','GB','Mull','ULL'),

(5609,'USA','US','Mullen~ NE','MHN'),

(5610,'Australia','AU','Mullewa~ Western Australia','MXU'),

(5611,'Pakistan','PK','Multan','MUX'),

(5612,'Malaysia','MY','Mulu','MZV'),

(5613,'Kenya','KE','Mumias','MUM'),

(5614,'Papua New Guinea','PG','Munbil','LNF'),

(5615,'USA','US','Muncie~ IN','MIE'),

(5616,'Solomon Islands','SB','Munda~ New Georgia Is.','MUA'),

(5617,'Papua New Guinea','PG','Munduku','MDM'),

(5618,'Australia','AU','Mungeranie~ South Australia','MNE'),

(5619,'Laos','LA','Muong Sai','UON'),

(5620,'Spain','ES','Murcia','MJV'),

(5621,'Brazil','BR','Muriae~ MG','QUR'),

(5622,'Russia','RU','Murmansk~ Murmansk','MMK'),

(5623,'Canada','CA','Murray Bay~ NT','YML'),

(5624,'Australia','AU','Murray Islands~ Queensland','MYI'),

(5625,'USA','US','Murray~ KY','CEY'),

(5626,'Oman','OM','Muscat','MCT'),

(5627,'USA','US','Muscatine~ IA','MUT'),

(5628,'USA','US','Muscle Shoals~ AL','MSL'),

(5629,'Australia','AU','Musgrave~ Queensland','MVU'),

(5630,'Djibouti','DJ','Musha','MHI'),

(5631,'USA','US','Muskegon~ MI','MKG'),

(5632,'USA','US','Muskogee~ OK','MKO'),

(5634,'Canada','CA','Muskoka~ ON','YQA'),

(5635,'Canada','CA','Muskrat Dam~ ON','MSA'),

(5636,'Tanzania','TZ','Musoma','MUZ'),

(5637,'Papua New Guinea','PG','Mussau','MWU'),

(5638,'St. Vincent and the Grenadines','VC','Mustique Island','MQS'),

(5639,'Zimbabwe','ZW','Mutare','UTA'),

(5640,'Indonesia','ID','Muting','MUF'),

(5641,'Australia','AU','Muttaburra~ Queensland','UTB'),

(5642,'Pakistan','PK','Muzaffarabad','MFG'),

(5643,'India','IN','Muzaffarnagar','MZA'),

(5644,'India','IN','Muzaffarpur','MZU'),

(5645,'Tanzania','TZ','Mwadui','MWN'),

(5646,'Tanzania','TZ','Mwanza','MWZ'),

(5647,'Zaire','ZR','Mweka','MEW'),

(5648,'Myanmar','MM','Myeik (Mergui)','MGZ'),

(5649,'Myanmar','MM','Myitkyina','MYT'),

(5650,'Ukraine','UA','Mykolayiv (Nikolayev)~ Mykolayiv','NLV'),

(5651,'Australia','AU','Myroodah','MYO'),

(5652,'USA','US','Myrtle Beach~ SC','MYR'),

(5653,'India','IN','Mysore','MYQ'),

(5654,'Greece','GR','Mytilene (Mitilini)~ Lesbos Isla','MJT'),

(5655,'Iceland','IS','Myvatn','MVA'),

(5656,'South Africa','ZA','Mzamba','MZF'),

(5657,'Malawi','MW','Mzuzu','ZZU'),

(5658,'Gabon','GA','N\'Dende','KDN'),

(5659,'Chad','TD','N\'Djamena','NDJ'),

(5660,'Gabon','GA','N\'Djole','KDJ'),

(5661,'Zambia','ZM','N\'Dola','NLA'),

(5662,'Cameroon','CM','N\'Gaoundere','NGE'),

(5663,'Cameroon','CM','N\'Kongsamba','NKS'),

(5664,'Angola','AO','N\'zeto','ARZ'),

(5665,'Guinea','GN','N Zerekore','NZE'),

(5666,'Russia','RU','Naberezhnyye Chelny~ Tatarstan','NBC'),

(5667,'Indonesia','ID','Nabire','NBX'),

(5668,'Mozambique','MZ','Nacala','MNC'),

(5669,'Tanzania','TZ','Nachingwea','NCH'),

(5670,'USA','US','Nacogdoches~ TX','OCH'),

(5671,'Fiji','FJ','Nadi','NAN'),

(5672,'Morocco','MA','Nador','NDR'),

(5673,'Russia','RU','Nadym~ Tyumen','NYM'),

(5674,'Philippines','PH','Naga','WNP'),

(5675,'Japan','JP','Nagano','QNG'),

(5676,'Japan','JP','Nagasaki','NGS'),

(5677,'Japan','JP','Nagoya~ Honshu','NGO'),

(5678,'India','IN','Nagpur','NAG'),

(5679,'Japan','JP','Naha','NHJ'),

(5680,'Japan','JP','Naha~ Okinawa','AHA'),

(5681,'Indonesia','ID','Naha~ Sangihe','NAH'),

(5682,'Canada','CA','Nain~ NF','YDP'),

(5683,'Kenya','KE','Nairobi','NBO'),

(5685,'Japan','JP','Nakashibetsu','SHB'),

(5686,'Thailand','TH','Nakhon Phanom','KOP'),

(5687,'Thailand','TH','Nakhon Ratchasima','NAK'),

(5688,'Thailand','TH','Nakhon Si Thammarat','NST'),

(5689,'Canada','CA','Nakina~ ON','YQN'),

(5690,'USA','US','Naknek~ AK','NNK'),

(5691,'Kenya','KE','Nakuru','NUU'),

(5692,'Russia','RU','Nalchik~ Kabardino-Balkaria','NAL'),

(5693,'Uzbekhistan','UZ','Namangan~ Namangan','NMA'),

(5694,'Papua New Guinea','PG','Namatanai','ATN'),

(5695,'Australia','AU','Nambour~ Queensland','NBR'),

(5696,'Australia','AU','Nambucca Heads~ New South Wales','NBH'),

(5697,'Angola','AO','Namibe','MSZ'),

(5698,'Indonesia','ID','Namlea','NAM'),

(5699,'Marshall Islands','MH','Namorik','NDK'),

(5700,'Mozambique','MZ','Nampula','APL'),

(5701,'Indonesia','ID','Namrole~ Buru Island','NRE'),

(5702,'Myanmar','MM','Namsang','NMS'),

(5703,'Norway','NO','Namsos','OSY'),

(5704,'Myanmar','MM','Namtu','NMT'),

(5705,'Canada','CA','Namu~ BC','ZNU'),

(5706,'Marshall Islands','MH','Namu','NMU'),

(5707,'Papua New Guinea','PG','Namudi','NDI'),

(5708,'Namibia','LC','Namutoni','NNI'),

(5709,'Thailand','TH','Nan','NNT'),

(5710,'Canada','CA','Nanaimo~ BC','YCD'),

(5712,'China','CN','Nanchang','KHN'),

(5713,'China','CN','Nanchong','NAO'),

(5714,'France','FR','Nancy','ENC'),

(5715,'India','IN','Nanded','NDC'),

(5716,'Mozambique','MZ','Nangade','NND'),

(5717,'Indonesia','ID','Nangapinoh','NPO'),

(5718,'Canada','CA','Nanisivik~ NT','YSR'),

(5719,'China','CN','Nanjing','NKG'),

(5720,'Japan','JP','Nanki Shirahana','SHM'),

(5721,'Papua New Guinea','PG','Nankina','NKN'),

(5722,'China','CN','Nanning','NNG'),

(5723,'Greenland','GL','Nanortalik','JNN'),

(5724,'France','FR','Nantes','NTE'),

(5725,'China','CN','Nantong','NTG'),

(5726,'USA','US','Nantucket~ MA','ACK'),

(5727,'Brazil','BR','Nanuque~ MG','NNU'),

(5728,'China','CN','Nanyang','NNY'),

(5729,'Kenya','KE','Nanyuki','NYK'),

(5730,'Papua New Guinea','PG','Naoro','NOO'),

(5731,'USA','US','Napa~ CA','APC'),

(5732,'USA','US','Napakiak~ AK','WNA'),

(5733,'USA','US','Napaskiak~ AK','PKA'),

(5734,'New Zealand','NZ','Napier/Hastings','NPE'),

(5735,'USA','US','Naples~ FL','APF'),

(5736,'Italy','IT','Napoli (Naples)','NAP'),

(5737,'Australia','AU','Nappa Merry~ Queensland','NMR'),

(5738,'Australia','AU','Napperby~ Northern Territory','NPP'),

(5739,'French Polynesia','PF','Napuka','NAU'),

(5740,'Mali','ML','Nara','NRM'),

(5741,'Australia','AU','Naracoorte~ South Australia','NAC'),

(5742,'Thailand','TH','Narathiwat','NAW'),

(5743,'Colombia','CO','Nare','NAR'),

(5744,'Panama','PA','Nargana','NGN'),

(5745,'Australia','AU','Narooma','QRX'),

(5746,'Australia','AU','Narrabri~ New South Wales','NAA'),

(5747,'Australia','AU','Narrandera~ New South Wales','NRA'),

(5748,'Australia','AU','Narrogin~ Western Australia','NRG'),

(5749,'Australia','AU','Narromine~ New South Wales','QRM'),

(5750,'Greenland','GL','Narssaq','JNS'),

(5751,'Greenland','GL','Narssarssuaq','UAK'),

(5752,'Papua New Guinea','PG','Narum','NRU'),

(5753,'Norway','NO','Narvik','NVK'),

(5754,'USA','US','Nashua~ NH','ASH'),

(5755,'USA','US','Nashville~ TN','JWN'),

(5757,'India','IN','Nasik','ISK'),

(5758,'Bahamas','BS','Nassau~ New Providence','NAS'),

(5760,'Fiji','FJ','Natadola','NTA'),

(5761,'Brazil','BR','Natal~ RN','NAT'),

(5762,'Canada','CA','Natashquan~ QC','YNA'),

(5763,'USA','US','Natchez~ MS','HEZ'),

(5764,'Benin','BJ','Natitingou','NAE'),

(5765,'Indonesia','ID','Natuna Ranai','NTX'),

(5766,'USA','US','Naukiti~ AK','NKI'),

(5767,'Nauru','NR','Nauru','INU'),

(5768,'Brazil','BR','Navegantes','NVT'),

(5769,'Pakistan','PK','Nawab Shah','WNS'),

(5770,'Greece','GR','Naxos','JNX'),

(5771,'Peru','PE','Nazca','NZA'),

(5772,'Central African Republic','CF','Ndele','NDL'),

(5773,'Argentina','AR','Necochea','NEC'),

(5774,'Colombia','CO','Necocli','NCI'),

(5775,'USA','US','Needles~ CA','EED'),

(5776,'Russia','RU','Nefteyugansk~ Tyumen','NFG'),

(5777,'Angola','AO','Negage','GXG'),

(5778,'Papua New Guinea','PG','Negarbo','GBF'),

(5779,'Canada','CA','Negginan~ MB','ZNG'),

(5780,'Ethiopia','ET','Neghelli','EGL'),

(5781,'Jamaica','JM','Negril','NEG'),

(5782,'Colombia','CO','Neiva','NVA'),

(5783,'Saudi Arabia','SA','Nejran','EAM'),

(5784,'Ethiopia','ET','Nekemete','NEK'),

(5785,'Ethiopia','ET','Nekempt','LKM'),

(5786,'USA','US','Nelson Lagoon~ AK','NLG'),

(5787,'Canada','CA','Nelson~ BC','ZNL'),

(5788,'New Zealand','NZ','Nelson','NSN'),

(5789,'South Africa','ZA','Nelspruit','NLP'),

(5790,'Mauritania','MR','Nema','EMN'),

(5791,'Canada','CA','Nemiscau~ QC','YNS'),

(5792,'USA','US','Nenana~ AK','ENN'),

(5793,'USA','US','Neosho~ MO','EOS'),

(5794,'Nepal','NP','Nepalganj','KEP'),

(5795,'USA','US','Nephi~ UT','NPH'),

(5796,'Russia','RU','Neryungri~ Yakutia-Sakha','NER'),

(5797,'Germany','DE','Neu Isenburg','QGV'),

(5798,'Germany','DE','Neumuenster','EUM'),

(5799,'Argentina','AR','Neuquen','NQN'),

(5800,'USA','US','Nevada~ MO','NVD'),

(5801,'France','FR','Neveras','NVS'),

(5802,'USA','US','New Bedford~ MA','EWB'),

(5803,'USA','US','New Bern~ NC','EWN'),

(5804,'USA','US','New Castle~ IN','UWL'),

(5805,'USA','US','New Chenega~ AK','NCN'),

(5806,'Sudan','SD','New Halfa','NHF'),

(5807,'USA','US','New Haven~ CT','HVN'),

(5808,'USA','US','New Iberia~ LA','ARA'),

(5809,'USA','US','New Madrid~ MO','EIW'),

(5810,'Australia','AU','New Moon~ Queensland','NMP'),

(5811,'USA','US','New Orleans~ LA (Moisant Field)]','MSY'),

(5812,'USA','US','New Orleans~ LA','NEW'),

(5813,'LA [New Orleans Naval Air Station] USA','US','New Orleans','NBG'),

(5814,'USA','US','New Philadelphia~ OH','PHD'),

(5815,'New Zealand','NZ','New Plymouth','NPL'),

(5816,'USA','US','New Richmond~ WI','RNH'),

(5817,'USA','US','New Stuyahok~ AK','KNW'),

(5818,'USA','US','New Ulm~ MN','ULM'),

(5819,'Egypt','EG','New Valley','UVL'),

(5820,'USA','US','New York (Flushing)~ NY','FLU'),

(5821,'USA','US','New York~ NY','TSS'),

(5827,'NY [Downtown Heliport] USA','US','New York','JWS'),

(5832,'USA','US','Newark~ NJ','EWR'),

(5833,'USA','US','Newberry~ MI','ERY'),

(5834,'USA','US','Newburgh~ NY','SWF'),

(5835,'UK','GB','Newbury~ England','EWY'),

(5836,'Australia','AU','Newcastle~ New South Wales','BEO'),

(5838,'South Africa','ZA','Newcastle','NCS'),

(5839,'United Kingdom','GB','Newcastle','NCL'),

(5840,'USA','US','Newcastle~ WY','ECS'),

(5841,'Australia','AU','Newman~ Western Australia','ZNE'),

(5842,'USA','US','Newport Beach~ CA','JNP'),

(5843,'VA USA','US','Newport News/Williamsburg','PHF'),

(5844,'USA','US','Newport~ NH','NWH'),

(5845,'USA','US','Newport~ OR','ONP'),

(5846,'USA','US','Newport~ RI','NPT'),

(5847,'USA','US','Newport~ VT','EFK'),

(5848,'United Kingdom','GB','Newquay','NQY'),

(5849,'Australia','AU','Newry~ Northern Territory','NRY'),

(5850,'USA','US','Newtok~ AK','EWU'),

(5852,'USA','US','Newton~ IA','TNU'),

(5853,'USA','US','Newton~ KS','EWK'),

(5854,'India','IN','Neyveli','NVY'),

(5855,'Fiji','FJ','Ngau','NGI'),

(5856,'Zambia','ZM','Ngoma','ZGM'),

(5857,'Australia','AU','Ngukurr~ Northern Territory','RPM'),

(5858,'Vietnam','VN','Nha-Trang','NHA'),

(5859,'Australia','AU','Nhulunbuy~ Northern Territory','GOV'),

(5860,'USA','US','Niagara Falls~ NY','IAG'),

(5861,'Niger','NE','Niamey','NIM'),

(5862,'Togo','TG','Niamtougou/Lama Kara','LRL'),

(5863,'USA','US','Niblack~ AK','NIE'),

(5864,'Cuba','CU','Nicaro','ICR'),

(5865,'France','FR','Nice','NCE'),

(5866,'USA','US','Nichen Cove~ AK','NKV'),

(5867,'Canada','CA','Nicholson Peninsula','YUC'),

(5868,'Australia','AU','Nicholson~ Western Australia','NLS'),

(5869,'Cyprus','CY','Nicosia','NMK'),

(5871,'Costa Rica','CR','Nicoya','NCT'),

(5872,'Suriname','SR','Nieuw Nickerie (New Nickerie)','ICK'),

(5873,'Australia','AU','Nifty~ Western Australia','NIF'),

(5874,'Papua New Guinea','PG','Nigerum','NGR'),

(5875,'USA','US','Nightmute~ AK','NME'),

(5876,'Japan','JP','Niigata~ Honshu','KIJ'),

(5877,'Japan','JP','Niihame','IHA'),

(5878,'USA','US','Nikolai~ AK','NIB'),

(5879,'USA','US','Nikolski~ AK','IKO'),

(5880,'Kiribati','KI','Nikunau','NIG'),

(5881,'USA','US','Niles~ MI','NLE'),

(5882,'Liberia','LR','Nimba','NIA'),

(5883,'France','FR','Nimes','FNI'),

(5884,'Afghanistan','AF','Nimroz','IMZ'),

(5885,'China','CN','Ningbo','NGB'),

(5886,'USA','US','Ninilchik~ AK','NIN'),

(5887,'Zaire','ZR','Nioki','NIO'),

(5888,'Senegal','SN','Niokolo Koba','NIK'),

(5889,'Mali','ML','Nioro','NIX'),

(5890,'France','FR','Niort','NII'),

(5892,'Papua New Guinea','PG','Nipa','NPG'),

(5893,'Canada','CA','Nipawin~ SK','YBU'),

(5894,'Brazil','BR','Niquelandia~ GO','NQL'),

(5895,'Yugoslavia','YU','Nis','INI'),

(5896,'Japan','JP','Nishinoomote','IIN'),

(5897,'Papua New Guinea','PG','Nissan Island','IIS'),

(5898,'Canada','CA','Nitchequon~ QC','YNI'),

(5899,'Brazil','BR','Niteroi~ RJ','QNT'),

(5900,'Western Samoa','EH','Niuafo\'ou','NFO'),

(5901,'Western Samoa','EH','Niuatoputapu','NTT'),

(5902,'Niue Island','NU','Niue Island','IUE'),

(5903,'Russia','RU','Nizhevartovsk~ Tyumen','NJC'),

(5904,'Russia','RU','Nizhniy Novgorod~ Nizhniy Novgor','GOJ'),

(5905,'Tanzania','TZ','Njombe','JOM'),

(5906,'Gabon','GA','Nkan','NKA'),

(5907,'Lesotho','LS','Nkaus','NKU'),

(5908,'Congo','CG','Nkayi','NKY'),

(5909,'Zaire','ZR','Nkolo','NKL'),

(5910,'USA','US','Noatak~ AK','WTK'),

(5911,'USA','US','Nogales~ AZ','OLS'),

(5912,'Mexico','MX','Nogales','NOG'),

(5913,'Russia','RU','Nojabrxsk','NOJ'),

(5914,'Papua New Guinea','PG','Nomad River','NOM'),

(5915,'USA','US','Nome~ AK','OME'),

(5916,'USA','US','Nondalton~ AK','NNL'),

(5917,'Kiribati','KI','Nonouti','NON'),

(5918,'Australia','AU','Noonkanbah~ Western Australia','NKB'),

(5919,'USA','US','Noorvik~ AK','ORV'),

(5920,'Australia','AU','Noosa~ Queensland','NSA'),

(5921,'Australia','AU','Noosaville~ Queensland','NSV'),

(5922,'Canada','CA','Nootka Sound~ BC','YNK'),

(5923,'USA','US','Nora~ AK','QAA'),

(5924,'Germany','DE','Norddeich','NOE'),

(5925,'Germany','DE','Norden','NOD'),

(5926,'Germany','DE','Norderney','NRD'),

(5927,'Iceland','IS','Nordfjordur','NOR'),

(5928,'Germany','DE','Nordholz','NDZ'),

(5929,'Australia','AU','Norfolk Island~ Norfolk Island','NLK'),

(5930,'USA','US','Norfolk~ NE','OFK'),

(5931,'USA','US','Norfolk~ VA','NGU'),

(5932,'VA USA','US','Norfolk/Virginia Beach/Williamsb','ORF'),

(5933,'Russia','RU','Noril\'sk (Noryl\'sk~Norylsk)~ Kra','NSK'),

(5934,'Bahamas','BS','Norman\'s Cay','NMC'),

(5935,'Canada','CA','Norman Wells~ NT','YVQ'),

(5936,'USA','US','Norman~ OK','OUN'),

(5937,'Australia','AU','Normanton~ Queensland','NTN'),

(5938,'USA','US','Norridgewock~ ME','OWK'),

(5939,'Sweden','SE','Norrkoping','NRK'),

(5940,'Australia','AU','Norseman~ Western Australia','NSM'),

(5941,'Vanuatu','VU','Norsup','NUS'),

(5942,'Canada','CA','North Battleford~ SK','YQW'),

(5943,'Canada','CA','North Bay~ ON','YYB'),

(5944,'USA','US','North Bend~ OR','OTH'),

(5945,'Turks & Caicos','TC','North Caicos','NCA'),

(5946,'Bahamas','BS','North Eleuthera~ Eleuthera','ELH'),

(5947,'USA','US','North Kingstown/Quonset Point~ R','NCO'),

(5948,'USA','US','North Myrtle Beach~ SC','CRE'),

(5949,'USA','US','North Platte~ NE','LBF'),

(5950,'United Kingdom','GB','North Ronaldsway','NRL'),

(5951,'Canada','CA','North Spirit Lake~ ON','YNO'),

(5952,'USA','US','North Vernon~ IN','OVO'),

(5953,'USA','US','North Wilkesboro~ NC','UKF'),

(5954,'USA','US','North~ SC','XNO'),

(5955,'England','GB','Northampton/Peterborough','ORM'),

(5956,'USA','US','Northbrook~ IL','OBK'),

(5957,'USA','US','Northeast Cape~ AK','OHC'),

(5958,'United Kingdom','GB','Northolt~ England','NHT'),

(5959,'USA','US','Northway~ AK','ORT'),

(5960,'USA','US','Norton~ KS','NRN'),

(5961,'USA','US','Norwalk~ CT','ORQ'),

(5962,'Canada','CA','Norway House~ MB','YNE'),

(5963,'USA','US','Norwich~ NY','OIC'),

(5964,'United Kingdom','GB','Norwich','NWI'),

(5965,'USA','US','Norwood~ MA','OWD'),

(5966,'Costa Rica','CR','Nosara Beach','NOB'),

(5967,'Madagascar','MG','Nossi-Be','NOS'),

(5968,'Norway','NO','Notodden','NTB'),

(5969,'Mauritania','MR','Nouadhibou','NDB'),

(5970,'Mauritania','MR','Nouakchott','NKC'),

(5971,'New Caledonia','NC','Noumea','NOU'),

(5973,'Burkina Faso','BF','Nounae','XNU'),

(5974,'Brazil','BR','Nova Iguacu~ RJ','QNV'),

(5975,'Guinea Bissau','GN','Nova Lamego','NEJ'),

(5976,'Brazil','BR','Nova Xavantina','NOK'),

(5977,'USA','US','Novato~ CA','NOT'),

(5978,'Russia','RU','Novgorod~ Novgorod','NVR'),

(5979,'Yugoslavia','YU','Novi Sad','QND'),

(5980,'Brazil','BR','Novo Aripuana','NVP'),

(5981,'Brazil','BR','Novo Hamburgo~ RS','QHV'),

(5982,'Russia','RU','Novokuznetsk~ Novokuznetsk','NOZ'),

(5983,'Russia','RU','Novorossiysk~ Krasnodar','NOI'),

(5984,'Russia','RU','Novosibirsk~ Novosibirsk','OVB'),

(5985,'Russia','RU','Novy Urengoy','NUX'),

(5986,'Iran','IR','Now Shahr','IEN'),

(5987,'Papua New Guinea','PG','Nowata','NWT'),

(5988,'Australia','AU','Nowra~ New South Wales','NOA'),

(5989,'Iran','IR','Nowshahr','NSH'),

(5990,'Germany','DE','Nuernberg (Nurnberg~Nuremburg)','NUE'),

(5991,'Cuba','CU','Nueva Gerona','GER'),

(5992,'Nicaragua','NI','Nueva Guinea','NVG'),

(5993,'Mexico','MX','Nuevo Laredo','NLD'),

(5994,'Papua New Guinea','PG','Nuguria','NUG'),

(5995,'Tonga','TO','Nuiatoputapu','NPB'),

(5996,'USA','US','Nuiqsut~ AK','NUI'),

(5997,'Tonga','TO','Nuku\'Alofa (Tongatapu)','TBU'),

(5998,'French Polynesia','PF','Nuku Hiva~ Marquesas Islands','NHV'),

(5999,'Papua New Guinea','PG','Nuku','UKU'),

(6000,'Uzbekhistan','UZ','Nukus~ Karakalpakstan','NCU'),

(6001,'French Polynesia','PF','Nukutaveke','NUK'),

(6002,'USA','US','Nulato~ AK','NUL'),

(6003,'Australia','AU','Nullagine~ Western Australia','NLL'),

(6004,'Australia','AU','Nullarbor~ South Australia','NUR'),

(6005,'Australia','AU','Numbulwar~ Northern Territory','NUB'),

(6006,'Indonesia','ID','Numfoor','FOO'),

(6007,'USA','US','Nunapitchuk~ AK','NUP'),

(6008,'Colombia','CO','Nunchia','NUH'),

(6009,'Indonesia','ID','Nunukan~ Borneo','NNX'),

(6010,'Italy','IT','Nuoro','QNU'),

(6011,'Colombia','CO','Nuqui','NQU'),

(6012,'Pakistan','PK','Nushki','NHS'),

(6013,'Papua New Guinea','PG','Nutuve','NUT'),

(6014,'Australia','AU','Nutwood Downs~ Northern Territor','UTD'),

(6015,'USA','US','Nyack~ AK','ZNC'),

(6016,'Sudan','SD','Nyala','UYL'),

(6017,'Myanmar','MM','Nyaung U','NYU'),

(6018,'Kenya','KE','Nyeri','NYE'),

(6019,'Sweden','SE','Nykoping','NYO'),

(6020,'Australia','AU','Nyngan~ New South Wales','NYN'),

(6021,'Kenya','KE','Nzoia','NZO'),

(6022,'USA','US','O\'Neill~ NE','ONL'),

(6023,'Lesotho','LS','Oachas Neck','UNE'),

(6024,'USA','US','Oak Harbor~ WA','ODW'),

(6025,'WA [Whidbey Island Naval Air Station] USA','US','Oak Harbor','NUW'),

(6026,'Australia','AU','Oakey~ Queensland','OKY'),

(6027,'United Kingdom','GB','Oakham~ England','OKH'),

(6028,'USA','US','Oakland~ CA','OBT'),

(6031,'USA','US','Oakland~ MD','ODM'),

(6032,'USA','US','Oakley~ KS','OEL'),

(6033,'USA','US','Oaktown~ IN','OTN'),

(6034,'New Zealand','NZ','Oamaru','OAM'),

(6035,'Mexico','MX','Oaxaca','OAX'),

(6036,'United Kingdom','GB','Oban','OHP'),

(6037,'Australia','AU','Oban~ Queensland','OBA'),

(6039,'Indonesia','ID','Obano','OBD'),

(6040,'Somalia','SO','Obbia','CMO'),

(6041,'USA','US','Oberlin~ KS','OIN'),

(6042,'Germany','DE','Oberpfaffenhofen','OBF'),

(6043,'Brazil','BR','Obidos~ PA','OBI'),

(6044,'Japan','JP','Obihiro','OBO'),

(6045,'Papua New Guinea','PG','Obo','OBX'),

(6046,'Djibouti','DJ','Obock','OBC'),

(6047,'USA','US','Ocala~ FL','OCF'),

(6048,'Colombia','CO','Ocana','OCV'),

(6049,'USA','US','Ocean City~ MD','OCE'),

(6050,'Canada','CA','Ocean Falls~ BC','ZOF'),

(6051,'USA','US','Oceanic~ AK','OCI'),

(6052,'USA','US','Oceanside~ CA','OCN'),

(6053,'Jamaica','JM','Ocho Rios','OCJ'),

(6054,'USA','US','Oconto~ WI','OCQ'),

(6055,'Indonesia','ID','Ocussi','OEC'),

(6056,'Cambodia','KH','Oddor Meanchey','OMY'),

(6057,'Denmark','DK','Odense','ODE'),

(6058,'Ukraine','UA','Odessa~ Odesa','ODS'),

(6059,'Ivory Coast','CI','Odienne','KEO'),

(6060,'United Kingdom','GB','Odiham~ England','ODH'),

(6061,'USA','US','Oelwein~ IA','OLZ'),

(6062,'Australia','AU','Oenpelli~ Northern Territory','OPI'),

(6063,'Norway','NO','Oersta/Volda','HOV'),

(6064,'American Samoa','AS','Ofu Island','OFU'),

(6065,'USA','US','Ogallala~ NE','OGA'),

(6066,'USA','US','Ogden~ UT','HIF'),

(6068,'USA','US','Ogdensburg~ NY','OGS'),

(6069,'Papua New Guinea','PG','Ogeranang','OGE'),

(6070,'Guyana','GY','Ogle','OGL'),

(6071,'Papua New Guinea','PG','Ogn','OPG'),

(6072,'Canada','CA','Ogoki Post~ ON','YOG'),

(6073,'Macedonia','MK','Ohrid','OHD'),

(6074,'Brazil','BR','Oiapoque~ AP','OYK'),

(6075,'USA','US','Oil City~ PA','OIL'),

(6076,'Japan','JP','Oita','OIT'),

(6077,'Indonesia','ID','Okaba','OKQ'),

(6078,'Namibia','LC','Okaukuejo','OKF'),

(6079,'Japan','JP','Okayama','OKJ'),

(6080,'USA','US','Okeechobee~ FL','OBE'),

(6081,'Japan','JP','Oki Island','OKI'),

(6082,'Japan','JP','Okinawa~ Ryukyu Is.','DNA'),

(6084,'Japan','JP','Okino Erabu','OKE'),

(6085,'USA','US','Oklahoma City~ OK','DWN'),

(6090,'USA','US','Okmulgee~ OK','OKM'),

(6091,'Gabon','GA','Okondja','OKN'),

(6092,'Congo','CG','Okoyo','OKG'),

(6093,'Papua New Guinea','PG','Oksapmin','OKP'),

(6094,'Indonesia','ID','Oksibil','OKL'),

(6095,'Japan','JP','Okushiri','OIR'),

(6096,'Iceland','IS','Olafsfjordur','OFJ'),

(6097,'Iceland','IS','Olafsvik','OLI'),

(6098,'Honduras','HN','Olanchito','OAN'),

(6099,'USA','US','Olathe~ KS/Kansas City~ MO','OJC'),

(6101,'Italy','IT','Olbia~ Sardinia','OLB'),

(6102,'Canada','CA','Old Crow~ YT','YOC'),

(6103,'Canada','CA','Old Fort Bay~ QC','ZFB'),

(6104,'USA','US','Old Harbor~ AK','OLH'),

(6105,'USA','US','Old Town~ ME','OLD'),

(6106,'USA','US','Olean~ NY','OLE'),

(6107,'USA','US','Olga Bay~ AK','KOY'),

(6108,'USA','US','Olive Branch~ MS','OLV'),

(6109,'USA','US','Olney-Noble~ IL','OLY'),

(6110,'USA','US','Olney~ TX','ONY'),

(6111,'Czech Republic','CZ','Olomouc','OLO'),

(6112,'Vanuatu','VU','Olpoi','OLJ'),

(6113,'Papua New Guinea','PG','Olsobip','OLQ'),

(6114,'USA','US','Olympia~ WA','OLM'),

(6115,'Australia','AU','Olympic Dam~ South Australia','OLP'),

(6116,'USA','US','Omaha~ NE','OMA'),

(6119,'USA','US','Omak~ WA','OMK'),

(6120,'Gabon','GA','Omboue','OMB'),

(6121,'Namibia','LC','Omega','OMG'),

(6122,'Papua New Guinea','PG','Omkalai','OML'),

(6123,'Papua New Guinea','PG','Omora','OSE'),

(6124,'Russia','RU','Omsk~ Omsk','OMS'),

(6125,'Japan','JP','Omura','OMJ'),

(6126,'Japan','JP','Omyia','QOM'),

(6127,'Namibia','LC','Ondangwa','OND'),

(6128,'Canada','CA','One Hundred Eight Mile Ranch','ZMH'),

(6129,'USA','US','Oneonta~ NY','ONH'),

(6130,'Solomon Islands','SB','Onepuso','ONE'),

(6131,'Angola','AO','Ongiva (Ondjiva)','VPE'),

(6132,'USA','US','Onion Bay~ AK','ONN'),

(6133,'Fiji','FJ','Ono I Lau','ONU'),

(6134,'Papua New Guinea','PG','Ononge','ONB'),

(6135,'Kiribati','KI','Onotoa','OOT'),

(6136,'Australia','AU','Onslow~ Western Australia','ONS'),

(6137,'USA','US','Ontario~ CA','JIO'),

(6139,'USA','US','Ontario~ OR','ONO'),

(6140,'USA','US','Ontonagon~ MI','OGM'),

(6141,'Iceland','IS','Onundarfjordur','HLO'),

(6142,'Australia','AU','Oodnadatta~ South Australia','ODD'),

(6143,'USA','US','Opelousas~ LA','OPL'),

(6144,'Papua New Guinea','PG','Open Bay','OPB'),

(6145,'Namibia','LC','Opuwa','OPW'),

(6146,'Romania','RO','Oradea','OMR'),

(6147,'Kazakhstan','KZ','Oral (Uralsk)~ West Kazakhstan','URA'),

(6148,'Papua New Guinea','PG','Oram','RAX'),

(6149,'Algeria','DZ','Oran','ORN'),

(6150,'Argentina','AR','Oran','ORA'),

(6151,'CA [John Wayne Airport] USA','US','Orange County (Santa Ana)','SNA'),

(6152,'USA','US','Orange County~ CA','JOC'),

(6153,'Belize','BZ','Orange Walk','ORZ'),

(6154,'USA','US','Orange~ CA','JOR'),

(6155,'USA','US','Orange~ MA','ORE'),

(6156,'Australia','AU','Orange~ New South Wales','CUG'),

(6158,'USA','US','Orangeburg~ SC','OGB'),

(6159,'Namibia','LC','Oranjemund','OMD'),

(6160,'Botswana','BW','Orapa','ORP'),

(6161,'Australia','AU','Orchid Beach','OKB'),

(6162,'Taiwan','TW','Orchid Island','KYD'),

(6163,'Australia','AU','Ord River~ Western Australia','ODR'),

(6164,'USA','US','Ord~ NE','ODX'),

(6165,'Turkey','TR','Ordu','QOR'),

(6166,'Sweden','SE','Orebro','ORB'),

(6167,'Russia','RU','Orenburg~ Orenburg','REN'),

(6168,'Papua New Guinea','PG','Oria','OTY'),

(6169,'Australia','AU','Orientos~ New South Wales','OXO'),

(6170,'Guyana','GY','Orinduik','ORJ'),

(6171,'Italy','IT','Oristamo','QOS'),

(6172,'Brazil','BR','Oriximina~ PA','ORX'),

(6173,'Norway','NO','Orland','OLA'),

(6174,'USA','US','Orlando~ FL','DWS'),

(6177,'Pakistan','PK','Ormara','ORW'),

(6178,'Philippines','PH','Ormoc','OMC'),

(6179,'Sweden','SE','Ornskoldsvik','OER'),

(6180,'Colombia','CO','Orocue','ORC'),

(6181,'USA','US','Oroville~ CA','OVE'),

(6182,'Australia','AU','Orpheus Island Resort~ Queenslan','ORS'),

(6183,'Russia','RU','Orsk~ Orenburg','OSW'),

(6184,'USA','US','Ortonville~ MN','VVV'),

(6185,'Bolivia','BO','Oruro','ORU'),

(6186,'USA','US','Osage Beach~ MO','OSB'),

(6187,'Japan','JP','Osaka','ITM'),

(6190,'South Korea','KR','Osan','OSN'),

(6191,'Brazil','BR','Osasco~ SP','QOC'),

(6192,'USA','US','Osceola~ WI','OEO'),

(6193,'USA','US','Oscoda~ MI','OSC'),

(6194,'Kyrgyzstan','KG','Osh~ Osh','OSS'),

(6195,'Namibia','LC','Oshakati','OHI'),

(6196,'Canada','CA','Oshawa~ ON','YOO'),

(6197,'Japan','JP','Oshima Island','OIM'),

(6198,'USA','US','Oshkosh~ NE','OKS'),

(6199,'USA','US','Oshkosh~ WI','OSH'),

(6200,'Croatia','HR','Osijek','OSI'),

(6201,'USA','US','Oskaloosa~ IA','OOA'),

(6202,'Sweden','SE','Oskarshamn','OSK'),

(6203,'Kazakhstan','KZ','Oskeman (Ust Kamenogorsk)~ East ','UKK'),

(6204,'Norway','NO','Oslo','FBU'),

(6207,'India','IN','Osmanabad','OMN'),

(6208,'Germany','DE','Osnabrueck (Osnabruck)','ZPE'),

(6209,'Chile','CL','Osorno','ZOS'),

(6210,'Belgium','BE','Ostend (Oostende)','OST'),

(6211,'Sweden','SE','Ostersund','OSD'),

(6212,'Czech Republic','CZ','Ostrava','OSR'),

(6213,'Namibia','LC','Otavia','OTV'),

(6214,'Namibia','LC','Otjiwarongo','OJW'),

(6215,'USA','US','Ottawa~ KS','OWI'),

(6216,'USA','US','Ottawa~ OH','OWX'),

(6217,'Canada','CA','Ottawa~ ON','YOW'),

(6219,'USA','US','Otto~ NM','OTO'),

(6220,'USA','US','Ottumwa~ IA','OTM'),

(6221,'Colombia','CO','Otu','OTU'),

(6222,'Central African Republic','CF','Ouadda','ODA'),

(6223,'Ivory Coast','CI','Ouaga','OUC'),

(6224,'Burkina Faso','BF','Ouagadougou','OUA'),

(6225,'Burkina Faso','BF','Ouahigouya','OUG'),

(6226,'Central African Republic','CF','Ouanda Djalle','ODJ'),

(6227,'Ivory Coast','CI','Ouango Fitini','OFI'),

(6228,'Algeria','DZ','Ouargla','OGX'),

(6229,'Morocco','MA','Ouarzazate','OZZ'),

(6230,'Laos','LA','Oudomxay','ODY'),

(6231,'South Africa','ZA','Oudtshoorn','OUH'),

(6232,'Congo','CG','Ouesso','OUE'),

(6233,'Morocco','MA','Oujda','OUD'),

(6234,'Finland','FI','Oulu','OUL'),

(6235,'Brazil','BR','Ourinhos~ SP','OUS'),

(6236,'United Kingdom','GB','Outer Skerries~ Shetland Islands','OUK'),

(6237,'Namibia','LC','Outjo','OJO'),

(6238,'New Caledonia','NC','Ouvea (Uvea)~ Loyalty Islands','UVE'),

(6239,'Australia','AU','Ouven','OVN'),

(6240,'Australia','AU','Ouyen~ Victoria','OYN'),

(6241,'USA','US','Ouzinkie~ AK','KOZ'),

(6242,'Chile','CL','Ovalle','OVL'),

(6243,'Israel','IL','Ovda','VDA'),

(6244,'Spain','ES','Oviedo/Aviles','OVD'),

(6245,'USA','US','Owatonna~ MN','OWA'),

(6246,'Canada','CA','Owen Sound~ ON','YOS'),

(6247,'Gabon','GA','Owendo','OWE'),

(6248,'USA','US','Owensboro~ KY','OWB'),

(6249,'Canada','CA','Oxford House~ MB','YOH'),

(6250,'USA','US','Oxford~ CT','OXC'),

(6251,'United Kingdom','GB','Oxford~ England','BZZ'),

(6253,'USA','US','Oxford~ MS','UOX'),

(6254,'USA','US','Oxford~ NC','HNZ'),

(6255,'USA','US','Oxford~ OH','OXD'),

(6256,'USA','US','Oxnard~ CA','OXR'),

(6257,'Gabon','GA','Oyem','OYE'),

(6258,'Philippines','PH','Ozamis City','OZC'),

(6259,'USA','US','Ozona~ TX','OZA'),

(6260,'Myanmar','MM','Pa An','PAA'),

(6261,'Vanuatu','VU','Paama','PBJ'),

(6262,'USA','US','Pacific City~ OR','PFC'),

(6263,'Fiji','FJ','Pacific Harbour','PHR'),

(6264,'USA','US','Pack Creek~ AK','PBK'),

(6265,'Indonesia','ID','Padang','PDG'),

(6266,'Germany','DE','Paderborn/Lippstadt','PAD'),

(6267,'Italy','IT','Padova','QPA'),

(6268,'USA','US','Paducah~ KY','PAH'),

(6269,'USA','US','Paf Warren~ AK','PFA'),

(6270,'Philippines','PH','Pagadian','PAG'),

(6271,'USA','US','Page~ AZ','PGA'),

(6272,'USA','US','Pageland~ SC','PYG'),

(6273,'American Samoa','AS','Pago Pago~ Tutuila Island','PPG'),

(6274,'USA','US','Pagosa Springs~ CO','PGO'),

(6275,'USA','US','Pahokee~ FL','PHK'),

(6276,'Papua New Guinea','PG','Paiela','PLE'),

(6277,'Cambodia','KH','Pailin','PAI'),

(6278,'USA','US','Paimiut~ AK','PMU'),

(6279,'USA','US','Painesville~ OH','PVZ'),

(6280,'USA','US','Painter Creek~ AK','PCE'),

(6281,'New Zealand','NZ','Pakatoa Island','PKL'),

(6282,'Myanmar','MM','Pakokku','PKK'),

(6283,'New Zealand','NZ','Pakotoa Island','PKI'),

(6284,'Laos','LA','Paksane','PKS'),

(6285,'Laos','LA','Pakse','PKZ'),

(6286,'Canada','CA','Pakuashipi~ QC','YIF'),

(6287,'Uganda','UG','Pakuba','PAF'),

(6288,'Chad','TD','Pala','PLF'),

(6289,'Honduras','HN','Palacios','PCH'),

(6290,'USA','US','Palacios~ TX','PSX'),

(6291,'Lithuania','LT','Palanga','PLQ'),

(6292,'Indonesia','ID','Palangkaraya','PKY'),

(6293,'Colombia','CO','Palanquero','PAL'),

(6294,'Indonesia','ID','Palembang','PLM'),

(6295,'Mexico','MX','Palenque','PQM'),

(6296,'Italy','IT','Palermo~ Sicily','PMO'),

(6297,'USA','US','Palestine~ TX','PSN'),

(6298,'Indonesia','ID','Palibelo','PBW'),

(6299,'Australia','AU','Palm Island~ Queensland','PMK'),

(6300,'St. Vincent and the Grenadines','VC','Palm Island','PLI'),

(6301,'USA','US','Palm Springs~ CA','UDD'),

(6303,'Spain','ES','Palma de Mallorca~ Balearic Isla','PMI'),

(6304,'Mozambique','MZ','Palma','LMZ'),

(6305,'Costa Rica','CR','Palmar','PMZ'),

(6306,'Brazil','BR','Palmares~ PE','QGK'),

(6307,'Venezuela','VE','Palmarito','PTM'),

(6308,'Puerto Rico','PR','Palmas del Mar','HPM'),

(6309,'Brazil','BR','Palmas~ PR','PMW'),

(6310,'CA USA','US','Palmdale','PMD'),

(6311,'USA','US','Palmer~ AK','PAQ'),

(6312,'USA','US','Palmer~ MA','PMX'),

(6313,'New Zealand','NZ','Palmerston North','PMR'),

(6314,'Mexico','MX','Palmia','PLL'),

(6315,'Syria','SY','Palmyra','PMS'),

(6316,'USA','US','Palo Alto~ CA','PAO'),

(6317,'Suriname','SR','Paloemeu','OEM'),

(6318,'Indonesia','ID','Palu','PLW'),

(6319,'Burkina Faso','BF','Pama','XPA'),

(6320,'Papua New Guinea','PG','Pambwa','PAW'),

(6321,'Malaysia','MY','Pamol~ Sabah','PAY'),

(6322,'USA','US','Pampa~ TX','PPA'),

(6323,'Spain','ES','Pamplona','PNA'),

(6324,'India','IN','Panaji','DBL'),

(6325,'Panama','PA','Panama City','PTY'),

(6327,'USA','US','Panama City~ FL','PFN'),

(6329,'Brazil','BR','Panambi','QMB'),

(6330,'Yugoslavia','YU','Pancevo','QBG'),

(6331,'Australia','AU','Pandie Pandie~ South Australia','PDE'),

(6332,'Papua New Guinea','PG','Pangia','PGN'),

(6333,'Indonesia','ID','Pangkalanbuun','PKN'),

(6334,'Indonesia','ID','Pangkalpinang','PGK'),

(6335,'Malaysia','MY','Pangkor Island','PKG'),

(6336,'Canada','CA','Pangnirtung~ NT','YXP'),

(6337,'Papua New Guinea','PG','Pangoa','PGB'),

(6338,'USA','US','Panguitch~ UT','PNU'),

(6339,'Pakistan','PK','Panjgur','PJG'),

(6340,'Italy','IT','Pantelleria~ Pantelleria Island','PNL'),

(6341,'India','IN','Pantnagar','PGH'),

(6342,'USA','US','Paonia~ CO','WPO'),

(6343,'United Kingdom','GB','Papa Stour~ Shetland Islands','PSV'),

(6344,'United Kingdom','GB','Papa Westray','PPW'),

(6345,'French Polynesia','PF','Papeete~ Tahiti~ Society Islands','PPT'),

(6346,'Cyprus','CY','Paphos','PFO'),

(6347,'Myanmar','MM','Papun','PPU'),

(6348,'Pakistan','PK','Para Chinar','PAJ'),

(6349,'Australia','AU','Paraburdoo~ Western Australia','PBO'),

(6350,'Bahamas','BS','Paradise Island~ Paradise','PID'),

(6351,'Canada','CA','Paradise River~ NF','YDE'),

(6352,'USA','US','Paragould~ AR','PGR'),

(6353,'Venezuela','VE','Paraguana','QQZ'),

(6354,'Benin','BJ','Parakou','PKO'),

(6355,'Guyana','GY','Paramakatoi','PMT'),

(6356,'Suriname','SR','Paramaribo','ORG'),

(6357,'Papua New Guinea','PG','Paran','PPX'),

(6358,'Argentina','AR','Parana','PRA'),

(6359,'Brazil','BR','Parana~ GO','PXA'),

(6360,'Brazil','BR','Paranagua~ PR','PNG'),

(6361,'Brazil','BR','Paranaiba~ MG','PBB'),

(6362,'Brazil','BR','Paranavai~ PR','PVI'),

(6363,'New Zealand','NZ','Paraparaumu','PPQ'),

(6364,'Solomon Islands','SB','Parasi','PRS'),

(6365,'Colombia','CO','Paratebueno','EUO'),

(6366,'Australia','AU','Pardoo~ Western Australia','PRD'),

(6367,'Brazil','BR','Parintins~ AM','PIN'),

(6368,'France','FR','Paris','CDG'),

(6374,'USA','US','Paris~ TN','PHT'),

(6375,'USA','US','Paris~ TX','PRX'),

(6376,'USA','US','Park Falls~ WI','PKF'),

(6377,'USA','US','Park Rapids~ MN','PKD'),

(6378,'USA','US','Parkersburg~ WV','PKB'),

(6379,'Australia','AU','Parkes~ New South Wales','PKE'),

(6380,'USA','US','Parks~ AK','KPK'),

(6381,'Italy','IT','Parma','PMF'),

(6382,'Brazil','BR','Parmalba','PHB'),

(6383,'Australia','AU','Parndana~ South Australia','PDN'),

(6384,'Bhutan','BT','Paro','PBH'),

(6385,'Greece','GR','Paros','PAS'),

(6386,'Canada','CA','Parry Sound~ ON','YPD'),

(6387,'USA','US','Parsons~ KS','PPF'),

(6388,'Guyana','GY','Paruima','PRR'),

(6389,'USA','US','Pasadena~ CA','JPD'),

(6390,'USA','US','Pascagoula~ MS','PGL'),

(6391,'USA','US','Pasco~ WA','PSC'),

(6392,'India','IN','Pasighat','IXT'),

(6393,'Indonesia','ID','Pasir Pangarayan','PPR'),

(6394,'Pakistan','PK','Pasni','PSI'),

(6395,'Guatemala','GT','Paso Caballos','PCG'),

(6396,'Argentina','AR','Paso de los Libres','AOL'),

(6397,'USA','US','Paso Robles~ CA','PRB'),

(6398,'Brazil','BR','Passo Fundo~ RS','PFB'),

(6399,'Brazil','BR','Passos','PSW'),

(6400,'Ecuador','EC','Pastaza','PTZ'),

(6401,'Colombia','CO','Pasto','PSO'),

(6402,'USA','US','Paterson~ NJ','JPJ'),

(6403,'India','IN','Pathankot','IXP'),

(6404,'India','IN','Patna','PAT'),

(6405,'Brazil','BR','Pato Branco~ PR','PTO'),

(6406,'Thailand','TH','Patong Beach','PBS'),

(6407,'Iceland','IS','Patreksfjordur','PFJ'),

(6408,'Thailand','TH','Pattani','PAN'),

(6409,'Thailand','TH','Pattaya','PYX'),

(6410,'USA','US','Patterson/Morgan City~ LA','PTN'),

(6411,'MD [Patuxent River Naval Air Station] USA','US','Patuxent River','NHK'),

(6412,'France','FR','Pau','PUF'),

(6413,'Myanmar','MM','Pauk','PAU'),

(6414,'Canada','CA','Paulatuk~ NT','YPC'),

(6415,'Brazil','BR','Paulo Afonso~ BA','PAV'),

(6416,'USA','US','Pauloff Harbor (Sanak Island)~ A','KPH'),

(6417,'Kazakhstan','KZ','Pavlodar~ Pavlodar','PWQ'),

(6418,'Ethiopia','ET','Pawi','PWI'),

(6419,'USA','US','Pawtucket/Smithfield~ RI','SFZ'),

(6420,'Colombia','CO','Payan','PYN'),

(6421,'Uruguay','UY','Paysandu','PDU'),

(6422,'USA','US','Payson~ AZ','PJB'),

(6423,'Colombia','CO','Paz de Ariporo','PZA'),

(6424,'Canada','CA','Peace River~ AB','YPE'),

(6425,'USA','US','Peach Springs~ AZ','PGS'),

(6426,'GA USA','US','Peachtree City','FFC'),

(6427,'Canada','CA','Peawanuck~ ON','YPO'),

(6429,'Mozambique','MZ','Pebane','PEB'),

(6430,'USA','US','Pecos~ TX','PEQ'),

(6431,'Venezuela','VE','Pedernales','PDZ'),

(6432,'USA','US','Pedro Bay~ AK','PDB'),

(6433,'Paraguay','PY','Pedro Juan Caballero','PJC'),

(6434,'Argentina','AR','Pehuajo','PEH'),

(6435,'Indonesia','ID','Pekanbaru','PKU'),

(6436,'Lesotho','LS','Pelaneng','PEL'),

(6437,'USA','US','Pelican~ AK','PEC'),

(6438,'USA','US','Pell City~ AL','PLR'),

(6439,'USA','US','Pellston~ MI','PLN'),

(6440,'Canada','CA','Pelly Bay~ NT','YUF'),

(6442,'Brazil','BR','Pelotas~ RS','PET'),

(6443,'Mozambique','MZ','Pemba (Porto Amelia)','POL'),

(6444,'Tanzania','TZ','Pemba Island','PMA'),

(6445,'USA','US','Pembina~ ND','PMB'),

(6446,'Canada','CA','Pembroke~ ON','YTA'),

(6447,'Malaysia','MY','Penang~ Peninsular','PEN'),

(6448,'Canada','CA','Pender Harbour~ BC','YPT'),

(6449,'USA','US','Pendleton~ OR','PDT'),

(6450,'Indonesia','ID','Pendopo','PDO'),

(6451,'Australia','AU','Penneshaw~ South Australia','PEA'),

(6452,'Australia','AU','Penong~ South Australia','PEY'),

(6453,'Cook Islands','CK','Penrhyn Island','PYE'),

(6454,'USA','US','Pensacola~ FL','NDP'),

(6455,'FL [Pensacola Naval Air Station] USA','US','Pensacola','NPA'),

(6458,'Canada','CA','Penticton~ BC','YYF'),

(6459,'Russia','RU','Penza~ Penza','PEZ'),

(6460,'United Kingdom','GB','Penzance~ England','PZE'),

(6461,'USA','US','Peoria~ IL','PIA'),

(6462,'Australia','AU','Peppimenarti~ Northern Territory','PEP'),

(6463,'Venezuela','VE','Peraitepuys','PPH'),

(6464,'Colombia','CO','Pereira','PEI'),

(6465,'France','FR','Perigueux','PGX'),

(6466,'Australia','AU','Perisher Valley~ New South Wales','QPV'),

(6467,'Argentina','AR','Perito Moreno','PMQ'),

(6468,'Russia','RU','Perm~ Perm','PEE'),

(6469,'France','FR','Perpignan','PGF'),

(6470,'USA','US','Perry Island~ AK','PYL'),

(6471,'USA','US','Perry~ FL','FPY'),

(6472,'USA','US','Perry~ IA','PRO'),

(6473,'USA','US','Perryville~ AK','KPV'),

(6474,'Iran','IR','Persepolis','WPS'),

(6475,'United Kingdom','GB','Perth~ Scotland','PSL'),

(6476,'Australia','AU','Perth~ Western Australia','PER'),

(6477,'IL USA','US','Peru','VYS'),

(6478,'USA','US','Peru~ IN','GUS'),

(6479,'Italy','IT','Perugia','PEG'),

(6480,'Indonesia','ID','Perwokerto','PWL'),

(6481,'Italy','IT','Pescara','PSR'),

(6482,'Pakistan','PK','Peshawar','PEW'),

(6483,'Canada','CA','Petawawa~ ON','YWA'),

(6484,'Canada','CA','Peterborough~ ON','YPQ'),

(6485,'USA','US','Petersburg~ AK','PSG'),

(6486,'USA','US','Petersburg~ VA','PTB'),

(6487,'USA','US','Petersburg~ WV','PGC'),

(6488,'VA USA','US','Petersburg/Fort Lee','FLE'),

(6489,'USA','US','Petersons Point~ AK','PNF'),

(6490,'Brazil','BR','Petrolina~ PE','PNZ'),

(6491,'Russia','RU','Petropavlovsk Kamchatskiy~ Kamch','PKC'),

(6492,'Russia','RU','Petropavlovsk~ Kamchatka','PPK'),

(6493,'Brazil','BR','Petropolis~ RJ','QPE'),

(6494,'Russia','RU','Petrozavodsk~ Karelia','PES'),

(6495,'Russia','RU','Pevek~ Magadan','PWE'),

(6496,'Germany','DE','Pforzheim','UPF'),

(6497,'South Africa','ZA','Phalaborwa','PHW'),

(6498,'Vietnam','VN','Phan Rang','PHA'),

(6499,'Vietnam','VN','Phan Thiet','PHH'),

(6500,'Thailand','TH','Phanom Sarakham','PMM'),

(6501,'Nepal','NP','Phaplu','PPL'),

(6502,'USA','US','Philadelphia~ PA','MUV'),

(6505,'USA','US','Philip~ SD','PHP'),

(6506,'USA','US','Philipsburg~ PA','PSB'),

(6507,'USA','US','Phillipsburg~ KS','PHG'),

(6508,'Thailand','TH','Phitsanulok','PHS'),

(6509,'Cambodia','KH','Phnom Penh','PNH'),

(6510,'USA','US','Phoenix~ AZ','DVT'),

(6512,'Thailand','TH','Phrae','PRH'),

(6513,'Vietnam','VN','Phu-Bon','HBN'),

(6514,'Vietnam','VN','Phu Quoc','PQC'),

(6515,'Vietnam','VN','Phu Vinh','PHU'),

(6516,'Thailand','TH','Phuket','HKT'),

(6517,'Vietnam','VN','Phuoclong','VSO'),

(6518,'USA','US','Picayune~ MS','PCU'),

(6519,'USA','US','Pickens~ SC','LQK'),

(6520,'Canada','CA','Pickle Lake~ ON','YPL'),

(6521,'Portugal','PT','Pico Island~ Azores','PIX'),

(6522,'Brazil','BR','Picos~ PI','PCS'),

(6523,'New Zealand','NZ','Picton','PCN'),

(6524,'Mexico','MX','Piedras Negras','PDS'),

(6525,'USA','US','Pierre~ SD','PIR'),

(6526,'Slovakia','SK','Piestany','PZY'),

(6527,'South Africa','ZA','Pietermaritzburg','PZB'),

(6528,'South Africa','ZA','Pietersburg','PTG'),

(6529,'Venezuela','VE','Pijiguaos','LPJ'),

(6530,'Canada','CA','Pikangikum~ ON','YPM'),

(6532,'South Africa','ZA','Pilanesberg/Sun City','NTY'),

(6533,'Paraguay','PY','Pilar','PIL'),

(6534,'USA','US','Pilot Point~ AK','PIP'),

(6536,'USA','US','Pilot Station~ AK','PQS'),

(6537,'Papua New Guinea','PG','Pimaga','PMP'),

(6538,'Cuba','CU','Pinar del Rio','QPD'),

(6539,'Canada','CA','Pincher Creek~ AB','WPC'),

(6540,'USA','US','Pinckneyville~ IL','PJY'),

(6541,'Papua New Guinea','PG','Pindiu','PDI'),

(6542,'USA','US','Pine Bluff~ AR','PBF'),

(6543,'Turks & Caicos','TC','Pine Cay','PIC'),

(6544,'USA','US','Pine Mountain~ GA','PIM'),

(6545,'Canada','CA','Pine Point~ NT','YPP'),

(6546,'USA','US','Pine Ridge~ SD','XPR'),

(6547,'USA','US','Pinebelt~ MS','PIF'),

(6548,'Canada','CA','Pinehouse Lake~ SK','ZPO'),

(6549,'USA','US','Pinehurst/Southern Pines~ NC','SOP'),

(6550,'Taiwan','TW','Ping Tung','PIW'),

(6551,'Brazil','BR','Pinheiro~ MA','PHI'),

(6552,'USA','US','Pipestone~ MN','PQN'),

(6553,'Guyana','GY','Pipillipai','PIQ'),

(6554,'Italy','IT','Pisa','PSA'),

(6555,'Peru','PE','Pisco','PIO'),

(6556,'Colombia','CO','Pitalito','PTX'),

(6557,'Brazil','BR','Pitinga','PIG'),

(6558,'Canada','CA','Pitt Meadows~ BC','YPK'),

(6559,'Bahamas','BS','Pitts Town','PWN'),

(6560,'USA','US','Pittsburg~ KS','PTS'),

(6561,'USA','US','Pittsburgh~ PA','AGC'),

(6563,'USA','US','Pittsfield~ MA','PSF'),

(6564,'Peru','PE','Piura','PIU'),

(6565,'USA','US','Placerville~ CA','PVF'),

(6566,'USA','US','Plainview~ TX','PVW'),

(6567,'Colombia','CO','Planadas','PLA'),

(6568,'Colombia','CO','Planeta Rica','PLC'),

(6569,'USA','US','Plano~ TX','DNE'),

(6570,'USA','US','Platinum~ AK','PTU'),

(6571,'Colombia','CO','Plato','PLT'),

(6572,'USA','US','Platteville~ WI','PVB'),

(6573,'USA','US','Plattsburgh~ NY','PLB'),

(6575,'Mexico','MX','Playa del Carmen','PCM'),

(6576,'Costa Rica','CR','Playa Samara','PLD'),

(6577,'Panama','PA','Playon Chico','PYC'),

(6578,'USA','US','Pleasant Harbor~ AK','PTR'),

(6579,'USA','US','Pleasanton~ CA','JBS'),

(6580,'Vietnam','VN','Pleiku','PXU'),

(6581,'USA','US','Plentywood~ MT','PWD'),

(6582,'South Africa','ZA','Plettenberg Bay','PBZ'),

(6583,'Bulgaria','BG','Pleven','PVN'),

(6584,'Bulgaria','BG','Plovdiv','PDV'),

(6585,'United Kingdom','GB','Plymouth~ England','PLH'),

(6586,'USA','US','Plymouth~ MA','PYM'),

(6587,'Burkina Faso','BF','Po','PUP'),

(6588,'USA','US','Pocahontas~ IA','POH'),

(6589,'USA','US','Pocatello~ ID','PIH'),

(6590,'Mexico','MX','Pochutla','PUH'),

(6591,'Brazil','BR','Pocos de Caldas~ MG','POO'),

(6592,'Senegal','SN','Podor','POD'),

(6593,'Yugoslavia','YU','Pogdorica (Titograd)','TGD'),

(6594,'South Korea','KR','Pohang','KPO'),

(6595,'Micronesia','FM','Pohnpei Island','PNI'),

(6596,'USA','US','Point Baker~ AK','KPB'),

(6597,'USA','US','Point Barrow~ AK','PBA'),

(6598,'USA','US','Point Hope~ AK','PHO'),

(6599,'USA','US','Point Lay~ AK','PIZ'),

(6600,'USA','US','Point Lookout~ MO','PLK'),

(6601,'USA','US','Point Mugu~ CA','NTD'),

(6602,'Guadeloupe','GP','Pointe-a-Pitre','PTP'),

(6603,'Congo','CG','Pointe Noire','PNR'),

(6604,'USA','US','Pointe Retreat~ AK','PRT'),

(6605,'Grenada','GD','Pointe Saline','GNO'),

(6606,'Canada','CA','Points North Landing~ SK','YNL'),

(6607,'France','FR','Poitiers','PIS'),

(6608,'Nepal','NP','Pokhara','PKR'),

(6609,'USA','US','Polacca~ AZ','PXL'),

(6610,'USA','US','Polk Inlet~ AK','POQ'),

(6611,'Ukraine','UA','Poltava~ Poltava','PLV'),

(6612,'Indonesia','ID','Pomalaa','PUM'),

(6613,'Italy','IT','Pomezia','QEZ'),

(6614,'USA','US','Pompano Beach~ FL','PPM'),

(6615,'Brazil','BR','Pompeia~ SP','QPF'),

(6616,'USA','US','Ponca City~ OK','PNC'),

(6617,'Puerto Rico','PR','Ponce','PSE'),

(6618,'Canada','CA','Pond Inlet~ NT','YIO'),

(6619,'Indonesia','ID','Pondok Cabe','PCB'),

(6620,'Portugal','PT','Ponta Delgada (Sao Miguel Island','PDL'),

(6621,'Brazil','BR','Ponta Grossa~ PR','PGZ'),

(6622,'Brazil','BR','Ponta Pora~ SP','PMG'),

(6623,'USA','US','Pontiac~ MI','PTK'),

(6624,'Indonesia','ID','Pontianak','PNK'),

(6625,'France','FR','Pontoise','POX'),

(6626,'India','IN','Poona','PNQ'),

(6627,'Colombia','CO','Popayan','PPN'),

(6628,'USA','US','Pope Vanoy~ AK','PVY'),

(6629,'USA','US','Poplar Bluff~ MO','POF'),

(6630,'Canada','CA','Poplar Hill~ ON','YHP'),

(6631,'Canada','CA','Poplar River~ MB','XPP'),

(6632,'Papua New Guinea','PG','Popondetta','PNP'),

(6633,'Slovakia','SK','Poprad','TAT'),

(6634,'Guatemala','GT','Poptun','PON'),

(6635,'India','IN','Porbandar','PBD'),

(6636,'USA','US','Porcupine Creek~ AK','PCK'),

(6637,'Colombia','CO','Pore','PRE'),

(6638,'Papua New Guinea','PG','Porgera','RGE'),

(6639,'Finland','FI','Pori','POR'),

(6640,'Haiti','HT','Port-au-Prince','PAP'),

(6641,'Canada','CA','Port-Menier~ QC','YPN'),

(6642,'Canada','CA','Port Alberni~ BC','YPB'),

(6643,'USA','US','Port Alexander~ AK','PTD'),

(6644,'USA','US','Port Alice~ AK','PTC'),

(6645,'USA','US','Port Alsworth~ AK','PTA'),

(6646,'USA','US','Port Angeles~ WA','NOW'),

(6648,'Jamaica','JM','Port Antonio','POT'),

(6649,'USA','US','Port Armstrong~ AK','PTL'),

(6650,'Australia','AU','Port Augusta~ South Australia','PUG'),

(6651,'USA','US','Port Bailey~ AK','KPY'),

(6652,'Madagascar','MG','Port Berge','WPB'),

(6653,'India','IN','Port Blair','IXZ'),

(6654,'USA','US','Port Clarence~ AK','KPC'),

(6655,'USA','US','Port Clinton~ OH','PCW'),

(6656,'Haiti','HT','Port de Paix','PAX'),

(6657,'Australia','AU','Port Douglas~ Queensland','PTI'),

(6658,'South Africa','ZA','Port Elizabeth','PLZ'),

(6659,'New Zealand','NZ','Port Fitzroy','GBS'),

(6660,'Gabon','GA','Port Gentil','POG'),

(6661,'USA','US','Port Graham~ AK','PGM'),

(6662,'Nigeria','NG','Port Harcourt','PHC'),

(6663,'Canada','CA','Port Hardy (Inukjuak)~ QC','YPH'),

(6664,'Canada','CA','Port Hardy~ BC','YZT'),

(6666,'Canada','CA','Port Hawkesbury~ NS','YPS'),

(6667,'Australia','AU','Port Hedland~ Western Australia','PHE'),

(6668,'USA','US','Port Heiden~ AK','PTH'),

(6669,'Canada','CA','Port Hope Simpson~ NF','YHA'),

(6670,'Australia','AU','Port Hunter~ New South Wales','PHJ'),

(6671,'USA','US','Port Huron~ MI','PHN'),

(6672,'USA','US','Port Johnson~ AK','PRF'),

(6673,'Guyana','GY','Port Kaituma','PKM'),

(6674,'Australia','AU','Port Keats~ Northern Territory','PKT'),

(6675,'Australia','AU','Port Lincoln~ South Australia','PLO'),

(6676,'USA','US','Port Lions~ AK','ORI'),

(6677,'Australia','AU','Port Macquarie~ New South Wales','PQQ'),

(6678,'Canada','CA','Port McNeill~ BC','YMP'),

(6679,'USA','US','Port Moller~ AK','PML'),

(6680,'Papua New Guinea','PG','Port Moresby','POM'),

(6681,'USA','US','Port Oceanic~ AK','PRL'),

(6682,'Trinidad & Tobago','TT','Port of Spain~ Trinidad Is.','POS'),

(6683,'USA','US','Port Protection~ AK','PPV'),

(6684,'Canada','CA','Port Radium~ NT','YIX'),

(6685,'Egypt','EG','Port Said','PSD'),

(6686,'USA','US','Port San Juan~ AK','PJS'),

(6687,'Canada','CA','Port Simpson~ BC','YPI'),

(6688,'Australia','AU','Port Stephens~ New South Wales','PTE'),

(6689,'Sudan','SD','Port Sudan','PZU'),

(6690,'USA','US','Port Townsend~ WA','TWD'),

(6692,'Vanuatu','VU','Port Vila~ Efate Is.','VLI'),

(6693,'USA','US','Port Walter~ AK','PWR'),

(6694,'USA','US','Port Williams~ AK','KPR'),

(6695,'USA','US','Portage Creek~ AK','PCA'),

(6696,'Canada','CA','Portage~ MB','YPG'),

(6697,'USA','US','Porterville~ CA','PTV'),

(6698,'Portugal','PT','Portimao','PRM'),

(6699,'USA','US','Portland~ ME','PWM'),

(6700,'USA','US','Portland~ OR','TTD'),

(6702,'Australia','AU','Portland~ Victoria','PTJ'),

(6703,'Greece','GR','Porto-Kheli','PKH'),

(6704,'Portugal','PT','Porto (Oporto)','OPO'),

(6705,'Brazil','BR','Porto Alegre~ RS','POA'),

(6706,'Sao Tome & Principe','ST','Porto Alegre~ Sao Tome','PGP'),

(6707,'Angola','AO','Porto Amboim','PBN'),

(6708,'Brazil','BR','Porto de Mos~ PA','PTQ'),

(6709,'Brazil','BR','Porto Nacional~ GO','PNB'),

(6710,'Portugal','PT','Porto Santo~ Madeira','PXO'),

(6711,'Brazil','BR','Porto Seguro~ BA','BPS'),

(6712,'Brazil','BR','Porto Trombetas~ PA','TMT'),

(6713,'Brazil','BR','Porto Velho~ RO','PVH'),

(6714,'Yugoslavia','YU','Portoroz','POW'),

(6715,'Ecuador','EC','Portoviejo','PVO'),

(6716,'Australia','AU','Portpirie~ South Australia','PPI'),

(6717,'United Kingdom','GB','Portsmouth~ England','PME'),

(6718,'USA','US','Portsmouth~ NH','PSM'),

(6719,'USA','US','Portsmouth~ OH','PMH'),

(6720,'USA','US','Portsmouth~ VA','PVG'),

(6721,'Chile','CL','Porvenir','WPR'),

(6722,'Argentina','AR','Posadas','PSS'),

(6723,'Indonesia','ID','Poso','PSJ'),

(6724,'Canada','CA','Postville~ NF','YSO'),

(6725,'USA','US','Poteau~ OK','RKR'),

(6726,'Bolivia','BO','Potosi','POI'),

(6727,'USA','US','Pottstown~ PA','PTW'),

(6728,'USA','US','Poughkeepsie~ NY','POU'),

(6729,'USA','US','Poulsbo~ WA','PUL'),

(6730,'Brazil','BR','Pouso Alegre~ MG','PPY'),

(6731,'Canada','CA','Povungnituk~ QC','YPX'),

(6732,'Canada','CA','Powell Lake~ BC','WPL'),

(6733,'Bahamas','BS','Powell Point','PPO'),

(6734,'Canada','CA','Powell River~ BC','YPW'),

(6735,'USA','US','Powell~ WY','POY'),

(6736,'Mexico','MX','Poza Rica','PAZ'),

(6737,'Poland','PL','Poznan','POZ'),

(6738,'Brazil','BR','Prado~ BA','PDF'),

(6739,'Czech Republic','CZ','Praha (Prague)','PRG'),

(6740,'Cape Verde','CV','Praia~ Sao Tiago','RAI'),

(6741,'USA','US','Prairie du Chien~ WI','PCD'),

(6742,'Seychelles','SC','Praslin Island','PRI'),

(6743,'Italy','IT','Prato','QPR'),

(6744,'USA','US','Pratt~ KS','PTT'),

(6745,'USA','US','Prentice~ WI','PRW'),

(6746,'Czech Republic','CZ','Prerov','PRV'),

(6747,'USA','US','Prescott~ AZ','PRC'),

(6748,'Argentina','AR','Presidencia Roque Saenz Pena','PRQ'),

(6749,'Brazil','BR','Presidente Dutra','PDR'),

(6750,'Brazil','BR','Presidente Prudente~ SP','PPB'),

(6751,'ME USA','US','Presque Isle','PQI'),

(6752,'Cuba','CU','Preston','PST'),

(6753,'United Kingdom','GB','Prestwick~ Scotland','PIK'),

(6754,'South Africa','ZA','Pretoria','HPR'),

(6757,'Greece','GR','Preveza/Lefkas','PVK'),

(6758,'USA','US','Price~ UT','PUC'),

(6759,'Canada','CA','Prince Albert~ SK','YPA'),

(6760,'Canada','CA','Prince George~ BC','YXS'),

(6761,'Canada','CA','Prince Rupert~ BC','YPR'),

(6763,'USA','US','Princeton (Rocky Hill)~ NJ','PCT'),

(6764,'USA','US','Princeton~ ME','PNN'),

(6765,'USA','US','Princeton~ MN','PNM'),

(6766,'USA','US','Princeville (Hanalei)~ HI','HPV'),

(6767,'Brazil','BR','Principe da Beira~ RO','FDB'),

(6768,'Sao Tome & Principe','ST','Principe~ Principe','PCP'),

(6769,'USA','US','Prineville~ OR','PRZ'),

(6770,'Yugoslavia','YU','Pristina','PRN'),

(6771,'Brazil','BR','Progresso','PGG'),

(6772,'Myanmar','MM','Prome','PRU'),

(6773,'France','FR','Propriano','PRP'),

(6774,'Australia','AU','Proserpine~ Queensland','PPP'),

(6775,'USA','US','Prospect Creek~ AK','PPC'),

(6776,'USA','US','Providence~ RI','PVD'),

(6777,'Colombia','CO','Providencia','PVA'),

(6778,'Turks & Caicos','TC','Providenciales~ Caicos Is.','PLS'),

(6779,'Russia','RU','Provideniya~ Magadan','PVS'),

(6780,'USA','US','Provincetown~ MA','PVC'),

(6781,'USA','US','Provo~ UT','PVU'),

(6782,'USA','US','Prudhoe Bay~ AK','PUO'),

(6783,'USA','US','Prudhoe Bay/Deadhorse~ AK','SCC'),

(6784,'Papua New Guinea','PG','Puas','PUA'),

(6785,'Peru','PE','Pucallpa','PCL'),

(6786,'Chile','CL','Pucon','ZPC'),

(6787,'Mexico','MX','Puebla','PBC'),

(6788,'USA','US','Pueblo~ CO','PUB'),

(6789,'Chile','CL','Puerto Aisen','WPA'),

(6790,'Panama','PA','Puerto Armuella','AML'),

(6791,'Colombia','CO','Puerto Asis','PUU'),

(6792,'Venezuela','VE','Puerto Ayacucho','PYH'),

(6793,'Guatemala','GT','Puerto Barrios','PBR'),

(6794,'Colombia','CO','Puerto Berrio','PBE'),

(6795,'Colombia','CO','Puerto Boyaca','PYA'),

(6796,'Venezuela','VE','Puerto Cabello','PBL'),

(6797,'Nicaragua','NI','Puerto Cabezas','PUZ'),

(6798,'Colombia','CO','Puerto Carreno','PCR'),

(6799,'Argentina','AR','Puerto Deseado','PUD'),

(6800,'Mexico','MX','Puerto Escondido','PXM'),

(6801,'Colombia','CO','Puerto Inirida','PDA'),

(6802,'Costa Rica','CR','Puerto Jimenez','PJM'),

(6803,'Mexico','MX','Puerto Juarez','PJZ'),

(6804,'Venezuela','VE','Puerto La Cruz','PCZ'),

(6806,'Colombia','CO','Puerto Leguizam','LQM'),

(6807,'Honduras','HN','Puerto Lenpira','PEU'),

(6808,'Argentina','AR','Puerto Madryn','PMY'),

(6809,'Peru','PE','Puerto Maldonado','PEM'),

(6810,'Chile','CL','Puerto Montt','PMC'),

(6811,'Panama','PA','Puerto Obaldia','PUE'),

(6812,'Venezuela','VE','Puerto Ordaz','PZO'),

(6813,'Venezuela','VE','Puerto Paez','PPZ'),

(6814,'Mexico','MX','Puerto Penasco','PPE'),

(6815,'Dominican Republic','DO','Puerto Plata','POP'),

(6816,'Philippines','PH','Puerto Princesa','PPS'),

(6817,'Bolivia','BO','Puerto Rico','PUR'),

(6818,'Colombia','CO','Puerto Rico','PCC'),

(6819,'Bolivia','BO','Puerto Suarez','PSZ'),

(6820,'Mexico','MX','Puerto Vallarta','PVR'),

(6821,'Chile','CL','Puerto Williams','WPU'),

(6822,'French Polynesia','PF','Pukapuka','PKP'),

(6823,'French Polynesia','PF','Pukaru','PUK'),

(6824,'Canada','CA','Pukatawagan~ MB','XPK'),

(6825,'Croatia','HR','Pula','PUY'),

(6826,'USA','US','Pulaski~ TN','GZS'),

(6827,'Malaysia','MY','Pulau','PPJ'),

(6828,'USA','US','Pullman~ WA/Moscow~ ID','PUW'),

(6829,'Papua New Guinea','PG','Pumani','PMN'),

(6830,'Zaire','ZR','Punia','PUN'),

(6831,'Mexico','MX','Punoteca','PNO'),

(6832,'Cuba','CU','Punta Alegre','UPA'),

(6833,'Chile','CL','Punta Arenas','PUQ'),

(6834,'Dominican Republic','DO','Punta Cana','PUJ'),

(6835,'Mexico','MX','Punta Chivato','PCV'),

(6836,'Mexico','MX','Punta Colorada','PCO'),

(6837,'Cuba','CU','Punta de Maisi','UMA'),

(6838,'Uruguay','UY','Punta del Este','PDP'),

(6839,'Belize','BZ','Punta Gorda','PND'),

(6840,'USA','US','Punta Gorda~ FL','PGD'),

(6841,'Canada','CA','Puntzi Mountain~ BC','YPU'),

(6842,'South Korea','KR','Pusan','PUS'),

(6843,'Brazil','BR','Pusso Alegre~ MG','QGR'),

(6844,'Myanmar','MM','Putao','PBU'),

(6845,'India','IN','Puttaparthi','PUT'),

(6846,'Germany','DE','Puttgarden','QUA'),

(6847,'Ecuador','EC','Putumayo','PYO'),

(6848,'Indonesia','ID','Putussibau~ Borneo','PSU'),

(6849,'Zaire','ZR','Pweto','PWO'),

(6850,'North Korea','KP','Pyongyang','FNJ'),

(6851,'Greece','GR','Pyrgos','PYR'),

(6852,'Greenland','GL','Qaanaaq','NAQ'),

(6853,'Saudi Arabia','SA','Qaisumah','AQI'),

(6854,'Afghanistan','AF','Qala-Nau','LQN'),

(6855,'Uzbekhistan','UZ','Qarshi (Karshi)~ Qashqadaryo','KSQ'),

(6856,'China','CN','Qiemo','IQM'),

(6857,'China','CN','Qingdao','TAO'),

(6858,'China','CN','Qingyang','IQN'),

(6859,'China','CN','Qinhuangdao','SHP'),

(6860,'China','CN','Qiqihar (Tsi-tsihar)','NDG'),

(6861,'Yemen','YE','Qishn','IHN'),

(6862,'Kazakhstan','KZ','Qostanay (Kustanay)~ Qostanay','KSN'),

(6863,'USA','US','Quakertown~ PA','UKT'),

(6864,'Canada','CA','Qualicum Beach~ BC','XQU'),

(6865,'Vietnam','VN','Quanduc','HOO'),

(6866,'Vietnam','VN','Quang Ngai','XNG'),

(6867,'Gabon','GA','Quanga','OUU'),

(6868,'VA USA','US','Quantico','NYG'),

(6869,'Canada','CA','Quaqtaq~ QC','YQC'),

(6870,'Canada','CA','Quebec~ QC','YQB'),

(6871,'Canada','CA','Queen Charlotte~ BC','ZQS'),

(6872,'USA','US','Queens~ AK','UQE'),

(6873,'New Zealand','NZ','Queenstown','ZQN'),

(6874,'South Africa','ZA','Queenstown','UTW'),

(6875,'Australia','AU','Queenstown~ Tasmania','UEE'),

(6876,'Mozambique','MZ','Quelimane','UEL'),

(6877,'Costa Rica','CR','Quepos','XQP'),

(6878,'Mexico','MX','Queretaro','QRO'),

(6879,'Canada','CA','Quesnel~ BC','YQZ'),

(6880,'Pakistan','PK','Quetta','UET'),

(6881,'Colombia','CO','Quibdo','UIB'),

(6882,'USA','US','Quillayute~ WA','UIL'),

(6883,'Australia','AU','Quilpie~ Queensland','ULP'),

(6884,'France','FR','Quimper','UIP'),

(6885,'Peru','PE','Quince Mil','UMI'),

(6886,'USA','US','Quincy~ IL','UIN'),

(6887,'USA','US','Quincy~ MA','MQI'),

(6888,'Vanuatu','VU','Quine Hill','UIQ'),

(6889,'USA','US','Quinhagak~ AK','KWN'),

(6890,'Australia','AU','Quirindi~ New South Wales','UIR'),

(6891,'Ecuador','EC','Quito','UIO'),

(6892,'Vietnam','VN','Quy Nhon','UIH'),

(6893,'China','CN','Quzhou','QUZ'),

(6894,'Papua New Guinea','PG','Rabaraba','RBP'),

(6895,'Morocco','MA','Rabat','RBA'),

(6896,'Papua New Guinea','PG','Rabaul','RAB'),

(6897,'Fiji','FJ','Rabi','RBI'),

(6898,'Vietnam','VN','Rach Gia','VKG'),

(6899,'USA','US','Racine~ WI','RAC'),

(6900,'Russia','RU','Raduzhnyi','RAT'),

(6901,'India','IN','Rae Bareli','BEK'),

(6902,'Canada','CA','Rae Lakes~ NT','YRA'),

(6903,'Central African Republic','CF','Rafai','RFA'),

(6904,'Saudi Arabia','SA','Rafha','RAH'),

(6905,'New Zealand','NZ','Ragland','RAG'),

(6906,'Indonesia','ID','Raha','RAQ'),

(6907,'Pakistan','PK','Rahim Yar Khan','RYK'),

(6908,'French Polynesia','PF','Raiatea~ Society Islands','RFP'),

(6909,'Canada','CA','Rainbow Lake~ AB','YOP'),

(6910,'India','IN','Raipur','RPR'),

(6911,'India','IN','Rajahmundry','RJA'),

(6912,'Nepal','NP','Rajbiraj','RJB'),

(6913,'India','IN','Rajkot','RAJ'),

(6914,'India','IN','Rajouri','RJI'),

(6915,'Bangladesh','BD','Rajshani','RJH'),

(6916,'Papua New Guinea','PG','Rakanda','RAA'),

(6917,'USA','US','Raleigh-Durham~ NC','RDU'),

(6918,'India','IN','Ramagundam','RMD'),

(6919,'Nepal','NP','Ramechhap','RHP'),

(6920,'Australia','AU','Ramingining~ Northern Territory','RAM'),

(6921,'USA','US','Rampart~ AK','RMP'),

(6922,'Iran','IR','Ramsar','RZR'),

(6923,'Germany','DE','Ramstein','RMS'),

(6924,'Malaysia','MY','Ranau','RNU'),

(6925,'India','IN','Ranchi','IXR'),

(6926,'Mexico','MX','Rancho Buena Vista','RBV'),

(6927,'USA','US','Rancho California~ CA','RBK'),

(6928,'USA','US','Rancho Murieta~ CA','RIU'),

(6929,'USA','US','Rangely~ CO','RNG'),

(6930,'USA','US','Ranger~ TX','RGR'),

(6931,'French Polynesia','PF','Rangiroa~ Tuamotu Archipelago','RGI'),

(6932,'Bangladesh','BD','Rangpur','RAU'),

(6934,'Canada','CA','Rankin Inlet~ NT','YRT'),

(6935,'Indonesia','ID','Ransiki','RSK'),

(6936,'USA','US','Rapid City~ SD','RCA'),

(6938,'United Arab Emirates','AE','Ras al Khaymah','RKT'),

(6939,'Egypt','EG','Ras el Naqb (Ras an Naqb)','RAF'),

(6940,'Egypt','EG','Ras Nasrani','MFO'),

(6941,'Iran','IR','Rasht','RAS'),

(6942,'USA','US','Raspberry Strait~ AK','RSP'),

(6943,'India','IN','Ratnagiri','RTC'),

(6944,'USA','US','Raton~ NM','RTN'),

(6945,'Yemen','YE','Raudha','RXA'),

(6946,'Iceland','IS','Raufarhofn','RFN'),

(6947,'Italy','IT','Ravenna','RAN'),

(6948,'Pakistan','PK','Rawala Kot','RAZ'),

(6949,'Pakistan','PK','Rawalpindi','RWP'),

(6950,'USA','US','Rawlins~ WY','RWL'),

(6951,'Canada','CA','Rea Point~ NT','YOX'),

(6952,'French Polynesia','PF','Read','REA'),

(6953,'USA','US','Reading~ PA','RDG'),

(6954,'Japan','JP','Rebun','RBJ'),

(6955,'Brazil','BR','Recife~ PE','REC'),

(6956,'Argentina','AR','Reconquista','RCQ'),

(6957,'USA','US','Red Bluff~ CA','RBL'),

(6958,'Canada','CA','Red Deer~ AB','YQF'),

(6959,'USA','US','Red Devil~ AK','RDV'),

(6960,'USA','US','Red Dog~ AK','RDB'),

(6961,'Canada','CA','Red Lake~ ON','YRL'),

(6962,'USA','US','Red Oak~ IA','RDK'),

(6963,'USA','US','Red River~ ND','RDR'),

(6964,'Canada','CA','Red Sucker Lake~ ON','YRS'),

(6965,'USA','US','Red Wing~ MN','RGK'),

(6966,'Vanuatu','VU','Redcliffe','RCL'),

(6967,'USA','US','Redding~ CA','RDD'),

(6968,'Brazil','BR','Redencao','RDC'),

(6969,'United Kingdom','GB','Redhill~ England','KRH'),

(6970,'USA','US','Redmond~ OR','RDM'),

(6971,'USA','US','Redstone Arsenal/Huntsville~ AL ','HUA'),

(6972,'USA','US','Redwood Falls~ MN','RWF'),

(6973,'USA','US','Reed City~ MI','RCT'),

(6974,'USA','US','Reedsville~ PA','RED'),

(6975,'USA','US','Refugio~ TX','RFG'),

(6977,'Italy','IT','Reggio Calabria','REG'),

(6978,'French Guyana','GF','Regina','REI'),

(6979,'Canada','CA','Regina~ SK','YQR'),

(6980,'USA','US','Rehoboth Beach/Dewey Beach~ DE','REH'),

(6981,'USA','US','Reidsville~ GA','RVJ'),

(6982,'France','FR','Reims','RHE'),

(6983,'South Africa','ZA','Reivilo','RVO'),

(6984,'Indonesia','ID','Rengat','RGT'),

(6985,'Australia','AU','Renmark~ South Australia','RMK'),

(6986,'Solomon Islands','SB','Rennell Island','RNL'),

(6987,'France','FR','Rennes','RNS'),

(6988,'USA','US','Reno~ NV','RNO'),

(6989,'USA','US','Rensselaer~ IN','RNZ'),

(6990,'USA','US','Renton~ WA','RNT'),

(6991,'Canada','CA','Repulse Bay~ NT','YUT'),

(6992,'Spain','ES','Requena','REQ'),

(6993,'Brazil','BR','Resende~ RJ','QRZ'),

(6994,'Argentina','AR','Resistencia','RES'),

(6995,'Canada','CA','Resolute Bay~ NT','YRB'),

(6996,'Canada','CA','Resolution Island~ NT','YRE'),

(6997,'Greece','GR','Rethymnon~ Crete','ZRE'),

(6998,'Reunion','RE','Reunion (Saint Denis de la Reuni','RUN'),

(6999,'Spain','ES','Reus','REU'),

(7000,'Canada','CA','Revelstoke~ BC','YRV'),

(7001,'India','IN','Rewa','REW'),

(7002,'Bolivia','BO','Reyes','REY'),

(7003,'Iceland','IS','Reykholar','RHA'),

(7004,'Iceland','IS','Reykjarnes','GJR'),

(7005,'Iceland','IS','Reykjavik','KEF'),

(7007,'Mexico','MX','Reynosa','REX'),

(7008,'Iran','IR','Rezayieh','RZY'),

(7009,'Germany','DE','Rheindahlen','GMY'),

(7010,'USA','US','Rhinelander~ WI','RHI'),

(7011,'Greece','GR','Rhodos (Rhodes)~ Rhodos Island','RHO'),

(7012,'Bolivia','BO','Riberalta','RIB'),

(7013,'Brazil','BR','Riberao Preto~ SP','RAO'),

(7014,'USA','US','Rice Lake~ WI','RIE'),

(7015,'Senegal','SN','Richard Toll','RDT'),

(7016,'South Africa','ZA','Richards Bay','RCB'),

(7017,'USA','US','Richfield~ UT','RIF'),

(7018,'USA','US','Richland~ WA','RLD'),

(7019,'USA','US','Richmond~ IN','RID'),

(7020,'Australia','AU','Richmond~ Queensland','RCM'),

(7021,'USA','US','Richmond~ VA','RIC'),

(7022,'USA','US','Richmond/Ashland~ VA','OFP'),

(7023,'USA','US','Rifle~ CO','RIL'),

(7024,'Latvia','LV','Riga','RSC'),

(7026,'Canada','CA','Rigolet~ NF','YRG'),

(7027,'Croatia','HR','Rijeka','RJK'),

(7028,'Italy','IT','Rimini','RMI'),

(7029,'Canada','CA','Rimouski~ QC','YXK'),

(7030,'Solomon Islands','SB','Ringi Cove','RIN'),

(7031,'Panama','PA','Rio Alzucar','RIZ'),

(7032,'Brazil','BR','Rio Branco~ AC','RBR'),

(7033,'Argentina','AR','Rio Cuarto','RCU'),

(7034,'Brazil','BR','Rio de Janeiro~ RJ','GIG'),

(7037,'Costa Rica','CR','Rio Frio','RFR'),

(7038,'Argentina','AR','Rio Gallegos','RGL'),

(7039,'USA','US','Rio Grande Valley~ TX','RGV'),

(7040,'Argentina','AR','Rio Grande','RGA'),

(7041,'Brazil','BR','Rio Grande~ RS','RIG'),

(7042,'Argentina','AR','Rio Hondo','RHD'),

(7043,'Argentina','AR','Rio Mayo','ROY'),

(7044,'Panama','PA','Rio Sidra','RSI'),

(7045,'Brazil','BR','Rio so Sul~ SC','QRU'),

(7046,'Panama','PA','Rio Tigre','RIT'),

(7047,'Argentina','AR','Rio Turbio','RYO'),

(7048,'Brazil','BR','Rio Verde','RVD'),

(7049,'Colombia','CO','Riohacha','RCH'),

(7050,'Peru','PE','Rioja','RIJ'),

(7051,'Japan','JP','Rishiri','RIS'),

(7052,'Liberia','LR','River Cess','RVC'),

(7053,'Uruguay','UY','Rivera','RVY'),

(7054,'Canada','CA','Rivers Inlet~ BC','YRN'),

(7055,'Canada','CA','Rivers~ MB','YYI'),

(7056,'USA','US','Riverside (Rubidoux)~ CA','RIR'),

(7057,'USA','US','Riverside~ CA','RIV'),

(7060,'USA','US','Riverton~ WY','RIW'),

(7061,'Canada','CA','Riviere-du-Loup~ QC','YRI'),

(7062,'Canada','CA','Riviere au Tonnerre~ QC','YTN'),

(7063,'Ukraine','UA','Rivne (Rovno)~ Rivne','RWN'),

(7064,'Saudi Arabia','SA','Riyadh','RUH'),

(7066,'Yemen','YE','Riyan','RIY'),

(7067,'Turkey','TR','Rize','QRI'),

(7068,'France','FR','Roanne','RNE'),

(7069,'USA','US','Roanoke Rapids~ NC','RZZ'),

(7070,'USA','US','Roanoke~ VA','ROA'),

(7071,'Honduras','HN','Roatan','RTB'),

(7072,'Canada','CA','Roberval~ QC','YRJ'),

(7073,'Australia','AU','Robinhood~ Queensland','ROH'),

(7074,'Australia','AU','Robinson River~ Northern Territo','RRV'),

(7075,'Papua New Guinea','PG','Robinson River','RNR'),

(7076,'USA','US','Robinson~ IL','RSV'),

(7077,'Australia','AU','Robinvale~ Victoria','RBC'),

(7078,'Bolivia','BO','Robore','RBO'),

(7079,'USA','US','Roche Harbor~ WA','RCE'),

(7080,'France','FR','Rochefort','RCO'),

(7081,'USA','US','Rochester~ IN','RCR'),

(7082,'USA','US','Rochester~ MN','JRC'),

(7084,'USA','US','Rochester~ NY','ROC'),

(7085,'United Kingdom','GB','Rochester','RCS'),

(7086,'USA','US','Rock Hill~ SC','RKH'),

(7087,'USA','US','Rock Rapids~ IA','RRQ'),

(7088,'Bahamas','BS','Rock Sound~ Eleuthera','RSD'),

(7089,'USA','US','Rock Springs~ WY','RKS'),

(7090,'USA','US','Rockdale~ TX','RCK'),

(7091,'USA','US','Rockford~ IL','ZRF'),

(7094,'Australia','AU','Rockhampton Downs~ Northern Terr','RDA'),

(7095,'Australia','AU','Rockhampton~ Queensland','ROK'),

(7096,'USA','US','Rockland~ ME','RKD'),

(7097,'USA','US','Rockleigh~ NJ','RKL'),

(7098,'USA','US','Rockport~ TX','RKP'),

(7099,'USA','US','Rockwood~ TN','RKW'),

(7100,'USA','US','Rocky Mount~ NC','RMT'),

(7102,'Canada','CA','Rocky Mountain House~ AB','YRM'),

(7103,'France','FR','Rodez','RDZ'),

(7104,'Mauritius','MU','Rodrigues Island','RRG'),

(7105,'Peru','PE','Rodriguez de Mendez','RIM'),

(7106,'Australia','AU','Roebourne~ Western Australia','RBU'),

(7107,'USA','US','Rogers City~ MI','PZQ'),

(7108,'USA','US','Rogers~ AR','ROG'),

(7109,'Marshall Islands','MH','Roi-Namur','ROI'),

(7110,'Australia','AU','Rokeby~ Queensland','RKY'),

(7111,'Indonesia','ID','Rokot','RKI'),

(7112,'USA','US','Rolla~ MO','RLA'),

(7113,'USA','US','Rolla/Vichy~ MO','VIH'),

(7114,'Nepal','NP','Rolpa','RPA'),

(7115,'Italy','IT','Roma (Rome)','CIA'),

(7118,'Australia','AU','Roma~ Queensland','RMA'),

(7119,'USA','US','Roma~ TX','FAL'),

(7120,'USA','US','Rome~ GA','RMG'),

(7121,'USA','US','Rome~ NY','RME'),

(7122,'USA','US','Rome~ OR','REO'),

(7123,'Colombia','CO','Rondon','RON'),

(7124,'Brazil','BR','Rondonopolis~ MT','ROO'),

(7125,'Marshall Islands','MH','Rongelap','RNP'),

(7126,'Denmark','DK','Ronne (Roenne)','RNN'),

(7127,'Sweden','SE','Ronneby','RNB'),

(7128,'Puerto Rico','PR','Roosevelt Roads','NRR'),

(7129,'USA','US','Roosevelt~ UT','ROL'),

(7130,'Australia','AU','Roper Bar','RPB'),

(7131,'Australia','AU','Roper Valley~ Northern Territory','RPV'),

(7132,'Papua New Guinea','PG','Rorona','RNA'),

(7133,'Norway','NO','Roros','RRS'),

(7134,'Norway','NO','Rorvik (Roervik)','RVK'),

(7135,'Argentina','AR','Rosario','ROS'),

(7136,'USA','US','Rosario~ WA','RSJ'),

(7137,'USA','US','Roseau~ MN','ROX'),

(7138,'Australia','AU','Roseberth~ Queensland','RSB'),

(7139,'USA','US','Roseburg~ OR','RBG'),

(7140,'Sudan','SD','Roseires','RSS'),

(7141,'Australia','AU','Rosella Plains~ Queensland','RLP'),

(7142,'USA','US','Roseville~ CA','RVL'),

(7143,'Israel','IL','Rosh Pina','RPN'),

(7144,'Canada','CA','Ross River~ YT','XRR'),

(7145,'Norway','NO','Rost (Roest)','RET'),

(7146,'Germany','DE','Rostock','RLG'),

(7147,'Russia','RU','Rostov~ Rostov','ROV'),

(7148,'USA','US','Roswell~ NM','ROW'),

(7149,'Spain','ES','Rota','ZXA'),

(7150,'Mariana Islands','US','Rota Island','ROP'),

(7151,'Germany','DE','Rothenburg','QTK'),

(7152,'United Kingdom','GB','Rothesay','RAY'),

(7153,'Indonesia','ID','Roti','RTI'),

(7154,'New Zealand','NZ','Rotorua','ROT'),

(7155,'Netherlands','NL','Rotterdam','RTM'),

(7156,'Australia','AU','Rottnest Island~ Western Austral','RTS'),

(7157,'Fiji','FJ','Rotuma','RTA'),

(7158,'USA','US','Rotunda~ CA','RTD'),

(7159,'France','FR','Rouen','URO'),

(7160,'Canada','CA','Round Lake~ ON','ZRJ'),

(7161,'USA','US','Roundup~ MT','RPX'),

(7162,'India','IN','Rourkela','RRK'),

(7163,'USA','US','Rouses Point~ NY','RSX'),

(7164,'Canada','CA','Rouyn-Noranda~ QC','YUY'),

(7165,'Finland','FI','Rovaniemi','RVN'),

(7166,'USA','US','Rowan Bay~ AK','RWB'),

(7167,'Philippines','PH','Roxas','RXS'),

(7168,'USA','US','Roxboro~ NC','TDF'),

(7169,'Australia','AU','Roy Hill','RHL'),

(7170,'France','FR','Royan','RYN'),

(7171,'Guatemala','GT','Rubelsanto','RUV'),

(7172,'USA','US','Ruby~ AK','RBY'),

(7173,'China','CN','Rugao','RUG'),

(7174,'Rwanda','RW','Ruhengeri','RHG'),

(7175,'USA','US','Ruidoso~ NM','RUI'),

(7176,'Nepal','NP','Rukumkot','RUK'),

(7177,'Bahamas','BS','Rum Cay','RCY'),

(7178,'Papua New Guinea','PG','Rumginae','RMN'),

(7179,'Nepal','NP','Rumjartar','RUM'),

(7180,'Namibia','LC','Rundu','NDU'),

(7181,'India','IN','Rupsi','RUP'),

(7182,'Bolivia','BO','Rurrenabaque','RBQ'),

(7183,'French Polynesia','PF','Rurutu~ Tubuai Islands','RUR'),

(7184,'Bulgaria','BG','Ruse','ROU'),

(7185,'USA','US','Russell~ KS','RSL'),

(7186,'USA','US','Russian Mission~ AK','RSH'),

(7187,'USA','US','Ruston~ LA','RSN'),

(7188,'Indonesia','ID','Ruteng','RTG'),

(7189,'Australia','AU','Rutland Plains','RTP'),

(7190,'USA','US','Rutland~ VT','RUT'),

(7191,'Japan','JP','Ryotsu~ Sado Is.','SDO'),

(7192,'Poland','PL','Rzeszow','RZE'),

(7193,'Germany','DE','Saarbruecken (Saarbrucken)','SCN'),

(7194,'Netherlands Antilles','NL','Saba','SAB'),

(7195,'Spain','ES','Sabadell','QSA'),

(7196,'Papua New Guinea','PG','Sabah','SBV'),

(7197,'Dominican Republic','DO','Sabana de La Mar','SNX'),

(7198,'Colombia','CO','Sabana de Torres','SNT'),

(7199,'Canada','CA','Sable Island~ NS','YSA'),

(7200,'Canada','CA','Sachigo Lake~ NT','ZPB'),

(7201,'Canada','CA','Sachs Harbour~ NT','YSY'),

(7202,'USA','US','Sacramento~ CA','MHR'),

(7206,'Yemen','YE','Sadah','SYE'),

(7207,'Japan','JP','Sado Shima','SDS'),

(7208,'Argentina','AR','Saenz Pena','SZQ'),

(7209,'USA','US','Safford~ AZ','SAD'),

(7210,'Morocco','MA','Safi','SFI'),

(7211,'Papua New Guinea','PG','Safia','SFU'),

(7212,'Papua New Guinea','PG','Sagarai','SGJ'),

(7213,'USA','US','Saginaw~ MI','SGW'),

(7215,'Canada','CA','Saglek~ NF','YSV'),

(7216,'USA','US','Sagwon~ AK','SAG'),

(7217,'Malaysia','MY','Sahabat 16','SXS'),

(7218,'Pakistan','PK','Sahiwal','SWN'),

(7219,'Australia','AU','Saibai Island~ Queensland','SBR'),

(7220,'Bangladesh','BD','Said Pur','SPD'),

(7221,'Papua New Guinea','PG','Saidor','SDI'),

(7222,'Pakistan','PK','Saidu Sharif','SDT'),

(7223,'France','FR','Saint-Etienne','EBU'),

(7224,'France','FR','Saint-Nazaire','SNR'),

(7225,'France','FR','Saint-Yan','SYT'),

(7226,'Guadeloupe','GP','Saint Barthelemy','SBH'),

(7227,'France','FR','Saint Brieuc','SBK'),

(7228,'Guadeloupe','GP','Saint Francois','SFC'),

(7229,'Canada','CA','Saint John~ NB','YSJ'),

(7230,'Senegal','SN','Saint Louis','XLS'),

(7231,'Guadeloupe','GP','Saint Martin','SFG'),

(7233,'Reunion','RE','Saint Pierre','ZSE'),

(7234,'Mariana Islands','US','Saipan','SPN'),

(7235,'Thailand','TH','Sakon Nakhon','SNO'),

(7236,'Cape Verde','CV','Sal~ Sal','SID'),

(7237,'Oman','OM','Salalah','SLL'),

(7238,'Spain','ES','Salamanca','SLM'),

(7239,'Papua New Guinea','PG','Salamo','SAM'),

(7240,'Australia','AU','Sale~ Victoria','SXE'),

(7241,'USA','US','Salem~ IL','SLO'),

(7242,'USA','US','Salem~ OR','SLE'),

(7243,'Italy','IT','Salerno','QSR'),

(7244,'USA','US','Salida~ CO','SLT'),

(7245,'Malawi','MW','Salima','LMB'),

(7246,'Mexico','MX','Salina Cruz','SCX'),

(7247,'USA','US','Salina~ KS','SLN'),

(7248,'USA','US','Salina~ UT','SBO'),

(7249,'Ecuador','EC','Salinas','SNC'),

(7250,'USA','US','Salinas~ CA','SNS'),

(7251,'USA','US','Salisbury~ MD','SBY'),

(7252,'USA','US','Salisbury~ NC','SRW'),

(7253,'Canada','CA','Salluit~ QC','YZG'),

(7254,'Canada','CA','Salmon Arm~ BC','YSN'),

(7255,'USA','US','Salmon~ ID','SMN'),

(7256,'Turks & Caicos','TC','Salt Cay~ Salt Cay','SLX'),

(7257,'USA','US','Salt Lake City~ UT','SLC'),

(7258,'Argentina','AR','Salta','SLA'),

(7259,'Mexico','MX','Saltillo','SLW'),

(7260,'Uruguay','UY','Salto','STY'),

(7261,'USA','US','Salton City~ CA','SAS'),

(7262,'Brazil','BR','Salvador~ BA','SSA'),

(7263,'Austria','AT','Salzburg','SZG'),

(7264,'Russia','RU','Samara~ Samara','KUF'),

(7265,'Indonesia','ID','Samarinda','SRI'),

(7266,'Uzbekhistan','UZ','Samarqand (Samarkand)~ Samarqand','SKD'),

(7267,'Madagascar','MG','Sambava','SVB'),

(7268,'Panama','PA','Sambu','SAX'),

(7269,'Kenya','KE','Samburu','UAS'),

(7270,'South Korea','KR','Samchok','SUK'),

(7271,'Switzerland','CH','Samedan/St. Moritz','SMV'),

(7272,'Greece','GR','Samos~ Samos Island','SMI'),

(7273,'Indonesia','ID','Sampit~ Borneo','SMQ'),

(7274,'Turkey','TR','Samsun','SSX'),

(7275,'Colombia','CO','San Andres Island~ San Andres','ADZ'),

(7276,'Bahamas','BS','San Andros (Nichols Town)~ Andro','SAQ'),

(7277,'USA','US','San Angelo~ TX','GOF'),

(7279,'Argentina','AR','San Antonio Oeste','OES'),

(7280,'USA','US','San Antonio~ TX','SKF'),

(7281,'TX [Martindale Army Air Field] USA','US','San Antonio','MDA'),

(7284,'Venezuela','VE','San Antonio','SVZ'),

(7285,'USA','US','San Bernardino~ CA','SBT'),

(7287,'Panama','PA','San Blas','NBL'),

(7288,'Bolivia','BO','San Borja','SRJ'),

(7289,'Argentina','AR','San Carlos de Bariloche','BRC'),

(7290,'USA','US','San Carlos~ CA','SQL'),

(7291,'CA USA','US','San Clemente Island','NUC'),

(7292,'Venezuela','VE','San Cristobal','SCI'),

(7293,'USA','US','San Diego (El Cajon)~ CA','SEE'),

(7294,'USA','US','San Diego~ CA','SDM'),

(7299,'Honduras','HN','San Esteban','SET'),

(7300,'Colombia','CO','San Felipe','SSD'),

(7301,'Mexico','MX','San Felipe','SFH'),

(7302,'Venezuela','VE','San Felipe','SNF'),

(7303,'Venezuela','VE','San Felix','SFX'),

(7304,'Venezuela','VE','San Fernando de Apu','SFD'),

(7305,'USA','US','San Fernando~ CA','SFR'),

(7306,'Philippines','PH','San Fernando','SFE'),

(7307,'USA','US','San Francisco~ CA','JCC'),

(7311,'Peru','PE','San Francisco','SCY'),

(7312,'Mexico','MX','San Francisquito','SFQ'),

(7313,'Bolivia','BO','San Ignacio de Moxos','SNM'),

(7314,'Bolivia','BO','San Ignacio de VLS','SNG'),

(7315,'Mexico','MX','San Ignacio','SGM'),

(7316,'Dominican Republic','DO','San Isidro','ZXD'),

(7317,'Bolivia','BO','San Javier','SJV'),

(7318,'Bolivia','BO','San Joaquin','SJB'),

(7319,'Costa Rica','CR','San Jose','OCO'),

(7321,'Colombia','CO','San Jose del Guaviaro','SJE'),

(7322,'Bolivia','BO','San Jose','SJS'),

(7323,'USA','US','San Jose~ CA','RHV'),

(7325,'Philippines','PH','San Jose','SJI'),

(7326,'Puerto Rico','PR','San Juan','SIG'),

(7328,'Peru','PE','San Juan Aposento','APE'),

(7329,'Dominican Republic','DO','San Juan de la Mar','SJM'),

(7330,'Colombia','CO','San Juan de Uraba','SJR'),

(7331,'Colombia','CO','San Juan del Cesar','SJH'),

(7332,'USA','US','San Juan~ AK','WSJ'),

(7333,'Argentina','AR','San Juan','UAQ'),

(7334,'Peru','PE','San Juan','SJA'),

(7335,'Argentina','AR','San Julian','ULA'),

(7336,'Cuba','CU','San Julian','SNJ'),

(7337,'Colombia','CO','San Luis de Palenque','SQE'),

(7338,'CA USA','US','San Luis Obispo','CSL'),

(7340,'Mexico','MX','San Luis Potosi','SLP'),

(7341,'Mexico','MX','San Luis Rio Colorado','UAC'),

(7342,'Argentina','AR','San Luis','LUQ'),

(7343,'Colombia','CO','San Marcos','SRS'),

(7344,'San Marino','SM','San Marino','SAI'),

(7345,'Argentina','AR','San Martin de los Andes','CPC'),

(7346,'Panama','PA','San Miguel','NMG'),

(7347,'Cuba','CU','San Nicolas de Bari','QSN'),

(7348,'Spain','ES','San Pablo','SPO'),

(7349,'USA','US','San Pedro (Catalina Island)~ CA ','SPQ'),

(7350,'Belize','BZ','San Pedro','SPR'),

(7351,'Colombia','CO','San Pedro de Uraba','NPU'),

(7352,'Colombia','CO','San Pedro Jagua','SJG'),

(7353,'Honduras','HN','San Pedro Sula','SAP'),

(7354,'Ivory Coast','CI','San Pedro','SPY'),

(7355,'Mexico','MX','San Quintin','SNQ'),

(7356,'Argentina','AR','San Rafael','AFA'),

(7357,'Bolivia','BO','San Ramon','SRD'),

(7358,'Bahamas','BS','San Salvador (Cockburn Town)~ Sa','ZSA'),

(7359,'El Salvador','SV','San Salvador','SAL'),

(7360,'Venezuela','VE','San Salvador','SVV'),

(7361,'Spain','ES','San Sebastian','EAS'),

(7362,'Venezuela','VE','San Tome','SOM'),

(7363,'Colombia','CO','San Vicente del Caguan','SVI'),

(7364,'Yemen','YE','Sanaa (Sana\'a)','SAH'),

(7365,'Indonesia','ID','Sanana','SQN'),

(7366,'Iran','IR','Sanandaj','SDG'),

(7367,'Cuba','CU','Sancti Spiritu','QSP'),

(7368,'USA','US','Sand Point~ AK','SDP'),

(7369,'Malaysia','MY','Sandakan~ Sabah','SDK'),

(7370,'Norway','NO','Sandane','SDN'),

(7371,'United Kingdom','GB','Sanday~ Orkney Islands~ Scotland','NDY'),

(7372,'Guyana','GY','Sandcreek','SDC'),

(7373,'Norway','NO','Sandefjord','TRF'),

(7374,'USA','US','Sandersville~ GA','OKZ'),

(7375,'Norway','NO','Sandnessjoen','SSJ'),

(7376,'Myanmar','MM','Sandoway','SNW'),

(7377,'Australia','AU','Sandringham~ Queensland','SRM'),

(7378,'Canada','CA','Sandspit~ BC','YZP'),

(7379,'Australia','AU','Sandstone~ Western Australia','NDS'),

(7380,'USA','US','Sandusky~ OH','SKY'),

(7381,'Bangladesh','BD','Sandwip','SDW'),

(7382,'Canada','CA','Sandy Lake~ ON','ZSJ'),

(7383,'USA','US','Sandy~ OR','KSR'),

(7384,'Nepal','NP','Sanfebagar','FEB'),

(7385,'USA','US','Sanford~ FL','SFB'),

(7386,'USA','US','Sanford~ ME','SFM'),

(7387,'Philippines','PH','Sanga Sanga','SGS'),

(7388,'Papua New Guinea','PG','Sangapi','SGK'),

(7389,'Indonesia','ID','Sanggata','SGQ'),

(7390,'Indonesia','ID','Sangir','SAE'),

(7391,'Philippines','PH','Sangley Point','NSP'),

(7392,'Canada','CA','Sanikiluaq~ NT','YSK'),

(7393,'Canada','CA','Sans Souci~ ON','YSI'),

(7394,'Solomon Islands','SB','Santa Ana','NNB'),

(7395,'Bolivia','BO','Santa Ana','SBL'),

(7396,'USA','US','Santa Ana~ CA','NZJ'),

(7397,'Colombia','CO','Santa Ana','SQB'),

(7398,'USA','US','Santa Barbara~ CA','DNT'),

(7401,'Venezuela','VE','Santa Barbara','SBB'),

(7403,'Mozambique','MZ','Santa Carolina','NTC'),

(7404,'Colombia','CO','Santa Catalina','SCA'),

(7405,'Ecuador','EC','Santa Cecilia','WSE'),

(7406,'Cuba','CU','Santa Clara','SNU'),

(7407,'Portugal','PT','Santa Cruz (Flores Island)~ Azor','FLW'),

(7408,'Bolivia','BO','Santa Cruz','SRZ'),

(7410,'Spain','ES','Santa Cruz de la Palma','SPC'),

(7411,'Spain','ES','Santa Cruz de Tenerife~ Canary I','TFS'),

(7412,'Argentina','AR','Santa Cruz','RZA'),

(7413,'Belize','BZ','Santa Cruz','STU'),

(7414,'Brazil','BR','Santa Cruz','SNZ'),

(7415,'USA','US','Santa Cruz~ CA','SRU'),

(7416,'Costa Rica','CR','Santa Cruz','SZC'),

(7417,'Solomon Islands','SB','Santa Cruz','SCZ'),

(7418,'Mexico','MX','Santa Cruz/Huatulco','HUX'),

(7419,'Guatemala','GT','Santa Elena','SNV'),

(7420,'Argentina','AR','Santa Fe','SFN'),

(7421,'Brazil','BR','Santa Fe do Sul','SFV'),

(7422,'USA','US','Santa Fe~ NM','ZSH'),

(7424,'Panama','PA','Santa Fe','SFW'),

(7425,'USA','US','Santa Inez~ CA','SQA'),

(7426,'Brazil','BR','Santa Isabel','IDO'),

(7427,'Egypt','EG','Santa Katarina','SKV'),

(7428,'Peru','PE','Santa Lucia','SQD'),

(7429,'Portugal','PT','Santa Maria~ Azores','SMA'),

(7430,'USA','US','Santa Maria~ CA','SMX'),

(7431,'Colombia','CO','Santa Maria','SMC'),

(7432,'Peru','PE','Santa Maria','SMG'),

(7433,'Brazil','BR','Santa Maria~ RS','RIA'),

(7434,'Colombia','CO','Santa Marta','SMR'),

(7435,'USA','US','Santa Monica~ CA','SMO'),

(7436,'USA','US','Santa Paula~ CA','SZP'),

(7437,'Honduras','HN','Santa Rosa de Copan','SDH'),

(7438,'Argentina','AR','Santa Rosa','RSA'),

(7439,'Bolivia','BO','Santa Rosa','SRB'),

(7440,'USA','US','Santa Rosa~ CA','STS'),

(7441,'Brazil','BR','Santa Rosa~ RS','SRA'),

(7442,'Mexico','MX','Santa Rosalia','SRL'),

(7443,'Venezuela','VE','Santa Rosalia','SSL'),

(7444,'Argentina','AR','Santa Teresita','SST'),

(7445,'Brazil','BR','Santa Terezinha','STZ'),

(7446,'Brazil','BR','Santa Vitoria~ MG','CTQ'),

(7447,'USA','US','Santa Ynez~ CA','IZA'),

(7448,'Brazil','BR','Santana do Livramento~ RS','LVB'),

(7449,'Colombia','CO','Santana Ramos','SRO'),

(7450,'Spain','ES','Santander','SDR'),

(7451,'Brazil','BR','Santarem~ PA','STM'),

(7452,'Cuba','CU','Santiago','SCU'),

(7453,'Dominican Republic','DO','Santiago','STI'),

(7454,'Chile','CL','Santiago de Chile','SCL'),

(7456,'Spain','ES','Santiago de Compostela','SCQ'),

(7457,'Argentina','AR','Santiago del Estero','SDE'),

(7458,'Brazil','BR','Santo Andre~ SP','QSE'),

(7459,'Brazil','BR','Santo Angelo~ RS','GEL'),

(7460,'Cape Verde','CV','Santo Antao','NTO'),

(7461,'Dominican Republic','DO','Santo Domingo','SDQ'),

(7462,'Venezuela','VE','Santo Domingo','STD'),

(7463,'Dominican Republic','DO','Santo Don Herrera','HEX'),

(7464,'Greece','GR','Santorini~ Thira','JTR'),

(7465,'Brazil','BR','Santos~ SP','SSZ'),

(7466,'China','CN','Sanya','SYX'),

(7467,'Brazil','BR','Sao Bento do Sul~ SC','QHE'),

(7468,'Brazil','BR','Sao Bernardo do Campo~ SP','QSB'),

(7469,'Brazil','BR','Sao Caetano do Sul~ SP','QCX'),

(7470,'Brazil','BR','Sao Carlos~ SP','QSC'),

(7471,'Guinea Bissau','GN','Sao Domingos','SLY'),

(7472,'Cape Verde','CV','Sao Felipe','SFL'),

(7473,'Brazil','BR','Sao Felix Araguai','SXO'),

(7474,'Brazil','BR','Sao Felix de Xingu','SXX'),

(7475,'Brazil','BR','Sao Francisco do Sul~ SC','QFS'),

(7476,'Brazil','BR','Sao Gabriel','SJL'),

(7477,'Brazil','BR','Sao Goncalo do Amarante~ RN','QTE'),

(7478,'Brazil','BR','Sao Goncalo~ RJ','QSD'),

(7479,'Brazil','BR','Sao Joao del Rei~ MG','QSJ'),

(7480,'Portugal','PT','Sao Jorge~ Azores','SJZ'),

(7481,'Brazil','BR','Sao Jose do Rio Preto~ SP','SJP'),

(7482,'Brazil','BR','Sao Jose do Xingu','SXN'),

(7483,'Brazil','BR','Sao Jose dos Lampos~ SP','SJK'),

(7484,'Brazil','BR','Sao Leopoldo~ RS','QLL'),

(7485,'Brazil','BR','Sao Lourenco','SSO'),

(7486,'Brazil','BR','Sao Luis~ MA','SLZ'),

(7487,'Brazil','BR','Sao Mateus~ ES','SBJ'),

(7488,'Brazil','BR','Sao Miguel de Aragao','SQM'),

(7489,'Cape Verde','CV','Sao Nicolau~ Sao Nicolau','SNE'),

(7490,'Brazil','BR','Sao Paulo~ SP','CGH'),

(7494,'Brazil','BR','Sao Paulo/Campinas~ SP','VCP'),

(7495,'Sao Tome & Principe','ST','Sao Tome~ Sao Tome','TMS'),

(7496,'Cape Verde','CV','Sao Vicente~ Sao Vicente','VXE'),

(7497,'Papua New Guinea','PG','Sapmanga','SMH'),

(7498,'Japan','JP','Saporro','SPK'),

(7499,'Peru','PE','Saposoa','SFS'),

(7500,'Japan','JP','Sapporo','OKD'),

(7501,'Fiji','FJ','Saqani','AQS'),

(7502,'Vanuatu','VU','Sara','SSR'),

(7503,'Bosnia-Herzegovina','BA','Sarajevo','SJJ'),

(7504,'USA','US','Saranac Lake~ NY','SLK'),

(7505,'Russia','RU','Saransk~ Mordvinia','SKX'),

(7506,'USA','US','Sarasota/Bradenton~ FL','SRQ'),

(7507,'USA','US','Saratoga~ WY','SAA'),

(7508,'Russia','RU','Saratov~ Saratov','RTW'),

(7509,'Laos','LA','Saravane','VNA'),

(7510,'Colombia','CO','Saravena','RVE'),

(7511,'Afghanistan','AF','Sardeh Band','SBF'),

(7512,'Pakistan','PK','Sargodha','BHW'),

(7514,'Chad','TD','Sarh','SRH'),

(7515,'USA','US','Sarichef~ AK','WSF'),

(7516,'Indonesia','ID','Sarmi~ New Guinea','ZRM'),

(7517,'Canada','CA','Sarnia~ ON','YZR'),

(7518,'Belize','BZ','Sartaneja','SJX'),

(7519,'Iran','IR','Sary','SRY'),

(7520,'Canada','CA','Saskatoon~ SK','YXE'),

(7521,'Ivory Coast','CI','Sassandra','ZSS'),

(7522,'Liberia','LR','Sasstown','SAZ'),

(7523,'Peru','PE','Satipo','SFK'),

(7524,'India','IN','Satna','TNI'),

(7525,'Romania','RO','Satu Mare','SUJ'),

(7526,'Papua New Guinea','PG','Saubi','SBE'),

(7527,'Iceland','IS','Saudarkrokur','SAK'),

(7528,'French Guyana','GF','Saul','XAU'),

(7529,'USA','US','Sault Ste. Marie~ MI','CIU'),

(7531,'MI USA','US','Sault Ste. Marie','SSM'),

(7532,'Canada','CA','Sault Ste. Marie~ ON','YAM'),

(7533,'Indonesia','ID','Saumlaki','SXK'),

(7534,'Angola','AO','Saurimo','VHC'),

(7535,'USA','US','Sausalito~ CA','JMC'),

(7536,'USA','US','Savannah~ GA','SVN'),

(7538,'Laos','LA','Savannakhet','ZVK'),

(7539,'Benin','BJ','Save','SVF'),

(7540,'Solomon Islands','SB','Savo','SVY'),

(7541,'Finland','FI','Savonlinna','SVL'),

(7542,'USA','US','Savoonga~ AK','SVA'),

(7543,'Fiji','FJ','Savusavu','SVU'),

(7544,'Indonesia','ID','Sawu','SAU'),

(7545,'Laos','LA','Sayaboury','ZBY'),

(7546,'USA','US','Scammon Bay~ AK','SCM'),

(7547,'United Kingdom','GB','Scampton~ England','SQZ'),

(7548,'Canada','CA','Schefferville~ QC','YKL'),

(7549,'USA','US','Schenectady~ NY','SCH'),

(7550,'United Kingdom','GB','Scilly Isles~ England','ISC'),

(7551,'United Kingdom','GB','Scilly Tresco','TSO'),

(7552,'Australia','AU','Scone~ New South Wales','NSO'),

(7553,'Greenland','GL','Scoresbysund','OBY'),

(7554,'USA','US','Scott City~ KS','TQK'),

(7555,'USA','US','Scottsbluff~ NE','BFF'),

(7556,'USA','US','Scottsdale~ AZ','SCF'),

(7557,'USA','US','Scranton~ PA','SCR'),

(7558,'USA','US','Scribner~ NE','SCB'),

(7559,'United Kingdom','GB','Sculthorpe','ZXE'),

(7560,'Somalia','SO','Scusciuban','CMS'),

(7561,'USA','US','Seal Bay~ AK','SYB'),

(7562,'USA','US','Searcy~ AR','SRC'),

(7563,'USA','US','Seattle (Kenmore)~ WA','KEH'),

(7564,'USA','US','Seattle~ WA','BFI'),

(7567,'Burkina Faso','BF','Sebba','XSE'),

(7568,'Libya','LY','Sebha','SEB'),

(7569,'USA','US','Sebring~ FL','SEF'),

(7570,'Canada','CA','Sechelt~ BC','YHS'),

(7571,'South Africa','ZA','Seconda','ZEC'),

(7572,'USA','US','Sedalia~ MO','DMO'),

(7573,'Israel','IL','Sedom','SED'),

(7574,'USA','US','Sedona~ AZ','SDX'),

(7575,'Germany','DE','Seeheim','QSH'),

(7576,'Solomon Islands','SB','Sege','EGM'),

(7577,'Mali','ML','Segou','SZU'),

(7578,'Ivory Coast','CI','Seguela','SEO'),

(7579,'Lesotho','LS','Sehonghong','SHK'),

(7580,'Papua New Guinea','PG','Sehulea','SXH'),

(7581,'Finland','FI','Seinajoki','SJY'),

(7582,'Yemen','YE','Seiyun','GXF'),

(7583,'Lesotho','LS','Sekakes','SKQ'),

(7584,'USA','US','Selawik~ AK','WLK'),

(7585,'USA','US','Seldovia~ AK','SOV'),

(7586,'Mauritania','MR','Selibaby','SEY'),

(7587,'Botswana','BW','Selibi Phikwe','PKW'),

(7588,'USA','US','Selinsgrove~ PA','SEG'),

(7589,'USA','US','Selma~ AL','SEM'),

(7591,'USA','US','Selmer~ TN','SZY'),

(7592,'Indonesia','ID','Semarang','SRG'),

(7593,'Malaysia','MY','Sematan','BSE'),

(7594,'Germany','DE','Sembach','SEX'),

(7595,'Kazakhstan','KZ','Semey (Semipalatinsk)~ Semey','PLX'),

(7596,'Lesotho','LS','Semongkong','SOK'),

(7597,'Malaysia','MY','Semporna~ Sabah','SMM'),

(7598,'Brazil','BR','Sena Madureira~ AC','ZMD'),

(7599,'Zambia','ZM','Senanga','SXG'),

(7600,'Japan','JP','Sendai~ Honshu','SDJ'),

(7601,'Indonesia','ID','Senggeh','SEH'),

(7602,'Indonesia','ID','Senggo','ZEG'),

(7603,'Brazil','BR','Senhor do Bonfim~ BA','SEI'),

(7604,'Indonesia','ID','Senipah','SZH'),

(7605,'Laos','LA','Seno','SND'),

(7606,'Spain','ES','Seo de Urgel','LEU'),

(7607,'South Korea','KR','Seoul','JGE'),

(7610,'Canada','CA','Sept-Iles~ QC','YZV'),

(7611,'Malaysia','MY','Sepulot','SPE'),

(7612,'USA','US','Sequim~ WA','SQV'),

(7613,'Tanzania','TZ','Seronera','SEU'),

(7614,'Brazil','BR','Serra Norte~ MT','RRN'),

(7615,'Brazil','BR','Serra Pelada','RSG'),

(7616,'France','FR','Serre Chevalier','SEC'),

(7617,'Libya','LY','Sert','SRX'),

(7618,'Indonesia','ID','Serui','ZRI'),

(7619,'Zambia','ZM','Sesheke','SJQ'),

(7620,'Lesotho','LS','Seshutes','SHZ'),

(7621,'Gabon','GA','Sette Cama','ZKM'),

(7622,'Spain','ES','Sevilla','SVQ'),

(7623,'USA','US','Sewanee~ TN','UOS'),

(7624,'USA','US','Seward~ AK','SWD'),

(7625,'USA','US','Seymour~ IN','SER'),

(7626,'Tunisia','TN','Sfax','SFA'),

(7627,'USA','US','Shafter~ CA','MIT'),

(7628,'USA','US','Shageluk~ AK','SHX'),

(7629,'Ethiopia','ET','Shakiso','SKR'),

(7630,'USA','US','Shaktoolik~ AK','SKK'),

(7631,'Canada','CA','Shamattawa~ MB','ZTM'),

(7632,'Bangladesh','BD','Shamshernagar','ZHM'),

(7633,'China','CN','Shanghai','SHA'),

(7634,'USA','US','Shangri La~ OK','NRI'),

(7635,'China','CN','Shanhaiguan','SHF'),

(7636,'Ireland','IE','Shannon (Limerick)','SNN'),

(7637,'China','CN','Shantou','SWA'),

(7638,'China','CN','Shaoguan','HSC'),

(7639,'United Arab Emirates','AE','Sharjah','SHJ'),

(7640,'Egypt','EG','Sharm El Sheikh','SSH'),

(7641,'USA','US','Sharpe Army Depot (Lathrop)~ CA ','LRO'),

(7642,'Saudi Arabia','SA','Sharurah','SHW'),

(7643,'China','CN','Shashi','SHS'),

(7644,'Lithuania','LT','Shauliaj','HLJ'),

(7645,'Australia','AU','Shaw River~ Western Australia','SWB'),

(7646,'USA','US','Shawnee~ OK','SNL'),

(7647,'Australia','AU','Shay Gap~ Western Australia','SGP'),

(7648,'USA','US','Sheboygan~ WI','SBM'),

(7649,'USA','US','Sheep Mountain~ AK','SMU'),

(7650,'Ethiopia','ET','Shehdi','SQJ'),

(7651,'USA','US','Shelby~ MT','SBX'),

(7652,'USA','US','Shelby~ NC','EHO'),

(7653,'USA','US','Shelbyville~ TN','SYI'),

(7654,'USA','US','Sheldon Point~ AK','SXP'),

(7655,'USA','US','Shelton~ WA','SHN'),

(7656,'USA','US','Shemya Island~ AK','SYA'),

(7657,'China','CN','Shenchiu','SYQ'),

(7658,'China','CN','Shenyang','SHE'),

(7659,'Canada','CA','Sheperd Bay~ NT','YUS'),

(7660,'Australia','AU','Shepparton~ Victoria','SHT'),

(7661,'Canada','CA','Sherbrooke~ QC','YSC'),

(7662,'USA','US','Sheridan~ WY','SHR'),

(7663,'USA','US','Sherman/Denison~ TX','PNX'),

(7664,'United Kingdom','GB','Shetland Islands~ Shetland Islan','SDZ'),

(7665,'China','CN','Shijiazhuang','SJW'),

(7666,'Ethiopia','ET','Shillavo','HIL'),

(7667,'India','IN','Shillong','SHL'),

(7668,'Canada','CA','Shilo~ MB','YLO'),

(7669,'Kazakhstan','KZ','Shimkent (Chimkent)~ South Kazak','CIT'),

(7670,'Japan','JP','Shimojishima','SHI'),

(7671,'Taiwan','TW','Shin Chu','SQH'),

(7672,'Canada','CA','Shingle Point~ YT','YUA'),

(7673,'Tanzania','TZ','Shinyanga','SHY'),

(7674,'Iran','IR','Shiraz','SYZ'),

(7675,'USA','US','Shirley~ NY','WSH'),

(7676,'USA','US','Shishmaref~ AK','SHH'),

(7677,'Japan','JP','Shizuoka City','QSZ'),

(7678,'USA','US','Shoal Cove~ AK','HCB'),

(7679,'India','IN','Sholapur','SSE'),

(7680,'Japan','JP','Shonai','SYO'),

(7681,'United Kingdom','GB','Shoreham','ESH'),

(7682,'USA','US','Show Low~ AZ','SOW'),

(7683,'USA','US','Shreveport~ LA','DTN'),

(7685,'USA','US','Shungnak~ AK','SHG'),

(7686,'Australia','AU','Shute Harbour~ Queensland','JHQ'),

(7687,'Pakistan','PK','Sialkot','SKT'),

(7688,'Papua New Guinea','PG','Sialum','SXA'),

(7689,'Papua New Guinea','PG','Siassi','SSS'),

(7690,'South Africa','ZA','Sibasa','SBC'),

(7691,'Pakistan','PK','Sibi','SBQ'),

(7692,'Indonesia','ID','Sibisa','SIW'),

(7693,'Congo','CG','Sibiti','SIB'),

(7694,'Romania','RO','Sibiu','SBZ'),

(7695,'Malaysia','MY','Sibu~ Sarawak','SBW'),

(7696,'Morocco','MA','Sidi Ifni','SII'),

(7697,'USA','US','Sidney~ MT','SDY'),

(7698,'USA','US','Sidney~ NE','SNY'),

(7699,'USA','US','Sidney~ NY','SXY'),

(7700,'Germany','DE','Siegen','SGE'),

(7701,'Cambodia','KH','Siem Reap','REP'),

(7702,'Italy','IT','Siena','SAY'),

(7703,'Argentina','AR','Sierra Grande','SGV'),

(7704,'Sierra Leone','SL','Sierra Leone','SRK'),

(7705,'Iceland','IS','Siglufjordur','SIJ'),

(7706,'Italy','IT','Sigonella','NSY'),

(7707,'Guinea','GN','Siguiri','GII'),

(7708,'Mali','ML','Sikasso','KSS'),

(7709,'USA','US','Sikeston~ MO','SIK'),

(7710,'Papua New Guinea','PG','Sila','SIL'),

(7711,'India','IN','Silchar','IXS'),

(7712,'Nepal','NP','Silgadi Doti','SIH'),

(7713,'Bulgaria','BG','Silistra','SLS'),

(7714,'USA','US','Siloam Springs~ AR','SLG'),

(7715,'USA','US','Silver Bay~ MN','BFW'),

(7716,'USA','US','Silver City~ NM','SVC'),

(7717,'Belize','BZ','Silver Creek','SVK'),

(7718,'Australia','AU','Silver Plains~ Queensland','SSP'),

(7719,'Papua New Guinea','PG','Sim','SMJ'),

(7720,'Malaysia','MY','Simanggang','SGG'),

(7721,'China','CN','Simao','SYM'),

(7722,'Papua New Guinea','PG','Simbai','SIM'),

(7723,'Russia','RU','Simbirsk (Ulyanovsk)~ Ul\'yanovsk','ULY'),

(7724,'Senegal','SN','Simenti','SMY'),

(7725,'Ukraine','UA','Simferopol~ Adygea','SIP'),

(7726,'Nepal','NP','Simikot','IMK'),

(7727,'India','IN','Simla','SLV'),

(7728,'USA','US','Simmons~ MI','XMQ'),

(7729,'Nepal','NP','Simra','SIF'),

(7730,'Denmark','DK','Sindal','CNL'),

(7731,'Portugal','PT','Sines','SIE'),

(7732,'Singapore','SG','Singapore','SIN'),

(7735,'Papua New Guinea','PG','Singaua','SGB'),

(7736,'Indonesia','ID','Singkep','SIQ'),

(7737,'Australia','AU','Singleton~ New South Wales','SIX'),

(7738,'Liberia','LR','Sinoe','SNI'),

(7739,'Turkey','TR','Sinop','SIC'),

(7740,'Brazil','BR','Sinop~ MT','OPS'),

(7741,'Indonesia','ID','Sintang~ Borneo','SQG'),

(7742,'Switzerland','CH','Sion (Sitten)','SIR'),

(7743,'USA','US','Sioux City~ IA','SUX'),

(7744,'USA','US','Sioux Falls~ SD','FSD'),

(7745,'Canada','CA','Sioux Lookout~ ON','YXL'),

(7746,'Malaysia','MY','Sipitang','SPT'),

(7747,'Indonesia','ID','Sipora','RKO'),

(7748,'Bangladesh','BD','Sirajganj','SAJ'),

(7749,'USA','US','Siren~ WI','RZN'),

(7750,'Nepal','NP','Sirkhet','SKH'),

(7751,'Iran','IR','Sirri Island','SXI'),

(7752,'South Africa','ZA','Sishen','SIS'),

(7753,'Papua New Guinea','PG','Sissano','SIZ'),

(7754,'Greece','GR','Sitia~ Crete','JSH'),

(7755,'Malaysia','MY','Sitiawan','SWY'),

(7756,'USA','US','Sitka~ AK','SIT'),

(7757,'USA','US','Sitkinak~ AK','SKJ'),

(7758,'Myanmar','MM','Sittwe (Akyab)','AKY'),

(7759,'Nicaragua','NI','Siuna','SIU'),

(7760,'Turkey','TR','Sivas','VAS'),

(7761,'Egypt','EG','Siwa','SEW'),

(7762,'Papua New Guinea','PG','Siwea','SWE'),

(7763,'USA','US','Skagway~ AK','SGY'),

(7764,'Pakistan','PK','Skardu','KDU'),

(7765,'Norway','NO','Skein','SKE'),

(7766,'Guyana','GY','Skeldon','SKM'),

(7767,'Sweden','SE','Skelleftea','SFT'),

(7768,'Greece','GR','Skiathos','JSI'),

(7769,'Algeria','DZ','Skikda','SKI'),

(7770,'Greece','GR','Skiros','SKU'),

(7771,'Macedonia','MK','Skopje','SKP'),

(7772,'Sweden','SE','Skovde','KVB'),

(7773,'Denmark','DK','Skrydstrup','SKS'),

(7774,'South Africa','ZA','Skukuza','SZK'),

(7775,'USA','US','Skwentna~ AK','SKW'),

(7776,'Canada','CA','Slate Island~ ON','YSS'),

(7777,'Canada','CA','Slave Lake~ AB','YZH'),

(7778,'USA','US','Sleetmute~ AK','SLQ'),

(7779,'Slovakia','SK','Sliac','SLD'),

(7780,'Ireland','IE','Sligo','SXL'),

(7781,'Poland','PL','Slupsk','OSP'),

(7782,'Morocco','MA','Smara','SMW'),

(7783,'Australia','AU','Smiggin Holes~ New South Wales','QZC'),

(7784,'USA','US','Smith Cove~ AK','SCJ'),

(7785,'Canada','CA','Smith Falls/Montague~ ON','YSH'),

(7786,'Australia','AU','Smith Point~ Northern Territory','SHU'),

(7787,'Canada','CA','Smithers~ BC','YYD'),

(7788,'Australia','AU','Smithton~ Tasmania','SIO'),

(7789,'Russia','RU','Smolensk~ Smolensk','LNX'),

(7790,'USA','US','Smyrna~ TN','MQY'),

(7791,'Australia','AU','Snake Bay~ Northern Territory','SNB'),

(7792,'Canada','CA','Snake River~ YT','YXF'),

(7793,'Canada','CA','Snowdrift~ NT','YSG'),

(7795,'USA','US','Snyder~ TX','SNK'),

(7796,'Madagascar','MG','Soalala','DWB'),

(7797,'Brazil','BR','Sobral~ CE','QBX'),

(7798,'Vietnam','VN','Soc Trang','SOA'),

(7799,'USA','US','Socorro~ NM','ONM'),

(7800,'Yemen','YE','Socotra','SCT'),

(7801,'Finland','FI','Sodankyla','SOT'),

(7802,'Ethiopia','ET','Soddu','SXU'),

(7803,'Sweden','SE','Soderhamn','SOO'),

(7804,'Sweden','SE','Sodertalje','JSO'),

(7805,'Norway','NO','Soerkjosen (Sorkjosen)','SOJ'),

(7806,'Bulgaria','BG','Sofia','SOF'),

(7807,'Colombia','CO','Sogamoso','SOX'),

(7808,'Norway','NO','Sogndal','SOG'),

(7809,'South Korea','KR','Sokcho','SHO'),

(7810,'Georgia','GE','Sokhumi~ Abkhazia','SUI'),

(7811,'Nigeria','NG','Sokoto','SKO'),

(7812,'Vanuatu','VU','Sola','SLH'),

(7813,'Venezuela','VE','Solano','SQF'),

(7814,'USA','US','Soldotna~ AK','SXQ'),

(7815,'Venezuela','VE','Solita','SOH'),

(7816,'Indonesia','ID','Solo City','SOC'),

(7817,'USA','US','Solomon~ AK','SOL'),

(7818,'USA','US','Solon Springs~ WI','OLG'),

(7819,'Zambia','ZM','Solwezi','SLI'),

(7820,'KY USA','US','Somerset','SME'),

(7821,'Denmark','DK','Sonderborg (Soenderborg)','SGD'),

(7822,'Greenland','GL','Sondre Stromfjord (Kangerlussuaq','SFJ'),

(7823,'Tanzania','TZ','Songea','SGX'),

(7824,'Thailand','TH','Songkhla','SGZ'),

(7825,'France','FR','Sophia Antipolis','SXD'),

(7826,'Papua New Guinea','PG','Sopu','SPH'),

(7827,'Indonesia','ID','Soroako','SQR'),

(7828,'Brazil','BR','Sorocaba','SOD'),

(7829,'Indonesia','ID','Sorong','SOQ'),

(7830,'Uganda','UG','Soroti','SRT'),

(7831,'Italy','IT','Sorrento','RRO'),

(7832,'Denmark','DK','Sorvag (Faroe Islands)~ Faroe Is','FAE'),

(7833,'Congo','CG','Souanke','SOE'),

(7834,'Tunisia','TN','Sousse','QSO'),

(7835,'Bahamas','BS','South Andros~ Andros','TZN'),

(7836,'USA','US','South Bend~ IN','SBN'),

(7837,'Turks & Caicos','TC','South Caicos Is.','XSC'),

(7838,'Australia','AU','South Galway','ZGL'),

(7839,'Canada','CA','South Indian Lake~ MB','XSI'),

(7840,'Australia','AU','South Molle Island~ Queensland','SOI'),

(7841,'USA','US','South Naknek~ AK','WSN'),

(7842,'Canada','CA','South Trout Lake~ ON','ZFL'),

(7843,'Vanuatu','VU','South West Bay','SWJ'),

(7844,'MA USA','US','South Weymouth','NZW'),

(7845,'United Kingdom','GB','Southampton~ England','SOU'),

(7846,'United Kingdom','GB','Southend~ England','SEN'),

(7847,'Australia','AU','Southern Cross~ Western Australi','SQC'),

(7848,'USA','US','Southport~ NC','SHQ'),

(7849,'Angola','AO','Soyo','SZA'),

(7850,'Germany','DE','Spangdahlem','SPM'),

(7851,'Bahamas','BS','Spanish Wells','SWL'),

(7852,'USA','US','Sparrevohn~ AK','SVW'),

(7853,'Greece','GR','Sparta','SPJ'),

(7854,'USA','US','Sparta~ IL','SAR'),

(7855,'USA','US','Sparta~ WI','CMY'),

(7856,'USA','US','Spartanburg~ SC','SPA'),

(7857,'USA','US','Spearfish~ SD','SPF'),

(7858,'Canada','CA','Spence Bay~ NT','YYH'),

(7859,'USA','US','Spencer~ IA','SPW'),

(7860,'Greenland','GL','Spetsai Island','JSS'),

(7861,'Switzerland','CH','Spiez','ZSZ'),

(7862,'Croatia','HR','Split','SPU'),

(7863,'USA','US','Spokane~ WA','SKA'),

(7866,'Australia','AU','Spring Creek~ Queensland','SCG'),

(7867,'Canada','CA','Spring Island~ BC','YSQ'),

(7868,'Bahamas','BS','Spring Point~ Crooked','AXP'),

(7869,'South Africa','ZA','Springbok','SBU'),

(7870,'USA','US','Springdale~ AR','SPZ'),

(7871,'USA','US','Springfield~ IL','SPI'),

(7872,'USA','US','Springfield~ MA','SFY'),

(7873,'USA','US','Springfield~ MO','SGF'),

(7874,'USA','US','Springfield~ OH','SGH'),

(7875,'USA','US','Springfield~ VT','VSF'),

(7876,'MA USA','US','Springfield/Chicopee','CEF'),

(7877,'Australia','AU','Springvale~ Queensland','KSV'),

(7878,'Australia','AU','Springvale~ Western Australia','ZVG'),

(7879,'India','IN','Srinagar','SXR'),

(7880,'Canada','CA','St-Honore~ QC','YRC'),

(7881,'Canada','CA','St-Jean~ QC','YJN'),

(7882,'France','FR','St.-Crepin','SCP'),

(7883,'Canada','CA','St.-Leonard~ NB','YSL'),

(7884,'United Kingdom','GB','St. Andrews~ Scotland','ADX'),

(7885,'Canada','CA','St. Anthony~ NF','YAY'),

(7886,'USA','US','St. Augustine~ FL','UST'),

(7887,'Canada','CA','St. Catharines~ ON','YCM'),

(7888,'USA','US','St. Cloud~ MN','JSK'),

(7890,'Netherlands Antilles','NL','St. Eustathius','EUX'),

(7891,'USA','US','St. Francis~ KS','SYF'),

(7892,'USA','US','St. George Island~ AK','STG'),

(7893,'French Guyana','GF','St. George Oyapock','OYP'),

(7894,'Australia','AU','St. George~ Queensland','SGO'),

(7895,'USA','US','St. George~ UT','SGU'),

(7896,'Australia','AU','St. Helens~ Tasmania','HLS'),

(7897,'Canada','CA','St. John\'s~ NF','YYT'),

(7898,'USA','US','St. Johns~ AZ','SJN'),

(7899,'USA','US','St. Joseph~ MO','STJ'),

(7900,'French Guyana','GF','St. Laurent du Maroni','LDX'),

(7901,'USA','US','St. Louis~ MO','STL'),

(7904,'St. Lucia','LC','St. Lucia (Castries)','SLU'),

(7905,'St. Lucia','LC','St. Lucia (Vieux Fort)','UVF'),

(7906,'Netherlands Antilles','NL','St. Maarten (Marigot)','MSB'),

(7907,'Netherlands Antilles','NL','St. Maarten (Philipsburg)','SXM'),

(7908,'Netherlands Antilles','NL','St. Maarten','QSM'),

(7909,'France','FR','St. Malo','XSB'),

(7910,'USA','US','St. Mary\'s~ AK','KSM'),

(7911,'USA','US','St. Mary\'s~ MD','XSM'),

(7912,'USA','US','St. Marys~ PA','STQ'),

(7913,'USA','US','St. Michael~ AK','SMK'),

(7914,'Australia','AU','St. Paul\'s Mission~ Queensland','SVM'),

(7915,'USA','US','St. Paul Island~ AK','SNP'),

(7916,'Canada','CA','St. Paul~ AB','ZSP'),

(7917,'USA','US','St. Paul~ MN','STP'),

(7918,'Germany','DE','St. Peter','PSH'),

(7919,'Russia','RU','St. Petersburg (Leningrad)~ Leni','LED'),

(7920,'USA','US','St. Petersburg~ FL','SPG'),

(7921,'FL USA','US','St. Petersburg','PIE'),

(7922,'St. Pierre & Miquelon','PM','St. Pierre','FSP'),

(7923,'Canada','CA','St. Thomas~ ON','YQS'),

(7924,'France','FR','St. Tropez','JSZ'),

(7925,'Bahamas','BS','Staniel Cay','TYM'),

(7926,'Falkland Islands','FK','Stanley','PSY'),

(7927,'Australia','AU','Stanthorpe~ Queensland','SNH'),

(7928,'USA','US','Stanton~ MN','SYN'),

(7929,'Bulgaria','BG','Stara Zagora','SZR'),

(7930,'Australia','AU','Starcke~ Queensland','SQP'),

(7931,'USA','US','Startford~ CT','JSD'),

(7932,'USA','US','State College~ PA','UNV'),

(7934,'USA','US','Statesboro~ GA','TBR'),

(7935,'USA','US','Statesville~ NC','SVH'),

(7936,'Papua New Guinea','PG','Statwag','SWG'),

(7937,'Denmark','DK','Stauning','STA'),

(7938,'VA USA','US','Staunton/Waynesboro/Harrisonburg','SHD'),

(7939,'Norway','NO','Stavanger','SVG'),

(7940,'United Kingdom','GB','Staverton~ England','SVT'),

(7941,'Russia','RU','Stavropol~ Stavropol','STW'),

(7942,'Australia','AU','Stawell~ Victoria','SWC'),

(7943,'Canada','CA','Ste-Anne-des-Monts~ QC','YSZ'),

(7944,'Madagascar','MG','Ste. Marie','SMS'),

(7945,'USA','US','Steamboat Bay~ AK','WSB'),

(7946,'USA','US','Steamboat Springs (Hayden)~ CO','HDN'),

(7947,'USA','US','Steamboat Springs~ CO','SBS'),

(7948,'USA','US','Stebbins~ AK','WBB'),

(7949,'Indonesia','ID','Steenkool','ZKL'),

(7950,'Bahamas','BS','Stella Maris~ Long','SML'),

(7951,'Australia','AU','Stephen Island~ Queensland','STF'),

(7952,'Canada','CA','Stephenville~ NF','YJT'),

(7953,'USA','US','Stephenville~ TX','SEP'),

(7954,'USA','US','Sterling~ CO','STK'),

(7955,'IL USA','US','Sterling/Rock Falls','SQI'),

(7956,'USA','US','Steubenville~ OH','JFN'),

(7957,'USA','US','Stevens Point~ WI','STE'),

(7958,'USA','US','Stevens Village~ AK','SVS'),

(7959,'New Zealand','NZ','Stewart Island','SZS'),

(7960,'Canada','CA','Stewart~ BC','ZST'),

(7961,'USA','US','Stillwater~ OK','SWO'),

(7962,'Sweden','SE','Stockholm','ARN'),

(7965,'Papua New Guinea','PG','Stockholm','SMP'),

(7966,'USA','US','Stockton~ CA','SCK'),

(7967,'Suriname','SR','Stoelmanseiland','SMZ'),

(7968,'Norway','NO','Stokmarknes','SKN'),

(7969,'Canada','CA','Stony Rapids~ SK','YSF'),

(7970,'USA','US','Stony River~ AK','SRV'),

(7971,'Norway','NO','Stord','SRP'),

(7972,'USA','US','Storm Lake~ IA','SLB'),

(7973,'United Kingdom','GB','Stornway','SYY'),

(7974,'Sweden','SE','Storuman','SQO'),

(7975,'USA','US','Stow~ MA','MMN'),

(7976,'Australia','AU','Stradbroke Island~ Queensland','SRR'),

(7977,'Australia','AU','Strahan~ Tasmania','SRN'),

(7978,'France','FR','Strasbourg','SXB'),

(7979,'USA','US','Strathmore~ CA','STH'),

(7980,'Australia','AU','Streaky Bay~ South Australia','KBY'),

(7981,'United Kingdom','GB','Stronsay','SOY'),

(7982,'USA','US','Stroud~ OK','SUD'),

(7983,'Macedonia','MK','Struga','QXP'),

(7984,'Russia','RU','Strzhewoi','SWT'),

(7985,'Canada','CA','Stuart Island~ BC','YRR'),

(7986,'USA','US','Stuart Island~ WA','SSW'),

(7987,'USA','US','Stuart~ FL','SUA'),

(7988,'Canada','CA','Sturdee~ BC','YTC'),

(7989,'USA','US','Sturgeon Bay~ WI','SUE'),

(7990,'USA','US','Sturgis~ MI','IRS'),

(7991,'Australia','AU','Sturt Creek~ Western Australia','SSK'),

(7992,'Germany','DE','Stuttgart','STR'),

(7994,'USA','US','Stuttgart~ AR','SGT'),

(7995,'Iceland','IS','Stykkisholmur','SYK'),

(7996,'South Korea','KR','Su Won City','SWU'),

(7997,'Indonesia','ID','Suai','UAI'),

(7998,'Solomon Islands','SB','Suavanao','VAO'),

(7999,'Romania','RO','Suceava','SCV'),

(8000,'Bolivia','BO','Sucre','SRE'),

(8001,'Ecuador','EC','Sucua','SUQ'),

(8002,'Canada','CA','Sudbury~ ON','YSB'),

(8003,'Iceland','IS','Sudureyri','SUY'),

(8004,'Australia','AU','Sue Island~ Queensland','SYU'),

(8005,'Canada','CA','Suffield~ AB','YSD'),

(8006,'United Kingdom','GB','Suffolk~ England','BWY'),

(8007,'Indonesia','ID','Sugapa','ZGP'),

(8008,'TX USA','US','Sugar Land (Houston)','SGR'),

(8009,'Pakistan','PK','Sui','SUL'),

(8010,'Brazil','BR','Suia-Missu~ MT','SWM'),

(8011,'Papua New Guinea','PG','Suki','SKC'),

(8012,'Greenland','GL','Sukkertoppen','JSU'),

(8013,'Pakistan','PK','Sukkur','SKZ'),

(8014,'Honduras','HN','Sulaco','SCD'),

(8015,'Saudi Arabia','SA','Sulayel','SLF'),

(8016,'Papua New Guinea','PG','Sule','ULE'),

(8017,'Canada','CA','Sullivan Bay~ BC','YTG'),

(8018,'USA','US','Sullivan~ IN','SIV'),

(8019,'USA','US','Sullivan~ MO','UUV'),

(8020,'USA','US','Sulphur Springs~ TX','SLR'),

(8021,'Indonesia','ID','Sumbawa Besar~ Sumbawa','SWQ'),

(8022,'Tanzania','TZ','Sumbawanga','SUT'),

(8023,'Angola','AO','Sumbe','NDD'),

(8024,'Indonesia','ID','Sumenep','SUP'),

(8025,'Canada','CA','Summer Beaver','SUR'),

(8026,'USA','US','Summerdale~ AL','NFD'),

(8027,'Canada','CA','Summerside~ PE','YSU'),

(8028,'USA','US','Summerville~ SC','DYB'),

(8029,'Canada','CA','Summit Lake~ BC','IUM'),

(8030,'USA','US','Summit~ AK','UMM'),

(8031,'USA','US','Sumter~ SC','SSC'),

(8033,'Ukraine','UA','Sumy~ Sumy','UMY'),

(8034,'Taiwan','TW','Sun Moon Lake','SMT'),

(8035,'United Kingdom','GB','Sun River','SUO'),

(8036,'USA','US','Sun Valley (Hailey)~ ID','SUN'),

(8037,'USA','US','Sundance~ WY','SUC'),

(8038,'Sweden','SE','Sundsvall','SDL'),

(8039,'Indonesia','ID','Sungal Pakning','SEQ'),

(8040,'Malaysia','MY','Sungei Takai','GTK'),

(8041,'Malaysia','MY','Sungei Tiang','SXT'),

(8042,'USA','US','Sunnyvale~ CA','JSV'),

(8043,'Ghana','GH','Sunyani','NYI'),

(8044,'USA','US','Superior~ WI','SUW'),

(8045,'Oman','OM','Sur','SUH'),

(8046,'Indonesia','ID','Surabaya','SUB'),

(8047,'Thailand','TH','Surat Thani','URT'),

(8048,'India','IN','Surat','STV'),

(8049,'New Zealand','NZ','Surfdale','WIK'),

(8050,'Australia','AU','Surfers Paradise~ Queensland','SFP'),

(8051,'Russia','RU','Surgut~ Tyumen','SGC'),

(8052,'Papua New Guinea','PG','Suria','SUZ'),

(8053,'Philippines','PH','Surigao','SUG'),

(8054,'Switzerland','CH','Sursee','ZKU'),

(8055,'USA','US','Susanville~ CA','SVE'),

(8056,'United Kingdom','GB','Suttonhead~ England','WOB'),

(8057,'Fiji','FJ','Suva','SUV'),

(8058,'China','CN','Suzhou','SZV'),

(8059,'Norway','NO','Svalbard','LYR'),

(8060,'Cambodia','KH','Svay Rieng','SVR'),

(8061,'Sweden','SE','Sveg','EVG'),

(8062,'Norway','NO','Svolvaer','SVJ'),

(8063,'Namibia','LC','Swakopmund','SWP'),

(8064,'Australia','AU','Swan Hill~ Victoria','SWH'),

(8065,'Canada','CA','Swan River~ MB','YSE'),

(8066,'NC USA','US','Swansboro','NJM'),

(8067,'United Kingdom','GB','Swansea~ Wales','SWS'),

(8068,'USA','US','Sweetwater~ TX','SWW'),

(8069,'Canada','CA','Swift Current~ SK','YYN'),

(8070,'United Kingdom','GB','Swindon','SWI'),

(8071,'Australia','AU','Sydney~ New South Wales','RSE'),

(8074,'Canada','CA','Sydney~ NS','YQY'),

(8075,'Russia','RU','Syktyvkar~ Komi','SCW'),

(8076,'Bangladesh','BD','Sylhet','ZYL'),

(8077,'USA','US','Sylvania~ GA','JYL'),

(8078,'USA','US','Sylvester~ GA','SYV'),

(8079,'USA','US','Syracuse~ NY','SYR'),

(8080,'Greece','GR','Syros Island','JSY'),

(8081,'Poland','PL','Szczecin (Stettin)','SZZ'),

(8082,'Tunisia','TN','Tabarka','TBJ'),

(8083,'Brazil','BR','Tabatinga~ AM','TBT'),

(8084,'Papua New Guinea','PG','Tabibuga','TBA'),

(8085,'Kiribati','KI','Tabiteuea North','TBF'),

(8086,'Kiribati','KI','Tabiteuea South','TSU'),

(8087,'Philippines','PH','Tablas','TBH'),

(8088,'Australia','AU','Tableland','TBL'),

(8089,'Colombia','CO','Tablon de Tamara','TTM'),

(8090,'Tanzania','TZ','Tabora','TBO'),

(8091,'Ivory Coast','CI','Tabou','TXU'),

(8092,'Iran','IR','Tabriz','TBZ'),

(8093,'Papua New Guinea','PG','Tabubil','TBG'),

(8094,'Saudi Arabia','SA','Tabuk','TUU'),

(8095,'Myanmar','MM','Tachilek','THL'),

(8096,'Philippines','PH','Tacloban','TAC'),

(8097,'Peru','PE','Tacna','TCQ'),

(8098,'USA','US','Tacoma~ WA','TCM'),

(8100,'Uruguay','UY','Tacuarembo','TAW'),

(8101,'Papua New Guinea','PG','Tadji','TAJ'),

(8102,'Djibouti','DJ','Tadjoura','TDJ'),

(8103,'Canada','CA','Tadoule Lake~ MB','YBQ'),

(8105,'South Korea','KR','Taegu','TAE'),

(8106,'South Korea','KR','Taejon','QTW'),

(8107,'Algeria','DZ','Tafarovi','TAF'),

(8108,'Pakistan','PK','Taftan','TFT'),

(8109,'Philippines','PH','Tagbilaran','TAG'),

(8110,'Guam','GU','Taguac','WUM'),

(8111,'Papua New Guinea','PG','Tagula','TGL'),

(8112,'New Zealand','NZ','Taharoa','THH'),

(8113,'USA','US','Tahneta Pass Lodge~ AK','HNE'),

(8114,'Niger','NE','Tahoua','THZ'),

(8115,'Canada','CA','Tahsis~ BC','ZTS'),

(8116,'Taiwan','TW','Taichung','TXG'),

(8117,'Saudi Arabia','SA','Taif','TIF'),

(8118,'Taiwan','TW','Tainan','TNN'),

(8119,'Taiwan','TW','Taipei','TPE'),

(8121,'Malaysia','MY','Taiping','TPG'),

(8122,'Ecuador','EC','Taisha','TSC'),

(8123,'Taiwan','TW','Taitung','TTT'),

(8124,'China','CN','Taiyuan','TYN'),

(8125,'Yemen','YE','Taiz','TAI'),

(8126,'Thailand','TH','Tak','TKT'),

(8127,'New Zealand','NZ','Takaka','KTF'),

(8128,'Japan','JP','Takamatsu','TAK'),

(8129,'French Polynesia','PF','Takapoto','TKP'),

(8130,'French Polynesia','PF','Takaroa','TKX'),

(8131,'Thailand','TH','Takhli','TKH'),

(8132,'Ghana','GH','Takoradi','TKD'),

(8133,'USA','US','Takotna~ AK','TCT'),

(8135,'USA','US','Taku Lodge~ AK','TKL'),

(8136,'Peru','PE','Talara','TYL'),

(8137,'Papua New Guinea','PG','Talasea','TLW'),

(8138,'Chile','CL','Talca','TLX'),

(8139,'Kazakhstan','KZ','Taldyqorghan (Taldy Kurgan)~ Tal','TDK'),

(8140,'Indonesia','ID','Taliabu','TAX'),

(8141,'USA','US','Talkeetna~ AK','TKA'),

(8142,'Iceland','IS','Talknafjordur','TLK'),

(8143,'USA','US','Talladega~ AL','ASN'),

(8144,'USA','US','Tallahassee~ FL','TLH'),

(8145,'Estonia','EE','Tallinn','TLL'),

(8146,'Chile','CL','Taltal','TTC'),

(8147,'Afghanistan','AF','Taluqan','TQN'),

(8148,'Ghana','GH','Tamale','TML'),

(8149,'Kiribati','KI','Tamana','TMN'),

(8150,'Algeria','DZ','Tamanrasset','TMR'),

(8151,'Costa Rica','CR','Tamarindo','TNO'),

(8152,'Madagascar','MG','Tamatave','TMM'),

(8153,'Senegal','SN','Tambacounda','TUD'),

(8154,'Burkina Faso','BF','Tambao','TMQ'),

(8155,'Madagascar','MG','Tambohorano','WTA'),

(8156,'Indonesia','ID','Tambolaka','TMC'),

(8157,'Costa Rica','CR','Tambor','TMU'),

(8158,'Russia','RU','Tambov~ Tambov','TBW'),

(8159,'Mauritania','MR','Tamchakett','THT'),

(8160,'Colombia','CO','Tame','TME'),

(8161,'Vietnam','VN','Tamky','TMK'),

(8162,'USA','US','Tampa~ FL','MCF'),

(8165,'Finland','FI','Tampere','TMP'),

(8166,'Mexico','MX','Tampico','TAM'),

(8167,'Mexico','MX','Tamuin','TSL'),

(8168,'Australia','AU','Tamworth~ New South Wales','TMW'),

(8169,'Morocco','MA','Tan Tan','TTA'),

(8170,'USA','US','Tanacross~ AK','TSG'),

(8171,'Indonesia','ID','Tanah Grogot','TNB'),

(8172,'Indonesia','ID','Tanahmerah','TMH'),

(8173,'USA','US','Tanalian~ AK','TPO'),

(8174,'USA','US','Tanana~ AK','TAL'),

(8175,'Madagascar','MG','Tanandava','TDV'),

(8176,'Indonesia','ID','Tanatoraja','TTR'),

(8177,'Australia','AU','Tanbar~ Queensland','TXR'),

(8178,'Philippines','PH','Tandag','TDG'),

(8179,'Argentina','AR','Tandil','TDL'),

(8180,'Japan','JP','Tanegashima','TNE'),

(8181,'Papua New Guinea','PG','Tanga Island','WXH'),

(8182,'Tanzania','TZ','Tanga','TGT'),

(8183,'Australia','AU','Tangalooma','TAN'),

(8184,'Morocco','MA','Tanger (Tangier)','TNG'),

(8185,'Indonesia','ID','Tanjung','TJB'),

(8187,'Indonesia','ID','Tanjung Pandan','TJQ'),

(8188,'Indonesia','ID','Tanjung Pinang','TNJ'),

(8189,'Indonesia','ID','Tanjung Selor~ Borneo','TJS'),

(8191,'Vanuatu','VU','Tanna Island','TAH'),

(8192,'USA','US','Taos~ NM','TSM'),

(8193,'Mexico','MX','Tapachula','TAP'),

(8194,'Indonesia','ID','Tapaktuan','TPK'),

(8195,'Liberia','LR','Tapeta','TPT'),

(8196,'Nepal','NP','Taplejung','TPJ'),

(8197,'Australia','AU','Tara~ Queensland','XTR'),

(8198,'Indonesia','ID','Tarakan~ Borneo','TRK'),

(8199,'Papua New Guinea','PG','Tarakbits','TRJ'),

(8200,'Japan','JP','Taramajima','TRA'),

(8201,'Italy','IT','Taranto','TAR'),

(8202,'Colombia','CO','Tarapaca','TCD'),

(8203,'Solomon Islands','SB','Tarapaina','TAA'),

(8204,'Ecuador','EC','Tarapoa','TPC'),

(8205,'Peru','PE','Tarapoto','TPP'),

(8206,'Brazil','BR','Tarauaca~ AC','TRQ'),

(8207,'Kiribati','KI','Tarawa','TRW'),

(8208,'Pakistan','PK','Tarbela','TLB'),

(8209,'France','FR','Tarbes','TFR'),

(8210,'Australia','AU','Tarcoola~ South Australia','TAQ'),

(8211,'Australia','AU','Taree~ New South Wales','TRO'),

(8212,'Morocco','MA','Tarfaya','TFY'),

(8213,'Bulgaria','BG','Targovishte','TGV'),

(8214,'Papua New Guinea','PG','Tari','TIZ'),

(8215,'Australia','AU','Taroom~ Queensland','XTO'),

(8216,'Spain','ES','Tarragona','QGN'),

(8217,'Argentina','AR','Tartagal','TTG'),

(8218,'Estonia','EE','Tartu','TAY'),

(8219,'Uzbekhistan','UZ','Tashkent~ Tashkent','TAS'),

(8220,'Indonesia','ID','Tasikmalaya','TSY'),

(8221,'Canada','CA','Tasiujuaq~ QC','YTQ'),

(8222,'Papua New Guinea','PG','Taskul','TSK'),

(8223,'Canada','CA','Tasu~ BC','YTU'),

(8224,'French Polynesia','PF','Tatakoto','TKV'),

(8225,'USA','US','Tatitlek~ AK','TEK'),

(8226,'American Samoa','AS','Tau Island','TAV'),

(8227,'New Zealand','NZ','Taupo','TUO'),

(8228,'Colombia','CO','Tauramena','TAU'),

(8229,'New Zealand','NZ','Tauranga','TRG'),

(8230,'Papua New Guinea','PG','Tauta','TUT'),

(8231,'Fiji','FJ','Taveuni','TVU'),

(8232,'Myanmar','MM','Tavoy','TVY'),

(8233,'China','CN','Tawa~ Tibet','TWY'),

(8234,'Malaysia','MY','Tawau~ Sabah','TWU'),

(8235,'Philippines','PH','Tawi Tawi','TWT'),

(8236,'USA','US','Taylor~ AK','TWE'),

(8237,'USA','US','Taylor~ AZ','TYZ'),

(8238,'Georgia','GE','Tbilisi~ Abkhazia','TBS'),

(8239,'Gabon','GA','Tchibanga','TCH'),

(8240,'Liberia','LR','Tchien','THC'),

(8241,'New Zealand','NZ','Te Anau','TEU'),

(8242,'Algeria','DZ','Tebessa','TEE'),

(8243,'United Kingdom','GB','Tees Side','MME'),

(8244,'Brazil','BR','Tefe~ MA','TFF'),

(8245,'Honduras','HN','Tegucigalpa','TGU'),

(8246,'USA','US','Tehachapi~ CA','TSP'),

(8247,'Iran','IR','Teheran (Theran)','THR'),

(8248,'Mexico','MX','Tehuacan','TCN'),

(8249,'Papua New Guinea','PG','Tekadu','TKB'),

(8250,'USA','US','Tekamah~ NE','TQE'),

(8251,'Papua New Guinea','PG','Tekin','TKW'),

(8252,'Israel','IL','Tel Aviv','TLV'),

(8253,'Israel','IL','Tel Aviv~','SDV'),

(8254,'Honduras','HN','Tela','TEA'),

(8255,'Papua New Guinea','PG','Telefomin','TFM'),

(8256,'Canada','CA','Telegraph Creek~ BC','YTX'),

(8257,'Brazil','BR','Telemaco Borba~ PR','TEC'),

(8258,'Australia','AU','Telfer~ Western Australia','TEF'),

(8259,'USA','US','Telida~ AK','TLF'),

(8260,'USA','US','Teller~ AK','TLA'),

(8261,'USA','US','Telluride~ CO','TEX'),

(8263,'Malaysia','MY','Telupid','TEL'),

(8264,'Indonesia','ID','Teminabuan','TXM'),

(8265,'Australia','AU','Temora~ New South Wales','TEM'),

(8266,'USA','US','Temple~ TX','TPL'),

(8267,'Chile','CL','Temuco','ZCO'),

(8268,'USA','US','Tenakee Springs~ AK','TKE'),

(8269,'Spain','ES','Tenerife~ Canary Islands','TFN'),

(8271,'Singapore','SG','Tengah','TGA'),

(8272,'Burkina Faso','BF','Tenkodogo','TEG'),

(8273,'Australia','AU','Tennant Creek~ Northern Territor','TCA'),

(8274,'Brazil','BR','Teofilo Otoni~ MG','TFL'),

(8275,'Mexico','MX','Tepic','TPQ'),

(8276,'Papua New Guinea','PG','Teptep','TEP'),

(8277,'Papua New Guinea','PG','Terapo','TEO'),

(8278,'Portugal','PT','Terceira~ Azores','TER'),

(8280,'Brazil','BR','Teresina~ PI','THE'),

(8281,'Brazil','BR','Teresopolis~ RJ','QHT'),

(8282,'Uzbekhistan','UZ','Termiz (Termes)~ Surkhondaryo','TMZ'),

(8283,'Indonesia','ID','Ternate','TTE'),

(8284,'Ukraine','UA','Ternopil (Ternopol)~ Ternopil','TNL'),

(8285,'Canada','CA','Terrace Bay~ ON','YTJ'),

(8286,'Canada','CA','Terrace~ BC','YXT'),

(8287,'Guadeloupe','GP','Terre de Bas','HTB'),

(8288,'USA','US','Terre Haute~ IN','HUF'),

(8289,'USA','US','Terrell~ TX','TRL'),

(8290,'USA','US','Terror Bay~ AK','KTY'),

(8291,'Canada','CA','Teslin~ YT','YZW'),

(8292,'Ethiopia','ET','Tessenei','TES'),

(8293,'Canada','CA','Tete-a-la-Baleine~ QC','ZTB'),

(8294,'Mozambique','MZ','Tete','TET'),

(8296,'Papua New Guinea','PG','Tetebedi','TDB'),

(8297,'USA','US','Teterboro~ NJ','TEB'),

(8298,'French Polynesia','PF','Tetiaroa Island','TTI'),

(8299,'USA','US','Tetlin~ AK','TEH'),

(8300,'Morocco','MA','Tetouan (Tetuan)','TTU'),

(8301,'Australia','AU','Tewantin~ Queensland','TWN'),

(8302,'USA','US','Texarkana~ AR','TXK'),

(8303,'India','IN','Tezpur','TEZ'),

(8304,'India','IN','Tezu','TEI'),

(8305,'South Africa','ZA','Thaba\'Nchu','TCU'),

(8306,'Lesotho','LS','Thaba Tseka','THB'),

(8307,'Laos','LA','Thakhek','THK'),

(8308,'Bangladesh','BD','Thakurgaon','TKR'),

(8309,'Australia','AU','Thangool/Biloela~ Queensland','THG'),

(8310,'India','IN','Thanjavur','TJV'),

(8311,'Australia','AU','Thargomindah~ Queensland','XTG'),

(8312,'Bahamas','BS','The Bight','TBI'),

(8313,'USA','US','The Dalles~ OR','DLS'),

(8314,'Canada','CA','The Pas~ MB','YQD'),

(8315,'Australia','AU','Theodore~ Queensland','TDR'),

(8316,'USA','US','Thermal~ CA','TRM'),

(8317,'WY USA','US','Thermopolis','THP'),

(8318,'Greece','GR','Thessaloniki (Saloniki)','SKG'),

(8319,'Canada','CA','Thicket Portage~ MB','YTD'),

(8320,'USA','US','Thief River Falls~ MN','TVF'),

(8321,'Iceland','IS','Thingeyri','TEY'),

(8322,'Denmark','DK','Thisted','TED'),

(8323,'South Africa','ZA','Thohoyandou~ Venda','THY'),

(8324,'USA','US','Thomaston~ GA','RGD'),

(8325,'USA','US','Thomasville~ GA','TVI'),

(8326,'USA','US','Thompson Falls~ MT','THM'),

(8327,'Canada','CA','Thompson~ MB','YTH'),

(8328,'USA','US','Thorne Bay~ AK','KTB'),

(8329,'Iceland','IS','Thorshofn','THO'),

(8330,'USA','US','Thousand Oaks~ CA','JTO'),

(8331,'Australia','AU','Thredbo~ New South Wales','QTH'),

(8332,'USA','US','Three Rivers~ MI','HAI'),

(8333,'Greenland','GL','Thule','THU'),

(8334,'Oman','OM','Thumrait','TTH'),

(8335,'Canada','CA','Thunder Bay~ ON','YQT'),

(8336,'Australia','AU','Thursday Island~ Queensland','TIS'),

(8337,'Australia','AU','Thylungra~ Queensland','TYG'),

(8338,'China','CN','Tianjin','TSN'),

(8339,'Algeria','DZ','Tiaret','TID'),

(8340,'Australia','AU','Tibooburra~ New South Wales','TYB'),

(8341,'Colombia','CO','Tibu','TIB'),

(8342,'Mauritania','MR','Tichitt','THI'),

(8343,'Mauritania','MR','Tidjikja','TIY'),

(8344,'USA','US','Tifton~ GA','TMA'),

(8345,'New Caledonia','NC','Tiga','TGJ'),

(8346,'France','FR','Tignes','TGF'),

(8347,'Mexico','MX','Tijuana','TIJ'),

(8348,'Guatemala','GT','Tikal','TKM'),

(8349,'Nepal','NP','Tikapur','TPU'),

(8350,'USA','US','Tikchik~ AK','KTH'),

(8351,'French Polynesia','PF','Tikehau Atoll','TIH'),

(8352,'Cameroon','CM','Tiko','TKC'),

(8353,'Russia','RU','Tiksi~ Yakutia-Sakha','IKS'),

(8354,'Papua New Guinea','PG','Tilfalmin','TFA'),

(8355,'Myanmar','MM','Tilin','TIO'),

(8356,'New Zealand','NZ','Timaru','TIU'),

(8357,'Brazil','BR','Timbauba~ PE','QTD'),

(8358,'Mauritania','MR','Timbedra','TMD'),

(8359,'Australia','AU','Timber Creek','TBK'),

(8360,'Colombia','CO','Timbiqui','TBD'),

(8361,'Papua New Guinea','PG','Timbunke','TBE'),

(8362,'Indonesia','ID','Timika (Timuka)/Tembagapura~ New','TIM'),

(8363,'Algeria','DZ','Timimoun','TMX'),

(8364,'Romania','RO','Timisoara','TSR'),

(8365,'Canada','CA','Timmins~ ON','YTS'),

(8366,'USA','US','Tin City~ AK','TNC'),

(8367,'Marshall Islands','MH','Tinak','TIC'),

(8368,'Algeria','DZ','Tindouf','TIN'),

(8369,'Peru','PE','Tingo Maria','TGI'),

(8370,'Papua New Guinea','PG','Tingwon','TIG'),

(8371,'Mariana Islands','US','Tinian (Peipeinimaru)','TIQ'),

(8372,'USA','US','Tioga~ ND','VEX'),

(8373,'Indonesia','ID','Tiom~ New Guinea','TMY'),

(8374,'Malaysia','MY','Tioman','TOD'),

(8375,'Ethiopia','ET','Tippi','TIE'),

(8376,'Ecuador','EC','Tiputini','TPN'),

(8377,'Albania','AL','Tirana','TIA'),

(8378,'United Kingdom','GB','Tiree Island','TRE'),

(8379,'Romania','RO','Tirgu Mures','TGM'),

(8380,'Bolivia','BO','Tirija (Tarija)','TJA'),

(8381,'Afghanistan','AF','Tirinkot','TII'),

(8382,'India','IN','Tiruchirapally','TRZ'),

(8383,'India','IN','Tirupati','TIR'),

(8384,'Canada','CA','Tisdale~ SK','YTT'),

(8385,'USA','US','Titusville~ FL','TIX'),

(8386,'Yugoslavia','YU','Tivat','TIV'),

(8387,'Mexico','MX','Tizimin','TZM'),

(8388,'Algeria','DZ','Tlemcen (Tilimsen)','TLM'),

(8389,'Lesotho','LS','Tlokoeng','TKO'),

(8390,'Trinidad & Tobago','TT','Tobago (Scarborough)~ Tobago Is.','TAB'),

(8391,'United Kingdom','GB','Tobermory','TYP'),

(8392,'Russia','RU','Tobol\'sk~ Tyumen','TOX'),

(8393,'Libya','LY','Tobruk','TOB'),

(8394,'Peru','PE','Tocache','TCG'),

(8395,'USA','US','Toccoa~ GA','TOC'),

(8396,'Honduras','HN','Tocoa','TCF'),

(8397,'Chile','CL','Tocopilla','TOQ'),

(8398,'Australia','AU','Tocumwal~ New South Wales','TCW'),

(8399,'Canada','CA','Tofino~ BC','YAZ'),

(8401,'USA','US','Togiak Fish~ AK','GFB'),

(8402,'USA','US','Togiak~ AK','TOG'),

(8403,'USA','US','Tok~ AK','TKJ'),

(8404,'USA','US','Tokeen~ AK','TKI'),

(8405,'USA','US','Toksook Bay~ AK','OOK'),

(8406,'Japan','JP','Tokuno Shima','TKN'),

(8407,'Japan','JP','Tokushima','TKS'),

(8408,'Japan','JP','Tokyo','HND'),

(8411,'Papua New Guinea','PG','Tol','TLO'),

(8412,'USA','US','Toledo~ OH','TDZ'),

(8414,'Brazil','BR','Toledo~ PR','QTO'),

(8416,'USA','US','Toledo~ WA','TDO'),

(8417,'Indonesia','ID','Tolitoli','TLI'),

(8418,'Colombia','CO','Tolu','TLU'),

(8419,'Mexico','MX','Toluca','TLC'),

(8420,'Australia','AU','Tom Price~ Western Australia','TPR'),

(8421,'Malaysia','MY','Tomanggong','TMG'),

(8422,'Mali','ML','Tombouctou','TOM'),

(8423,'USA','US','Tompkinsville~ KY','TZV'),

(8424,'Russia','RU','Tomsk~ Tomsk','TOF'),

(8425,'China','CN','Tonghua','TNH'),

(8426,'China','CN','Tongliao','TGO'),

(8427,'Vanuatu','VU','Tongoa','TGH'),

(8428,'USA','US','Tonopah~ NV','TPH'),

(8430,'Papua New Guinea','PG','Tonu','TON'),

(8431,'Australia','AU','Toowoomba~ Queensland','TWB'),

(8432,'USA','US','Topeka~ KS','FOE'),

(8434,'Italy','IT','Torino (Turin)','TRN'),

(8435,'Papua New Guinea','PG','Torokina','TOK'),

(8436,'Canada','CA','Toronto~ ON','YKZ'),

(8442,'Uganda','UG','Tororo','TRY'),

(8443,'USA','US','Torrance~ CA','TOA'),

(8444,'Spain','ES','Torremolinos','UTL'),

(8445,'Mexico','MX','Torreon','TRC'),

(8446,'Vanuatu','VU','Torres','TOH'),

(8447,'USA','US','Torrington~ WY','TOR'),

(8448,'Sweden','SE','Torsby','TYF'),

(8449,'British Virgin Islands','VG','Tortola','RAD'),

(8450,'British Virgin Islands','VG','Tortola~ Beef Is.','EIS'),

(8451,'Italy','IT','Tortoli~ Sardinia','TTB'),

(8452,'Costa Rica','CR','Tortuquero','TTQ'),

(8453,'Australia','AU','Torwood~ Queensland','TWP'),

(8454,'Suriname','SR','Totness','TOT'),

(8455,'Japan','JP','Tottori','TTJ'),

(8456,'Ivory Coast','CI','Touba','TOZ'),

(8457,'Burkina Faso','BF','Tougan','TUQ'),

(8458,'Algeria','DZ','Touggourt','TGR'),

(8459,'New Caledonia','NC','Touho','TOU'),

(8460,'France','FR','Toulon/Hyeres','TLN'),

(8461,'France','FR','Toulouse','TLS'),

(8462,'Egypt','EG','Tour Sinai City','ELT'),

(8463,'France','FR','Tours','TUF'),

(8464,'France','FR','Toussus-Le-Noble','TNF'),

(8465,'Australia','AU','Townsville~ Queensland','TSV'),

(8466,'Japan','JP','Toyama','TOY'),

(8467,'Tunisia','TN','Tozeur','TOE'),

(8468,'Turkey','TR','Trabzon','TZX'),

(8469,'USA','US','Tracy~ CA','TCY'),

(8470,'Thailand','TH','Trang','TST'),

(8471,'Italy','IT','Trapani','TPS'),

(8472,'Papua New Guinea','PG','Trapani','TPI'),

(8473,'Australia','AU','Traralgon~ Victoria','TGN'),

(8474,'USA','US','Traverse City~ MI','TVC'),

(8475,'Bahamas','BS','Treasure Cay~ Abaco','TCB'),

(8476,'USA','US','Tree Point~ AK','TRP'),

(8477,'Uruguay','UY','Treinta y Tres','TYT'),

(8478,'Argentina','AR','Trelew','REL'),

(8479,'USA','US','Tremonton~ UT','TRT'),

(8480,'USA','US','Trenton~ MO','TRX'),

(8481,'USA','US','Trenton~ NJ','TTN'),

(8482,'Canada','CA','Trenton~ ON','YTR'),

(8483,'USA','US','Trenton~ TN','TGC'),

(8484,'Argentina','AR','Tres Arroyos','OYO'),

(8485,'Brazil','BR','Tres Coracoes~ MG','QID'),

(8486,'Colombia','CO','Tres Esquinas','TQS'),

(8487,'Brazil','BR','Tres Lagoas~ MT','WKU'),

(8488,'Brazil','BR','Tres Rios~ RJ','QIH'),

(8489,'Italy','IT','Treviso','QTV'),

(8491,'TN USA','US','Tri-Cities (Bristol/Johnson City','TRI'),

(8492,'Italy','IT','Trieste','TRS'),

(8493,'Mozambique','MZ','Trigo de Morais','TGS'),

(8494,'Sri Lanka','LK','Trincomalee','TRR'),

(8495,'Bolivia','BO','Trinidad','TDD'),

(8496,'USA','US','Trinidad~ CO','TAD'),

(8497,'Colombia','CO','Trinidad','TDA'),

(8498,'Cuba','CU','Trinidad','TND'),

(8499,'Canada','CA','Triple Island~ BC','YTI'),

(8500,'Libya','LY','Tripoli','TIP'),

(8501,'Lebanon','LB','Tripoli','KYE'),

(8502,'India','IN','Trivandrum','TRV'),

(8503,'Canada','CA','Trois-Rivieres~ QC','YRQ'),

(8504,'Sweden','SE','Trollhattan','THN'),

(8505,'Norway','NO','Tromso','TOS'),

(8506,'USA','US','Trona~ CA','TRH'),

(8507,'Norway','NO','Trondheim','TRD'),

(8508,'USA','US','Troy~ AL','TOI'),

(8509,'USA','US','Truckee~ CA','TKF'),

(8510,'Honduras','HN','Trujillo','TJI'),

(8511,'Peru','PE','Trujillo','TRU'),

(8512,'Micronesia','FM','Truk Island (Weno Island)','TKK'),

(8513,'NM USA','US','Truth or Consequences','TCS'),

(8514,'Madagascar','MG','Tsaratanana','TTS'),

(8515,'Papua New Guinea','PG','Tsewi','TSW'),

(8516,'Zaire','ZR','Tshikapa','TSH'),

(8517,'South Africa','ZA','Tshipise','TSD'),

(8518,'Papua New Guinea','PG','Tsili Tsili','TSI'),

(8519,'Madagascar','MG','Tsiroanomandidy','WTS'),

(8520,'Namibia','LC','Tsumeb','TSB'),

(8521,'Japan','JP','Tsushima','TSJ'),

(8522,'USA','US','Tuba City~ AZ','TBC'),

(8523,'Panama','PA','Tubala','TUW'),

(8524,'French Polynesia','PF','Tubuai~ Tubuai Islands','TUB'),

(8525,'USA','US','Tucson~ AZ','AVW'),

(8528,'Brazil','BR','Tucuma','TUZ'),

(8529,'Argentina','AR','Tucuman (San Miguel Tucuman)','TUC'),

(8530,'USA','US','Tucumcari~ NM','TCC'),

(8531,'Venezuela','VE','Tucupita','TUV'),

(8532,'Brazil','BR','Tucurui~ PA','TUR'),

(8533,'Papua New Guinea','PG','Tufi','TFI'),

(8534,'Philippines','PH','Tuguegarao','TUG'),

(8535,'Canada','CA','Tuktoyaktuk~ NT','YUB'),

(8536,'Solomon Islands','SB','Tulagi','TLG'),

(8537,'USA','US','Tulare~ CA','TLR'),

(8538,'Ecuador','EC','Tulcan','TUA'),

(8539,'Romania','RO','Tulcea','TCE'),

(8540,'Madagascar','MG','Tulear','TLE'),

(8541,'Botswana','BW','Tuli Lodge','TLD'),

(8542,'USA','US','Tullahoma~ TN','TUH'),

(8544,'USA','US','Tulsa~ OK','RVS'),

(8546,'Colombia','CO','Tulua','ULQ'),

(8547,'Canada','CA','Tulugak','YTK'),

(8548,'USA','US','Tuluksak~ AK','TLT'),

(8549,'Mexico','MX','Tulum','TUY'),

(8550,'Ethiopia','ET','Tum','TUJ'),

(8551,'Colombia','CO','Tumaco','TCO'),

(8552,'Indonesia','ID','Tumbang Samba','TBM'),

(8553,'Peru','PE','Tumbes','TBP'),

(8554,'Canada','CA','Tumbler Ridge~ BC','TUX'),

(8555,'Venezuela','VE','Tumeremo','TMO'),

(8556,'Nepal','NP','Tumlingtar','TMI'),

(8557,'Papua New Guinea','PG','Tumolbil','TLP'),

(8558,'Australia','AU','Tumut~ New South Wales','TUM'),

(8559,'Canada','CA','Tungsten~ NT','TNS'),

(8560,'Tunisia','TN','Tunis','TUN'),

(8561,'USA','US','Tuntatuliak~ AK','WTL'),

(8562,'USA','US','Tununak~ AK','TNK'),

(8563,'China','CN','Tunxi','TXN'),

(8564,'USA','US','Tupelo~ MS','TUP'),

(8565,'Panama','PA','Tupile','TUE'),

(8566,'Saudi Arabia','SA','Turaif','TUI'),

(8567,'Pakistan','PK','Turbat','TUK'),

(8568,'Colombia','CO','Turbo','TRB'),

(8569,'French Polynesia','PF','Tureia','ZTA'),

(8570,'Australia','AU','Turkey Creek~ Western Australia','TKY'),

(8571,'Finland','FI','Turku','TKU'),

(8572,'Fiji','FJ','Turtle Island','TTL'),

(8573,'USA','US','Tuscaloosa~ AL','TCL'),

(8574,'USA','US','Tuskegee~ AL','TGE'),

(8575,'USA','US','Tustin~ CA','NTK'),

(8576,'USA','US','Tuxekan Island~ AK','WNC'),

(8577,'Mexico','MX','Tuxpan','WIX'),

(8578,'Mexico','MX','Tuxtla Gutierrez','TGX'),

(8580,'Vietnam','VN','Tuy Hoa','TBB'),

(8581,'Russia','RU','Tver (Kalinin)~ Tver','KLD'),

(8582,'USA','US','Twentynine Palms~ CA','TNP'),

(8583,'CA USA','US','Twentynine Palms','NXP'),

(8584,'ID USA','US','Twin Falls','TWF'),

(8585,'USA','US','Twin Hills~ AK','TWA'),

(8586,'USA','US','Two Harbors~ MN','TWM'),

(8587,'USA','US','Tyler~ TX','TYR'),

(8588,'USA','US','Tyonek~ AK','TYE'),

(8589,'Russia','RU','Tyumem~ Tyumen','TJM'),

(8590,'South Africa','ZA','Tzaneen','LTA'),

(8591,'Thailand','TH','U-Taphao (Utapao)~ Pattaya','UTP'),

(8592,'French Polynesia','PF','Ua Huka~ Marquesas Islands','UAH'),

(8593,'French Polynesia','PF','Ua Pu~ Marquesas Islands','UAP'),

(8594,'Guatemala','GT','Uaxactun','UAX'),

(8595,'Brazil','BR','Ubatuba','UBT'),

(8596,'Japan','JP','Ube','UBJ'),

(8597,'Brazil','BR','Uberaba~ MG','UBA'),

(8598,'Brazil','BR','Uberlandia~ MG','UDI'),

(8599,'Thailand','TH','Ubon Ratchathni','UBP'),

(8600,'Peru','PE','Uchiza','UCZ'),

(8601,'India','IN','Udaipur','UDR'),

(8602,'Italy','IT','Udine','UDN'),

(8603,'Laos','LA','Udomxay','UDO'),

(8604,'Thailand','TH','Udon Thani','UTH'),

(8605,'Russia','RU','Ufa~ Bashkortostan','UFA'),

(8606,'USA','US','Uganik~ AK','UGI'),

(8607,'USA','US','Ugashik~ AK','UGA'),

(8608,'Slovakia','SK','Uherske Hradiste','UHE'),

(8609,'Angola','AO','Uige','UGO'),

(8610,'Marshall Islands','MH','Ujae Island','UJE'),

(8611,'Indonesia','ID','Ujung Pandang','UPG'),

(8612,'Russia','RU','Ukhta~ Komi','UCT'),

(8613,'USA','US','Ukiah~ CA','UKI'),

(8614,'Kuwait','KW','Ul Kmars','ULK'),

(8615,'Mongolia','MN','Ulan Bator','ULN'),

(8616,'Russia','RU','Ulan Ude~ Buryatia','UUD'),

(8617,'China','CN','Ulanhot','HLH'),

(8618,'Vanuatu','VU','Ulei','ULB'),

(8619,'Micronesia','FM','Ulithi Island','ULI'),

(8620,'Germany','DE','Ulm','QUL'),

(8621,'South Korea','KR','Ulsan','USN'),

(8622,'South Africa','ZA','Ulundi','ULD'),

(8623,'Papua New Guinea','PG','Umba','UMC'),

(8624,'Sweden','SE','Umea','UME'),

(8625,'USA','US','Umiat~ AK','UMT'),

(8626,'Canada','CA','Umiujaq~ QC','YUD'),

(8627,'United Arab Emirates','AE','Umm Alquwain','QIW'),

(8628,'USA','US','Umnak Island~ AK','UNS'),

(8629,'USA','US','Umnak~ AK','UMB'),

(8630,'South Africa','ZA','Umtata~ Transkei','UTT'),

(8631,'Brazil','BR','Umuarama~ PR','UMU'),

(8632,'USA','US','Unalakleet~ AK','UNK'),

(8633,'USA','US','Unalaska~ AK','UNL'),

(8634,'Saudi Arabia','SA','Unayzah','UZH'),

(8635,'Australia','AU','Undarra','UDA'),

(8636,'Colombia','CO','Unguia','UNC'),

(8637,'Brazil','BR','Uniao do Vitoria~ PR','QVB'),

(8638,'USA','US','Union City~ TN','UCY'),

(8639,'St. Vincent and the Grenadines','VC','Union Island','UNI'),

(8640,'USA','US','Universal City/San Antonio~ TX','RND'),

(8641,'United Kingdom','GB','Unst~ Shetland Islands','UNT'),

(8642,'Costa Rica','CR','Upala','UPL'),

(8643,'United Kingdom','GB','Upavon~ England','UPV'),

(8644,'Greenland','GL','Upernavik','JUV'),

(8645,'Papua New Guinea','PG','Upiara','UPR'),

(8646,'South Africa','ZA','Upington','UTN'),

(8647,'USA','US','Upland~ CA','CCB'),

(8649,'United Kingdom','GB','Upper Heyford~ England','UHF'),

(8650,'Canada','CA','Uranium City~ SK','YBE'),

(8651,'Uzbekhistan','UZ','Urgench~ Karakalpakstan','UGC'),

(8652,'Afghanistan','AF','Urgoon','URN'),

(8653,'Colombia','CO','Uribe','URI'),

(8654,'Venezuela','VE','Uriman','URM'),

(8655,'Iran','IR','Urmieh','OMH'),

(8656,'Colombia','CO','Urrao','URR'),

(8657,'Mexico','MX','Uruapan','UPN'),

(8658,'Brazil','BR','Urubupunga~ MT','URB'),

(8659,'Brazil','BR','Uruguaiana~ RS','URG'),

(8660,'China','CN','Urumqi','URC'),

(8661,'Afghanistan','AF','Uruzgan','URZ'),

(8662,'Australia','AU','Useless Loop~ Western Australia','USL'),

(8663,'Argentina','AR','Ushuaia','USH'),

(8664,'Papua New Guinea','PG','Usino','USO'),

(8665,'Russia','RU','Usinsk','USK'),

(8666,'Russia','RU','Ust\'Ilimsk~ Irkutsk','UIK'),

(8667,'Panama','PA','Ustuop','UTU'),

(8668,'USA','US','Utica~ MI','UIZ'),

(8669,'USA','US','Utica~ NY','UCA'),

(8670,'Honduras','HN','Utila Island','UII'),

(8671,'Marshall Islands','MH','Utirik','UTK'),

(8672,'USA','US','Utopia Creek~ AK','UTO'),

(8673,'Japan','JP','Utsunomiya','QUT'),

(8674,'Thailand','TH','Uttaradit','UTR'),

(8675,'Greenland','GL','Uummannaq','UMD'),

(8676,'USA','US','Uvalde~ TX','UVA'),

(8677,'Papua New Guinea','PG','Uvol','UVO'),

(8678,'USA','US','Uyak~ AK','KUY'),

(8680,'Ukraine','UA','Uzhgorod~ Zakarpats\'ka (Transcar','UDJ'),

(8681,'Finland','FI','Vaasa','VAA'),

(8682,'Norway','NO','Vadsoe (Vadso)','VDS'),

(8683,'Norway','NO','Vaeroy','VRY'),

(8684,'French Polynesia','PF','Vahitahi','VHZ'),

(8685,'USA','US','Vail~ CO','WHR'),

(8686,'USA','US','Vail/Eagle~ CO','EGE'),

(8687,'France','FR','Val d\'Isere','VAZ'),

(8688,'Canada','CA','Val d\'Or~ QC','YVO'),

(8689,'France','FR','Valbonne','QVI'),

(8690,'Argentina','AR','Valcheta','VCF'),

(8691,'Spain','ES','Valdepenas','YDY'),

(8692,'USA','US','Valdez~ AK','VDZ'),

(8693,'Chile','CL','Valdivia','ZAL'),

(8694,'USA','US','Valdosta~ GA','VAD'),

(8696,'Brazil','BR','Valenca~ BA','VAL'),

(8697,'France','FR','Valence','VAF'),

(8698,'Venezuela','VE','Valencia','VLN'),

(8699,'Spain','ES','Valencia','VLC'),

(8700,'USA','US','Valentine~ NE','VTN'),

(8701,'Venezuela','VE','Valera','VLV'),

(8702,'Vanuatu','VU','Valesdir','VLS'),

(8703,'Spain','ES','Valladolid','VLL'),

(8704,'Venezuela','VE','Valle de Pascua','VDP'),

(8705,'Colombia','CO','Valledupar','VUP'),

(8706,'Mexico','MX','Vallejo','VLO'),

(8707,'Chile','CL','Vallenar','VLR'),

(8708,'Mexico','MX','Valles','VAE'),

(8709,'Chile','CL','Valparaiso','VAP'),

(8710,'USA','US','Valparaiso~ FL','EGI'),

(8711,'USA','US','Valparaiso~ IN','VPZ'),

(8712,'Spain','ES','Valverde','VDE'),

(8713,'USA','US','Van Horn~ TX','VHN'),

(8714,'USA','US','Van Wert~ OH','VNW'),

(8715,'Turkey','TR','Van','VAN'),

(8716,'Canada','CA','Vancouver (Boundary Bay)~ BC','YDT'),

(8717,'Canada','CA','Vancouver (Coal Harbour)','CXH'),

(8718,'Canada','CA','Vancouver~ BC','YBD'),

(8720,'USA','US','Vandalia~ IL','VLA'),

(8721,'Laos','LA','Vangrieng','VGG'),

(8722,'Papua New Guinea','PG','Vanimo','VAI'),

(8723,'China','CN','Vanji','VNJ'),

(8724,'France','FR','Vannes','VNE'),

(8725,'Australia','AU','Vanrook~ Queensland','VNR'),

(8726,'Fiji','FJ','Vanuabalavu','VBV'),

(8727,'Cuba','CU','Varadero','VRA'),

(8728,'India','IN','Varanasi','VNS'),

(8729,'Norway','NO','Vardo (Vardoe)','VAW'),

(8730,'Brazil','BR','Varginha~ MG','VAG'),

(8731,'Finland','FI','Varkaus','VRK'),

(8732,'Bulgaria','BG','Varna','VAR'),

(8733,'Germany','DE','Varrelbusch','VAC'),

(8734,'Sweden','SE','Vasteras','VST'),

(8735,'Sweden','SE','Vastervik','VVK'),

(8736,'Madagascar','MG','Vatomandry','VAT'),

(8737,'Fiji','FJ','Vatukoula','VAU'),

(8738,'Fiji','FJ','Vatulele','VTF'),

(8739,'Tonga','TO','Vava\'u','VAV'),

(8740,'Sweden','SE','Vaxjo','VXO'),

(8741,'Denmark','DK','Vejle','VEJ'),

(8742,'Russia','RU','Velikiye Luki (Welikije Luki)~ P','VEK'),

(8743,'Russia','RU','Velikiye Luki~ Pskov','VLU'),

(8744,'USA','US','Venetie~ AK','VEE'),

(8745,'Italy','IT','Venezia (Venice)','VCE'),

(8746,'USA','US','Venice~ FL','VNC'),

(8747,'Mexico','MX','Veracruz','VER'),

(8748,'Canada','CA','Vermilion~ AB','YVG'),

(8749,'USA','US','Vermillion~ SD','VMR'),

(8750,'USA','US','Vernal~ UT','VEL'),

(8751,'Canada','CA','Vernon~ BC','YVE'),

(8752,'USA','US','Vero Beach~ FL','VRB'),

(8753,'Italy','IT','Verona','VRN'),

(8754,'France','FR','Versailles','VRS'),

(8755,'USA','US','Versailles~ OH','VES'),

(8756,'Iceland','IS','Vestmannaeyjar','VEY'),

(8757,'Italy','IT','Vicenza','VIC'),

(8758,'Uruguay','UY','Vichadero','VCH'),

(8759,'France','FR','Vichy','VHY'),

(8760,'USA','US','Vicksburg~ MS','VKS'),

(8761,'Cuba','CU','Victoria de las Tunas','QVT'),

(8762,'Zimbabwe','ZW','Victoria Falls','VFA'),

(8763,'Australia','AU','Victoria River Downs~ Northern T','VCD'),

(8764,'Canada','CA','Victoria~ BC','YWH'),

(8766,'Cameroon','CM','Victoria','VCC'),

(8767,'Chile','CL','Victoria','ZIC'),

(8768,'Honduras','HN','Victoria','VTA'),

(8769,'Australia','AU','Victoria~ New South Wales','AVV'),

(8770,'USA','US','Victoria~ TX','VCT'),

(8771,'USA','US','Victorville~ CA','VCV'),

(8772,'USA','US','Vidalia~ GA','VDI'),

(8773,'Bulgaria','BG','Vidin','VID'),

(8774,'Argentina','AR','Viedma','VDM'),

(8775,'Laos','LA','Vientiane','VTE'),

(8776,'Puerto Rico','PR','Vieques','VQS'),

(8777,'USA','US','View Cove~ AK','VCB'),

(8778,'Philippines','PH','Vigan','VGN'),

(8779,'Spain','ES','Vigo','VGO'),

(8780,'India','IN','Vijayawada','VGA'),

(8781,'Mozambique','MZ','Vila Junqueiro','VJQ'),

(8782,'Portugal','PT','Vila Real','VRL'),

(8783,'Brazil','BR','Vila Rica','VLP'),

(8784,'Brazil','BR','Vila Velho~ ES','QVH'),

(8785,'Mozambique','MZ','Vilanculos','VNX'),

(8786,'Sweden','SE','Vilhelmina','VHM'),

(8787,'Brazil','BR','Vilhena~ RO','BVH'),

(8788,'Mexico','MX','Villa Constitucion','VIB'),

(8789,'Argentina','AR','Villa Dolores','VDR'),

(8790,'Argentina','AR','Villa Gesell','VLG'),

(8791,'Argentina','AR','Villa Mercedes','VME'),

(8792,'Bolivia','BO','Villa Montes','VLM'),

(8793,'Colombia','CO','Villagarzon','VGZ'),

(8794,'Mexico','MX','Villahermosa','VSA'),

(8795,'Colombia','CO','Villavicencio','VVC'),

(8796,'Lithuania','LT','Vilnius','VNO'),

(8797,'Chile','CL','Vina del Mar','KNA'),

(8798,'USA','US','Vincennes~ IN','OEA'),

(8799,'Vietnam','VN','Vinh Long','XVL'),

(8800,'Russia','RU','Vinnytsya~ Vinnytsya','VIN'),

(8801,'USA','US','Vinton~ IA','VTI'),

(8802,'Indonesia','ID','Viqueque','VIQ'),

(8803,'Philippines','PH','Virac','VRC'),

(8804,'British Virgin Islands','VG','Virgin Gorda (Valley)~ Virgin Go','VIJ'),

(8805,'British Virgin Islands','VG','Virgin Gorda','NSX'),

(8806,'U.S. Virgin Islands','US','Virgin Islands','XVI'),

(8807,'VA USA','US','Virginia Beach','NTU'),

(8808,'Solomon Islands','SB','Viru','QVU'),

(8810,'USA','US','Visalia~ CA','VIS'),

(8811,'Sweden','SE','Visby','VBY'),

(8812,'Portugal','PT','Viseu','VSE'),

(8813,'India','IN','Vishakhapatnam','VTZ'),

(8814,'Brazil','BR','Vitoria da Conquista~ BA','VDC'),

(8815,'Brazil','BR','Vitoria~ ES','VIX'),

(8816,'Spain','ES','Vitoria','VIT'),

(8817,'Belarus','BY','Vitsyebsk (Vitebsk)~ Vitsyebsk','VTB'),

(8818,'France','FR','Vittel','VTL'),

(8819,'Papua New Guinea','PG','Vivigani','VIV'),

(8820,'India','IN','Vizag','VIZ'),

(8821,'Russia','RU','Vladikavkaz~ North Ossetia','OGZ'),

(8822,'Russia','RU','Vladivostok~ Primor\'ye','VVO'),

(8823,'Madagascar','MG','Vohemar','VOH'),

(8824,'Liberia','LR','Voinjama','VOI'),

(8825,'Russia','RU','Volgodonsk~ Rostov','VLK'),

(8826,'Russia','RU','Volgograd (Stalingrad)~ Volgogra','VOG'),

(8827,'Greece','GR','Volos','VOL'),

(8828,'Madagascar','MG','Volovan','WVV'),

(8829,'Brazil','BR','Volta Redonda~ RJ','QVR'),

(8830,'Iceland','IS','Vopnafjordur','VPN'),

(8831,'Russia','RU','Vorkuta~ Komi','VKT'),

(8832,'Russia','RU','Voronezh~ Voronezh','VOZ'),

(8833,'Brazil','BR','Votuporanga~ SP','VOT'),

(8834,'South Africa','ZA','Vredendal','VRE'),

(8835,'South Africa','ZA','Vryburg','VRU'),

(8836,'South Africa','ZA','Vryheid','VYD'),

(8837,'Papua New Guinea','PG','Wabag','WAB'),

(8838,'USA','US','Wabash~ IN','IWH'),

(8839,'Papua New Guinea','PG','Wabo','WAO'),

(8840,'Canada','CA','Wabush~ NF','YWK'),

(8841,'Ethiopia','ET','Waca','WAC'),

(8842,'Angola','AO','Waco Kungo','CEO'),

(8843,'USA','US','Waco~ TX','CNW'),

(8845,'Sudan','SD','Wad Medani','DNI'),

(8846,'United Kingdom','GB','Waddington~ England','WTN'),

(8847,'Saudi Arabia','SA','Wadi Ad Dawasir','WAE'),

(8848,'Yemen','YE','Wadi Ain','WDA'),

(8849,'Sudan','SD','Wadi Halfa','WHF'),

(8850,'Suriname','SR','Wageningen','AGI'),

(8851,'Indonesia','ID','Wagethe','WET'),

(8852,'Australia','AU','Wagga Wagga~ New South Wales','WGA'),

(8853,'Gabon','GA','Wagny','WGY'),

(8854,'USA','US','Wahiawa~ HI','HHI'),

(8855,'USA','US','Wahoo~ NE','AHQ'),

(8856,'USA','US','Wahpeton~ ND','WAH'),

(8857,'USA','US','Waikoloa~ HI','WKL'),

(8858,'USA','US','Waimanalo~ HI','BLW'),

(8859,'Indonesia','ID','Waingapu','WGP'),

(8860,'Canada','CA','Wainwright~ AB','YWV'),

(8861,'USA','US','Wainwright~ AK','AIN'),

(8862,'New Zealand','NZ','Waitangi','WGN'),

(8863,'Kenya','KE','Wajir','WJR'),

(8864,'Fiji','FJ','Wakaya Island','KAY'),

(8865,'Wake Island','US','Wake Island','AWK'),

(8866,'Japan','JP','Wakkanai','WKJ'),

(8867,'Solomon Islands','SB','Wakunai','WKN'),

(8868,'Vanuatu','VU','Walaha','WLH'),

(8869,'Australia','AU','Walcha~ New South Wales','WLC'),

(8870,'USA','US','Wales~ AK','WAA'),

(8871,'Australia','AU','Walgett~ New South Wales','WGE'),

(8872,'Bahamas','BS','Walker\'s Cay~ Abaco','WKR'),

(8873,'USA','US','Walla Walla~ WA','ALW'),

(8874,'USA','US','Wallace~ NC','ACZ'),

(8875,'Australia','AU','Wallal','WLA'),

(8876,'Wallis and Futuna Islands','WF','Wallis Island','WLS'),

(8877,'USA','US','Walnut Ridge~ AR','ARG'),

(8878,'USA','US','Walterboro~ SC','RBW'),

(8879,'USA','US','Waltham~ MA','WLM'),

(8880,'Namibia','LC','Walvis Bay','WVB'),

(8881,'Indonesia','ID','Wamena','WMX'),

(8882,'Pakistan','PK','Wana','WAF'),

(8883,'New Zealand','NZ','Wanaka','WKA'),

(8884,'Papua New Guinea','PG','Wando','WDO'),

(8885,'New Zealand','NZ','Wanganui','WAG'),

(8886,'Australia','AU','Wangaratta~ Victoria','WGT'),

(8887,'Germany','DE','Wangerooge','AGE'),

(8888,'Papua New Guinea','PG','Wanigela','AGL'),

(8889,'Papua New Guinea','PG','Wantoat','WTT'),

(8890,'Papua New Guinea','PG','Wanuma','WNU'),

(8891,'China','CN','Wanxian~ Sichuan','WXN'),

(8892,'USA','US','Wapakoneta~ OH','AXV'),

(8893,'Papua New Guinea','PG','Wapenamanda','WBM'),

(8894,'Kazakhstan','KZ','Waraghandy (Karaganda)~ Qaraghan','KGF'),

(8895,'Ethiopia','ET','Warder','WRA'),

(8896,'USA','US','Ware~ MA','UWA'),

(8897,'Indonesia','ID','Waris','WAR'),

(8898,'USA','US','Warminster~ PA','NJP'),

(8899,'USA','US','Warner Robins~ GA','WRB'),

(8900,'Australia','AU','Warraber Island~ Queensland','WBA'),

(8901,'Australia','AU','Warracknabeal~ Victoria','WKB'),

(8902,'Australia','AU','Warramboor/Mt. Keith~ Western Au','WME'),

(8903,'Australia','AU','Warranagine~ Western Australia','WRW'),

(8904,'India','IN','Warrangal','WGC'),

(8905,'Australia','AU','Warren~ New South Wales','QRR'),

(8906,'Australia','AU','Warrnambool~ Victoria','WMB'),

(8907,'USA','US','Warroad~ MN','WAX'),

(8908,'Poland','PL','Warszawa (Warsaw)','WAW'),

(8909,'Australia','AU','Warwick~ Queensland','WAZ'),

(8910,'USA','US','Waseca~ MN','ACQ'),

(8911,'Suriname','SR','Washabo','WSO'),

(8912,'USA','US','Washington~ DC','NDV'),

(8919,'USA','US','Washington~ GA','IIY'),

(8920,'USA','US','Washington~ IA','AWG'),

(8921,'USA','US','Washington~ IN','DCY'),

(8922,'USA','US','Washington~ NC','OCW'),

(8923,'USA','US','Washington~ PA','WSG'),

(8924,'USA','US','Wasilla~ AK','WWA'),

(8925,'Indonesia','ID','Wasior','WSR'),

(8926,'Canada','CA','Waskaganish~ QC','YKQ'),

(8927,'Papua New Guinea','PG','Wasu','WSU'),

(8928,'Papua New Guinea','PG','Wasua','WSA'),

(8929,'USA','US','Waterfall~ AK','KWF'),

(8930,'Ireland','IE','Waterford','WAT'),

(8931,'USA','US','Waterloo~ IA','ALO'),

(8932,'Australia','AU','Waterloo~ Northern Territory','WLO'),

(8933,'USA','US','Watersmeet~ MI','RXW'),

(8934,'USA','US','Watertown~ NY','ART'),

(8935,'USA','US','Watertown~ SD','ATY'),

(8936,'USA','US','Watertown~ WI','RYV'),

(8937,'USA','US','Waterville~ ME','WVL'),

(8938,'Canada','CA','Watson Lake~ YT','YQH'),

(8939,'USA','US','Watsonville~ CA','WVI'),

(8940,'Papua New Guinea','PG','Wau','WUG'),

(8941,'Sudan','SD','Wau','WUU'),

(8942,'Australia','AU','Wauchope~ New South Wales','WAU'),

(8943,'USA','US','Waukesha~ WI','UES'),

(8944,'USA','US','Waukon~ IA','UKN'),

(8945,'USA','US','Wausau (Mosinee)~ WI','CWA'),

(8946,'USA','US','Wausau~ WI','AUW'),

(8947,'USA','US','Wauseon~ OH','USE'),

(8948,'Australia','AU','Wave Hill~ Northern Territory','WAV'),

(8949,'United Kingdom','GB','Waverney','WAN'),

(8950,'Canada','CA','Wawa~ ON','YXZ'),

(8951,'Papua New Guinea','PG','Wawoi Falls','WAJ'),

(8952,'USA','US','Waycross~ GA','AYS'),

(8953,'USA','US','Waynesboro~ GA','BXG'),

(8954,'USA','US','Waynesburg~ PA','WAY'),

(8955,'Papua New Guinea','PG','Weam','WEP'),

(8956,'Liberia','LR','Weasua','WES'),

(8957,'USA','US','Weatherford~ TX','WEA'),

(8958,'Canada','CA','Webequie~ ON','YWP'),

(8960,'USA','US','Webster City~ IA','EBS'),

(8961,'Papua New Guinea','PG','Wedau','WED'),

(8962,'Saudi Arabia','SA','Wedjh','EJH'),

(8963,'Australia','AU','Wee Waa~ New South Wales','WEW'),

(8964,'USA','US','Weeping Water~ NE','EPG'),

(8965,'China','CN','Weifang','WEF'),

(8966,'China','CN','Weihai','WEH'),

(8967,'Australia','AU','Weipa~ Queensland','WEI'),

(8968,'South Africa','ZA','Welkom','WEL'),

(8969,'New Zealand','NZ','Wellington','WLG'),

(8970,'USA','US','Wellington~ KS','EGT'),

(8971,'USA','US','Wells~ NV','LWL'),

(8972,'NY [Wellsville Municipal Airport] USA','US','Wellsville','ELZ'),

(8973,'Australia','AU','Welshpool~ Victoria','WHL'),

(8974,'Canada','CA','Wemindji~ QC','YNC'),

(8975,'USA','US','Wenatchee~ WA','EAT'),

(8976,'USA','US','Wendover~ UT','ENV'),

(8977,'China','CN','Wenzhou','WNZ'),

(8978,'Indonesia','ID','Werur','WRR'),

(8979,'Nicaragua','NI','Wespam','WSP'),

(8980,'USA','US','West Bend~ WI','ETB'),

(8981,'Bahamas','BS','West End','WTD'),

(8982,'British Virgin Islands','VG','West End~ Tortola','TOV'),

(8983,'USA','US','West Houston~ TX','WHA'),

(8984,'USA','US','West Kavi~ AK','VKW'),

(8985,'USA','US','West Kuparuk~ AK','XPU'),

(8986,'United Kingdom','GB','West Malling~ England','WEM'),

(8987,'USA','US','West Memphis~ AR','AWM'),

(8988,'USA','US','West Palm Beach~ FL','LNA'),

(8990,'USA','US','West Plains~ MO','UNO'),

(8991,'USA','US','West Point~ AK','KWP'),

(8992,'Australia','AU','West Wyalong~ New South Wales','WWY'),

(8993,'USA','US','West Yellowstone~ MT','WYS'),

(8994,'NY USA','US','Westchester County (White Plains','HPN'),

(8995,'Germany','DE','Westerland~ Sylt Island','GWT'),

(8996,'USA','US','Westerly~ RI','WST'),

(8997,'USA','US','Westfield~ MA','BAF'),

(8998,'USA','US','Westhampton Beach~ NY','FOK'),

(8999,'New Zealand','NZ','Westport','WPT'),

(9001,'United Kingdom','GB','Westray','WRY'),

(9002,'USA','US','Westsound~ WA','WSX'),

(9003,'Germany','DE','Wetzlar','ZQQ'),

(9004,'Papua New Guinea','PG','Wewak','WWK'),

(9005,'Ireland','IE','Wexford','WEX'),

(9006,'New Zealand','NZ','Whakatane','WHK'),

(9007,'Canada','CA','Whale Cove~ NT','YXN'),

(9008,'USA','US','Whale Pass~ AK','WWP'),

(9009,'United Kingdom','GB','Whalsay','WHS'),

(9010,'New Zealand','NZ','Whangarei','WRE'),

(9011,'USA','US','Wharton~ TX','WHT'),

(9012,'USA','US','Wheatland~ WY','EAN'),

(9013,'USA','US','Wheeling~ WV','HLG'),

(9014,'Afghanistan','AF','Wheghnan','SGA'),

(9015,'Canada','CA','Whistler~ BC','YWS'),

(9016,'USA','US','White Mountain~ AK','WMO'),

(9017,'Canada','CA','White River~ ON','YWR'),

(9018,'USA','US','White Sands~ NM','WSD'),

(9019,'USA','US','White Sulphur Springs~ WV','SSU'),

(9020,'Canada','CA','Whitecourt~ AB','YZU'),

(9021,'USA','US','Whitefield~ NH','HIE'),

(9022,'Canada','CA','Whitehorse~ YT','YXY'),

(9023,'USA','US','Whiteriver~ AZ','WTR'),

(9024,'USA','US','Whitesburg~ KY','BRG'),

(9025,'Australia','AU','Whitsunday Kontiki Resort (Long ','HAP'),

(9026,'Australia','AU','Whitsunday~ Queensland','KYF'),

(9027,'New Zealand','NZ','Whittanga','WTZ'),

(9028,'Australia','AU','Whyalla~ South Australia','WYA'),

(9029,'Canada','CA','Wiarton~ ON','YVV'),

(9030,'USA','US','Wichita Falls~ TX','KIP'),

(9031,'TX USA','US','Wichita Falls','SPS'),

(9032,'USA','US','Wichita~ KS','BEC'),

(9036,'United Kingdom','GB','Wick','WIC'),

(9037,'Australia','AU','Wickham','WHM'),

(9038,'Austria','AT','Wien (Vienna)','VIE'),

(9039,'Germany','DE','Wiesbaden','WIE'),

(9041,'Australia','AU','Wilcannia~ South Australia','WIO'),

(9042,'Germany','DE','Wildenrath','WID'),

(9043,'USA','US','Wildwood~ AK','WWS'),

(9044,'Germany','DE','Wilhemshaven','WVN'),

(9045,'USA','US','Wilkes-Barre~ PA','WBW'),

(9046,'PA USA','US','Wilkes-Barre/Scranton','AVP'),

(9047,'USA','US','Wilkesboro~ NC','IKB'),

(9048,'Canada','CA','Williams Harbour~ NF','YWM'),

(9049,'Canada','CA','Williams Lake~ BC','YWL'),

(9050,'USA','US','Williamsburg~ VA','JGG'),

(9051,'USA','US','Williamsport~ PA','IPT'),

(9052,'USA','US','Willimantic~ CT','IJD'),

(9053,'USA','US','Williston~ ND','ISN'),

(9054,'USA','US','Willmar~ MN','ILL'),

(9055,'USA','US','Willoughby~ OH','LNN'),

(9056,'USA','US','Willow Grove~ PA','NXX'),

(9057,'USA','US','Willow~ AK','WOW'),

(9058,'USA','US','Willows~ CA','WLW'),

(9059,'USA','US','Wilmington~ DE','ILG'),

(9060,'USA','US','Wilmington~ NC','ILM'),

(9061,'USA','US','Wilmington~ OH','ILN'),

(9062,'USA','US','Wilton~ CT','QCW'),

(9063,'Australia','AU','Wiluna~ Western Australia','WUN'),

(9064,'USA','US','Winchester~ VA','WGO'),

(9065,'Australia','AU','Windarra~ Western Australia','WND'),

(9066,'USA','US','Winder~ GA','WDR'),

(9067,'Namibia','LC','Windhoek','ERS'),

(9069,'USA','US','Windom~ MN','MWM'),

(9070,'Australia','AU','Windorah Park~ Queensland','WNR'),

(9071,'Canada','CA','Windsor~ ON','YQG'),

(9072,'USA','US','Winfield/Arkansas City~ KS','WLD'),

(9073,'Canada','CA','Winisk~ ON','YWN'),

(9074,'USA','US','Wink~ TX','INK'),

(9075,'USA','US','Winnemucca~ NV','WMC'),

(9076,'Canada','CA','Winnipeg~ MB','YWG'),

(9077,'USA','US','Winnsboro~ SC','FDW'),

(9078,'USA','US','Winona~ MN','ONA'),

(9079,'USA','US','Winslow~ AZ','INW'),

(9080,'USA','US','Winston-Salem~ NC','INT'),

(9081,'USA','US','Winter Haven~ FL','GIF'),

(9082,'USA','US','Winter Park~ CO','QWP'),

(9083,'Australia','AU','Winton~ Queensland','WIN'),

(9084,'Papua New Guinea','PG','Wipim','WPM'),

(9085,'USA','US','Wiscasset~ ME','ISS'),

(9086,'USA','US','Wisconsin Rapids~ WI','ISW'),

(9087,'USA','US','Wise~ VA','LNP'),

(9088,'USA','US','Wiseman~ AK','WSM'),

(9089,'Australia','AU','Wittendom Gorge~ Western Austral','WIT'),

(9090,'Papua New Guinea','PG','Witu','WIU'),

(9091,'USA','US','Woburn~ MA','WBN'),

(9092,'Netherlands','NL','Woensdrecht','WOE'),

(9093,'Papua New Guinea','PG','Woitape','WTP'),

(9094,'Marshall Islands','MH','Woja','WJA'),

(9095,'USA','US','Wolf Point~ MT','OLF'),

(9096,'Canada','CA','Wollaston Lake~ SK','ZWL'),

(9097,'Australia','AU','Wollogorang','WLL'),

(9098,'Australia','AU','Wollongong~ New South Wales','WOL'),

(9099,'Liberia','LR','Wologissi','WOI'),

(9100,'Taiwan','TW','Wonan','WOT'),

(9101,'Australia','AU','Wondai','WDI'),

(9102,'Australia','AU','Wondoola','WON'),

(9103,'Papua New Guinea','PG','Wonenara','WOA'),

(9104,'Venezuela','VE','Wonken','WOK'),

(9105,'USA','US','Wood River~ AK','WOD'),

(9106,'USA','US','Woodchopper~ AK','WOO'),

(9107,'Australia','AU','Woodgreen~ Northern Territory','WOG'),

(9108,'USA','US','Woodward~ OK','WWR'),

(9109,'Australia','AU','Woomera~ South Australia','UMR'),

(9110,'USA','US','Wooster~ OH','BJJ'),

(9111,'Gabon','GA','Wora Na Ye','WNE'),

(9112,'USA','US','Worcester~ MA','ORH'),

(9113,'USA','US','Worland~ WY','WRL'),

(9114,'USA','US','Worthington~ MN','OTG'),

(9115,'Marshall Islands','MH','Wotho','WTO'),

(9116,'Marshall Islands','MH','Wotje','WTE'),

(9117,'USA','US','Wrangell~ AK','WRG'),

(9118,'USA','US','Wrightstown~ NJ','WRI'),

(9119,'Canada','CA','Wrigley~ NT','YWY'),

(9120,'Poland','PL','Wroclaw','WRO'),

(9121,'Australia','AU','Wrotham~ Queensland','WPK'),

(9122,'Australia','AU','Wudinna~ South Australia','WUD'),

(9123,'China','CN','Wuhan','WUH'),

(9124,'China','CN','Wuhu','WHU'),

(9125,'Canada','CA','Wunnummin Lake~ ON','WNN'),

(9126,'Germany','DE','Wuppertal','UWP'),

(9127,'Germany','DE','Wurzburg','QWU'),

(9128,'Papua New Guinea','PG','Wuvulu Island','WUV'),

(9129,'China','CN','Wuxi','WUX'),

(9130,'China','CN','Wuyishan','WUS'),

(9131,'China','CN','Wuzhou','WUZ'),

(9132,'Germany','DE','Wyk auf Foehr','OHR'),

(9133,'Australia','AU','Wyndham~ Western Australia','WYN'),

(9134,'Canada','CA','Wynyard~ SK','YYO'),

(9135,'Australia','AU','Wynyard~ Tasmania','WNY'),

(9136,'Mozambique','MZ','Xai-Xai (Vila de Joao Belo)','VJB'),

(9137,'Angola','AO','Xangongo','XGN'),

(9138,'Laos','LA','Xayabury','XAY'),

(9139,'China','CN','Xiamen (Amoy)','XMA'),

(9140,'China','CN','Xiamen','XMN'),

(9141,'China','CN','Xian (Zi An)','SIA'),

(9142,'China','CN','Xian Xianyang','XIY'),

(9143,'China','CN','Xiangfan','XFN'),

(9144,'China','CN','Xichang','XIC'),

(9145,'Laos','LA','Xieng Khouang','XKH'),

(9146,'Laos','LA','Xienglom','XIE'),

(9147,'China','CN','Xilinhot','XIL'),

(9148,'China','CN','Xingcheng','XEN'),

(9149,'China','CN','Xingning','XIN'),

(9150,'China','CN','Xingtai','XNT'),

(9151,'Brazil','BR','Xinguara','XIG'),

(9152,'China','CN','Xining','XNN'),

(9153,'China','CN','Xuzhou','XUZ'),

(9154,'Bolivia','BO','Yacuiba','BYC'),

(9155,'Cameroon','CM','Yagoua','GXX'),

(9156,'Colombia','CO','Yaguara','AYG'),

(9157,'USA','US','Yakima~ WA','YKM'),

(9159,'Japan','JP','Yaku Shima','KUM'),

(9160,'USA','US','Yakutat~ AK','YAK'),

(9161,'Australia','AU','Yalata Mission~ South Australia','KYI'),

(9162,'Australia','AU','Yalgoo~ Western Australia','YLG'),

(9163,'Central African Republic','CF','Yalinga','AIG'),

(9164,'Turkey','TR','Yalova/Asagisoloz','TYA'),

(9165,'Papua New Guinea','PG','Yalumet','KYX'),

(9166,'Australia','AU','Yam Island~ Queensland','XMY'),

(9167,'Japan','JP','Yamagata~ Honshu','GAJ'),

(9168,'Ivory Coast','CI','Yamoussoukro','ASK'),

(9169,'China','CN','Yan An','ENY'),

(9170,'Saudi Arabia','SA','Yanbu','YNB'),

(9171,'China','CN','Yanchen','YNZ'),

(9172,'Solomon Islands','SB','Yandina~ Russel Is.','XYA'),

(9173,'Zaire','ZR','Yangambi','YAN'),

(9174,'Myanmar','MM','Yangoon (Rangoon)','RGN'),

(9175,'China','CN','Yanji','YNJ'),

(9176,'USA','US','Yankton~ SD','YKN'),

(9177,'China','CN','Yantai','YNT'),

(9178,'Cameroon','CM','Yaounde','NSI'),

(9180,'Papua New Guinea','PG','Yapsiei','KPE'),

(9181,'Colombia','CO','Yaquara','WBX'),

(9182,'Colombia','CO','Yari','AYI'),

(9183,'Canada','CA','Yarmouth~ NS','YQI'),

(9184,'Papua New Guinea','PG','Yasuru','KSX'),

(9185,'Colombia','CO','Yavarate','VAB'),

(9186,'Panama','PA','Yaviza','PYV'),

(9187,'Iran','IR','Yazd','AZD'),

(9188,'Myanmar','MM','Ye','XYE'),

(9189,'South Korea','KR','Yechon','YEC'),

(9190,'Papua New Guinea','PG','Yegepa','PGE'),

(9191,'Russia','RU','Yekaterinburg (Ekaterinburg)~ Sv','SVX'),

(9192,'Mali','ML','Yelimane','EYL'),

(9193,'Canada','CA','Yellowknife~ NT','YZF'),

(9194,'Sierra Leone','SL','Yengema','WYE'),

(9195,'Papua New Guinea','PG','Yenkis','YEQ'),

(9196,'United Kingdom','GB','Yeovilton','YEO'),

(9197,'USA','US','Yerington~ NV','EYR'),

(9198,'USA','US','Yes Bay~ AK','WYB'),

(9199,'Papua New Guinea','PG','Yeva','YVD'),

(9200,'China','CN','Yibin~ Sichuan','YBP'),

(9201,'China','CN','Yichang','YIH'),

(9202,'China','CN','Yilan','YLN'),

(9203,'China','CN','Yinchuan','INC'),

(9204,'China','CN','Yining','YIN'),

(9205,'China','CN','Yiwu','YIW'),

(9206,'Finland','FI','Ylivieska','YLI'),

(9207,'Indonesia','ID','Yogyakarta','JOG'),

(9208,'Japan','JP','Yokohama','YOK'),

(9209,'Japan','JP','Yokota','OKO'),

(9210,'Nigeria','NG','Yola','YOL'),

(9211,'Japan','JP','Yonago','YGJ'),

(9212,'Japan','JP','Yonaguni Jima','OGN'),

(9213,'Papua New Guinea','PG','Yongai','KGH'),

(9214,'Canada','CA','York Landing~ MB','ZAC'),

(9215,'USA','US','York~ NE','JYR'),

(9216,'USA','US','York~ PA','THV'),

(9217,'Australia','AU','Yorke Islands~ Queensland','OKR'),

(9218,'Australia','AU','Yorketown~ South Australia','ORR'),

(9219,'Canada','CA','Yorkton~ SK','YQV'),

(9220,'Honduras','HN','Yoro','ORO'),

(9221,'Japan','JP','Yoron Jima','RNJ'),

(9222,'USA','US','Yosemite Park~ CA','OYS'),

(9223,'Russia','RU','Yoshkar Ola (Joshkar-Ola)~ Mari-','JOK'),

(9224,'South Korea','KR','Yosu','RSU'),

(9225,'Australia','AU','Young~ New South Wales','NGA'),

(9226,'USA','US','Youngstown~ OH','YNG'),

(9227,'USA','US','Yucca Flats~ NV','UCC'),

(9228,'Australia','AU','Yuendumu~ Northern Territory','YUE'),

(9229,'Papua New Guinea','PG','Yule Island','RKU'),

(9230,'China','CN','Yulin','UYN'),

(9231,'USA','US','Yuma Proving Ground (Yuma)~ AZ','LGF'),

(9232,'USA','US','Yuma~ AZ','NYL'),

(9234,'Peru','PE','Yurimaguas','YMS'),

(9235,'Russia','RU','Yuzhno Sakhalinsk~ Sakhalin','UUS'),

(9236,'Yugoslavia','YU','Zabljak','ZBK'),

(9237,'Burkina Faso','BF','Zabre','XZA'),

(9238,'Czech Republic','CZ','Zabreh','ZBE'),

(9239,'Mexico','MX','Zacatecas','ZCL'),

(9240,'USA','US','Zachar Bay~ AK','KZB'),

(9241,'Croatia','HR','Zadar','ZAD'),

(9242,'Croatia','HR','Zagreb','ZAG'),

(9243,'Iran','IR','Zahedan','ZAH'),

(9244,'Chad','TD','Zakouma','AKM'),

(9245,'Greece','GR','Zakynthos','ZTH'),

(9246,'Zambia','ZM','Zambezi','BBZ'),

(9247,'Philippines','PH','Zamboanga','ZAM'),

(9248,'Mexico','MX','Zamora','ZMM'),

(9249,'Congo','CG','Zanaga','ANJ'),

(9250,'Suriname','SR','Zandery (Paramaribo)','PBM'),

(9251,'USA','US','Zanesville~ OH','ZZV'),

(9252,'Tanzania','TZ','Zanzibar Island','ZNZ'),

(9253,'Argentina','AR','Zapala','APZ'),

(9254,'Colombia','CO','Zapatoca','AZT'),

(9255,'Ukraine','UA','Zaporizhzhya~ Zaporizhzhya','OZH'),

(9256,'Spain','ES','Zaragoza','ZAZ'),

(9257,'Afghanistan','AF','Zaranj','ZAJ'),

(9258,'Nigeria','NG','Zaria','ZAR'),

(9259,'Jordan','JO','Zarka','QZA'),

(9260,'Central African Republic','CF','Zemid','IMO'),

(9261,'USA','US','Zephyrhills~ FL','ZPH'),

(9262,'India','IN','Zero','ZER'),

(9263,'Algeria','DZ','Zerzaltine','IAM'),

(9264,'Kazakhstan','KZ','Zhambyl (Dzhambul)~ Zhambyl','DMB'),

(9265,'China','CN','Zhanjiang','ZHA'),

(9266,'China','CN','Zhaotong','ZAT'),

(9267,'China','CN','Zhengzhou','CGO'),

(9268,'China','CN','Shenzhen','SZX'),

(9269,'Kazakhstan','KZ','Zhezqazghan (Dzhezkazgan)~ Zhezq','DZN'),

(9270,'Pakistan','PK','Zhob','PZH'),

(9271,'China','CN','Zhuhai','ZUH'),

(9272,'Ukraine','UA','Zhytomyr (Zhitomir)~ Zhytomyr','ZTR'),

(9273,'Poland','PL','Zielona Gora','IEG'),

(9274,'Senegal','SN','Ziguinchor','ZIG'),

(9275,'Saudi Arabia','SA','Zilfi','ZUL'),

(9276,'Slovakia','SK','Zilina','ILZ'),

(9277,'Niger','NE','Zinder','ZND'),

(9278,'Mauritania','MR','Zouerate','OUZ'),

(9279,'USA','US','Zuni Pueblo~ NM','ZUN'),

(9280,'Switzerland','CH','Zurich','ZRH'),

(9281,'Maldives','MV','Maafushi','MAF'),

(9284,'Maldives','MV','Hulhumale','HUL'),

(9285,'Maldives','MV','Ari North Atoll','NAR'),

(9286,'Maldives','MV','Ari South Atoll','SAR'),

(9287,'Maldives','MV','Baa Atoll','BAA'),

(9288,'Maldives','MV','Dhaalu Atoll','DHL'),

(9289,'Maldives','MV','Faafu Atoll','FAF'),

(9290,'Maldives','MV','Gaafu Alif Atoll','GAA'),

(9291,'Maldives','MV','Gaafu Dhaal Atoll','GAD'),

(9292,'Maldives','MV','Haa Alif Atoll','HAA'),

(9293,'Maldives','MV','Haa Dhaal Atoll','HAD'),

(9294,'Maldives','MV','Male North Atoll','NML'),

(9295,'Maldives','MV','Male South Atoll','SML'),

(9296,'Maldives','MV','Laamu Atoll','LAM'),

(9297,'Maldives','MV','Lhaviyani Atoll','LHV'),

(9298,'Maldives','MV','Meemu Atoll','MEM'),

(9299,'Maldives','MV','Fuvahmulah','FUA'),

(9300,'Maldives','MV','Noonu Atoll','NUN'),

(9301,'Maldives','MV','Raa Atoll','RAA'),

(9302,'Maldives','MV','Thaa Atoll','THA'),

(9303,'Maldives','MV','Vaavu Atoll','VAV'),

(9304,'Maldives','MV','Shaviyani Atoll','SHV'),

(9305,'Serbia','RS','Belgrade','BEG'),

(9306,'Serbia','RS','Nis','INI'),

(9307,'Serbia','RS','Uzice','UZC'),

(9308,'Serbia','RS','Kragujevac','KRG'),

(9309,'United Kingdom','GB','Cheshire','CHS'),

(9311,'France','FR','Saint-Ouen','SOU');

/*Table structure for table `oh_property` */

DROP TABLE IF EXISTS `oh_property`;

CREATE TABLE `oh_property` (
  `id` int(11) NOT NULL,
  `property_name` varchar(255) NOT NULL,
  `country_code` varchar(255) NOT NULL COMMENT '2 letter country code',
  `country_name` varchar(255) NOT NULL,
  `city_code` varchar(255) NOT NULL COMMENT '3 letter city code',
  `city_name` varchar(255) DEFAULT NULL,
  `default_meal_plan_code` int(11) DEFAULT NULL,
  `transfer_plan_code` int(11) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `oh_request_history` */

DROP TABLE IF EXISTS `oh_request_history`;

CREATE TABLE `oh_request_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `request_action` int(11) DEFAULT NULL,
  `message` text,
  `request_ip` varchar(20) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL COMMENT '1-Success, 0-Failure',
  `request_json` text,
  `response_json` text,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
