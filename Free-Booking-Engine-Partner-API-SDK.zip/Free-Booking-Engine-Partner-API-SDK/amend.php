<?php
ob_start();
$pageTitle = "Amend Booking";
include("includes/header.php");
$booking_id = $_GET['booking_id'];
if(isset($_POST['amend_booking'])){
	$amendBookingResponse = $dataQuery->amendBookingRequest($booking_id, $_POST);
	if(isset($amendBookingResponse->success) && $amendBookingResponse->success == 1){
		header("Location:view.php?booking_id=".$booking_id);
	}else{
		$_SESSION['error'] = $amendBookingResponse->error;
		header("Location:amend.php?booking_id=".$booking_id);
	}
}

$bookingDetail = $dataQuery->getBookingDetailByBookingId($booking_id);
if(empty($bookingDetail)){
	header("Location:".BASE_URL);
}
$propertyDetail = $dataQuery->fetchPropertyDetail($bookingDetail['property_id']);
$allRoomTypes = isset($propertyDetail->properties->property->rooms->room) ? ($propertyDetail->properties->property->rooms->room) : '';
if(count($allRoomTypes) == 1)
	$allRoomTypes[] = $allRoomTypes;
$countries = $dataQuery->dbSelectCountry();
?>
<style>
.input-max-10{padding:6px 0px;width:30px !important}
</style>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Booking
        <small>Amend</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Availability</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Main row -->
      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title"><?php echo $bookingDetail['no_of_rooms'].' '.$bookingDetail['room_type']; ?> for <?php echo $bookingDetail['no_of_nights']; ?> nights</h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
		<?php if(isset($_SESSION['error'])){?>
		<div class="col-md-12 text-center text-red" style="padding-bottom:10px"><?php echo $_SESSION['error']; ?></div>
		<?php unset($_SESSION['error']); }?>
          <div class="row">
			<form class="form-horizontal" method="post" id="validate-amend-form">
				<div class="col-md-12">
					<div class="form-group">
						<label class="col-md-2 control-label">Changes Made:</label>
						<div class="col-md-9">
							<textarea class="form-control required" name="amend_reason"></textarea>
						</div>
					</div>
				</div>
				<!--<div class="col-md-6">
					<div class="form-group">
						<label class="col-md-4 control-label">Seller:</label>
						<div class="col-md-6 display-booking-val">
							-
						</div>
					</div>
				</div>
				<!--<div class="col-md-6">
					<!--<div class="form-group">
						<label class="col-md-4 control-label">Seller Ref:</label>
						<div class="col-md-6 display-booking-val">
							-
						</div>
					</div>
				</div>-->
				<div class="col-md-6">
					<div class="form-group">
						<label class="col-md-4 control-label">Booking Date:</label>
						<div class="col-md-6 display-booking-val">
							<?php echo date("D, d M Y", strtotime($bookingDetail['created'])); ?>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label class="col-md-4 control-label">Last Modified Date:</label>
						<div class="col-md-6 display-booking-val">
							<?php echo date("D, d M Y", strtotime($bookingDetail['modified'])); ?>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label class="col-md-4 control-label">Property:</label>
						<div class="col-md-6 display-booking-val">
							<?php echo $bookingDetail['property_name']; ?>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label class="col-md-4 control-label"></label>
						<div class="col-md-6 display-booking-val">
							-
						</div>
					</div>
				</div>
				
				<div class="col-md-6">
					<div class="form-group">
						<label class="col-md-4 control-label">Check In Date:</label>
						<div class="col-md-6">
							<input type="text" class="form-control amend-datepicker change-nights" name="check_in_date" value="<?php echo $bookingDetail['check_in_date']; ?>" />
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label class="col-md-4 control-label">Check Out Date:</label>
						<div class="col-md-6">
							<input type="text" class="form-control amend-datepicker change-nights" name="check_out_date" value="<?php echo $bookingDetail['check_out_date']; ?>" />
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label class="col-md-4 control-label">Room Type:</label>
						<div class="col-md-6">
							<select class="form-control" name="room_type_code">
								<?php foreach($allRoomTypes AS $rmType){ ?>
								<option value="<?php echo $rmType->room_type_code; ?>" <?php echo ($rmType->room_type_code == $bookingDetail['room_type_code']) ? 'selected' : ''; ?> ><?php echo $rmType->room_desc; ?></option>
								<?php }?>
							</select>
							<input type="hidden" name="room_type" value="<?php echo $bookingDetail['room_type']; ?>" />
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label class="col-md-4 control-label">No. of Nights:</label>
						<div class="col-md-6 display-booking-val tot-nights">
							<?php echo $bookingDetail['no_of_nights']; ?>
						</div>
						<input type="hidden" name="no_of_nights" value="<?php echo $bookingDetail['no_of_nights']; ?>" />
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label class="col-md-4 control-label">No. of Rooms:</label>
						<div class="col-md-2">
							<input class="form-control input-max-10 text-center" readonly id="change-no-rooms" name="no_of_rooms" value="<?php echo $bookingDetail['no_of_rooms']; ?>" />
						</div>
						<input type="hidden" id="tot-rooms" value="<?php echo $bookingDetail['no_of_rooms']; ?>" />
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label class="col-md-4 control-label">Meal Plan:</label>
						<div class="col-md-6">
							<select class="form-control" name="meal_type_code">
								<?php foreach($dataQuery->mealPlan AS $key=>$val){?>
								<option <?php echo ($bookingDetail['meal_type_code'] == $key) ? 'selected' : ''; ?> value="<?php echo $key; ?>" >
									<?php echo $val; ?>
								</option>
								<?php }?>
							</select>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label class="col-md-4 control-label">Country of Passport:</label>
						<div class="col-md-6">
							<select class="form-control required" name="nation">
								<option value="">Select Country</option>
								<?php foreach($countries AS $country){ ?>
								<option value="<?php echo $country['cnt_code']; ?>" <?php echo ($bookingDetail['country_passport'] == $country['cnt_code']) ? 'selected' : ''; ?> >
									<?php echo $country['cnt_name']; ?>
								</option>
								<?php }?>
							</select>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label class="col-md-4 control-label">Arrival Info:</label>
						<div class="col-md-6">
							<input type="text" class="form-control" name="arrival_flight_details" value="<?php echo ucfirst($bookingDetail['arrival_flight_info']); ?>" />
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label class="col-md-4 control-label">Departure Info:</label>
						<div class="col-md-6">
							<input type="text" class="form-control" name="departure_flight_details" value="<?php echo ucfirst($bookingDetail['departure_flight_info']); ?>" />
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label class="col-md-4 control-label">Arr. Transfer:</label>
						<div class="col-md-6">
							<select class="form-control" name="transfer_code_arrival">
								<?php foreach($dataQuery->transferCode AS $key=>$val){?>
								<option <?php echo ($bookingDetail['arrival_transfer'] == $key) ? 'selected' : ''; ?> value="<?php echo $key; ?>" >
									<?php echo $val; ?>
								</option>
								<?php }?>
							</select>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label class="col-md-4 control-label">Dep. Transfer:</label>
						<div class="col-md-6">
							<select class="form-control" name="transfer_code_departure">
								<?php foreach($dataQuery->transferCode AS $key=>$val){?>
								<option <?php echo ($bookingDetail['departure_transfer'] == $key) ? 'selected' : ''; ?> value="<?php echo $key; ?>" >
									<?php echo $val; ?>
								</option>
								<?php }?>
							</select>
						</div>
					</div>
				</div>
				
				<div class="col-md-6">
					<div class="form-group">
						<label class="col-md-4 control-label">Airport Handling:</label>
						<div class="col-md-6">
							<select class="form-control" name="airport_handling">
								<option <?php echo ($bookingDetail['airport_handling'] == 0) ? 'selected' : ''; ?> value="0" >Not Required</option>
								<option <?php echo ($bookingDetail['airport_handling'] == 1) ? 'selected' : ''; ?> value="1" >Yes, Required</option>
							</select>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label class="col-md-4 control-label">Late Check-out:</label>
						<div class="col-md-6">
							<select class="form-control late_check_out" name="late_check_out">
								<option value=0 <?php echo ($bookingDetail['late_check_out_time'] == 0) ? 'selected' : ''; ?> >Not Required</option>
								<option value=1 <?php echo ($bookingDetail['late_check_out_time'] != 0) ? 'selected' : ''; ?> >Yes, Required</option>
							</select>
						</div>
						<div class="col-md-2 <?php echo ($bookingDetail['late_check_out_time'] == 0) ? 'display-none' : ''; ?> ">
							<select class="form-control" name="late_check_out_time">
								<?php for($i=1;$i<=11;$i++){ ?>
								<option value="<?php echo $i; ?>" <?php echo ($bookingDetail['late_check_out_time'] == $i) ? 'selected' : ''; ?> ><?php echo $i.' PM'; ?></option>
								<?php } ?>
							</select>
						</div>
					</div>
				</div>
				<!-- /.col -->
				<div class="append-more-booking-rooms">
				<?php 
					$booked = json_decode($bookingDetail['room_guest_detail']);
					foreach($booked AS $key=>$roombook){
						$r = ++$key;
						include('includes/booking_rooms_edit.php');
					}
				?>
				</div>
				<div class="col-md-12">
					<div class="form-group">
						<label class="col-md-2 control-label">Special Request:</label>
						<div class="col-md-9">
							<textarea class="form-control" name="comments"><?php echo $bookingDetail['comments']; ?></textarea>
						</div>
					</div>
				</div>
				<div class="col-md-11">
				  <div class="form-group pull-right margin-right-0">
					<a href="<?php echo BASE_URL.'view.php?booking_id='.$booking_id; ?>" class="btn btn-info">Abort</a>
					<button class="btn btn-info" name="amend_booking">Submit</button>
				  </div>
				  <!-- /.form-group -->
				</div>
				<!-- /.col -->
			</form>
          </div>
          <!-- /.row -->
        </div>
        <!-- /.box-body -->
		<div class="row" id="search-property-block-resule"></div>
      </div>
      <!-- /.box -->
      <!-- /.row (main row) -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<script>
$(function(){
	$(".room-adult").TouchSpin({
		min:1,
		max:2,
		prefix: "Adults",
		prefix_extraclass: "touch-postfix-bg",
	});
	
	$(".room-child").TouchSpin({
		min:0,
		max:2,
		prefix: "Children",
		prefix_extraclass: "touch-postfix-bg",
	});
	
	$(".room-infant").TouchSpin({
		min:0,
		max:2,
		prefix: "Infant",
		prefix_extraclass: "touch-postfix-bg",
	});
	
	$(".input-max-10").TouchSpin({
		min:1,
		max:10,
	});
	
	$("#validate-amend-form").validate({
        errorPlacement: function() {
            return false;
        }
	});
});
</script>
<?php
include("includes/footer.php");
ob_end_flush();
?>