<?php
ob_start();
$pageTitle = "Create Booking";
include("includes/header.php");
if(isset($_POST['booking'])){
	$bookingResponse = $dataQuery->bookingRequest($_POST);
	if(isset($bookingResponse->success) && $bookingResponse->success == 1){
		unset($_SESSION['search_key']);
		header('Location:view.php?booking_id='.$bookingResponse->booking_id);
		die;
	}else{
		$_SESSION['error'] = $amendBookingResponse->error;
		header('Location:booking.php');
	}
}

if(!isset($_SESSION['search_key'])){
	header("Location:availability.php");
}
$property_detail = $dataQuery->dbSelectFirst("oh_property", "*", "id=".$_SESSION['search_key']['booking_property']);
$countries = $dataQuery->dbSelectCountry();
$leftTIme = (strtotime(date("Y-m-d H:i:s"))-strtotime($_SESSION['search_key']['hold_time']))/60;
?>
<!-- Content Wrapper. Contains page content -->
<script src="js/jquery.simple.timer.js"></script>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Booking
        <small>Room</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Availability</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Main row -->
      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title pull-left"><?php echo $_SESSION['search_key']['no_of_rooms'].' '.$_SESSION['search_key']['room_type']; ?> blocked for <?php echo $_SESSION['search_key']['no_of_nights']; ?> nights for the next &nbsp;</h3><div style="font-weight:bold;color:#f46" class="pull-left timer" data-minutes-left="<?php echo ((10-$leftTIme)>0) ? (10-$leftTIme) : 0.01; ?>"> &nbsp;minutes </div>
		  <div class="box-tools pull-right">
            <a href="<?php echo BASE_URL.'availability.php'; ?>" class="btn btn-sm btn-default">Modify Search</a>
          </div>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
		<?php if(isset($_SESSION['error'])){?>
		<div class="col-md-12 text-center text-red" style="padding-bottom:10px"><?php echo $_SESSION['error']; ?></div>
		<?php unset($_SESSION['error']); }?>
          <div class="row">
			<form class="form-horizontal" method="post" id="validate-booking-form">
					<div class="col-md-6">
						<div class="form-group">
							<label class="col-md-4 control-label">Property Name:</label>
							<div class="col-md-6 display-booking-val">
								<input type="hidden" name="property_id" value="<?php echo $_SESSION['search_key']['booking_property']; ?>" />
								<?php echo $property_detail['property_name']; ?>
							</div>
						</div>
					</div>
					<!--<div class="col-md-6">
						<div class="form-group">
							<label class="col-md-4 control-label">Seller Partner:</label>
							<div class="col-md-6 display-booking-val">
								-
							</div>
						</div>
					</div>-->
					<div class="col-md-6">
						<div class="form-group">
							<label class="col-md-4 control-label">Room Type:</label>
							<div class="col-md-6 display-booking-val">
								<?php echo $_SESSION['search_key']['room_type']; ?>
								<input type="hidden" name="room_type_code" value="<?php echo $_SESSION['search_key']['room_category']; ?>" />
								<input type="hidden" name="room_type" value="<?php echo $_SESSION['search_key']['room_type']; ?>" />
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label class="col-md-4 control-label">No. of Nights:</label>
							<div class="col-md-6 display-booking-val">
								<input type="hidden" name="no_of_nights" value="<?php echo $_SESSION['search_key']['no_of_nights']; ?>" />
								<?php echo $_SESSION['search_key']['no_of_nights']; ?>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label class="col-md-4 control-label">Check In Date:</label>
							<div class="col-md-6 display-booking-val">
								<input type="hidden" name="check_in_date" value="<?php echo $_SESSION['search_key']['check_in_date']; ?>" />
								<?php echo date("D - M d Y", strtotime($_SESSION['search_key']['check_in_date'])); ?>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label class="col-md-4 control-label">Check Out Date:</label>
							<div class="col-md-6 display-booking-val">
								<?php echo date("D - M d Y", strtotime('+'.$_SESSION['search_key']['no_of_nights'].' days', strtotime($_SESSION['search_key']['check_in_date']))); ?>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label class="col-md-4 control-label">No. of Rooms:</label>
							<div class="col-md-6 display-booking-val">
								<input type="hidden" name="no_of_rooms" value="<?php echo $_SESSION['search_key']['no_of_rooms']; ?>" />
								<?php echo $_SESSION['search_key']['no_of_rooms']; ?>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label class="col-md-4 control-label">Partner Allocation:</label>
							<div class="col-md-6">
								<label class="radio-inline">
									<input type="radio" name="partner_allot" checked value=0>No
								</label>
								<label class="radio-inline">
									<input type="radio" name="partner_allot" value=1>Yes
								</label>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label class="col-md-4 control-label">Meal Plan:</label>
							<div class="col-md-6">
								<select class="form-control" name="meal_type_code">
									<option>Select Meal Plane</option>
									<?php foreach($dataQuery->mealPlan AS $key=>$val){ ?>
									<option value="<?php echo $key; ?>" <?php echo ($key==2) ? 'selected' : ''; ?> ><?php echo $val; ?></option>
									<?php } ?>
								</select>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label class="col-md-4 control-label">Country of Passport:</label>
							<div class="col-md-6">
								<select class="form-control required" name="country_passport">
									<option value="">Select Country</option>
									<?php foreach($countries AS $country){ ?>
									<option value="<?php echo $country['cnt_code']; ?>"><?php echo $country['cnt_name']; ?></option>
									<?php }?>
								</select>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label class="col-md-4 control-label">Arr flight / info.:</label>
							<div class="col-md-6">
								<input type="text" name="arrival_flight_details" class="form-control" />
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label class="col-md-4 control-label">Dep flight / info.:</label>
							<div class="col-md-6">
								<input type="text" name="departure_flight_details" class="form-control" />
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label class="col-md-4 control-label">Arr Transfer:</label>
							<div class="col-md-6">
								<select class="form-control" name="transfer_code_arrival">
									<?php foreach($dataQuery->transferCode AS $key=>$val){ ?>
									<option value="<?php echo $key; ?>" <?php echo ($key==99) ? 'selected' : ''; ?> ><?php echo $val; ?></option>
									<?php } ?>
								</select>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label class="col-md-4 control-label">Dep Transfer:</label>
							<div class="col-md-6">
								<select class="form-control" name="transfer_code_departure">
									<?php foreach($dataQuery->transferCode AS $key=>$val){ ?>
									<option value="<?php echo $key; ?>" <?php echo ($key==99) ? 'selected' : ''; ?> ><?php echo $val; ?></option>
									<?php } ?>
								</select>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label class="col-md-4 control-label">Airport Handling:</label>
							<div class="col-md-6">
								<select class="form-control" name="airport_handling">
									<option value=0>Not Required</option>
									<option value=1>Yes, Required</option>
								</select>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label class="col-md-4 control-label">Late Check-out:</label>
							<div class="col-md-4">
								<select class="form-control late_check_out" name="late_check_out">
									<option value=0>Not Required</option>
									<option value=1>Yes, Required</option>
								</select>
							</div>
							<div class="col-md-2 display-none">
								<select class="form-control" name="late_check_out_time">
									<?php for($i=1;$i<=11;$i++){ ?>
									<option value="<?php echo $i; ?>"><?php echo $i.' PM'; ?></option>
									<?php } ?>
								</select>
							</div>
						</div>
					</div>
					<?php for($r=1;$r<=$_SESSION['search_key']['no_of_rooms']; $r++){
						include('includes/booking_rooms.php');
					} ?>
					<div class="col-md-12">
						<div class="form-group">
							<label class="col-md-2 control-label">Special Request:</label>
							<div class="col-md-9">
								<textarea class="form-control" name="comments"></textarea>
							</div>
						</div>
					</div>
					<div class="col-md-11">
					  <div class="form-group pull-right margin-right-0">
						<button class="btn btn-info" name="booking">Submit</button>
					  </div>
					  <!-- /.form-group -->
					</div>
					<!-- /.col -->
				
			</form>
          </div>
          <!-- /.row -->
        </div>
        <!-- /.box-body -->
		<div class="row" id="search-property-block-resule"></div>
      </div>
      <!-- /.box -->
      <!-- /.row (main row) -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<script>
$(function(){
	$(".room-adult").TouchSpin({
		min:1,
		max:2,
		prefix: "Adults",
		prefix_extraclass: "touch-postfix-bg",
	});
	
	$(".room-child").TouchSpin({
		min:0,
		max:2,
		prefix: "Children",
		prefix_extraclass: "touch-postfix-bg",
	});
	
	$(".room-infant").TouchSpin({
		min:0,
		max:2,
		prefix: "Infant",
		prefix_extraclass: "touch-postfix-bg",
	});
	
	$("#validate-booking-form").validate({
        errorPlacement: function() {
            return false;
        }
	});
});
</script>
<script>
$(function(){
    $('.timer').startTimer({
      onComplete: function(){
        alert("Room blocked has been unlocked, You need to start again from search availability.");
		window.location.replace("availability.php");
      }
    });
})
</script>
<?php
include("includes/footer.php");
ob_end_flush();
?>