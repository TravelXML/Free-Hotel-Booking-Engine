function updateRooms(room){
	var adult = $('#room'+room).find('.room-adult').val();
	var child = $('#room'+room).find('.room-child').val();
	var infant = $('#room'+room).find('.room-infant').val();
	var total = parseInt(adult)+parseInt(child)+parseInt(infant);
	if(total > 4 && adult == 3){
		alert('Maximm 2 adults and 2 children allowed in a room.');
		return false;
	}
	
	for(var i=1;i<=4;i++){
		if(i<=total){
			$("#room"+room+i).removeClass('display-none');
			if(i>adult){
				$("#room"+room+i).find('.child-infant').removeClass('display-none');
			}else
				$("#room"+room+i).find('.child-infant').addClass('display-none');
		}
		else{
			$("#room"+room+i).find('input').val('');
			$("#room"+room+i).find('select').val('');
			$("#room"+room+i).addClass('display-none');
		}
	}
}

function getAge(dateString) {
    var today = new Date();
    var birthDate = new Date(dateString);
    var age = today.getFullYear() - birthDate.getFullYear();
    var m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--;
    }
    return age;
}

$(function(){
	$('.datepicker').datepicker({
		startDate:new Date(),
		format: "yyyy-mm-dd",
		autoclose: true
	});
	
	$('.dob-datepicker').datepicker({
		endDate:new Date(),
		format: "yyyy-mm-dd",
		autoclose: true
	});

	$(document).on("click", ".clicktobookroom", function(){
		var whattodo = 'booking_session_set';
		var booking_data = $(this).attr("id");
		var check_in_date = $("#check_in_date").val();
		var no_of_nights = $("#no_of_nights").val();
		var no_of_rooms = $("#no_of_rooms").val();
		$.ajax({
			url: 'ajax_request.php',
			data: {booking_data, check_in_date, no_of_nights, no_of_rooms, whattodo},
			type: 'POST',
			async: false,
			error: function(err){
				alert("Something went wrong.");
			},
			success: function(response){
				window.location.replace('booking.php');
			},
		});
	});
	
	$(document).on("change", ".room-adult", function(){
		updateRooms($(this).attr("rel"));
	});
	
	$(document).on("change", ".room-child", function(){
		updateRooms($(this).attr("rel"));
	});
	
	$(document).on("change", ".room-infant", function(){
		updateRooms($(this).attr("rel"));
	});
	
	$(".child-infant-age").change(function(){
		var age = getAge(new Date($(this).val()));
		if(age > 11){
			$(this).val('');
			alert("Children / Infant maximum age 11 years allowed.");
		}
	});
	
	$(".late_check_out").change(function(){
		if($(this).val() == 1)
			$(this).parent().next().removeClass('display-none');
		else
			$(this).parent().next().addClass('display-none');
	});
	
	$('.amend-datepicker').datepicker({
		startDate:new Date(),
		format: "yyyy-mm-dd",
		autoclose: true
	}).on('changeDate', function(){
		var total_nights = $(".tot-nights").text();
		var check_in = $("input[name='check_in_date']").val();
		var check_out = $("input[name='check_out_date']").val();
		var change_date_field = $(this).attr("name");
		
		if(change_date_field == 'check_in_date'){
			check_out = new Date(check_in);
			check_out.setDate(check_out.getDate() + parseInt(total_nights));
			var year = check_out.getFullYear();
			var month = ((check_out.getMonth()+1) < 10) ? ('0'+(check_out.getMonth()+1)) : (check_out.getMonth()+1);
			var day = check_out.getDate();
			$("input[name='check_out_date']").datepicker('update', year+'-'+month+'-'+day);
		}
		
		if(change_date_field == 'check_out_date'){
			var oneDay = 24*60*60*1000;
			check_in = new Date(check_in);
			check_out = new Date(check_out);
			if(check_in >= check_out){
				check_out = new Date(check_in);
				check_out.setDate(check_out.getDate() + parseInt(total_nights));
				var year = check_out.getFullYear();
				var month = ((check_out.getMonth()+1) < 10) ? ('0'+(check_out.getMonth()+1)) : (check_out.getMonth()+1);
				var day = check_out.getDate();
				$("input[name='check_out_date']").datepicker('update', year+'-'+month+'-'+day);
				return false;
			}
			var tot_nights = Math.round(Math.abs((check_in.getTime() - check_out.getTime())/(oneDay)));
			$(".tot-nights").text(tot_nights);
			$("input[name='no_of_nights']").val(tot_nights);
		}
	});
	
	$("#change-no-rooms").change(function(){
		$(".append-room-block").remove();
		$(".edit-room-block").show();
		var whattodo = "changeNoOfRooms";
		var previous_rooms = $("#tot-rooms").val();
		var new_rooms = $(this).val();
		if(new_rooms > previous_rooms){
			$.ajax({
				url: 'ajax_request.php',
				type: 'POST',
				data: {whattodo, previous_rooms, new_rooms},
				async: false,
				error: function(response){
					alert("Something went wrong.");
				},
				success: function(response){
					$(".append-more-booking-rooms").append(response);
				}
			});
		}else{
			var i = 0;
			for(i = previous_rooms; i > new_rooms; i--){
				$(".room-block-"+i).hide();
			}
		}
	});
	
	$("#validate-amend-form select[name='room_type_code']").change(function(){
		$("input[name='room_type']").val($(this).find("option:selected").text());
	});
});