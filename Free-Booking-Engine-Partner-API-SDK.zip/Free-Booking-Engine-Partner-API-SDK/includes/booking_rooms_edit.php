<div class="edit-room-block room-block-<?php echo $r; ?>">
	<div class="col-md-12" id="room<?php echo $r; ?>">
		<div class="form-group">
			<label class="col-md-2 control-label">Room <?php echo $r; ?></label>
			<div class="col-md-2">
				<input type="text" class="form-control room-adult text-center" readonly name="<?php echo 'r'.$r.'adults'; ?>" value="<?php echo $roombook->no_of_adult; ?>" rel="<?php echo $r; ?>">
			</div>
			<div class="col-md-2">
				<input type="text" class="form-control room-child text-center" readonly name="<?php echo 'r'.$r.'child'; ?>" value="<?php echo $roombook->no_of_child; ?>" rel="<?php echo $r; ?>">
			</div>
			<div class="col-md-2">
				<input type="text" class="form-control room-infant text-center" readonly name="<?php echo 'r'.$r.'infant'; ?>" value="<?php echo $roombook->no_of_infant; ?>" rel="<?php echo $r; ?>">
			</div>
		</div>
	</div>
	<div class="col-md-12">
		<div class="booking-room-note">
			Note: Date of birth is required for children and infants.
		</div>
	</div>
	<?php
	$persons = array();
	$adults = array();
	$childs = array();
	$infants = array();
	
 	if(isset($roombook->no_of_adult)){
		if($roombook->no_of_adult == 1){
			$adults[] = $roombook->guests->adult;
		}else{
			$adults = $roombook->guests->adult;
		}
	}
	
	if(isset($roombook->guests->child)){
		if($roombook->no_of_child == 1){
			$childs[] = $roombook->guests->child;
		}else{
			$childs = $roombook->guests->child;
		}
	}

	if(isset($roombook->guests->infant)){
		if($roombook->no_of_infant == 1){
			$infants[] = $roombook->guests->infant;
		}else{
			$infants = $roombook->guests->infant;
		}
	}
	$persons = array_merge($adults,$childs,$infants);
	$i = 0;
	for($p=1;$p<=4;$p++){
	?>
	<div class="col-md-12 <?php echo ($p>($roombook->no_of_adult+$roombook->no_of_infant+$roombook->no_of_child)) ? 'display-none' : ''; ?>" id="room<?php echo $r.$p; ?>">
		<div class="form-group guest-drop">
			<label class="col-md-2 control-label"></label>
			<div class="col-md-1">
				<select class="form-control <?php echo ($r == 1 && $p == 1) ? 'required' : 'required'; ?>" name="<?php echo 'r'.$r.'in'.$p;?>">
					<option value=''></option>
					<option <?php echo (isset($persons[$i]) && $persons[$i]->initial_name == "MR.") ? "selected" : ""; ?> >MR.</option>
					<option <?php echo (isset($persons[$i]) && $persons[$i]->initial_name == "MRS.") ? "selected" : ""; ?>>MRS.</option>
					<option <?php echo (isset($persons[$i]) && $persons[$i]->initial_name == "MS.") ? "selected" : ""; ?>>MS.</option>
					<option <?php echo (isset($persons[$i]) && $persons[$i]->initial_name == "DR.") ? "selected" : ""; ?>>DR.</option>
				</select>
			</div>
			<div class="col-md-3">
				<input type="text" class="form-control <?php echo ($r == 1 && $p == 1) ? 'required' : 'required'; ?>" name="<?php echo 'r'.$r.'f'.$p;?>" placeholder="First Name" value="<?php echo isset($persons[$i]) ? $persons[$i]->first_name : ""; ?>" />
			</div>
			<div class="col-md-3">
				<input type="text" class="form-control <?php echo ($r == 1 && $p == 1) ? 'required' : 'required'; ?>" name="<?php echo 'r'.$r.'l'.$p;?>" placeholder="Last Name" value="<?php echo isset($persons[$i]) ? $persons[$i]->last_name : ""; ?>" />
			</div>
			<div class="col-md-2 input-group date child-infant <?php echo ($p <= $roombook->no_of_adult) ? 'display-none' : ''; ?>">
				<div class="input-group-addon">
					<i class="fa fa-calendar"></i>
				</div>
				<input type="text" class="form-control child-infant-age dob-datepicker required" name="<?php echo 'r'.$r.'dob'.$p;?>" placeholder="Date of Birth" value="<?php echo isset($persons[$i]->age_or_dob) ? $persons[$i]->age_or_dob : ""; ?>" />
			</div>
		</div>
	</div>
	<?php $i++; }?>
</div>