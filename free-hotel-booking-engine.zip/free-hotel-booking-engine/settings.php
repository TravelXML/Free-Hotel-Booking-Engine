<?php
define('BASE_URL', 'http://'.$_SERVER['HTTP_HOST'].'/'.basename(__DIR__).'/');
define('THEME_NAME', 'admin_lt');

function put_ini_file($file, $array, $i = 0){
	$str="";
	foreach ($array as $k => $v){
		if (is_array($v)){
		$str.=str_repeat(" ",$i*2)."[$k]\r\n";
		$str.=put_ini_file("",$v, $i+1);
	}else
		$str.=str_repeat(" ",$i*2)."$k = $v\r\n";
	}
	
	$phpstr = "<?PHP\r\n/*\r\n".$str."*/\r\n?>";
	
	if($file)
		return file_put_contents($file,$str);
	else
		return $str;
}

if(isset($_POST['configuration'])){
	unset($_POST['configuration']);	
        $_POST['AGENCY_TITLE'] = "Openhotelier";
        $config = $_POST;
	put_ini_file('includes/config.ini', $config);
	
	/*************************** Import SQL File ***************************/
	// Create connection
	$conn = mysqli_connect($_POST['HOSTNAME'], $_POST['USERNAME'], $_POST['PASSWORD']);

	// Check connection
	if (!$conn) {
		die("Connection failed: " . mysqli_connect_error());
	}

	// Create database
	$sql = "CREATE DATABASE ".$_POST['DBNAME'];
	if (!mysqli_query($conn, $sql)) {
		echo "Error creating database: " . $conn->error;
	}
	// Change database to "test"
	mysqli_select_db($conn, $_POST['DBNAME']);

	// Temporary variable, used to store current query
	$templine = '';

	// Read in entire file
	$filename = BASE_URL.'includes/oh_sdk.sql';
	$lines = file($filename);

	// Loop through each line
	foreach ($lines as $line) {
		// Skip it if it's a comment
		if (substr($line, 0, 2) == '--' || $line == '') {
			continue;
		}

		// Add this line to the current segment
		$templine .= $line;
		// If it has a semicolon at the end, it's the end of the query

		if (substr(trim($line), -1, 1) == ';') {
			// Perform the query
			mysqli_query($conn, $templine) or die('Error performing query \'<strong>' . $templine . '\': ' .mysqli_error($conn). '<br />');

			// Reset temp variable to empty
			$templine = '';
		}
	}
	/************************* End Import SQL File *************************/
	header("Location:".BASE_URL);
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Openhotelier | Settings</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="<?php echo BASE_URL.'theme/'.THEME_NAME.'/'; ?>bootstrap/css/bootstrap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo BASE_URL.'theme/'.THEME_NAME.'/'; ?>dist/css/AdminLTE.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="<?php echo BASE_URL.'theme/'.THEME_NAME.'/'; ?>plugins/iCheck/square/blue.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>
<body class="hold-transition login-page">
<div class="login-box">
	<div class="login-logo">
		<span>Openhotelier SDK</span>
	</div>
	<!-- /.login-logo -->
	<div class="login-box-body">
		<p class="login-box-msg">Enter your configuration details. If you are not sure about these, please contact sales@openhotelier.com.</p>
		<form class="form-horizontal" method="post" id="settings-form">
			<div class="form-group has-feedback">
				<label class="label-control col-md-offset-1 col-md-3">Partner Id:</label>
				<div class="col-md-7">
					<input type="text" class="form-control required" placeholder="Openhotelier Partner Id" name="PARTNER_ID">
				</div>
			</div>
			<div class="form-group has-feedback">
				<label class="label-control col-md-offset-1 col-md-3">API Key:</label>
				<div class="col-md-7">
					<input type="text" class="form-control required" placeholder="Partner API Key" name="APIKEY">
				</div>
			</div>                    
			<div class="form-group has-feedback">
				<label class="label-control col-md-offset-1 col-md-3">Hostname:</label>
				<div class="col-md-7">
					<input type="text" class="form-control required" placeholder="Database Hostname" name="HOSTNAME">
				</div>
			</div>
			<div class="form-group has-feedback">
				<label class="label-control col-md-offset-1 col-md-3">Username:</label>
				<div class="col-md-7">
					<input type="text" class="form-control required" placeholder="Database Username" name="USERNAME">
				</div>
			</div>
			<div class="form-group has-feedback">
				<label class="label-control col-md-offset-1 col-md-3">Password:</label>
				<div class="col-md-7">
					<input type="text" class="form-control" placeholder="Database Password" name="PASSWORD">
				</div>
			</div>
			<div class="form-group has-feedback">
				<label class="label-control col-md-offset-1 col-md-3">Database Name:</label>
				<div class="col-md-7">
					<input type="text" class="form-control required" placeholder="Database Name" name="DBNAME">
				</div>
			</div>
			<!--<div class="form-group has-feedback">
				<label class="label-control col-md-offset-1 col-md-3">Agency Title:</label>
				<div class="col-md-7">
					<input type="text" class="form-control required" placeholder="Agency Title" name="AGENCY_TITLE">
				</div>
			</div>
			<div class="form-group has-feedback">
				<label class="label-control col-md-offset-1 col-md-3">Logo URL:</label>
				<div class="col-md-7">
					<input type="text" class="form-control url" placeholder="Logo URL" name="LOGO">
				</div>
			</div>-->
			<div class="row">
				<!-- /.col -->
				<div class="col-xs-offset-8 col-xs-3">
					<input type="hidden" name="SHOW_PRICE" value=3 />
					<input type="hidden" name="ENDPOINT" value='https://www.openhotelier.com/api/partner/v2/' />
					<input type="hidden" name="BASE_URL" value='<?php echo BASE_URL; ?>' />
					<input type="hidden" name="THEME_NAME" value='<?php echo THEME_NAME; ?>' />
					<button type="submit" name="configuration" class="btn btn-primary btn-block btn-flat">Submit</button>
				</div>
				<!-- /.col -->
			</div>
		</form>
	</div>
  <!-- /.login-box-body -->
</div>
<!-- /.login-box -->

<!-- jQuery 2.2.3 -->
<style>
.error{border: 1px solid #f00 !important;}
</style>
<script src="<?php echo BASE_URL.'theme/'.THEME_NAME.'/'; ?>plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo BASE_URL.'theme/'.THEME_NAME.'/'; ?>bootstrap/js/bootstrap.min.js"></script>
<script src="<?php echo BASE_URL.'theme/'.THEME_NAME.'/'; ?>plugins/jquery-validation/jquery.validate.js"></script>
<script src="<?php echo BASE_URL.'theme/'.THEME_NAME.'/'; ?>plugins/jquery-validation/additional-methods.js"></script>
<script>
$(function(){
	$("#settings-form").validate({
		rules: {
			APIKEY: {
				required: true,
				remote: {
					url: "includes/validate_apikey.php",
					type: "post",
					data: {
						APIKEY: function() {
							return $( "input[name='APIKEY']" ).val();
						}
					}
				}
			}
		},
		errorPlacement: function(){
			return false;
		}
	});
});
</script>
</body>
</html>
