<?php
$apikey = $_POST['APIKEY'];
$requestData = array('country_code' => 'MV', 'action' => 4);
$requestData = json_encode($requestData);
$curl = curl_init("https://www.openhotelier.com/api/partner/v2/api.php"); 
curl_setopt($curl, CURLOPT_HEADER, false); 
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true); 
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false); 
curl_setopt($curl, CURLOPT_HTTPHEADER, array( 
	"Content-type: application/json", 
	"APIKEY: ".$apikey 
)); 
curl_setopt($curl, CURLOPT_POST, true); 
curl_setopt($curl, CURLOPT_POSTFIELDS, $requestData); 
$JsonResponse = curl_exec($curl); 

// Check if any error occurred 
if (curl_errno($curl)) { 
	echo 'Curl error: ' . curl_error($curl); 
} 
curl_close($curl);
$response = json_decode($JsonResponse);
if(isset($response->error)){
	echo "false";
}else{
	echo "true";
}
?>