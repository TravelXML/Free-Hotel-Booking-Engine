<?php
$pageTitle = "Search Availability";
include("includes/header.php");
if(isset($_SESSION['search_key']['room_hold_token'])){
	$dataQuery->roomHoldRelease();
}
$properties = $dataQuery->getProperty();
?>
<style>
.input-max-10{padding:6px 0px;width:30px !important}
.select2{height:34px}
</style>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Availability
        <small>Search</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Availability</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Main row -->
      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title change-search-msg">Search</h3>
		  <div class="box-tools pull-right">
            <button type="button" class="btn btn-sm result-show" data-widget="collapse" style="display:none">Modify Search</button>
          </div>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <div class="row">
			<form id="search-availability">
				<div class="col-md-4">
				  <div class="form-group">
					<label>Country:</label>
					<select class="form-control select2" data-placeholder="Select Country" name="country_code" id="country_code" onchange="getCityByCountryCode(this.value)">
						<option value="MV">Maldives</option>
					</select>
				  </div>
				  <!-- /.form-group -->
				</div>
				<!-- /.col -->
				<div class="col-md-8">
				  <div class="form-group">
					<label>Property:</label>
					<select class="form-control select2" multiple="multiple" data-placeholder="Select Property" name="property_id[]" id="property_id">
						<?php foreach($properties AS $property){ ?>
						<option value="<?php echo $property['id']; ?>" <?php echo (isset($_SESSION['search_key']) && in_array($property['id'], $_SESSION['search_key']['property_id'])) ? 'selected' : ''; ?> ><?php echo $property['property_name']; ?></option>
						<?php }?>
					</select>
				  </div>
				  <!-- /.form-group -->
				</div>
				<!-- /.col -->
				<div class="col-md-4">
				  <div class="form-group">
					<label>City:</label>
					<select class="form-control select2" name="city_code" id="city_code" onchange="updateProperty()">
					  <option>All Cities</option>
					</select>
				  </div>
				  <!-- /.form-group -->
				</div>
				<!-- /.col -->
				<div class="col-md-3">
				  <div class="form-group">
					<label>Date:</label>

					<div class="input-group date">
					  <div class="input-group-addon">
						<i class="fa fa-calendar"></i>
					  </div>
					  <input type="text" class="form-control pull-right datepicker" name="check_in_date" id="check_in_date" value="<?php echo date("Y-m-d"); ?>">
					</div>
					<!-- /.input group -->
				  </div>
				  <!-- /.form-group -->
				</div>
				<!-- /.col -->
				<div class="col-md-1">
				  <div class="form-group">
					<label>Nights:</label>
					<input type="text" class="form-control input-max-10 text-center" readonly value="<?php echo (isset($_SESSION['search_key'])) ? $_SESSION['search_key']['no_of_nights'] : '1'; ?>" name="no_of_nights" id="no_of_nights">
				  </div>
				  <!-- /.form-group -->
				</div>
				<!-- /.col -->
				<div class="col-md-1">
				  <div class="form-group">
					<label>Rooms:</label>
					<input type="text" class="form-control input-max-10 text-center" readonly value="<?php echo (isset($_SESSION['search_key'])) ? $_SESSION['search_key']['no_of_rooms'] : '1'; ?>" name="no_of_rooms" id="no_of_rooms">
				  </div>
				  <!-- /.form-group -->
				</div>
				<!-- /.col -->
				<div class="col-md-3" style="margin-top:25px">
				  <div class="form-group pull-right">
					<input type="hidden" name="whattodo" value="search_availability" />
					<button type="button" class="btn btn-default" onclick="updateProperty()">Refresh Property</button>
					<button type="button" class="btn btn-info button-search-availability">Search</button>
				  </div>
				  <!-- /.form-group -->
				</div>
				<!-- /.col -->
			</form>
          </div>
          <!-- /.row -->
        </div>
        <!-- /.box-body -->
		<div class="row" id="search-property-block-resule"></div>
      </div>
      <!-- /.box -->
      <!-- /.row (main row) -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<script>
$(function(){
	$("#property_id").change(function(){
		$(this).next().css({'border' : '0px'});
	});
	
	$(".button-search-availability").click(function(){
		if($("#property_id").val() != null){
			var searchMsg = $("#no_of_rooms").val()+' room from '+$("#check_in_date").val()+' for '+$("#no_of_nights").val()+' nights';
			$.ajax({
				url: 'ajax_request.php',
				type: 'POST',
				data: $("#search-availability").serialize(),
				async: false,
				error: function(response){
					alert("Something went wrong.");
				},
				success: function(response){
					$(".result-show").click().show();
					$(".change-search-msg").text(searchMsg);
					$("#search-property-block-resule").html(response);
				}
			});
		}else{
			$("#property_id").next().css({'border' : '1px solid #f00'});
		}
	});
	getCityByCountryCode();
	
	$(".input-max-10").TouchSpin({
		min:1,
		max:10,
	});
});

function getCityByCountryCode(){
	var country_code = $("#country_code").val();
	var whattodo = "get_city";
	$.ajax({
		url: 'ajax_request.php',
		type: 'POST',
		data: {country_code, whattodo},
		async: false,
		error: function(response){
			alert("Something went wrong.");
		},
		success: function(response){
			$("#city_code").html(response);
		}
	});
}

function updateProperty(){
	var country_code = $("#country_code").val();
	var city_code = $("#city_code").val();
	var whattodo = "update_property";
	$.ajax({
		url: 'ajax_request.php',
		type: 'POST',
		data: {country_code, city_code, whattodo},
		async: false,
		error: function(response){
			alert("Something went wrong.");
		},
		success: function(response){
			$("#property_id").html(response);
		}
	});
}
</script>
<?php
include("includes/footer.php");
?>