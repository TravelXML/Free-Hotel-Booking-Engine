<!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu">
        <li class="header">MAIN NAVIGATION</li>
        <li class="<?php echo ($pageTitle == "Dashboard Booking") ? 'active' : ''?>" >
          <a href="<?php echo BASE_URL; ?>">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
          </a>
        </li>
        <li class="<?php echo ($pageTitle == "Search Availability") ? 'active' : ''?>">
          <a href="<?php echo BASE_URL.'availability.php'; ?>">
            <i class="fa fa-search"></i> <span>Availability</span>
          </a>
        </li>
        <li class="<?php echo ($pageTitle == "Bookings List") ? 'active' : ''?>">
          <a href="<?php echo BASE_URL.'listview.php'; ?>">
            <i class="fa fa-table"></i> <span>View List</span>
          </a>
        </li>
        <li class="">
            <a href="https://openhotelier.atlassian.net/wiki/display/API/Getting+Started/" target="blank">
            <i class="fa fa-exclamation"></i> <span>Help</span>
          </a>
        </li>
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>