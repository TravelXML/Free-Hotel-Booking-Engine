<?php
$pageTitle = "Bookings List";
include("includes/header.php");
$listBookings = $dataQuery->dbSelectAll("oh_booking_details");
?>
<link rel="stylesheet" href="<?php echo BASE_URL.'theme/'.THEME_NAME.'/'; ?>plugins/datatables/dataTables.bootstrap.css">
<style>
.padding-top-18{padding-bottom:18px !important}
</style>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Bookings
        <small>List</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Booking List</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Main row -->
      <div class="row">
        <!-- Left col -->
		<div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title change-search-msg">Bookings List</h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <!-- Custom tabs (Charts with tabs)-->
          <div class="col-md-12">
              <!-- Morris chart - Sales -->
				<!--div id="chart_div" style="width: 900px; height: 500px;"></div>
				<div class="chart tab-pane active" id="revenue-chart" style="position: relative; height: 300px;"></div-->
				<table id="example1" class="table table-bordered table-striped">
					<thead>
						<tr>
							<th>BKG ID<br/>BKG STATUS </th>
							<th class="padding-top-18">Property Guest Name</th>
							<th>C-IN<br/>C-OUT</th>
							<th>RM / MP<br/>A-C-I</th>
							<th class="padding-top-18">RM Cat</th>
							<th class="padding-top-18">Nights</th>
							<th>A-TF<br/>D-TF</th>
							<th>ARVL<br/>DEPT</th>
							<th class="padding-top-18">Action</th>
						</tr>
					</thead>
					<tbody>
						<?php foreach($listBookings AS $listBooking){ ?>
						<tr>
							<td><?php echo $listBooking['booking_id']; ?><br/><?php echo ($listBooking['cancelled'] == 1) ? 'Cancelled' : (($listBooking['amend'] == 1) ? 'Amend' : $listBooking['booking_status']); ?></td>
							<td><?php echo $listBooking['property_guest_name']; ?></td>
							<td><?php echo date("d M", strtotime($listBooking['check_in_date'])); ?><br/><?php echo date("d M", strtotime($listBooking['check_out_date'])); ?></td>
							<td><?php echo $listBooking['no_of_rooms'].'/'.$dataQuery->mealPlanCode[$listBooking['meal_type_code']].'<br/>'.$listBooking['total_adult'].'-'.$listBooking['total_child'].'-'.$listBooking['total_infant']; ?></td>
							<td><?php echo $listBooking['room_type_code']; ?></td>
							<td><?php echo $listBooking['no_of_nights']; ?></td>
							<td><?php echo (($listBooking['arrival_transfer'] == 99) ? 'N/A' : ($dataQuery->transferCode[$listBooking['arrival_transfer']])).'<br/>'.(($listBooking['departure_transfer'] == 99) ? 'N/A' : $dataQuery->transferCode[$listBooking['departure_transfer']]); ?></td>
							<td><?php echo $listBooking['arrival_flight_info'].'<br/>'.$listBooking['departure_flight_info']; ?></td>
							<td class="booking-action">
								<a href="view.php?booking_id=<?php echo $listBooking['booking_id']; ?>" title="View Booking Detail" class="fa fa-fw fa-eye"></a>
								<a href="amend.php?booking_id=<?php echo $listBooking['booking_id']; ?>" title="Amend Booking" class="fa fa-fw fa-pencil-square-o"></a>
								<a href="cancel.php?booking_id=<?php echo $listBooking['booking_id']; ?>" title="Cancel Booking" class="fa fa-fw fa-close"></a></td>
						</tr>
						<?php }?>
					</tbody>
				</table>
            </div>
            </div>
            </div>
          <!-- /.nav-tabs-custom -->
        
        <!-- /.Left col -->
      </div>
      <!-- /.row (main row) -->

    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<script src="<?php echo BASE_URL.'theme/'.THEME_NAME.'/'; ?>plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo BASE_URL.'theme/'.THEME_NAME.'/'; ?>plugins/datatables/dataTables.bootstrap.min.js"></script>
<script>
$(function(){
	$("#example1").DataTable();
});
</script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<?php
include("includes/footer.php");
?>