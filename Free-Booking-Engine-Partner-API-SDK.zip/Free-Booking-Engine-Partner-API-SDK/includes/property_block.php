<div class="col-md-12">	
	<!--div class="panel-heading">
		<span class="search-title"><?php echo $_POST['no_of_rooms'].' room from '.date("D - d M Y", strtotime($_POST['check_in_date'])).' till '.date("D - d M Y", strtotime(' + '.$_POST['no_of_nights'].' day', strtotime($_POST['check_in_date']))).' for '.$_POST['no_of_nights'].' nights'; ?></span>
		<span class="pull-right total-result"></span>
	</div-->
	<?php if(isset($properties->error)) { ?>
		<div class="search-error-msg"><?php echo $properties->error; ?></div>
	<?php } else {?>
	<?php foreach($properties AS $property){ $property_detail = $dataQuery->dbSelectFirst("oh_property", "*", "id=$property->property_id"); ?>
	<div class="result-property-block">
		<div class="col-md-12">
			<div class="col-md-1"><img class="hotel-search-image" src="images/no_image.png" /></div>
			<div class="col-md-11 padding-top-2">
				<div><?php echo $property->property_name; ?></div>
				<div>City: <?php echo $property_detail['city_name']; ?></div>
			</div>
		</div>
		<?php if(isset($property->room_categories->room_category)) { 
			foreach($property->room_categories->room_category AS $room_category) {
				$display_price = $dataQuery->showPrice($room_category->room_rates->room_rate, $_POST['no_of_nights']);
		?>
		<div class="rooms-booking-block">
			<div class="col-md-12 padding-top-10">
				<div class="col-md-4 room-category">
					<div class="adult-child"><?php echo $room_category->room_category_name; ?></div>
				</div>
				<div class="col-md-3">
					<div class="available-calander"><span aria-hidden="true" class="glyphicon glyphicon-calendar"></span>
					<?php echo ($room_category->available) ? 'Available</div><div>Instant Confirm' : 'On Request'; ?></div>
				</div>
				<div class="col-md-2">
					USD <?php echo $display_price; ?>
				</div>
				<div class="col-md-2">
					<button style="width:80px" type="button" id="<?php echo $property->property_id.'|'.$room_category->room_category_code.'|'.$room_category->room_category_name; ?>" class="btn btn-info clicktobookroom"><?php echo ($room_category->available) ? 'Book' : 'Request'; ?></button>
				</div>
			</div>
		</div>
		<?php } }?>
	<div class="clear-both"></div>
	</div>
	<?php } }?>
</div>